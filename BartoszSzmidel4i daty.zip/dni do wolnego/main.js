const przycisk = document.getElementById('przycisk');

const DzienNauczyciela = new Date('2025-10-14');

const DzienNiepodlegosci = new Date('2025-11-11');

const Swieta = new Date('2025-12-22');

const ferie = new Date('2026-02-16');

const wakacje = new Date('2026-06-27');

const display = document.querySelector('main p');

const kalendarz = document.querySelector('#Data');

przycisk.addEventListener('click', function(){
    let DzienWolny = document.getElementById('DzienWolny').value;

    let AktualnaData = new Date();

    let output;

    if (DzienWolny == '14p') {
        let IleDni = Math.floor((DzienNauczyciela - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == '11l') {
        let IleDni = Math.floor((DzienNiepodlegosci - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == '22g') {
        let IleDni = Math.floor((Swieta - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == 'ferie') {
        let IleDni = Math.floor((ferie - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == 'wakacje') {
        let IleDni = Math.floor((wakacje - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni} dni!`;
    } else {
        output = 'Wybierz któryś z dni wolnych!!'
    };

    display.innerText = output
});

kalendarz.addEventListener("change", function(){
    let DzienWolny = document.getElementById('DzienWolny').value;

    let Data = document.querySelector('#Data').value;

    let AktualnaData = new Date();

    let output;

    if (Data != 0){
        AktualnaData = new Date(Data);
    }

    if (DzienWolny == '14p') {
        let IleDni = Math.floor((DzienNauczyciela - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == '11l') {
        let IleDni = Math.floor((DzienNiepodlegosci - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == '22g') {
        let IleDni = Math.floor((Swieta - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == 'ferie') {
        let IleDni = Math.floor((ferie - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni}!`;
    } else if (DzienWolny == 'wakacje') {
        let IleDni = Math.floor((wakacje - AktualnaData)/86400000);

        output = `Zostało jeszcze ${IleDni} dni!`;
    } else {
        output = 'Wybierz któryś z dni wolnych!!'
    };

    display.innerText = output
});