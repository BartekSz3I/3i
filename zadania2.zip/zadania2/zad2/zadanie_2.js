const przycisk_clear = document.getElementById('clearBtn');

const przycisk_validate = document.getElementById('validateBtn');

const wyniki = document.getElementById('results');

const biale_znaki = document.getElementById('trimmed');

const malpa = document.getElementById('hasAt');

const pierwsza_litera = document.getElementById('startsLetter');

const domena = document.getElementById('endsDomain');

const czesc_usera = document.getElementById('localPart');

const czesc_domeny = document.getElementById('domainPart');

const zamiana_kropek = document.getElementById('domainReplaced');

let input = '';


przycisk_validate.addEventListener('click', function(){

    input = document.getElementById('email').value;


    if (input.includes('@')) {

        wyniki.style.display = 'block';
        
        biale_znaki.innerText = `"${input.trim()}"`;

        malpa.innerText = "TAK";
        
        if (input.trim().charAt(0) >= 'a' && input.trim().charAt(0) <= 'z' || input.trim().charAt(0) >= 'A' && input.trim().charAt(0) <= 'Z'){
            
            pierwsza_litera.innerText = 'TAK';
        
        } else {

            pierwsza_litera.innerText = 'NIE';
        };

        if (input.trim().endsWith('.com') || input.trim().endsWith('.pl')){
            domena.innerText = 'TAK';
        } else {
            domena.innerText = 'NIE';
        }

        let czesci_adresu = input.split('@');

        czesc_usera.innerText = `${czesci_adresu[0]}`;
        czesc_domeny.innerText = `${czesci_adresu[1]}`;

        zamiana_kropek.innerText = `${czesci_adresu[1].replace(/\./g,"-")}`;


    } else {
        wyniki.style.display = 'block';
        wyniki.innerText = 'Podałeś niepoprawny adres email lub nie podałeś go wcale';
    }

    przycisk_clear.addEventListener('click', function() {
        input = '';

        wyniki.style.display = 'none';
    });

});