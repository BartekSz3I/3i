# Zadanie 5 - System Krytycznej Notyfikacji

## Cel zadania
Wprowadzenie restrykcji by zapobiec przesłaniu nieprecyzyjnie zaewidencjonowanej zgłoszenia do bazy incydentów powierzonego podmiotu technicznego.

## Wymagania
1. Rozmówca składa relację błędu wraz ze składowym podaniem wydziału.
2. Przy woli zażądania wpisu następuje przerwanie procesowe (wstrzymanie silnika silnika przegladarki przed re-loadem).
3. Oprogramowanie lustruje dwa szczegóły: Treść incydentu zakłada długość na przekroczenie powyżej 10 znaków precyzyjnego poślizgu klawiaturalnego; Natywnie pole departamentowe nie ukrywa się w domyślnym "brak".
4. Lista niepowodzeń rzucona pod rubryki za weryfikatorem o uchybieniu. Sukces puszcza notę finalnej uciechy w stylu zielonego optymizmu.

## Dostosowania:
- Anuluj standardowy tryb wysyłki 'submit'.
- Dokonaj ewaluacji wartości atrybutu length usterki oraz wymiaru zawartości z wyboru strefy.
- Wynik ma charakter łańcuchowy (jedno lub dwa naruszenia obok siebie pod spodem zgłoszenia we wskazanym rejonie).