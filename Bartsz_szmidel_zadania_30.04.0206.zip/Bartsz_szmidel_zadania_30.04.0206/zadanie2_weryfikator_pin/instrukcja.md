# Zadanie 2 - Rygor Autentykatora

## Cel zadania
Przy wywoływaniu procesu autentykacji PIN użytkownik ma być informowany o prawidłowości formy bezwłocznie używając mechanizmów powiadamiania.

## Wymagania
1. Odczyt jest prowadzony już w mgnieniu dokonywania uzupełnienia wejściowego (gdy wpada wyraz / literka).
2. Określenie wymaga restrykcyjnej długości wynoszącej odpowiednio: cykl weryfikacyjny zezwala wyłącznie na pułap 6 styków tekstu. Mniej lub więcej oznacza błąd.
3. Przy braku precyzyjnego spełnienia kryterium przekaż negację faktu (komunikat "Zła długość" jaskrawo widoczny), w momencie optymalnym zweryfikuj fakt na zielono ("Długość OK").

## Dostosowania:
- Złap na żywo zdarzenie wpisywania liter do pola.
- Oblicz obiektywną wielkość zbioru wpisywanych znaków.
- Jeżeli cyfra wynosi absolutnie równo 6 to komunikat wyświetla co trzeba w kolorze zieleni, jeżeli jakkolwiek inaczej to w czerwieni alarmuje.