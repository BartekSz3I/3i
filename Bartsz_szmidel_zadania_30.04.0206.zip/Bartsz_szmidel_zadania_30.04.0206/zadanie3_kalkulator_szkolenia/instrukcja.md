# Zadanie 3 - Wyliczanie Czesnego

## Cel zadania
Proces decyzyjny przy nabyciu szkolenia on-line modyfikuje ostateczną wymowną zapłatę w panelu klienta dla księgowości.

## Wymagania
1. Algorytm włączony jest bezwarunkowo, odnotowuje na zgięciach procesów użytkownika (zmiana puli wyboru).
2. Na każdym stopniu ewentualnej perturbacji wyborów weryfikator przebiega cykl.
3. Koszta: Poziom Początkujący: 200zł, Średniozaawansowany: 450zł. Doposażenie (opcja wymiernie potwierdzana np. drukowanym papierowym dyplomem pobieranym w placówce) to taryfa 45zł.
4. Zapłata podlega edycji natychmiastowej po zdarzeniu na ekranie w dole panelu wpłat.

## Dostosowania:
- Akcja następuje "on-change", czyli bez guzika akceptacji, ale na bazie wpółdziałania z wyborem i włącznikiem.
- Odczyt wartości bazy następuje ze słownika option.
- Dopłata 45zł jest łączona tylko jeśli włącznik jest faktem pozytywnym.