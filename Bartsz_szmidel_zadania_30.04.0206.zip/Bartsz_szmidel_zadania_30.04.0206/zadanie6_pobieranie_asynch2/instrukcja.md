# Zadanie 6 - Konwojowanie Pobierania

## Cel zadania
Współpraca z opóźnioną usługą raportującą i udostępnienie mechaniki ładowania tak, by uniemożliwić zakłócenie harmonogramów (dwukrotny wcisk).

## Wymagania
1. Rozmówca pragnie załadowania dziennego protokołu do swojego klienta kliencją.
2. Przy rzucie żądania akcją przycisku zrywa na nim włącznik (deaktywacja włączności), z informacją uboczną w obiekcie, iż operacja przejęcia biega po łączach ("Zapisuję dane...").
3. Czekamy okres miary trzech pełnych obrotów sekundnika po czym zapada kurtyna powrotów, oddając chęć na sukces pobrania poprzez tekst "Utworzono prawidłowy bilans".

## Dostosowania:
- Zaimplantuj zmianę wizji interfejsu (deaktywacja) oraz adekwatny string na poczekaniu.
- Blok czasowy za pomocą wbudowanej struktury opóźniającej - 3000.
- Reset do stanu sukcesu i reaktywacja guzika (pozwolenie na użycie) nastąpi po wygaszeniu ustronnym oczekiwania.