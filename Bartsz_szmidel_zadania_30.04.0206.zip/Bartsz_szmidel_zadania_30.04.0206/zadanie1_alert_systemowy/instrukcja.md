# Zadanie 1 - Alert Konfiguracji

## Cel zadania
Zaprogramuj interaktywny element informujący (top-bar alert) na zapleczu administracyjnym z opcją potwierdzenia faktu i zgaszenia światła.

## Wymagania
1. Interfejs prezentuje z góry wyeksponowane poświadczenie o potrzebie zmiany hasła, a obok niego umiejscowiony symbol X (guzik do kasacji komunikatu).
2. Gwarantuj skuteczną akcję wyparcia wspomnianego boksu tak by stał się elementem niebiorącym uwagi.
3. Zaraz po ewaporacji bazy wykreuj nową odpowiedź dla oka obok lub w puste miejsce ("Ostrzeżenie usunięto z sesji") - na trzy sekundy długości, po czym ma zblednąć lub zaginąć.

## Dostosowania:
- Ukryj główny powiadamiacz.
- Ustaw nową zawartość do innego pola i zarządz zdarzeniem opóźniającym usunięcie tekstu na 3 sekundy.