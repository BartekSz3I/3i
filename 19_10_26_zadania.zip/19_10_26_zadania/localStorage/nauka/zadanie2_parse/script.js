// Twoje rozwiazanie

const display = document.querySelector('#wynik');

const btn = document.querySelector('#parsuj');

const pole = document.querySelector('#json').value;

btn.addEventListener('click', function(){

    try {
        const obj = JSON.parse(pole);

        display.textContent = obj;
      } catch (e) {
        display.textContent = "Niepoprawny JSON";
      }
    
})