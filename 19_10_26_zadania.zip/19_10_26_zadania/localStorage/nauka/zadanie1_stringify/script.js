// Twoje rozwiazanie

const produkt = { nazwa: "Mleko 2%", cena: 3.5 };

const napis = JSON.stringify(produkt);

const button = document.querySelector('#pokaz');

const display = document.querySelector('#wynik');


button.addEventListener('click', function(){

    display.textContent = napis;
})

