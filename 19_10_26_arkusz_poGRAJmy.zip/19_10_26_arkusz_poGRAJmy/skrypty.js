function licznik_funkcja() {

    if (localStorage.getItem('wyswietlenia') == null){
        localStorage.setItem('wyswietlenia', 1);
    } else {
        let liczba_wyswietlen = parseInt(localStorage.getItem('wyswietlenia'));
        liczba_wyswietlen += 1;
        localStorage.setItem('wyswietlenia', liczba_wyswietlen);
    }
    const licznik = document.querySelector('#licznik');
    licznik.textContent = `Liczba wejść na stronę: ${localStorage.getItem('wyswietlenia')}`;
}

licznik_funkcja();