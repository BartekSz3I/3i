// Twoje rozwiazanie


const ksiazki = [
    {tytul: 'Lalka', autor: 'Bolesław Prus', rok: '1890'},
    {tytul: 'Pan Tadeusz', autor: 'Adam Mickiewicz', rok: '1834'},
];

const tbody = document.querySelector('#tableBody');
tbody.textContent = '';

for (let i = 0; i < ksiazki.length; i++) {

    const tr = document.createElement('tr');

    const td1 = document.createElement('td');
    const td2 = document.createElement('td');
    const td3 = document.createElement('td');

    

    td1.textContent = ksiazki[i].tytul;
    td2.textContent = ksiazki[i].autor;
    td3.textContent = ksiazki[i].rok;

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);

    tbody.appendChild(tr);
}