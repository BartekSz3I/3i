// Twoje rozwiazanie

const pokaz = document.querySelector('#opisBtn');

const display = document.querySelector('#wynik');

const ksiazka ={
    autor: 'Adam Mickiewicz',
    tytul: 'Pan Tadeusz',
    karta: function (){
        return this.tytul + '-' + this.autor;
    }
};

pokaz.addEventListener('click', function(){
    
    display.textContent = ksiazka.karta();
})