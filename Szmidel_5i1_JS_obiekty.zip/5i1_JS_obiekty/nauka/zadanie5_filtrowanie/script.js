// Twoje rozwiazanie

const lista_html = document.querySelector('#lista');

const wszystkie = document.querySelector('#wszystkie');

const dostepne = document.querySelector('#tylkoDostepne');

const produkty = [
    {nazwa: 'Mleko'},
    {nazwa: 'Chleb'},
    {nazwa: 'Masło'},
];

function wypisz(lista){
    for (let i = 0; i < produkty.length; i++){
        const li = document.createElement('li');

        li.textContent = produkty[i].nazwa;
        
        lista_html.appendChild(li);
    }
};

wypisz(produkty);