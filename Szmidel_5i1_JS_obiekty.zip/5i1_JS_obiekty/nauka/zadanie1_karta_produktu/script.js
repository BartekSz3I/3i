// Twoje rozwiazanie

const produkt = {
    nazwa: 'Mleko 2%', 
    cena: '3.5 zł', 
    stan: '12 szt.',
};

const pole_nazwa = document.querySelector('#nazwa');
const pole_cena = document.querySelector('#cena');
const pole_stan = document.querySelector('#stan');
const pokaz = document.querySelector('#pokaz');

pokaz.addEventListener('click', function(){

    pole_nazwa.textContent = produkt.nazwa;

    pole_cena.textContent = produkt.cena;

    pole_stan.textContent = produkt.stan;

})