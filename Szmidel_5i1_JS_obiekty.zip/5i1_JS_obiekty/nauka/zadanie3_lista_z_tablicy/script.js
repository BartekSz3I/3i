// Twoje rozwiazanie


const lista = document.querySelector('#lista');

const produkt = [
    {nazwa: 'Mleko'},
    {nazwa: 'Chleb'},
    {nazwa: 'Masło'},
];

const ul = document.createElement('ul');



for (let i = 0; i < produkt.length; i++) {

    const li = document.createElement('li');
    li.textContent = produkt[i].nazwa;
    ul.appendChild(li);
};

lista.appendChild(ul);