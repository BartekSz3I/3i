# Pomoc krótka ogólna: Obliczenia i formatowanie dat

Szybka ściąga i przewodnik po strukturze plików dla modułu **T10: Obliczenia i formatowanie dat**.

---

## 1. Struktura folderów i tryb pracy

W każdym zadaniu praktycznym pracujesz w dedykowanym folderze zadania:

| Element | Lokalizacja | Przeznaczenie |
|:---|:---|:---|
| **Pliki startowe zadania** | `zadanieX_.../` (`index.html`, `style.css`, `script.js`) | Tutaj samodzielnie piszesz rozwiązanie, uzupełniając kod oznaczony jako `// Twoje rozwiazanie`. |
| **Instrukcja do zadania** | `zadanieX_.../instrukcja.md` | Dokładne wytyczne, wymagania funkcjonalne i treść do wpisania na stronę. |
| **Katalog rozwiązania** | `zadanieX_.../rozwiazanie/` | Wzorcowy, w 100% działający kod referencyjny do weryfikacji po własnej próbie. |

*Uwaga: W generatorze nie występuje katalog o nazwie szkielet — pracujesz bezpośrednio na plikach w głównym katalogu zadania.*

---

## 2. Podręczna ściąga składniowa (Cheat Sheet)

### Tworzenie daty ze składowymi
```javascript
// new Date(rok, miesiacOdZera, dzien, godzina, minuta, sekunda)
const termin = new Date(2026, 9, 25, 14, 30); // 25 października 2026, 14:30
```

### Modyfikacja składowych i przesunięcia w czasie (Rollover)
```javascript
const data = new Date(2026, 9, 20);
data.setDate(data.getDate() + 15); // Automatycznie przeskakuje na listopad!
data.setMonth(data.getMonth() + 24); // +24 miesiące (przeskok roku)
data.setFullYear(data.getFullYear() + 1); // +1 rok
data.setHours(data.getHours() + 48); // Dodanie 48 godzin do terminu
```

### Znaczniki czasu i różnica w milisekundach
```javascript
const start = new Date(2026, 9, 1);
const koniec = new Date(2026, 9, 10);

const roznicaMs = koniec.getTime() - start.getTime(); // Lub: koniec - start
```

### Stałe przeliczeniowe do dekompozycji czasu
```javascript
const MS_DZIEN = 1000 * 60 * 60 * 24; // 86 400 000 ms
const MS_GODZINA = 1000 * 60 * 60;     // 3 600 000 ms
const MS_MINUTA = 1000 * 60;           // 60 000 ms

const dni = Math.floor(roznicaMs / MS_DZIEN);
const godziny = Math.floor((roznicaMs % MS_DZIEN) / MS_GODZINA);
const minuty = Math.floor((roznicaMs % MS_GODZINA) / MS_MINUTA);
```

### Formatowanie z zerem wiodącym (`padStart`)
```javascript
const dzien = String(data.getDate()).padStart(2, "0");
const miesiac = String(data.getMonth() + 1).padStart(2, "0"); // +1 dla miesiąca!
const rok = data.getFullYear();
const sformatowanaData = `${rok}-${miesiac}-${dzien}`;
```

### Kwota z dwoma miejscami po przecinku
```javascript
const kwotaTekst = (dniSpoznienia * 2.5).toFixed(2); // np. "20.00"
```

### Klonowanie daty przed modyfikacją
```javascript
const kopia = new Date(oryginal.getTime());
kopia.setDate(kopia.getDate() + 7);
```

---

## 3. Identyfikatory i kontrakt Kamienia Milowego (Zadanie 5 Capstone)

W Zadaniu 5 (*Portal Usługowo-Handlowy IT-Partner*) obowiązuje ścisły kontrakt wyjścia i zachowanie ciągłości logicznej:
- Główny element wyjścia danych w DOM: `#wynik` (znacznik z klasą lub identyfikatorem obsługującym `white-space: pre-wrap`).
- Wypis wyłącznie za pomocą właściwości `textContent`:
  ```javascript
  document.getElementById("wynik").textContent = raportKoncowy;
  ```
- Obowiązkowe funkcjonalności przyrostowe:
  1. Wyznaczenie terminu realizacji (deadline) za pomocą modyfikacji `setDate()` na **kopii** daty zgłoszenia.
  2. Obliczenie różnicy czasu między terminem SLA a **chwilą bieżącą** (`new Date()`) oraz dekompozycja milisekund.
  3. Badanie statusu terminowości (czy termin upłynął względem „teraz”).
  4. Sformatowanie podsumowania czasowego z zerami wiodącymi `padStart(2, "0")`.

---

## 4. Szybkie przypomnienie (Dobre praktyki pracy)

1. **Konsola DevTools (F12)**: Zawsze miej otwartą kartę *Console* w przeglądarce podczas testowania skryptów — czerwony komunikat natychmiast wskaże numer linii z błędem składni lub literówką w nazwie zmiennej.
2. **Podgląd w przeglądarce**: Otwieraj plik `index.html` bezpośrednio przez protokół plikowy (`file:///...`) lub lokalny serwer testowy (np. Live Server w VS Code).
3. **Miesiące liczone od 0**: Zawsze pamiętaj: `0` to styczeń, `9` to październik, a `11` to grudzień. Dodawaj `+ 1` tylko przy prezentacji daty dla użytkownika!
4. **Typowanie w padStart**: Metoda `.padStart()` działa wyłącznie na napisach. Zawsze konwertuj liczbę przed formatowaniem: `String(liczba).padStart(2, "0")`.
5. **Rygor wyjścia**: W semestrze 2 nie używamy `document.write` ani `innerHTML`. Wszystkie komunikaty kierujemy do `document.getElementById("wynik").textContent`.
