# Pomoc dostępna: Obliczenia i formatowanie dat w JavaScript

Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

---

## 1. Słowniczek pojęć tego działu

- **Obiekt Date** — wbudowane w JavaScript narzędzie przechowujące informację o konkretnym punkcie w czasie, zawierające rok, miesiąc, dzień, godzinę, minutę i milisekundę.
- **Indeks miesiąca** — sposób numerowania miesięcy w JavaScript, gdzie styczeń to liczba 0, luty to 1, a grudzień to 11.
- **Metoda setDate()** — polecenie zmieniające dzień miesiąca w obiekcie daty.
- **Przepełnienie (Rollover)** — automatyczny mechanizm języka JavaScript, który przeskakuje do następnego miesiąca, jeśli dodasz do daty zbyt dużą liczbę dni.
- **Znacznik czasu (Timestamp / getTime)** — pojedyncza liczba określająca liczbę milisekund, które upłynęły od 1 stycznia 1970 roku.
- **Metoda padStart()** — polecenie tekstowe, które dodaje znak (np. cyfrę 0) na początku napisu, dopóki napis nie osiągnie określonej długości.
- **SLA (Termin zlecenia)** — ustalony czas, w którym usługa lub naprawa musi zostać zrealizowana.

---

## 2. Stały porządek pracy nad każdym zadaniem

Aby poprawnie i spokojnie wykonać każde ćwiczenie, wykonuj poniższe kroki dokładnie w podanej kolejności:

1. Otwórz plik `instrukcja.md` znajdujący się w folderze danego zadania i przeczytaj wymagania.
2. Zwróć szczególną uwagę na sekcję zatytułowaną „Treść do wpisania”, w której podano dokładne teksty i komunikaty.
3. Otwórz plik `script.js` w swoim edytorze kodu.
4. Odszukaj w kodzie komentarz `// Twoje rozwiazanie`.
5. Wpisz swój kod dokładnie pod tym komentarzem, nie kasując pozostałych fragmentów pliku.
6. Zapisz plik za pomocą skrótu klawiszowego `Ctrl + S`.
7. Otwórz plik `index.html` w przeglądarce internetowej i sprawdź, czy wynik pojawił się w polu o identyfikatorze `wynik`.
8. Naciśnij klawisz `F12` w przeglądarce i przejdź do zakładki *Konsola*, aby upewnić się, że nie ma tam czerwonych błędów.
9. Po samodzielnej próbie wykonania zadania możesz otworzyć plik w folderze `rozwiazanie/` i porównać swój kod z rozwiązaniem wzorcowym.

---

## 3. Instrukcja krok po kroku: Jak przesunąć datę o kilka dni

1. Jeśli masz już obiekt daty i nie chcesz go zniszczyć, najpierw zrób kopię:
   ```javascript
   const data = new Date(dataStartu.getTime());
   ```
2. Pobierz bieżący dzień za pomocą `data.getDate()`.
3. Dodaj wymaganą liczbę dni i zapisz wynik za pomocą `data.setDate()`:
   ```javascript
   data.setDate(data.getDate() + 7);
   ```
4. JavaScript sam zmieni miesiąc, jeśli liczba dni przekroczy koniec miesiąca.
5. Analogicznie działają `setHours(...)`, `setFullYear(...)` i `setMonth(...)` — ta sama zasada przepełnienia.

---

## 4. Instrukcja krok po kroku: Jak obliczyć różnicę czasu w dniach

1. Pobierz znaczniki czasu obu dat za pomocą metody `getTime()`:
   ```javascript
   const czasStart = dataPoczatkowa.getTime();
   const czasKoniec = dataKoncowa.getTime();
   ```
2. Odejmij czas początkowy od czasu końcowego, aby otrzymać milisekundy:
   ```javascript
   const roznicaMs = czasKoniec - czasStart;
   ```
3. Podziel otrzymaną liczbę przez liczbę milisekund w dobie (`86400000`):
   ```javascript
   const pelneDni = Math.floor(roznicaMs / (1000 * 60 * 60 * 24));
   ```
4. Wynik przypisz do tekstu wyjściowego.

---

## 5. Instrukcja krok po kroku: Jak dodać zero wiodące (format dwucyfrowy)

1. Pobierz wartość liczbową (np. dzień miesiąca):
   ```javascript
   const dzienLiczba = data.getDate();
   ```
2. Zamień liczbę na tekst za pomocą funkcji `String()`:
   ```javascript
   const dzienTekst = String(dzienLiczba);
   ```
3. Użyj metody `padStart(2, "0")`:
   ```javascript
   const dzienDwucyfrowy = dzienTekst.padStart(2, "0");
   ```
4. Złącz przygotowane części w jeden łańcuch:
   ```javascript
   const wynik = `Data: ${dzienDwucyfrowy}`;
   ```

---

## 6. Instrukcja krok po kroku: Jak zapisać kwotę z dwoma miejscami po przecinku

1. Oblicz kwotę jako liczbę (np. `dni * 2.5`).
2. Wywołaj na wyniku metodę `toFixed(2)` — otrzymasz napis, np. `"20.00"`.
3. Wstaw napis do raportu razem z jednostką (`" zł"`).

---

## 7. Proste zasady dostępności cyfrowej (a11y) w tym module

1. Wszystkie generowane teksty muszą mieć wyraźny kontrast z tłem (ciemny tekst na jasnym tle lub jasny na ciemnym).
2. Wynik prezentowany w elemencie `#wynik` powinien być sformułowany prostym, pełnym zdaniem, a nie tylko ciągiem liczb.
3. Jeśli w zadaniu pojawia się polecenie wprowadzenia danych, komunikat w `prompt()` musi jednoznacznie wyjaśniać oczekiwany format (np. „Podaj liczbę dni (np. 5):”).
