# Zadanie 1: Obliczanie terminu zwrotu sprzętu z automatyczną normalizacją kalendarza

## Cel
Celem zadania jest utworzenie funkcji obliczającej termin zwrotu wypożyczonego sprzętu budowlanego na podstawie daty początkowej oraz liczby dni najmu, z wykorzystaniem wbudowanej metody `setDate()` i mechanizmu automatycznego przepełnienia miesiąca.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Systemy e-commerce wyliczające prognozowaną datę doręczenia paczki kurierskiej (np. „Zamów w ciągu 2 godzin, dostawa w piątek”).
- Wypożyczalnie samochodów kalkulujące datę i godzinę zwrotu pojazdu przy rezerwacji wielodniowej.
- Portale biblioteczne wyznaczające automatyczny 30-dniowy termin oddania wypożyczonych książek.

## Wskazówki aktywizujące
- Przejrzyj rozdział 3 w pliku `teoria.md` („Modyfikacja składowych daty i mechanizm przepełnienia”) oraz rozdział 7 (`padStart` — format `RRRR-MM-DD`).
- Przy klonowaniu daty startowej skorzystaj ze wzorca z rozdziału 6: `new Date(dataStartu.getTime())`, aby nie nadpisać oryginału.
- Zastanów się: dlaczego nie musisz pisać instrukcji `if`, aby sprawdzić, czy dodanie 10 dni do 25 października przekroczy długość miesiąca?
- Sprawdź w konsoli przeglądarki polecenie: `const d = new Date(2026, 9, 25); d.setDate(d.getDate() + 10); console.log(d.toLocaleDateString());`.

## Treść do wpisania
W skrypcie wykorzystaj następujące dosłowne teksty i komunikaty:
- Komunikat w oknie dialogowym prompt: `"Podaj liczbę dni wypożyczenia sprzętu budowlanego:"` z wartością domyślną `"7"`.
- Nagłówek zestawienia: `"=== WYPOŻYCZALNIA SPRZĘTU BUDOWLANEGO MAJSTER-BUD ==="`.
- Etykieta sprzętu: `"Wypożyczony sprzęt: Agregat prądotwórczy 5.5 kW"`.
- Etykieta daty wydania: `"Data wydania sprzętu: 2026-10-24"`.
- Etykieta liczby dób: `"Liczba dób najmu: "` (uzupełniona o liczbę dni podaną przez użytkownika).
- Etykieta terminu zwrotu: `"Wyliczony termin zwrotu: "` (uzupełniony o wyznaczoną datę w formacie `RRRR-MM-DD`).
- Komunikat regulaminowy: `"Zwrot po godzinie 17:00 skutkuje naliczeniem kolejnej doby najmu."`.

## Wymagania
1. Zadeklaruj funkcję `obliczTerminZwrotu(dataStartu, liczbaDni)`, która:
   - Tworzy nową instancję `Date` na podstawie znacznika czasu przekazanego obiektu `dataStartu` (klonowanie daty).
   - Zwiększa dzień miesiąca o wartość `liczbaDni` za pomocą `setDate(kopiaDaty.getDate() + liczbaDni)`.
   - Zwraca sformatowany ciąg w formacie `RRRR-MM-DD`, korzystając z `getFullYear()`, `getMonth() + 1` oraz `getDate()` z uzupełnieniem zerami wiodącymi przez `padStart(2, "0")`.
2. Poza ciałem funkcji pobierz liczbę dni od użytkownika za pomocą funkcji `prompt()`, przekazując treść pytania oraz wartość domyślną `"7"`. Skonwertuj pobraną wartość na liczbę za pomocą `Number()` lub `parseInt()`.
3. Przygotuj datę wydania sprzętu: 24 października 2026 r. (`new Date(2026, 9, 24)`).
4. Wygeneruj pełny raport tekstowy i wypisz go do elementu o identyfikatorze `wynik` za pomocą właściwości `textContent`.

## Przykład
Stan początkowy:
Użytkownik uruchamia stronę i akceptuje domyślną wartość `7` w oknie `prompt`.

Efekt na ekranie w elemencie `#wynik`:
```text
=== WYPOŻYCZALNIA SPRZĘTU BUDOWLANEGO MAJSTER-BUD ===

Wypożyczony sprzęt: Agregat prądotwórczy 5.5 kW
Data wydania sprzętu: 2026-10-24
Liczba dób najmu: 7
Wyliczony termin zwrotu: 2026-10-31

Zwrot po godzinie 17:00 skutkuje naliczeniem kolejnej doby najmu.
```
*(Uwaga: w przypadku podania 10 dni, termin zwrotu automatycznie przeskoczy na `2026-11-03`)*.
