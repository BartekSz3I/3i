/**
 * Zadanie 1: Obliczanie terminu zwrotu sprzętu z automatyczną normalizacją kalendarza
 * Szablon startowy dla ucznia
 */

// 1. Zadeklaruj funkcję obliczającą termin zwrotu
function obliczTerminZwrotu(dataStartu, liczbaDni) {
  // Twoje rozwiazanie
  // Krok 1: Sklonuj obiekt daty początkowej (new Date(...))
  // Krok 2: Użyj metody setDate() dodając liczbę dni najmu
  // Krok 3: Sformatuj datę do postaci RRRR-MM-DD z padStart(2, "0") i zwróć wynik
}

// 2. Pobierz liczbę dni od użytkownika za pomocą prompt z wartością domyślną "7"
const dniWejsciowe = prompt("Podaj liczbę dni wypożyczenia sprzętu budowlanego:", "7");
const liczbaDni = parseInt(dniWejsciowe, 10) || 7;

// 3. Zdefiniuj datę wydania sprzętu: 24 października 2026 r.
const dataWydania = new Date(2026, 9, 24);

// 4. Wywołaj funkcję, zbuduj raport i wypisz do elementu #wynik
// Twoje rozwiazanie
