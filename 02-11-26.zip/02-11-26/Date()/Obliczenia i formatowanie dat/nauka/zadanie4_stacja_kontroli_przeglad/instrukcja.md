# Zadanie 4: Zintegrowany system weryfikacji ważności okresowych badań technicznych

## Cel
Celem zadania jest zbudowanie zintegrowanego modułu weryfikacji okresowych badań technicznych pojazdów, łączącego w spójnej procedurze modyfikację składowych daty (przesunięcie o rok), obliczenie różnicy czasu w milisekundach, dekompozycję na dni i godziny, logikę badania ważności oraz formatowanie tekstu z zerami wiodącymi i tablicą lookup.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Systemy CEPiK i stacji kontroli pojazdów generujące powiadomienia SMS o zbliżającym się terminie badania technicznego.
- Flotowe systemy telemetryczne monitorujące ważność polis ubezpieczeniowych OC/AC i przeglądów gwarancyjnych.
- Panele administracyjne infrastruktury serwerowej wyliczające czas wygaśnięcia certyfikatów SSL/TLS.

## Wskazówki aktywizujące
- Przeanalizuj zagadnienia z zadań 1, 2 i 3 oraz sekcje 3, 5 i 7 z pliku `teoria.md`.
- Zastanów się: jak za pomocą metody `setFullYear()` wydłużyć ważność badania dokładnie o 1 rok bez ręcznego modyfikowania dnia i miesiąca?
- Przetestuj w konsoli: `const t = new Date(2025, 9, 15); t.setFullYear(t.getFullYear() + 1); console.log(t.toISOString());`.

## Treść do wpisania
W skrypcie wykorzystaj następujące dosłowne teksty i komunikaty:
- Nagłówek raportu: `"=== STACJA KONTROLI POJAZDÓW MOTO-TEST — AUDYT TECHNICZNY ==="`.
- Etykieta pojazdu: `"Identyfikator pojazdu: Samochód dostawczy (VIN: VF1MA000358921)"`.
- Etykieta daty badania: `"Data wykonania ostatniego badania: 2025-10-15"`.
- Etykieta terminu ważności: `"Termin ważności badania (rok od badania): "` (uzupełniona o datę w formacie słownym z polskim miesiącem).
- Etykieta daty kontroli: `"Data bieżącej kontroli drogowej: 2026-10-28"`.
- Status nieważny: `"STATUS: BRAK WAŻNEGO BADANIA TECHNICZNEGO — ZAKAZ DALSZEJ JAZDY"`.
- Status ważny: `"STATUS: BADANIE TECHNICZNE WAŻNE — POJAZD DOPUSZCZONY DO RUCHU"`.
- Etykieta różnicy czasu: `"Różnica względem terminu ważności: "` — uzupełnij jedną z fraz:
  - po terminie: `"X dni, Y godz. po terminie"` (np. `"12 dni, 10 godz. po terminie"`),
  - przed terminem: `"Pozostało X dni, Y godz. ważności"`.
- Podsumowanie: `"Kierujący pojazdem bez ważnego badania technicznego podlega zatrzymaniu dowodu rejestracyjnego."`.

## Wymagania
1. Zdefiniuj słownik lookup nazw miesięcy w języku polskim:
   `const NAZWY_MIESIECY = ["stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września", "października", "listopada", "grudnia"];`
2. Zadeklaruj funkcję `wyznaczWaznoscBadania(dataBadania)`, która:
   - Klonuje przekazaną datę (`new Date(dataBadania.getTime())`).
   - Modyfikuje rok o 1 w przód za pomocą `kopia.setFullYear(kopia.getFullYear() + 1)`.
   - Zwraca wyznaczony termin ważności.
3. Zadeklaruj funkcję `audytujBadanieTechniczne(dataWaznosci, dataKontroli)`, która:
   - Oblicza różnicę milisekund między `dataKontroli` a `dataWaznosci`.
   - Sprawdza warunek: jeśli data kontroli jest późniejsza niż data ważności, oblicza liczbę pełnych dni i godzin opóźnienia:
     - `dni = Math.floor(roznicaMs / (1000 * 60 * 60 * 24))`
     - `godziny = Math.floor((roznicaMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))`
     - Zwraca status negatywny oraz frazę różnicy w postaci `"X dni, Y godz. po terminie"`.
   - W przeciwnym razie oblicza pozostały czas (`Math.abs`) i zwraca status pozytywny oraz frazę `"Pozostało X dni, Y godz. ważności"`.
4. Zadeklaruj funkcję pomocniczą `formatujDateSlownie(data)`, która zwraca napis w formacie: `DD [nazwaMiesiąca] RRRR r.` z uzupełnieniem dnia zerem wiodącym przez `padStart(2, "0")`.
5. Zdefiniuj w kodzie:
   - Datę ostatniego badania: 15 października 2025 r. (`new Date(2025, 9, 15)`).
   - Datę kontroli drogowej: 28 października 2026 r. (`new Date(2026, 9, 28, 10, 30)`).
6. Wygeneruj spójny raport zawierający wszystkie wymagane komunikaty i wypisz go do kontenera `#wynik` za pomocą właściwości `textContent`.

## Przykład
Stan początkowy:
Aplikacja wczytuje dane przeglądu i daty kontroli z pamięci skryptu.

Efekt na ekranie w elemencie `#wynik`:
```text
=== STACJA KONTROLI POJAZDÓW MOTO-TEST — AUDYT TECHNICZNY ===

Identyfikator pojazdu: Samochód dostawczy (VIN: VF1MA000358921)
Data wykonania ostatniego badania: 2025-10-15
Termin ważności badania (rok od badania): 15 października 2026 r.
Data bieżącej kontroli drogowej: 2026-10-28
Różnica względem terminu ważności: 12 dni, 10 godz. po terminie
STATUS: BRAK WAŻNEGO BADANIA TECHNICZNEGO — ZAKAZ DALSZEJ JAZDY

Kierujący pojazdem bez ważnego badania technicznego podlega zatrzymaniu dowodu rejestracyjnego.
```
