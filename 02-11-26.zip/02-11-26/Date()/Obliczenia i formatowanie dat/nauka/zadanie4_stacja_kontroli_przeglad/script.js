/**
 * Zadanie 4: Zintegrowany system weryfikacji ważności okresowych badań technicznych
 * Szablon startowy dla ucznia
 */

// 1. Słownik pomocniczy polskich nazw miesięcy
const NAZWY_MIESIECY = [
  "stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca",
  "lipca", "sierpnia", "września", "października", "listopada", "grudnia"
];

// 2. Funkcja wyznaczająca termin ważności badania (rok naprzód)
function wyznaczWaznoscBadania(dataBadania) {
  // Twoje rozwiazanie
  // Krok: Sklonuj obiekt i użyj setFullYear(kopia.getFullYear() + 1)
}

// 3. Funkcja formatująca datę w postaci słownej: DD nazwaMiesiąca RRRR r.
function formatujDateSlownie(data) {
  // Twoje rozwiazanie
  // Krok: Wykorzystaj padStart(2, "0") dla dnia oraz słownik NAZWY_MIESIECY dla miesiąca
}

// 4. Funkcja audytująca termin badania technicznego
function audytujBadanieTechniczne(dataWaznosci, dataKontroli) {
  // Twoje rozwiazanie
  // Krok: Wylicz różnicę ms, sprawdź znak i przelicz na pełne dni i godziny
}

// 5. Dane wejściowe: data badania oraz data kontroli drogowej
const badanieTechniczne = new Date(2025, 9, 15);
const kontrolaDrogowa = new Date(2026, 9, 28, 10, 30);

// 6. Wywołanie funkcji, integracja raportu i wypis do #wynik
// Twoje rozwiazanie
