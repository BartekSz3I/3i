/**
 * Zadanie 2: Obliczanie różnicy czasu i liczby dób pobytu
 * Szablon startowy dla ucznia
 */

// 1. Zadeklaruj funkcję obliczającą liczbę dób między dwiema datami
function obliczDobyPobytu(dataStart, dataKoniec) {
  // Twoje rozwiazanie
  // Krok 1: Pobierz znaczniki czasu w ms obu dat metodą getTime()
  // Krok 2: Odejmij czas początkowy od końcowego
  // Krok 3: Podziel różnicę przez (1000 * 60 * 60 * 24) i zaokrąglij w dół za pomocą Math.floor()
}

// 2. Przygotuj daty zameldowania i wymeldowania
const zameldowanie = new Date(2026, 6, 10, 14, 0); // 10 lipca 2026, 14:00
const wymeldowanie = new Date(2026, 6, 24, 11, 0); // 24 lipca 2026, 11:00

// 3. Stawka za dobę pobytu
const STAWKA_DOBA = 120;

// 4. Wywołaj funkcję, oblicz koszt, przygotuj raport i wypisz do elementu #wynik
// Twoje rozwiazanie
