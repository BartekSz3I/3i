# Zadanie 2: Obliczanie różnicy czasu i liczby dób pobytu

## Cel
Celem zadania jest zaimplementowanie funkcji obliczającej bezwzględną różnicę czasu w milisekundach między dwiema datami przy użyciu metody `getTime()`, a następnie przeliczenie jej na liczbę pełnych dób hotelowych za pomocą funkcji `Math.floor()`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Systemy rezerwacji hotelowych i kempingowych naliczające opłatę za rzeczywistą liczbę spędzonych nocy.
- Parkingi lotniskowe kalkulujące opłatę długoterminową na podstawie czasu wjazdu i wyjazdu przez szlaban.
- Platformy streamingowe monitorujące liczbę dni pozostałych do wygaśnięcia okresu próbnego subskrypcji.

## Wskazówki aktywizujące
- Przeczytaj rozdział 4 i 5 w pliku `teoria.md` („Znaczniki czasu w milisekundach” oraz „Różnica czasu: Dekompozycja milisekund”).
- Zastanów się: dlaczego bezpośrednie odejmowanie dni `koniec.getDate() - start.getDate()` jest błędne, gdy pobyt zaczyna się w lipcu, a kończy w sierpniu?
- Wpisz w konsoli przeglądarki: `const ms = 1000 * 60 * 60 * 24; console.log(ms);` i sprawdź, jaka stała przeliczeniowa odpowiada 24 godzinom.

## Treść do wpisania
W skrypcie wykorzystaj następujące dosłowne teksty i komunikaty:
- Nagłówek raportu: `"=== KEMPING SŁONECZNA PRZYSTAŃ — KARTA ROZLICZENIA POBYTU ==="`.
- Etykieta stanowiska: `"Stanowisko kempingowe: Parcela A-14 (kamper + przyłącze prądu)"`.
- Etykieta zameldowania: `"Termin zameldowania (check-in): 2026-07-10 14:00"`.
- Etykieta wymeldowania: `"Termin wymeldowania (check-out): 2026-07-24 11:00"`.
- Etykieta dób pobytu: `"Liczba zarejestrowanych pełnych dób: "` (uzupełniona o wyliczoną liczbę dób).
- Etykieta łącznego kosztu: `"Należność za pobyt (stawka 120 zł / doba): "` (uzupełniona o wyliczoną kwotę z dopiskiem `" zł"`).
- Podsumowanie: `"Doba hotelowa trwa od godziny 14:00 do godziny 11:00 dnia następnego."`.

## Wymagania
1. Zadeklaruj funkcję `obliczDobyPobytu(dataStart, dataKoniec)`, która:
   - Pobiera znaczniki czasu w milisekundach obu dat za pomocą metody `getTime()`.
   - Oblicza różnicę milisekund (`roznicaMs = koniecMs - startMs`).
   - Dzieli różnicę przez liczbę milisekund w dobie (`1000 * 60 * 60 * 24`) i zaokrągla wynik w dół przy użyciu `Math.floor()`.
   - Zwraca obliczoną liczbę dób jako liczbę całkowitą.
2. Zdefiniuj obiekty dat w kodzie:
   - Zameldowanie: 10 lipca 2026 r., godz. 14:00 (`new Date(2026, 6, 10, 14, 0)`).
   - Wymeldowanie: 24 lipca 2026 r., godz. 11:00 (`new Date(2026, 6, 24, 11, 0)`).
3. Oblicz łączny koszt pobytu, mnożąc liczbę dób przez stawkę `120` zł.
4. Zbuduj wielowierszowy raport tekstowy zawierający wszystkie wymagane etykiety i wypisz go do elementu `#wynik` za pomocą właściwości `textContent`.

## Przykład
Stan początkowy:
Skrypt uruchamia się automatycznie po załadowaniu strony z zadeklarowanymi terminami pobytu.

Efekt na ekranie w elemencie `#wynik`:
```text
=== KEMPING SŁONECZNA PRZYSTAŃ — KARTA ROZLICZENIA POBYTU ===

Stanowisko kempingowe: Parcela A-14 (kamper + przyłącze prądu)
Termin zameldowania (check-in): 2026-07-10 14:00
Termin wymeldowania (check-out): 2026-07-24 11:00
Liczba zarejestrowanych pełnych dób: 13
Należność za pobyt (stawka 120 zł / doba): 1560 zł

Doba hotelowa trwa od godziny 14:00 do godziny 11:00 dnia następnego.
```
