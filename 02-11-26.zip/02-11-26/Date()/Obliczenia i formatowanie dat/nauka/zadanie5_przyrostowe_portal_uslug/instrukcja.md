# Zadanie 5 (Przyrostowe Capstone): Moduł kalkulacji terminów realizacji, SLA i różnic czasowych IT-Partner

## Cel
Celem zadania jest przyrostowa rozbudowa platformy *Portal Usługowo-Handlowy IT-Partner* o strategiczny moduł kalkulacji terminów realizacji, monitorowania gwarantowanego czasu usunięcia awarii (SLA) oraz badania różnic czasowych z zachowaniem pełnej zasady Zero Regresji (M2_T01 – M2_T09).

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Portale partnerskie B2B automatycznie wyliczające gwarantowany czas reakcji i usunięcia awarii serwerowej.
- Systemy ERP i CRM śledzące postęp wdrożeń oprogramowania i alarmujące o zagrożeniu karami umownymi.
- Działy wsparcia technicznego (Helpdesk / Service Desk) prezentujące licznik czasu pozostałego do eskalacji incydentu.

## Wskazówki aktywizujące
- Przeanalizuj kod z poprzedniego etapu (M2_T09) oraz rozdziały 3, 5 i 6 w pliku `teoria.md`.
- Zastanów się: dlaczego wyznaczenie terminu realizacji poprzez `setDate()` bezpośrednio na obiekcie daty zgłoszenia byłoby błędem mutacji stanu początkowego?
- Przetestuj w konsoli: `const t = new Date(); t.setDate(t.getDate() + 3); console.log(t > new Date());`.

## Treść do wpisania
W skrypcie wykorzystaj następujące dosłowne teksty i etykiety sekcji:
- Nagłówek sekcji SLA: `"--- MONITORING TERMINÓW I GWARANCJI SLA ---"`.
- Etykieta przyznanego czasu SLA: `"Gwarantowany czas realizacji (SLA): "` (uzupełniona o wyliczoną liczbę dób, np. `"4 dni kalendarzowe (po 1 dniu na moduł)"`).
- Etykieta terminu granicznego: `"Termin graniczny zakończenia prac (deadline): "` (uzupełniona o sformatowaną datę i godzinę w formacie `RRRR-MM-DD GG:MM`).
- Etykieta statusu terminowości: `"Status harmonogramu wdrożenia: "` (uzupełniona o komunikat `"Zlecenie w trakcie planowej realizacji"` lub `"OSTRZEŻENIE: Przekroczono gwarantowany czas SLA!"`).
- Etykieta czasu pozostałego: `"Czas pozostały do zakończenia SLA: "` — przy czasie dodatnim wpisz dekompozycję `X dni, Y godz., Z min.`; przy przekroczeniu terminu: `"Opóźnienie: X dni, Y godz., Z min."`.
- Komunikat końcowy audytu: `"Procedura audytu SLA: Wszystkie wskaźniki czasowe podlegają automatycznemu raportowaniu do dyrekcji technicznej."`.

## Wymagania
1. **Zasada Zero Regresji (M2_T01 – M2_T09)**:
   - Zachowaj bez żadnych modyfikacji wszystkie istniejące selektory HTML (`#wynik`), style CSS oraz dotychczas zaimplementowane funkcje: `maskujEmail()`, `maskujNip()` oraz cały mechanizm walidacji, parsowania tagów, maskowania i odczytu znacznika czasu audytu.
2. **Kalkulacja terminu realizacji (Deadline SLA)**:
   - Wewnątrz funkcji `przetworzZgloszeniePartnera(rekord)` wyznacz liczbę dób wymaganego czasu SLA na podstawie liczby sparsowanych modułów (zmienna `liczbaModulow`). Przyjmij 1 dzień kalendarzowy na każdy moduł infrastrukturalny (`const dniSla = liczbaModulow;`).
   - Utwórz nową instancję daty terminu granicznego na bazie znacznika czasu rejestracji zgłoszenia: `const terminSla = new Date(dataZgloszenia.getTime());`.
   - Zwiększ dzień terminu za pomocą `terminSla.setDate(terminSla.getDate() + dniSla)`.
3. **Kalkulacja różnicy czasowej względem chwili bieżącej (jak w teorii §6)**:
   - Pobierz bieżący moment: `const teraz = new Date();`.
   - Oblicz różnicę milisekund między terminem granicznym a chwilą bieżącą: `roznicaMs = terminSla.getTime() - teraz.getTime();`.
   - Jeśli `roznicaMs < 0`, ustaw status ostrzeżenia i zdekomponuj `|roznicaMs|` jako opóźnienie; w przeciwnym razie ustaw status planowej realizacji i zdekomponuj `roznicaMs` jako czas pozostały:
     - `dni = Math.floor(ms / (1000 * 60 * 60 * 24))`
     - `godziny = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))`
     - `minuty = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60))`
4. **Formatowanie z zerami wiodącymi**:
   - Przygotuj sformatowany łańcuch terminu granicznego w standardzie `RRRR-MM-DD GG:MM` przy użyciu `padStart(2, "0")`.
5. **Generowanie raportu końcowego**:
   - Dołącz nową sekcję audytu SLA do dotychczasowego potwierdzenia zgłoszenia i wypisz całość do elementu o identyfikatorzie `#wynik` za pomocą właściwości `textContent`.

## Przykład
Stan początkowy:
Aplikacja przetwarza przykładowe zgłoszenie z 4 modułami infrastruktury:
`"ZLECENIE/2026/SERWER/CHMURA#EMAIL:jan.kowalski@klient-partner.pl#NIP:5252891234#TRYB:PILNY#TAGI:chmura,serwer,siec,backup"`

Efekt na ekranie w elemencie `#wynik`:
```text
=== PORTAL USŁUGOWO-HANDLOWY IT-PARTNER — POTWIERDZENIE ZLECENIA ===

Znormalizowany identyfikator zlecenia: ZLECENIE-2026-SERWER-CHMURA
Kategoria wdrożenia: Konfiguracja infrastruktury serwerowej w chmurze (potwierdzona)
Główny moduł infrastrukturalny (split kodu): SERWER
Sparsowane komponenty technologiczne (split/join): chmura + serwer + siec + backup
Liczba zadeklarowanych modułów wdrożenia: 4
Zabezpieczony adres e-mail powiadomień: j***i@klient-partner.pl
Zamaskowany numer identyfikacyjny NIP: 52******34

--- AUDYT CZASOWY ZGŁOSZENIA ---
Data i czas przyjęcia zgłoszenia: 2026-10-18 23:15
Dzień rejestracji zgłoszenia: Niedziela
Tryb obsługi serwisowej: Dyżur weekendowy wsparcia technicznego

--- MONITORING TERMINÓW I GWARANCJI SLA ---
Gwarantowany czas realizacji (SLA): 4 dni kalendarzowe (po 1 dniu na moduł)
Termin graniczny zakończenia prac (deadline): 2026-10-22 23:15
Status harmonogramu wdrożenia: Zlecenie w trakcie planowej realizacji
Czas pozostały do zakończenia SLA: 4 dni, 0 godz., 0 min.

Procedura audytu SLA: Wszystkie wskaźniki czasowe podlegają automatycznemu raportowaniu do dyrekcji technicznej.
Status bezpieczeństwa: Wszystkie dane kontrahenta zanonimizowano zgodnie z procedurą RODO/B2B.
```
