# Zadanie 3: Badanie terminowości zwrotu publikacji i kalkulacja opłat

## Cel
Celem zadania jest zaimplementowanie funkcji weryfikującej terminowość zwrotu publikacji bibliotecznej, badającej znak różnicy czasowej oraz obliczającej ewentualną opłatę za przetrzymanie materiałów edukacyjnych z precyzyjnym formatowaniem daty za pomocą `padStart(2, "0")`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Systemy biblioteczne i wypożyczalnie multimediów naliczające automatyczne opłaty za przetrzymanie pozycji.
- Systemy księgowe i fakturowe monitorujące przeterminowane płatności i naliczające odsetki ustawowe.
- Aplikacje transportu miejskiego i rowerów miejskich weryfikujące przekroczenie darmowego czasu przejazdu.

## Wskazówki aktywizujące
- Przeczytaj rozdział 6 w pliku `teoria.md` („Weryfikacja terminowości i statusów SLA”).
- Zastanów się: dlaczego po odjęciu daty zwrotu od terminu granicznego ujemna liczba milisekund oznacza opóźnienie?
- Przetestuj w konsoli: `const diff = new Date("2026-10-25") - new Date("2026-10-20"); console.log(diff > 0);`.

## Treść do wpisania
W skrypcie wykorzystaj następujące dosłowne teksty i komunikaty:
- Komunikat w oknie dialogowym prompt: `"Podaj datę faktycznego zwrotu publikacji (format RRRR-MM-DD):"` z wartością domyślną `"2026-10-28"`.
- Nagłówek raportu: `"=== MEDIATEKA MIEJSKA E-KSIĄŻKA — ROZLICZENIE ZWROTU ==="`.
- Tytuł pozycji: `"Wypożyczona publikacja: Podręcznik zaawansowanego JavaScript (ISBN 978-83-01)"`.
- Etykieta terminu regulaminowego: `"Regulaminowy termin zwrotu: 2026-10-20"`.
- Etykieta daty faktycznego zwrotu: `"Faktyczna data oddania pozycji: "` (uzupełniona o sformatowaną datę zwrotu).
- Etykieta liczby dni spóźnienia: `"Liczba dni spóźnienia: "` (uzupełniona o wyliczoną liczbę; przy zwrocie w terminie wpisz `0`).
- Status po terminie: `"STATUS: PRZEKROCZONO REGULAMINOWY TERMIN ZWROTU"`.
- Status w terminie: `"STATUS: ZWROT W TERMINIE — BRAK OPŁAT DODATKOWYCH"`.
- Etykieta opłaty karnej: `"Naliczona opłata za zwłokę (2.50 zł / dzień): "` (uzupełniona o kwotę w formacie z dwoma miejscami po przecinku, np. `"20.00"`, oraz dopiskiem `" zł"`).
- Podsumowanie: `"Prosimy o terminowe oddawanie zbiorów w celu umożliwienia korzystania innym czytelnikom."`.

## Wymagania
1. Zadeklaruj funkcję `sprawdzTerminowoscZwrotu(dataGraniczna, dataZwrotu)`, która:
   - Oblicza różnicę milisekund między datą zwrotu a datą graniczną (`dataZwrotu.getTime() - dataGraniczna.getTime()`).
   - Jeśli różnica jest większa od zera, wylicza liczbę pełnych dni spóźnienia za pomocą `Math.floor(roznicaMs / (1000 * 60 * 60 * 24))` oraz nalicza karę (liczba dni × 2.50 zł).
   - Kwotę kary sformatuj do dwóch miejsc po przecinku metodą `toFixed(2)` (np. `(dni * 2.5).toFixed(2)` → `"20.00"`).
   - Zwróć wynik jako obiekt z polami: `dni`, `kwotaKary` (napis po `toFixed`) oraz `status` (jeden z komunikatów statusu z treści).
   - W przeciwnym razie zwróć obiekt z `dni: 0`, `kwotaKary: "0.00"` oraz statusem braku opłat.
2. Poza ciałem funkcji pobierz od użytkownika faktyczną datę zwrotu za pomocą `prompt()` z pytaniem oraz wartością domyślną `"2026-10-28"`.
3. Utwórz obiekt `Date` na podstawie tekstu z `prompt()` oraz obiekt regulaminowego terminu granicznego przypadający na 20 października 2026 r. (`new Date(2026, 9, 20)`).
4. Sformatuj daty z dopełnieniem zerami wiodącymi `padStart(2, "0")`.
5. Wygeneruj raport i wypisz go do kontenera `#wynik` za pomocą `textContent`.

## Przykład
Stan początkowy:
Użytkownik zatwierdza domyślną datę `"2026-10-28"` w oknie dialogowym `prompt`.

Efekt na ekranie w elemencie `#wynik`:
```text
=== MEDIATEKA MIEJSKA E-KSIĄŻKA — ROZLICZENIE ZWROTU ===

Wypożyczona publikacja: Podręcznik zaawansowanego JavaScript (ISBN 978-83-01)
Regulaminowy termin zwrotu: 2026-10-20
Faktyczna data oddania pozycji: 2026-10-28
Liczba dni spóźnienia: 8
STATUS: PRZEKROCZONO REGULAMINOWY TERMIN ZWROTU
Naliczona opłata za zwłokę (2.50 zł / dzień): 20.00 zł

Prosimy o terminowe oddawanie zbiorów w celu umożliwienia korzystania innym czytelnikom.
```
