/**
 * Zadanie 3: Badanie terminowości zwrotu publikacji i kalkulacja opłat
 * Szablon startowy dla ucznia
 */

// 1. Zadeklaruj funkcję weryfikującą terminowość
function sprawdzTerminowoscZwrotu(dataGraniczna, dataZwrotu) {
  // Twoje rozwiazanie
  // Krok 1: Wyznacz różnicę czasu w ms (dataZwrotu.getTime() - dataGraniczna.getTime())
  // Krok 2: Sprawdź warunek: czy roznicaMs > 0?
  // Krok 3: Jeśli spóźnienie — dni (Math.floor) i kara (dni * 2.5).toFixed(2)
  // Krok 4: Zwróć obiekt { dni, kwotaKary, status }
}

// 2. Pobierz datę zwrotu od użytkownika przez prompt z wartością domyślną "2026-10-28"
const wejscieData = prompt("Podaj datę faktycznego zwrotu publikacji (format RRRR-MM-DD):", "2026-10-28");

// 3. Zdefiniuj obiekty dat: regulaminowy termin (20 października 2026) oraz faktyczny zwrot
const terminRegulaminowy = new Date(2026, 9, 20);
const faktycznyZwrot = new Date(wejscieData);

// 4. Wywołaj funkcję, sformatuj raport i wypisz wynik do elementu #wynik
// Twoje rozwiazanie
