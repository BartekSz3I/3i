// Zadanie 3: Przychodnia lekarska — weryfikacja dyżuru i nazwy dnia tygodnia

// KROK 1: Przygotuj tablicę nazw dni tygodnia (indeks 0 = Niedziela)
const dniTygodnia = [
  "Niedziela",
  "Poniedziałek",
  "Wtorek",
  "Środa",
  "Czwartek",
  "Piątek",
  "Sobota"
];

// KROK 2: Zaimplementuj funkcję sprawdzDyzurPoradni()
function sprawdzDyzurPoradni() {
  // TODO: Utwórz nową instancję Date

  // TODO: Pobierz dzień tygodnia za pomocą metody getDay()

  // TODO: Pobierz polską nazwę dnia z tablicy dniTygodnia

  // TODO: Sprawdź, czy dzień to weekend (0 lub 6) i dobierz odpowiedni status trybu pracy

  // TODO: Zbuduj i zwróć raport tekstowy
  return "";
}

// KROK 3: Wywołaj funkcję i wypisz wynik do #wynik
const raportDyzuru = sprawdzDyzurPoradni();
document.getElementById("wynik").textContent = raportDyzuru;
