# Zadanie 3: Przychodnia lekarska — weryfikacja dyżuru i nazwy dnia tygodnia

W systemach rejestracji pacjentów kluczowe jest ustalenie, czy bieżący dzień to dzień roboczy, czy też weekend, kiedy czynny jest wyłącznie dyżur nocnej i świątecznej opieki zdrowotnej. Twoim zadaniem jest pobranie numeru dnia tygodnia za pomocą metody `getDay()`, zmapowanie go na polską nazwę za pomocą tablicy oraz sprawdzenie warunku weekendu.

### Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy rejestracji medycznej (np. ZnanyLekarz, e-Zdrowie):** Wyświetlanie informacji o dyżurze świątecznym lub dostępnych lekarzach dyżurnych.
2. **Platformy e-commerce:** Informowanie klienta o wysyłce paczki dopiero w najbliższy dzień roboczy.
3. **Placówki bankowe i urzędy:** Automatyczne przełączanie komunikatu o godzinach otwarcia infolinii w soboty i niedziele.

---

## Wymagania techniczne
1. Przygotuj tablicę z nazwami dni tygodnia w języku polskim, pamiętając, że pierwszym elementem pod indeksem `0` musi być niedziela:
   `["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"]`.
2. Zdefiniuj funkcję `sprawdzDyzurPoradni()`, która:
   - Tworzy instancję `new Date()`.
   - Pobiera indeks dnia tygodnia za pomocą metody `getDay()`.
   - Pobiera polską nazwę dnia z przygotowanej tablicy słownikowej.
   - Bada, czy dany dzień to weekend (gdy indeks wynosi `0` lub `6`).
   - Przypisuje odpowiedni status trybu pracy:
     - dla weekendu: `"Dyżur świąteczno-weekendowy (SOR)"`,
     - dla pozostałych dni: `"Standardowe przyjęcia pacjentów w poradni"`.
   - Zwraca sformatowany komunikat informacyjny.
3. Wywołaj funkcję i wyświetl wynik w elemencie o identyfikatorze `wynik` za pomocą właściwości `textContent`.

---

## Treść do wpisania
W generowanym raporcie użyj dokładnie następujących nagłówków i sformułowań (łącznie ze znakami `===`):
- `"=== CENTRUM MEDYCZNE ZDROWIE - HARMONOGRAM PRZYJĘĆ ==="` jako nagłówek raportu,
- `"Dzień tygodnia: "` przed nazwą dnia,
- `"Tryb pracy gabinetu: "` przed statusem przyjęć,
- `"Dyżur świąteczno-weekendowy (SOR)"` dla dni wolnych od pracy,
- `"Standardowe przyjęcia pacjentów w poradni"` dla dni roboczych.

---

## Efekt działania skryptu
W ramce `#wynik` powinien pojawić się wielowierszowy tekst w formacie:
```text
=== CENTRUM MEDYCZNE ZDROWIE - HARMONOGRAM PRZYJĘĆ ===
Dzień tygodnia: Poniedziałek
Tryb pracy gabinetu: Standardowe przyjęcia pacjentów w poradni
```
