/**
 * Zadanie 5: Przyrostowy moduł rejestracji znacznika czasu i audytu zgłoszeń IT-Partner
 * Szablon startowy dla ucznia (M2_T09) — Baza z M2_T07 z komentarzami wdrożeniowymi
 */

// Słownik pomocniczy dni tygodnia w języku polskim
const dniTygodnia = [
  "Niedziela",
  "Poniedziałek",
  "Wtorek",
  "Środa",
  "Czwartek",
  "Piątek",
  "Sobota"
];

// Funkcja pomocnicza maskująca adres e-mail (M2_T06)
function maskujEmail(email) {
  const atIdx = email.indexOf("@");
  if (atIdx === -1) return "BŁĘDNY_ADRES_EMAIL";

  const uzytkownik = email.slice(0, atIdx);
  const domena = email.slice(atIdx);

  if (uzytkownik.length <= 2) {
    return `*${domena}`;
  }

  const pierwszaLitera = uzytkownik.slice(0, 1);
  const ostatniaLitera = uzytkownik.slice(-1);
  return `${pierwszaLitera}***${ostatniaLitera}${domena}`;
}

// Funkcja pomocnicza maskująca numer NIP (M2_T06)
function maskujNip(nip) {
  if (nip.length !== 10) return "BŁĘDNY_NUMER_NIP";

  const startNip = nip.slice(0, 2);
  const koniecNip = nip.slice(-2);
  return `${startNip}******${koniecNip}`;
}

// Główna funkcja przetwarzająca zgłoszenie (rozszerzenie M2_T09)
function przetworzZgloszeniePartnera(rekord) {
  // 1. Walidacja formatu zlecenia (M2_T06)
  const poprawneZlecenie = rekord.startsWith("ZLECENIE/");
  if (!poprawneZlecenie) {
    return "BŁĄD KRYTYCZNY: Niepoprawny format identyfikatora zlecenia partnerskiego.";
  }

  // 2. Ekstrakcja i normalizacja kodu zlecenia (zamiana / na -)
  const hash1Idx = rekord.indexOf("#");
  const suroweZlecenie = rekord.slice(0, hash1Idx);
  const znormalizowaneZlecenie = suroweZlecenie.replaceAll("/", "-");

  // Ekstrakcja tokenu modułu ze znormalizowanego kodu (M2_T07)
  const czesciKodu = znormalizowaneZlecenie.split("-");
  const glownyModul = czesciKodu[2]; // 'SERWER'

  // 3. Sprawdzenie kategorii zlecenia (M2_T06)
  const czyChmura = suroweZlecenie.includes("/CHMURA");
  let opisKategorii = "";
  if (czyChmura) {
    opisKategorii = "Kategoria wdrożenia: Konfiguracja infrastruktury serwerowej w chmurze (potwierdzona)";
  } else {
    opisKategorii = "Kategoria wdrożenia: Standardowe zlecenie serwisowe";
  }

  // Ekstrakcja i parsowanie tagów technologicznych (M2_T07)
  const tagiMarker = "#TAGI:";
  const tagiIdx = rekord.indexOf(tagiMarker);
  const suroweTagi = rekord.slice(tagiIdx + tagiMarker.length);
  const tablicaTagow = suroweTagi.split(",");
  const liczbaModulow = tablicaTagow.length;
  const scaloneTagi = tablicaTagow.join(" + ");

  // 4. Ekstrakcja i maskowanie e-maila (M2_T06)
  const emailTag = "EMAIL:";
  const emailIdx = rekord.indexOf(emailTag);
  const hash2Idx = rekord.indexOf("#", emailIdx);
  const surowyEmail = rekord.slice(emailIdx + emailTag.length, hash2Idx);
  const bezpiecznyEmail = maskujEmail(surowyEmail);

  // 5. Ekstrakcja i maskowanie numeru NIP (M2_T06)
  const nipTag = "NIP:";
  const nipIdx = rekord.indexOf(nipTag);
  const hash3Idx = rekord.indexOf("#", nipIdx);
  const surowyNip = rekord.slice(nipIdx + nipTag.length, hash3Idx);
  const bezpiecznyNip = maskujNip(surowyNip);

  // KROK DLA UCZNIA 1: Utwórz instancję new Date() reprezentującą moment audytu zgłoszenia
  // const dataZgloszenia = new Date();

  // KROK DLA UCZNIA 2: Odczytaj i sformatuj składowe daty i czasu (padStart(2, "0"))
  // Rok: getFullYear(), Miesiąc (+1) i Dzień: padStart(2, "0")
  // Godzina i Minuta: padStart(2, "0")

  // KROK DLA UCZNIA 3: Odczytaj dzień tygodnia metodą getDay() i pobierz nazwę z tablicy dniTygodnia
  // Sprawdź czy dzień to weekend (0 lub 6) i ustaw status trybu obsługi

  // KROK DLA UCZNIA 4: Włącz sekcję audytu czasowego do treści raportu

  const naglowek = "=== PORTAL USŁUGOWO-HANDLOWY IT-PARTNER — POTWIERDZENIE ZLECENIA ===\n\n";
  const wiersz1 = `Znormalizowany identyfikator zlecenia: ${znormalizowaneZlecenie}\n`;
  const wiersz2 = `${opisKategorii}\n`;
  const wiersz3 = `Główny moduł infrastrukturalny (split kodu): ${glownyModul}\n`;
  const wiersz4 = `Sparsowane komponenty technologiczne (split/join): ${scaloneTagi}\n`;
  const wiersz5 = `Liczba zadeklarowanych modułów wdrożenia: ${liczbaModulow}\n`;
  const wiersz6 = `Zabezpieczony adres e-mail powiadomień: ${bezpiecznyEmail}\n`;
  const wiersz7 = `Zamaskowany numer identyfikacyjny NIP: ${bezpiecznyNip}\n\n`;

  // Do uzupełnienia przez ucznia w ramach M2_T09:
  const sekcjaAudytu = "--- AUDYT CZASOWY ZGŁOSZENIA ---\n[OCZEKUJE NA IMPLEMENTACJĘ METOD DATE]\n\n";

  const stopka = "Status bezpieczeństwa: Wszystkie dane kontrahenta zanonimizowano zgodnie z procedurą RODO/B2B.";

  return `${naglowek}${wiersz1}${wiersz2}${wiersz3}${wiersz4}${wiersz5}${wiersz6}${wiersz7}${sekcjaAudytu}${stopka}`;
}

const rekordSprawy = "ZLECENIE/2026/SERWER/CHMURA#EMAIL:jan.kowalski@klient-partner.pl#NIP:5252891234#TRYB:PILNY#TAGI:chmura,serwer,siec,backup";
const potwierdzenie = przetworzZgloszeniePartnera(rekordSprawy);

document.getElementById("wynik").textContent = potwierdzenie;
