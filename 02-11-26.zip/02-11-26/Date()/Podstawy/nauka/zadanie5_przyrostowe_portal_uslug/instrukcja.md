# Zadanie 5: Projekt przyrostowy Capstone — Audyt znacznika czasu w Portalu IT-Partner

Rozwijasz strategiczny projekt przyrostowy **Portal Usługowo-Handlowy IT-Partner** (Kamień Milowy M2_T09). Dotychczasowy system waliduje format zgłoszenia, normalizuje kod referencyjny, anonimizuje adres e-mail oraz NIP kontrahenta, a także rozbija ciąg tagów na listę modułów wdrożenia. W tym etapie zintegrujesz moduł rejestracji czasu: pobierzesz bieżący znacznik czasu z obiektu `Date`, sformatujesz go z zerami wiodącymi, ustalisz polską nazwę dnia tygodnia oraz oznaczysz tryb obsługi (dni powszednie vs dyżur weekendowy).

### Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Portale serwisowe B2B (np. Jira Service Management, ServiceNow):** Rejestrowanie znacznika czasu (timestamp) wpłynięcia incydentu na potrzeby audytu SLA.
2. **Platformy fakturowania i ERP:** Wystawianie dokumentów księgowych z jednoznacznym czasem operacji.
3. **Centra monitoringu infrastruktury:** Rejestracja logów zdarzeń sieciowych z dokładną datą i dniem tygodnia.

---

## Wymagania techniczne
1. Obowiązuje bezwzględna **Zasada Zero Regresji** — **nie usuwaj i nie zmieniaj** istniejących funkcji pomocniczych (`maskujEmail`, `maskujNip`) ani logiki parsowania z etapów M2_T01–M2_T07. Szablon już je zawiera; Twoja praca to wyłącznie uzupełnienie sekcji audytu czasowego (komentarze `KROK DLA UCZNIA` oraz zmienna `sekcjaAudytu`).
2. Tablica słownikowa dni tygodnia jest już zdefiniowana w szablonie:
   `["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"]`.
3. Rozbuduj funkcję `przetworzZgloszeniePartnera(rekord)` o moduł audytu czasowego:
   - Utwórz instancję `new Date()` reprezentującą moment rejestracji zgłoszenia.
   - Pobierz pełny rok (`getFullYear()`).
   - Pobierz numer miesiąca z dodaniem `1` oraz dzień miesiąca, po czym sformatuj je do dwóch znaków metodą `String(...).padStart(2, "0")`.
   - Pobierz godzinę oraz minutę i sformatuj je metodą `String(...).padStart(2, "0")`.
   - Pobierz indeks dnia tygodnia (`getDay()`) i przypisz polską nazwę dnia z tablicy słownikowej.
   - Sprawdź, czy dzień przyjęcia zgłoszenia to weekend (`indeksDnia === 0 || indeksDnia === 6`). Jeśli tak, ustaw tryb: `"Dyżur weekendowy wsparcia technicznego"`; w przeciwnym razie ustaw: `"Standardowy tryb roboczy B2B"`.
   - Włącz sekcję audytu czasowego do generowanego potwierdzenia zgłoszenia.
4. Zwróć wygenerowany dokument i wyświetl go w elemencie `#wynik` za pomocą właściwości `textContent`.

---

## Treść do wpisania
W generowanym raporcie potwierdzenia zlecenia użyj dokładnie następujących nagłówków i sformułowań (łącznie ze znakami `===` oraz separatorem sekcji audytu):
- `"=== PORTAL USŁUGOWO-HANDLOWY IT-PARTNER — POTWIERDZENIE ZLECENIA ==="` jako nagłówek dokumentu (już obecny w szablonie — nie usuwaj go),
- `"--- AUDYT CZASOWY ZGŁOSZENIA ---"` jako nagłówek sekcji audytu,
- `"Data i czas przyjęcia zgłoszenia: "` przed sformatowanym czasem `RRRR-MM-DD GG:MM` (z `padStart`),
- `"Dzień rejestracji zgłoszenia: "` przed polską nazwą dnia tygodnia,
- `"Tryb obsługi serwisowej: "` przed statusem dyżuru,
- `"Dyżur weekendowy wsparcia technicznego"` dla sobót i niedziel,
- `"Standardowy tryb roboczy B2B"` dla dni powszednich.

---

## Efekt działania skryptu
W ramce `#wynik` pojawi się kompletny, zintegrowany raport audytowy Portalu IT-Partner:
```text
=== PORTAL USŁUGOWO-HANDLOWY IT-PARTNER — POTWIERDZENIE ZLECENIA ===

Znormalizowany identyfikator zlecenia: ZLECENIE-2026-SERWER-CHMURA
Kategoria wdrożenia: Konfiguracja infrastruktury serwerowej w chmurze (potwierdzona)
Główny moduł infrastrukturalny (split kodu): SERWER
Sparsowane komponenty technologiczne (split/join): chmura + serwer + siec + backup
Liczba zadeklarowanych modułów wdrożenia: 4
Zabezpieczony adres e-mail powiadomień: j***i@klient-partner.pl
Zamaskowany numer identyfikacyjny NIP: 52******34

--- AUDYT CZASOWY ZGŁOSZENIA ---
Data i czas przyjęcia zgłoszenia: 2026-10-18 14:30
Dzień rejestracji zgłoszenia: Niedziela
Tryb obsługi serwisowej: Dyżur weekendowy wsparcia technicznego

Status bezpieczeństwa: Wszystkie dane kontrahenta zanonimizowano zgodnie z procedurą RODO/B2B.
```
