// Zadanie 2: Komunikacja miejska — formatowanie czasu skasowania biletu

// KROK 1: Pobierz numer linii za pomocą prompt() z wartością domyślną "14"
const numerLinii = prompt("Podaj numer linii tramwajowej:", "14");

// KROK 2: Zaimplementuj funkcję skasujBilet(linia)
function skasujBilet(linia) {
  // TODO: Utwórz nową instancję obiektu Date

  // TODO: Odczytaj godziny (getHours()), minuty (getMinutes()) i sekundy (getSeconds())

  // TODO: Sformatuj każdą wartość do dwóch cyfr za pomocą String(...).padStart(2, "0")

  // TODO: Złóż czas w formacie GG:MM:SS i zwróć pełną treść biletu
  return "";
}

// KROK 3: Wywołaj funkcję dla pobranej linii i wyświetl bilet w #wynik
const biletTekst = skasujBilet(numerLinii);
document.getElementById("wynik").textContent = biletTekst;
