# Zadanie 2: Komunikacja miejska — formatowanie czasu skasowania biletu

W kasownikach i aplikacjach transportu miejskiego bilet czasowy musi precyzyjnie rejestrować godzinę, minutę i sekundę skasowania. Aby czas był jednoznaczny i czytelny, każda wartość jednocyfrowa musi zostać uzupełniona zerem wiodącym (np. `08:05:09` zamiast `8:5:9`). Twoim zadaniem jest odczytanie czasu z obiektu `Date` i sformatowanie go metodą `padStart()`.

### Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Aplikacje biletowe (np. Jakdojade, mPay):** Wyświetlanie animowanego biletu czasowego z dokładną godziną rozpoczęcia i zakończenia ważności.
2. **Systemy parkingowe:** Wydruk biletu wjazdu na parking podziemny z dokładnym czasem rozliczeniowym.
3. **Rejestratory czasu pracy:** Zapis momentu odbicia karty pracowniczej w systemie kontroli dostępu.

---

## Wymagania techniczne
1. Pobierz numer linii za pomocą instrukcji `prompt("Podaj numer linii tramwajowej:", "14");` umieszczonej poza ciałem funkcji.
2. Zdefiniuj funkcję `skasujBilet(linia)`, która:
   - Tworzy instancję `new Date()`.
   - Pobiera godzinę (`getHours()`), minutę (`getMinutes()`) oraz sekundę (`getSeconds()`).
   - Formatuje każdą z tych trzech wartości do postaci dwuznakowej za pomocą konstrukcji `String(wartosc).padStart(2, "0")`.
   - Tworzy sformatowany łańcuch czasu w formacie `GG:MM:SS`.
   - Zwraca raport potwierdzenia skasowania biletu.
3. Wywołaj funkcję i wyświetl wynik w elemencie o identyfikatorze `wynik` za pomocą właściwości `textContent`.

---

## Treść do wpisania
W generowanym raporcie użyj dokładnie następujących nagłówków i sformułowań (łącznie ze znakami `===`):
- `"=== ELEKTRONICZNY BILET CZASOWY - METRO-BUS ==="` jako nagłówek biletu,
- `"Linia komunikacyjna nr: "` przed numerem linii,
- `"Godzina skasowania biletu: "` przed sformatowanym czasem `GG:MM:SS` (z `padStart`),
- `"Ważność biletu: 45 minut od momentu skasowania"` jako informacja taryfowa.

---

## Efekt działania skryptu
W ramce `#wynik` powinien pojawić się wielowierszowy tekst w formacie:
```text
=== ELEKTRONICZNY BILET CZASOWY - METRO-BUS ===
Linia komunikacyjna nr: 14
Godzina skasowania biletu: 14:05:09
Ważność biletu: 45 minut od momentu skasowania
```
