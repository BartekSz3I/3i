# Zadanie 4: Hotelarstwo — integracyjna karta meldunkowa gościa

W hotelowych systemach recepcyjnych (PMS) podczas meldowania gościa recepcjonista generuje kartę meldunkową. Karta ta łączy wszystkie poznane dotychczas elementy: pełną datę kalendarzową, precyzyjny czas z zerami wiodącymi oraz polską nazwę dnia tygodnia. Twoim zadaniem jest stworzenie funkcji integrującej te mechanizmy.

### Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy recepcyjne w hotelarstwie (np. KWHotel, Opera PMS):** Generowanie potwierdzeń zameldowania i kart pobytu.
2. **Platformy rezerwacji sal konferencyjnych:** Drukowanie grafiku rezerwacji z datą, godziną i dniem tygodnia.
3. **Centra obsługi pasażerów na lotniskach:** Karty pokładowe i potwierdzenia odprawy pasażerskiej.

---

## Wymagania techniczne
1. Przygotuj tablicę słownikową zawierającą nazwy dni tygodnia po polsku:
   `["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"]`.
2. Zdefiniuj funkcję `generujKarteMeldunkowa(nazwiskoGoscia, numerPokoju)`, która:
   - Tworzy instancję `new Date()`.
   - Odczytuje pełny rok (`getFullYear()`).
   - Odczytuje miesiąc (`getMonth() + 1`) oraz dzień (`getDate()`) i formatuje je do 2 znaków metodą `padStart(2, "0")`.
   - Odczytuje godzinę (`getHours()`) oraz minutę (`getMinutes()`) i formatuje je metodą `padStart(2, "0")`.
   - Odczytuje dzień tygodnia (`getDay()`) i pobiera jego nazwę z tablicy słownikowej.
   - Tworzy ciąg daty i godziny: `RRRR-MM-DD GG:MM`.
   - Składa pełny raport rejestracji pobytu gościa.
   - Zwraca gotowy raport za pomocą instrukcji `return`.
3. Wywołaj funkcję dla parametrów `"Nowak"` oraz `104`, a wynik wypisz do kontenera `#wynik` za pomocą właściwości `textContent`.

---

## Treść do wpisania
W generowanym raporcie użyj dokładnie następujących nagłówków i sformułowań (łącznie ze znakami `===`):
- `"=== HOTEL REZYDENCJA PARKOWA - KARTA REJESTRACYJNA GOŚCIA ==="` jako nagłówek dokumentu,
- `"Gość: "` przed nazwiskiem oraz `" | Pokój nr: "` przed numerem pokoju (w jednym wierszu),
- `"Data i godzina zameldowania: "` przed sformatowaną datą i czasem `RRRR-MM-DD GG:MM` (z `padStart`),
- `"Dzień zameldowania: "` przed polską nazwą dnia tygodnia,
- `"Status rezerwacji: Potwierdzona w systemie centralnym"` jako stopka statusowa.

---

## Efekt działania skryptu
W ramce `#wynik` powinien pojawić się wielowierszowy tekst w formacie:
```text
=== HOTEL REZYDENCJA PARKOWA - KARTA REJESTRACYJNA GOŚCIA ===
Gość: Nowak | Pokój nr: 104
Data i godzina zameldowania: 2026-10-18 14:30
Dzień zameldowania: Niedziela
Status rezerwacji: Potwierdzona w systemie centralnym
```
