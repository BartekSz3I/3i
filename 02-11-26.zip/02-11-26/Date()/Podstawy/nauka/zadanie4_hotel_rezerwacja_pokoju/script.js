// Zadanie 4: Hotelarstwo — integracyjna karta meldunkowa gościa

// KROK 1: Słownik nazw dni tygodnia (indeks 0 = Niedziela)
const dniTygodnia = [
  "Niedziela",
  "Poniedziałek",
  "Wtorek",
  "Środa",
  "Czwartek",
  "Piątek",
  "Sobota"
];

// KROK 2: Zaimplementuj funkcję generujKarteMeldunkowa(nazwiskoGoscia, numerPokoju)
function generujKarteMeldunkowa(nazwiskoGoscia, numerPokoju) {
  // TODO: Utwórz nową instancję obiektu Date

  // TODO: Pobierz rok, miesiąc (+1) oraz dzień z dopełnieniem padStart(2, "0")

  // TODO: Pobierz godzinę i minutę z dopełnieniem padStart(2, "0")

  // TODO: Pobierz polską nazwę dnia tygodnia z tablicy dniTygodnia

  // TODO: Skomponuj wielowierszowy raport z danymi gościa i zwróć go
  return "";
}

// KROK 3: Wywołaj funkcję dla parametrów "Nowak", 104 i wyświetl wynik w #wynik
const kartaGoscia = generujKarteMeldunkowa("Nowak", 104);
document.getElementById("wynik").textContent = kartaGoscia;
