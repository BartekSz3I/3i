# Zadanie 1: Wypożyczalnia pojazdów — pobieranie bieżącej daty umowy

W systemach obsługi wypożyczalni samochodowych każdy dokument umowy najmu musi zawierać dokładną datę jego sporządzenia pobraną z zegara systemowego. Twoim zadaniem jest utworzenie instancji obiektu `Date`, odczytanie poszczególnych składowych daty oraz ich sformatowanie.

### Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Wypożyczalnie aut (np. Traficar, Panek):** Automatyczne generowanie protokołu rozpoczęcia wynajmu z bieżącym rokiem, miesiącem i dniem.
2. **Kasy fiskalne i systemy POS:** Rejestracja daty sprzedaży na paragonie fiskalnym.
3. **Systemy bankowości internetowej:** Oznaczanie daty zlecenia przelewu krajowego lub walutowego.

---

## Wymagania techniczne
1. Pobierz nazwisko najemcy za pomocą instrukcji `prompt("Podaj nazwisko najemcy:", "Kowalski");` umieszczonej poza ciałem funkcji.
2. Napisz funkcję `generujDaneUmowy(nazwisko)`, która:
   - Tworzy nową instancję obiektu `Date` za pomocą operatora `new Date()`.
   - Pobiera pełny czterocyfrowy rok za pomocą metody `getFullYear()`.
   - Pobiera miesiąc za pomocą metody `getMonth()` i dodaje do niego `1`, aby uzyskać prawidłowy numer miesiąca kalendarzowego.
   - Pobiera dzień miesiąca za pomocą metody `getDate()`.
   - Składa datę w formacie `RRRR-M-D` **bez** metody `padStart` (np. 5 stycznia: `2026-1-5`; 18 października: `2026-10-18`).
   - Składa czytelny raport tekstowy wykorzystujący szablony tekstowe (template literals).
   - Zwraca wygenerowany tekst za pomocą instrukcji `return`.
3. Wywołaj funkcję i wypisz jej wynik do elementu o identyfikatorze `wynik` za pomocą właściwości `textContent`.

---

## Treść do wpisania
W generowanym raporcie użyj dokładnie następujących nagłówków i sformułowań (łącznie ze znakami `===`):
- `"=== UMOWA WYPOŻYCZENIA POJAZDU - AUTO-DRIVE ==="` jako nagłówek dokumentu,
- `"Data sporządzenia dokumentu: "` przed złożoną datą w formacie `RRRR-M-D`,
- `"Najemca pojazdu: Pan/Pani "` przed nazwiskiem najemcy,
- `"Status weryfikacji: Zgłoszenie przyjęte do realizacji"` jako podsumowanie.

---

## Efekt działania skryptu
W ramce `#wynik` powinien pojawić się wielowierszowy tekst w formacie (przykład dla 18 października; w dniu 5 stycznia data brzmi `2026-1-5`):
```text
=== UMOWA WYPOŻYCZENIA POJAZDU - AUTO-DRIVE ===
Data sporządzenia dokumentu: 2026-10-18
Najemca pojazdu: Pan/Pani Kowalski
Status weryfikacji: Zgłoszenie przyjęte do realizacji
```
