// Zadanie 1: Wypożyczalnia Auto-Drive — pobieranie bieżącej daty umowy

// KROK 1: Pobierz nazwisko najemcy za pomocą prompt() z wartością domyślną "Kowalski"
const nazwiskoNajemcy = prompt("Podaj nazwisko najemcy:", "Kowalski");

// KROK 2: Zaimplementuj funkcję generujDaneUmowy(nazwisko)
function generujDaneUmowy(nazwisko) {
  // TODO: Utwórz nową instancję obiektu Date za pomocą new Date()

  // TODO: Odczytaj pełny rok za pomocą metody getFullYear()

  // TODO: Odczytaj miesiąc metodą getMonth() i dodaj 1

  // TODO: Odczytaj dzień miesiąca metodą getDate()

  // TODO: Zbuduj i zwróć wielowierszowy łańcuch znaków z nagłówkiem i danymi umowy
  return "";
}

// KROK 3: Wywołaj funkcję dla pobranego nazwiska i wypisz rezultat do #wynik za pomocą textContent
const wynikUmowy = generujDaneUmowy(nazwiskoNajemcy);
document.getElementById("wynik").textContent = wynikUmowy;
