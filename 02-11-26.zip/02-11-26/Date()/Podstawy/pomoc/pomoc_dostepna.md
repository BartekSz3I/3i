# Pomoc dostępna — Moduł T09: Obiekt Date

Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

Ten plik opisuje **jak pracować z ćwiczeniami** (kolejność kroków, oznaczenia w plikach, zasady czytelności).  
Dokładne stringi raportu i wymagane metody znajdziesz zawsze w `instrukcja.md` danego zadania oraz w komentarzach `// KROK ...` w pliku `script.js`. Ściągę składniową `Date` znajdziesz w `pomoc_krotka_ogolna.md`.

---

## 1. Słowniczek pojęć modułu T09

- **Obiekt `Date`** — wbudowany w język JavaScript moduł reprezentujący określony punkt w czasie mierzony w milisekundach od 1 stycznia 1970 roku.
- **Instancja obiektu** — konkretny egzemplarz obiektu utworzony w pamięci komputera za pomocą zapisu `new Date()`.
- **Metoda `getFullYear()`** — funkcja odczytująca pełny rok w postaci czterech cyfr, na przykład `2026`.
- **Metoda `getMonth()`** — funkcja zwracająca numer miesiąca w zakresie od `0` do `11`, gdzie liczba `0` oznacza styczeń. Przed prezentacją numeru kalendarzowego dodaj `1`.
- **Metoda `getDate()`** — funkcja zwracająca numer dnia miesiąca w zakresie od `1` do `31`.
- **Metoda `getDay()`** — funkcja zwracająca numer dnia tygodnia w zakresie od `0` do `6`, gdzie `0` oznacza niedzielę.
- **Metoda `padStart()`** — funkcja tekstowa uzupełniająca początek napisu wskazanym znakiem do określonej długości, na przykład zamieniająca `"5"` na `"05"`. Stosuj ją **tylko wtedy**, gdy instrukcja wymaga formatu dwucyfrowego (`GG:MM`, `RRRR-MM-DD`).

---

## 2. Stały schemat pracy z zadaniem

Wszystkie ćwiczenia w module wykonuj według poniższych kroków:

1. Otwórz plik `instrukcja.md` znajdujący się w katalogu wybranego zadania. Przeczytaj uważnie cel, wymagania techniczne oraz sekcję **Treść do wpisania** / **Treść merytoryczna** (łącznie ze znakami `===` w nagłówkach).
2. Otwórz plik `script.js` znajdujący się bezpośrednio w katalogu tego zadania. W tym pliku będziesz wpisywać kod programu.
3. Odszukaj w kodzie komentarze z numerami kroków. Każdy komentarz precyzuje, jaką instrukcję należy umieścić w danym miejscu. Szablon często ma już gotowy `prompt`, tablicę dni lub szkielet funkcji — uzupełniaj tylko miejsca oznaczone `TODO` lub `KROK DLA UCZNIA`.
4. Porównaj swój raport z blokiem **Efekt działania** / **Przykład działania** w instrukcji (układ wierszy i dokładne brzmienie etykiet).
5. Zapisz plik `script.js` za pomocą skrótu klawiszowego `Ctrl + S`.
6. Uruchom plik `index.html` w przeglądarce internetowej (kliknij dwukrotnie plik w menedżerze plików).
7. Sprawdź, czy w ramce o identyfikatorze `wynik` pojawił się oczekiwany tekst.
8. Jeśli wynik jest poprawny lub napotkasz trudności, otwórz podfolder `rozwiazanie/` i porównaj swój kod z plikiem wzorcowym.

---

## 3. Oznaczenia miejsc do uzupełnienia w plikach

W plikach szablonu startowego przygotowano wyraźne znaczniki wskazujące miejsca pracy:

- W plikach HTML struktura jest gotowa i zawiera komentarze wskazujące kontener wyjściowy:
  ```html
  <!-- KROK 1: Kontener wyjściowy skryptu -->
  <div id="wynik"></div>
  ```
- W plikach JavaScript instrukcje należy dopisywać bezpośrednio pod dedykowanymi komentarzami:
  ```javascript
  // KROK 1: Utwórz instancję obiektu Date
  // TODO: ...
  ```

---

## 4. Kiedy stosować `padStart`, a kiedy nie

| Sytuacja w instrukcji | Co robić |
|---|---|
| Format daty zapisany jako `RRRR-M-D` | Wypisz `${rok}-${miesiac}-${dzien}` **bez** `padStart` (w styczniu może wyjść `2026-1-5`) |
| Format czasu / daty zapisany jako `GG:MM`, `GG:MM:SS` lub `RRRR-MM-DD` | Użyj `String(...).padStart(2, "0")` dla składowych jednocyfrowych |
| Nagłówek z `=== ... ===` | Skopiuj **dokładnie** ten zapis z sekcji treści instrukcji |

---

## 5. Zasady dostępności cyfrowej (a11y) w module T09

Prezentacja danych czasowych musi spełniać podstawowe wymagania czytelności dla każdego odbiorcy:

1. **Hierarchia nagłówków:** Każdy dokument HTML posiada dokładnie jeden nagłówek pierwszego stopnia `<h1>` określający tematykę modułu oraz nagłówki `<h2>` dla sekcji funkcjonalnych.
2. **Kontrast tekstu:** Tekst w kontenerze `#wynik` posiada wysoki współczynnik kontrastu względem tła (ciemny tekst na jasnym tle lub jasny na ciemnym).
3. **Formatowanie czytelne dla czytników ekranu:** Daty i godziny są sformatowane jednoznacznie z użyciem standardowych separatorów myślnika (`-`) lub dwukropka (`:`), co ułatwia syntezatorom mowy prawidłową interpretację liczb.
