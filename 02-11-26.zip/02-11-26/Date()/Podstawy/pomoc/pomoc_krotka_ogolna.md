# Pomoc krótka ogólna — Moduł T09: Obiekt Date

Podręczna ściąga syntaktyczna i przewodnik po organizacji plików dla modułu T09.

---

## 1. Organizacja pracy: Szablon startowy vs Rozwiązanie

Każde ćwiczenie w dziale dydaktycznym posiada niezależny katalog z przygotowanymi plikami:

| Element | Szablon startowy w katalogu zadania | Wzorzec w podkatalogu `rozwiazanie/` |
|---|---|---|
| **Lokalizacja** | Bezpośrednio w folderze zadania, np. `nauka/zadanie1_.../` | Wewnątrz dedykowanego podfolderu `rozwiazanie/` |
| **Zawartość `index.html`** | Kompletna struktura semantyczna z podpiętymi plikami `.css` i `.js` oraz kontenerem `#wynik` | Gotowy plik HTML do weryfikacji i uruchomienia |
| **Zawartość `style.css`** | Gotowy arkusz stylów zapewniający czytelność i regułę `white-space: pre-wrap;` | Identyczny styl wzorcowy |
| **Zawartość `script.js`** | Komentarze prowadzące ucznia krok po kroku (`// KROK 1: ...`, `// KROK 2: ...`) | W 100% działający, przetestowany kod JavaScript |
| **Rola w nauce** | Miejsce samodzielnego pisania kodu przez ucznia | Punkt odniesienia po wykonaniu własnej próby rozwiązania |

---

## 2. Ściąga składniowa modułu T09 (Obiekt `Date`)

### Tworzenie instancji
```javascript
const teraz = new Date(); // Zawsze z operatorem new!
```

### Odczyt składowych daty i czasu
```javascript
const rok = teraz.getFullYear();                  // np. 2026 (pełny rok)
const miesiac = teraz.getMonth() + 1;             // 1 - 12 (getMonth() zwraca 0 - 11!)
const dzienMiesiaca = teraz.getDate();            // 1 - 31 (dzień kalendarzowy)
const dzienTygodnia = teraz.getDay();             // 0 - 6 (0 = Niedziela, 1 = Poniedziałek)

const godzina = teraz.getHours();                 // 0 - 23
const minuta = teraz.getMinutes();                // 0 - 59
const sekunda = teraz.getSeconds();               // 0 - 59
const milisekunda = teraz.getMilliseconds();      // 0 - 999
```

### Data bez dopełniania (format `RRRR-M-D`)
Stosuj, gdy instrukcja **nie** wymaga `padStart` (np. zadanie 1 nauki, zadanie 1 sprawdzianu):
```javascript
const miesiac = teraz.getMonth() + 1;
const dzien = teraz.getDate();
const dataProsta = `${rok}-${miesiac}-${dzien}`; // np. 2026-1-5 lub 2026-10-18
```

### Dopełnianie zerem wiodącym (`padStart`) — format `RRRR-MM-DD` / `GG:MM`
Stosuj **tylko**, gdy instrukcja wymaga zapisu dwucyfrowego:
```javascript
// padStart wymaga konwersji do tekstu za pomocą String(...)
const miesiacZapis = String(teraz.getMonth() + 1).padStart(2, "0");
const dzienZapis = String(teraz.getDate()).padStart(2, "0");
const godzinaZapis = String(teraz.getHours()).padStart(2, "0");
const minutaZapis = String(teraz.getMinutes()).padStart(2, "0");

// Złożenie formatu RRRR-MM-DD GG:MM
const dataFormat = `${rok}-${miesiacZapis}-${dzienZapis} ${godzinaZapis}:${minutaZapis}`;
```

### Lookup w tablicach słownikowych (język polski)
```javascript
const dni = ["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"];
const miesiace = ["stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września", "października", "listopada", "grudnia"];

const nazwaDnia = dni[teraz.getDay()];
const nazwaMiesiaca = miesiace[teraz.getMonth()];
```

---

## 3. Identyfikatory interfejsu (Kamień Milowy Capstone)
W zadaniu przyrostowym oraz ćwiczeniach semestru 2 obowiązuje jednolity kontrakt selektorów wyjściowych:
- `#wynik` — główny kontener prezentacji raportu i danych czasowych (właściwość `.textContent`).

---

## 4. Szybkie przypomnienie (Checklist techniczny)
1. **Narzędzia deweloperskie (F12):** W przypadku braku widocznego wyniku na stronie wciśnij klawisz F12, przejdź do zakładki *Console* i sprawdź, czy skrypt nie zgłasza błędu składniowego.
2. **Ścieżki względne:** Upewnij się, że plik `script.js` jest podpięty w `index.html` przez `<script src="script.js"></script>` i znajduje się w tym samym folderze.
3. **Rygor wyjścia Semestru 2:** Zawsze używaj `document.getElementById("wynik").textContent = ...;` — nie stosuj `document.write` ani `innerHTML`.
4. **Pułapka miesięcy:** Pamiętaj: `teraz.getMonth()` zwraca dla stycznia `0`, a dla grudnia `11`. Dodawaj `+ 1` przed prezentacją numeru miesiąca.
5. **Niedziela na początku tygodnia:** W JavaScript `teraz.getDay() === 0` to niedziela. Sobota to `6`.
6. **Nagłówki raportu:** Kopiuj tytuł **razem** ze znakami `===` dokładnie tak, jak w instrukcji (np. `=== ... ===`).
7. **`padStart` tylko na życzenie instrukcji:** `RRRR-M-D` = bez dopełniania; `GG:MM` / `RRRR-MM-DD` = z `padStart`.
