# Szybka Pomoc Ogólna — Moduł T60: JSON — stringify i parse

---

## 1. Struktura katalogu zadania i pliki

Każde zadanie w module posiada przejrzystą strukturę plików. W katalogu głównym zadania znajduje się szablon roboczy dla ucznia, a w podkatalogu `rozwiazanie/` kompletny, wzorcowy kod referencyjny:

| Plik w folderze roboczym | Rola i przeznaczenie | Odpowiednik w `rozwiazanie/` |
| :--- | :--- | :--- |
| `index.html` | Struktura interfejsu (formularz, kontrolki, `<pre>`, kontenery komunikatów). | Gotowy plik HTML powiązany ze skryptem i stylami. |
| `style.css` | Arkusz stylów CSS (układ, klasy błędów i sukcesu). | Kompletne style wizualne dla aplikacji. |
| `script.js` | Plik skryptu z komentarzami `// KROK N:` do samodzielnego uzupełnienia logiki. | W 100% działający, wzorcowy kod JavaScript. |
| `dane.js` *(gdy występuje)* | Zewnętrzny plik danych startowych (wzorzec CKE). Linkowany przed `script.js`. | Tożsamy plik danych referencyjnych. |
| `instrukcja.md` | Dokładne wytyczne, kroki realizacji oraz sekcja „Treść do wpisania”. | — |

---

## 2. Pigułka składniowa modułu T60

### Serializacja: obiekt / tablica do tekstu JSON
```javascript
// Zamiana obiektu na sformatowany tekst (parametr 2 = wcięcie 2 spacji)
const tekstJson = JSON.stringify(daneObiektu, null, 2);

// Bezpieczne wstawienie podglądu do znacznika <pre>
document.getElementById("podglad").textContent = tekstJson;
```

### Deserializacja: tekst JSON do obiektu z obsługą błędów
```javascript
const poleTekstowe = document.getElementById("wejscie-json");
const komunikatBledu = document.getElementById("blad");

try {
  const surowyTekst = poleTekstowe.value.trim();
  
  if (!surowyTekst) {
    throw new Error("Pole tekstowe jest puste!");
  }

  // Próba przekształcenia napisu w obiekt JS:
  const obiekt = JSON.parse(surowyTekst);
  
  // Sukces:
  komunikatBledu.textContent = "";
  console.log("Sparsowano poprawnie:", obiekt);
  
} catch (blad) {
  // Przechwycenie błędu składni (SyntaxError) lub własnego błędu walidacji:
  komunikatBledu.textContent = `Błąd formatu JSON: ${blad.message}`;
}
```

---

## 3. Szybkie przypomnienie (Checklista programisty)

1. **Podwójne cudzysłowy w JSON:** W formacie JSON klucze oraz wartości tekstowe **zawsze** muszą być ujęte w cudzysłowy `""`. Zapis `{'klucz': 'tekst'}` to błąd składni `SyntaxError`.
2. **Zakaz przecinka na końcu (trailing comma):** Zapis `{"a": 1, "b": 2,}` spowoduje błąd w `JSON.parse()`. Ostatni element pary nie może mieć przecinka.
3. **Zawsze stosuj `try...catch`:** Każde parsowanie tekstu wprowadzonego przez użytkownika za pomocą `JSON.parse()` musi być w bloku `try...catch`. Zapobiega to awarii skryptu przy literówce.
4. **Ochrona przed XSS (`textContent`):** Nigdy nie wstrzykuj danych zdeserializowanego obiektu do `innerHTML`. Dla pól tekstowych zawsze używaj właściwości `element.textContent`.
5. **Formatowanie w `<pre>`:** Aby podgląd JSON zachował wcięcia i podziały wierszy w HTML, wyświetlaj wynik `JSON.stringify(..., null, 2)` w znaczniku `<pre><code>`.
6. **Konsola DevTools (F12):** Używaj skrótu F12 w przeglądarce i zakładki *Console*. Jeśli `JSON.parse()` rzuci błąd, w konsoli zobaczysz dokładny numer wiersza i znaku błędu.
