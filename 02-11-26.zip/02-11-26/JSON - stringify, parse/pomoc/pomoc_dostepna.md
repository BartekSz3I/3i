Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

---

## 1. Słowniczek pojęć modułu

- **JSON:** Tekstowy format zapisu danych. Używa klamer `{}` dla obiektów, nawiasów `[]` dla tablic i podwójnych cudzysłowów `""` dla nazw właściwości oraz tekstów.
- **Serializacja (`JSON.stringify`):** Zamiana obiektu lub tablicy z pamięci JavaScript na zwykły ciąg znaków (tekst).
- **Deserializacja (`JSON.parse`):** Zamiana ciągu znaków w formacie JSON z powrotem na obiekt lub tablicę w pamięci JavaScript.
- **`SyntaxError`:** Błąd składniowy. Występuje, gdy tekst przekazany do `JSON.parse` nie spełnia reguł formatu JSON.
- **Blok `try...catch`:** Konstrukcja ochronna w kodzie. Blok `try` wykonuje próbę parsowania, a blok `catch` przejmuje kontrolę, jeśli wystąpi błąd.
- **XSS (Cross-Site Scripting):** Zagrożenie bezpieczeństwa polegające na wstrzyknięciu złośliwego kodu HTML do strony. Chronimy się przed nim, używając `textContent`.

---

## 2. Kolejność wykonywania każdego zadania

Każde ćwiczenie wykonuj według poniższych czterech kroków:

1. **Krok 1 — Zapoznanie z instrukcją:** Otwórz plik `instrukcja.md` w folderze danego zadania. Przeczytaj cel zadania oraz sekcję „Treść do wpisania”.
2. **Krok 2 — Praca z kodem:** Otwórz pliki `index.html` oraz `script.js` w swoim edytorze kodu. W pliku HTML odszukaj komentarze `<!-- KROK N: ... -->`, a w pliku JS uzupełnij kod w wyznaczonych miejscach `// KROK N: ...`.
3. **Krok 3 — Test w przeglądarce:** Otwórz plik `index.html` w przeglądarce internetowej. Otwórz konsolę klawiszem F12 i przetestuj działanie przycisków oraz wprowadzanie danych.
4. **Krok 4 — Weryfikacja:** Po wykonaniu zadania porównaj swój kod z plikami w podkatalogu `rozwiazanie/`. Sprawdź, czy Twoje rozwiązanie działa identycznie.

---

## 3. Instrukcja krok po kroku — jak napisać operacje JSON

### Jak zamienić obiekt na tekst JSON (Serializacja):
1. Przygotuj obiekt z danymi w zmiennej `const dane = { ... };`.
2. Wywołaj metodę `const tekst = JSON.stringify(dane, null, 2);`.
3. Pobierz element podglądu `const pre = document.getElementById("podglad");`.
4. Wpisz sformatowany tekst do elementu za pomocą `pre.textContent = tekst;`.

### Jak odczytać tekst JSON i zamienić na obiekt (Deserializacja):
1. Pobierz tekst z pola formularza: `const tekst = poleWejsciowe.value.trim();`.
2. Otwórz blok ochronny `try {`.
3. Wewnątrz bloku wywołaj `const obiekt = JSON.parse(tekst);`.
4. Użyj danych z obiektu, np. `wynik.textContent = obiekt.nazwa;`.
5. Zamknij blok `try` i otwórz blok `catch (blad) {`.
6. W bloku `catch` wyświetl komunikat: `komunikatBledu.textContent = "Błąd formatu JSON!";`.
7. Zamknij blok `}`.

---

## 4. Dostępność i czytelność interfejsu (a11y)

1. Każde pole tekstowe `<textarea>` lub `<input>` musi posiadać powiązaną etykietę `<label for="id-pola">`.
2. Komunikaty o błędach składni JSON umieszczaj w dedykowanym elemencie z czytelnym, kontrastowym kolorem tekstu.
3. Elementy `<pre>` prezentujące kod JSON powinny posiadać czytelną czcionkę o stałej szerokości znaków (monospace).
