# Teoria — Moduł T60: JSON — stringify i parse

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Czym jest format JSON i dlaczego jest fundamentem sieci?

W nowoczesnych aplikacjach internetowych dane muszą być nieustannie przesyłane pomiędzy różnymi systemami: z przeglądarki do pamięci podręcznej, z formularza do pliku konfiguracyjnego lub między aplikacją kliencką a serwerem. Obiekt JavaScript przechowywany w pamięci operacyjnej RAM komputera (np. `{ imie: "Anna", wiek: 25 }`) to skomplikowana struktura binarna, powiązana ze wskaźnikami w pamięci silnika V8 przeglądarki. Aby taki obiekt zapisać do pliku tekstowego, wysłać przez sieć lub umieścić w kontrolce formularza, musimy przekształcić go w zwykły ciąg znaków (tekst). Ten proces nazywamy **serializacją**.

Odpowiedzią na tę potrzebę stał się format **JSON (JavaScript Object Notation)**. Jest to lekki, w pełni tekstowy format wymiany danych, czytelny zarówno dla człowieka, jak i dla maszyny. Choć wywodzi się bezpośrednio ze składni literałów obiektowych języka JavaScript, jest formatem całkowicie niezależnym od języka programowania — dane zapisane w JSON mogą być bez trudu odczytane w Pythonie, PHP, Javie, C# czy Go.

```json
{
  "id": 101,
  "nazwa": "Kabel sieciowy UTP Kat. 6",
  "cena": 34.99,
  "dostepny": true,
  "kategorie": ["Sieci", "Okablowanie"],
  "parametry": {
    "dlugosc": 10,
    "kolor": "szary"
  },
  "uwagi": null
}
```

> **Po co to jest:**  
> JSON jest uniwersalnym standardem zapisu danych w postaci tekstowej. Pozwala zamienić złożony obiekt z pamięci programu na prosty napis, który można łatwo zapisać, podejrzeć, przesłać lub przekazać między różnymi modułami aplikacji.

> **Typowa pomyłka:**  
> Mylenie formatu JSON z obiektem JavaScript. JSON nie jest obiektem w pamięci — **JSON jest zawsze ciągiem znaków (stringiem)** o ściśle określonej składni.

---

## 2. Rygor składniowy formatu JSON — czym różni się od literału JS?

W języku JavaScript literały obiektowe są bardzo elastyczne: klucze mogą być pisane bez cudzysłowów, łańcuchy znaków można ujmować w apostrofy (`'tekst'`), a w strukturze mogą znajdować się funkcje czy komentarze. **W formacie JSON panuje absolutny, bezwzględny rygor:**

1. **Klucze właściwości:** Każdy klucz w obiekcie JSON **musi** być ujęty w podwójne cudzysłowy `""`. Brak cudzysłowu lub użycie pojedynczych apostrofów to błąd składni.
2. **Łańcuchy znaków (stringi):** Wszystkie wartości tekstowe **muszą** być ujęte wyłącznie w podwójne cudzysłowy `""`. Pojedyncze apostrofy `''` są w formacie JSON niedozwolone!
3. **Dozwolone typy danych:** W formacie JSON można zapisać wyłącznie:
   - `string` (tekst w cudzysłowach `""`),
   - `number` (liczby całkowite i zmiennoprzecinkowe, np. `42`, `3.14`),
   - `boolean` (`true` lub `false`),
   - `null` (wartość pusta/brak danych),
   - `array` (tablica uporządkowana `[...]`),
   - `object` (obiekt z parami klucz-wartość `{...}`).
4. **Niedozwolone w JSON:**
   - Wartość `undefined`,
   - Funkcje i metody (`function() {}`, `() => {}`),
   - Symbole (`Symbol`),
   - Komentarze jednoliniowe (`//`) i wieloliniowe (`/* */`),
   - Przecinek na końcu ostatniego elementu tablicy lub obiektu (tzw. *trailing comma*) — w JSON jest to błąd krytyczny!

| Cecha / Składnia | Literał obiektu JavaScript | Format JSON |
| :--- | :--- | :--- |
| Cudzysłowy przy kluczach | Opcjonalne (`{ cena: 10 }`) | **Bezwzględnie wymagane podwójne** (`{ "cena": 10 }`) |
| Apostrofy w stringach | Dozwolone (`'Warszawa'`) | **Zabronione** (tylko `"Warszawa"`) |
| Funkcje / metody | Dozwolone | **Niedozwolone** |
| Wartość `undefined` | Dozwolona | **Niedozwolona** |
| Komentarze w kodzie | Dozwolone (`// notatka`) | **Zabronione** |
| Przecinek na końcu listy | Dozwolony (`{ a: 1, }`) | **Zabroniony (błąd parsowania)** |

> **Po co to jest:**  
> Rygorystyczna specyfikacja formatu JSON gwarantuje, że plik lub ciąg tekstowy wygenerowany w jednym systemie zostanie bezbłędnie zinterpretowany przez dowolny inny program na świecie bez dwuznaczności składniowych.

> **Typowa pomyłka:**  
> Pozostawienie przecinka po ostatnim elemencie obiektu (np. `{"a": 1, "b": 2,}`). W kodzie JS przeglądarka to wybaczy, ale parser JSON natychmiast zgłosi błąd `SyntaxError`.

---

## 3. Serializacja danych: `JSON.stringify()`

Aby zamienić strukturę danych znajdującą się w pamięci JavaScript (liczbę, napis, tablicę lub obiekt) na ciąg tekstowy zgodny ze specyfikacją JSON, używamy wbudowanej metody **`JSON.stringify()`**.

### Podstawowe użycie

```javascript
const produkt = {
  id: 1,
  nazwa: "Monitor biurowy 24 cale",
  cena: 599.99,
  dostepny: true
};

const jsonTekst = JSON.stringify(produkt);
console.log(jsonTekst);
// Wynik: '{"id":1,"nazwa":"Monitor biurowy 24 cale","cena":599.99,"dostepny":true}'
```

Zwróć uwagę, że zmienna `jsonTekst` jest zwykłym łańcuchem znaków (`typeof jsonTekst === "string"`), a silnik automatycznie dodał podwójne cudzysłowy wokół wszystkich nazw kluczy.

### Formatowanie czytelne dla człowieka: parametr `space`

Gdy wypisujemy wygenerowany ciąg JSON na stronie WWW (np. w znaczniku `<pre><code>`) lub logujemy do celów inspekcyjnych, zbity ciąg bez spacji jest trudny do odczytania. Metoda `JSON.stringify` przyjmuje trzy parametry:
`JSON.stringify(wartosc, replacer, wciecie)`.

Przekazanie liczby (np. `2` lub `4`) jako trzeciego parametru powoduje sformatowanie tekstu z estetycznymi wcięciami i podziałem na wiersze:

```javascript
const konfiguracja = {
  tryb: "produkcja",
  powiadomienia: true,
  limity: { maxProb: 3, timeoutMs: 5000 }
};

// Formatowanie z wcięciem 2 spacji
const czytelnyJson = JSON.stringify(konfiguracja, null, 2);

// Bezpieczne wstawienie sformatowanego tekstu do elementu <pre>
const prePodglad = document.getElementById("podglad-json");
prePodglad.textContent = czytelnyJson;
```

Zawartość elementu `<pre>` będzie wyglądać następująco:
```json
{
  "tryb": "produkcja",
  "powiadomienia": true,
  "limity": {
    "maxProb": 3,
    "timeoutMs": 5000
  }
}
```

### Jak `JSON.stringify()` traktuje wartości specjalne?

Podczas przekształcania obiektu na JSON, silnik JavaScript napotyka wartości, których specyfikacja JSON nie obsługuje:
- **W obiektach:** Właściwości przechowujące `undefined`, funkcje lub symbole są **całkowicie pomijane** (usuwane z wynikowego napisu).
- **W tablicach:** Elementy o wartości `undefined` lub funkcje są **zamieniane na wartość `null`**, aby zachować prawidłowe indeksy pozostałych elementów.

```javascript
const uzytkownik = {
  imie: "Marek",
  pensja: undefined,       // zostanie usunięte
  obliczPremie: () => 500  // zostanie usunięte
};

console.log(JSON.stringify(uzytkownik));
// Wynik: '{"imie":"Marek"}'

const lista = [10, undefined, "test", () => {}];
console.log(JSON.stringify(lista));
// Wynik: '[10,null,"test",null]'
```

> **Po co to jest:**  
> Metoda `JSON.stringify()` pozwala automatycznie przygotować stan danych aplikacji do eksportu, zapisu lub prezentacji w postaci tekstowej bez konieczności ręcznego sklejania łańcuchów znaków.

> **Typowa pomyłka:**  
> Próba serializacji obiektu o strukturze cyklicznej (obiekt `A` wskazuje na obiekt `B`, a obiekt `B` wskazuje z powrotem na obiekt `A`). Taka operacja kończy się błędem `TypeError: Converting circular structure to JSON`.

---

## 4. Deserializacja danych: `JSON.parse()`

Operacją odwrotną do serializacji jest **deserializacja** — odczytanie ciągu tekstowego JSON i zrekonstruowanie w pamięci operacyjnej gotowego obiektu lub tablicy JavaScript. Służy do tego metoda **`JSON.parse()`**.

```javascript
const surowyTekst = '{"id":45,"tytul":"Wymiana oleju","koszt":150}';

const rekord = JSON.parse(surowyTekst);

console.log(rekord.id);     // 45 (liczba)
console.log(rekord.tytul);  // "Wymiana oleju" (string)
console.log(rekord.koszt);  // 150 (liczba)
```

Po wykonaniu `JSON.parse()` otrzymujemy pełnoprawny obiekt JavaScript. Możemy odczytywać jego właściwości operatorem kropki (`rekord.tytul`), modyfikować je, dodawać do tablic czy przekazywać do funkcji renderujących widok DOM.

---

## 5. Bezpieczna obsługa błędów: blok `try...catch`

Gdy dane JSON pochodzą z zewnątrz — np. z pola tekstowego formularza `<textarea>`, do którego użytkownik wkleja konfigurację — **nie mamy żadnej gwarancji**, że tekst jest poprawny składniowo.

Jeśli przekażemy do `JSON.parse()` niepoprawny ciąg znaków (np. literówkę, brak cudzysłowu, pojedynczy apostrof lub pusty ciąg), metoda natychmiast rzuci krytyczny błąd: **`SyntaxError`**. Jeśli ten błąd nie zostanie obsłużony, wykonywanie całego skryptu zostanie gwałtownie przerwane, a strona przestanie reagować na akcje użytkownika.

Aby temu zapobiec, każde wywołanie `JSON.parse()` operujące na danych wejściowych od użytkownika **musi być bezwzględnie zabezpieczone blokiem `try...catch`**:

```javascript
const poleTekstowe = document.getElementById("dane-json");
const kontenerBledu = document.getElementById("komunikat-bledu");
const kontenerWyniku = document.getElementById("podglad-obiektu");

try {
  // Próba odczytania i sparsowania tekstu wprowadzonego przez użytkownika
  const wprowadzonyTekst = poleTekstowe.value.trim();
  
  if (wprowadzonyTekst === "") {
    throw new Error("Pole danych JSON nie może być puste.");
  }

  const sparsowaneDane = JSON.parse(wprowadzonyTekst);

  // Jeśli kod dotarł tutaj, parsowanie zakończyło się pełnym sukcesem!
  kontenerBledu.textContent = "";
  kontenerBledu.classList.remove("aktywny-blad");
  
  console.log("Dane sparsowane pomyślnie:", sparsowaneDane);
  
} catch (blad) {
  // Blok catch przechwytuje zarówno SyntaxError z JSON.parse, jak i nasz rzucony Error
  kontenerBledu.textContent = `Błąd formatu JSON: ${blad.message}`;
  kontenerBledu.classList.add("aktywny-blad");
  console.error("Nie udało się przetworzyć danych JSON:", blad);
}
```

### Mechanizm działania `try...catch`:
1. Blok `try { ... }` zawiera kod, w którym może wystąpić błąd wykonania.
2. Jeśli wewnątrz bloku `try` zostanie rzucony wyjątek (np. błąd składni `SyntaxError`), JavaScript natychmiast przerywa dalsze instrukcje w bloku `try` i bezpiecznie przekazuje sterowanie do bloku `catch (blad) { ... }`.
3. Skrypt nie zawiesza się — aplikacja działa dalej, a my możemy wyświetlić użytkownikowi zrozumiały komunikat z informacją, co poszło nie tak.

> **Po co to jest:**  
> Blok `try...catch` to mechanizm obronny aplikacji. Chroni przeglądarkę przed awarią przy próbie przetworzenia uszkodzonych danych tekstowych i pozwala obsłużyć błąd w cywilizowany sposób w interfejsie użytkownika.

> **Typowa pomyłka:**  
> Wywołanie `JSON.parse(pole.value)` bezpośrednio bez bloku `try...catch`. Przy pierwszym niepoprawnym znaku (np. brakującym nawiasie klamrowym) cała strona przestaje działać.

---

## 6. Bezpieczeństwo DOM i bezwzględna ochrona przed atakami XSS

Częstym zastosowaniem formatu JSON jest import danych: użytkownik wkleja zserializowany rekord lub listę, aplikacja parsuje tekst do tablicy obiektów, a następnie wyświetla te informacje w tabeli lub na kartach.

W tym momencie pojawia się krytyczne zagrożenie bezpieczeństwa: **atak XSS (Cross-Site Scripting)**. Jeśli ciąg JSON zawiera złośliwy kod wstrzyknięty przez atakującego, np.:
```json
{
  "nazwisko": "<img src=x onerror='alert(\"Atak XSS!\")'>"
}
```
i wstawimy tę wartość do drzewa DOM za pomocą `element.innerHTML`:
```javascript
// BŁĄD KRYTYCZNY! PODATNOŚĆ NA XSS!
tabela.innerHTML = `<tr><td>${rekord.nazwisko}</td></tr>`;
```
przeglądarka zinterpretuje wstrzyknięty tekst jako kod HTML i wykona niebezpieczny skrypt w kontekście sesji użytkownika!

### Zasada bezpiecznego renderowania danych ze sparsowanego JSON:
1. Wszystkie pola tekstowe pochodzące z obiektu JSON **zawsze** przypisujemy za pomocą **`element.textContent`** — przeglądarka potraktuje wszelkie tagi `<script>` czy `<img>` jako zwykłe, nieszkodliwe litery i nie wykona w nich żadnego kodu.
2. Alternatywnie stosujemy bezpieczne tworzenie węzłów: **`document.createElement()`** oraz **`document.createTextNode()`**.

```javascript
// BEZPIECZNE RENDEROWANIE Z OCHRONĄ PRZED XSS:
function renderujWizytowke(rekord, kontener) {
  kontener.replaceChildren(); // czyszczenie kontenera

  const karta = document.createElement("div");
  karta.className = "karta-uzytkownika";

  const naglowek = document.createElement("h3");
  // Bezpieczne wstawienie tekstu - ochrona przed XSS!
  naglowek.textContent = rekord.nazwisko;

  const opis = document.createElement("p");
  opis.textContent = `Stanowisko: ${rekord.stanowisko}`;

  karta.append(naglowek, opis);
  kontener.append(karta);
}
```

> **Po co to jest:**  
> Rygorystyczne stosowanie `textContent` eliminuje podatność XSS. Dane pochodzące z zewnątrz mogą zawierać złośliwy kod, ale traktowane jako zwykły tekst są w 100% bezpieczne.

> **Typowa pomyłka:**  
> Łączenie surowych wartości zdeserializowanego obiektu bezpośrednio z szablonem `innerHTML` bez uprzedniej walidacji i zabezpieczenia.

---

## 7. Podsumowanie składniowe modułu T60

```javascript
// 1. Serializacja z wcięciem 2 spacji (obiekt -> sformatowany tekst)
const tekstJson = JSON.stringify(obiektDanych, null, 2);

// 2. Bezpieczna deserializacja (tekst -> obiekt) z blokiem try...catch
try {
  const obiekt = JSON.parse(tekstJson);
  // Operacje na sparsowanym obiekcie...
} catch (blad) {
  console.error("Błąd składni JSON:", blad.message);
}

// 3. Bezpieczne wypisanie w DOM
podgladPre.textContent = tekstJson;
```
