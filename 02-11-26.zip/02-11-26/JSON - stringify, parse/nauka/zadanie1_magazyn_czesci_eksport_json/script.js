// Zadanie 1: Magazyn Części — Eksport JSON (Szablon ucznia)

const formCzesc = document.getElementById("form-czesc");
const poleNazwa = document.getElementById("pole-nazwa");
const wyborKategoria = document.getElementById("wybor-kategoria");
const poleIlosc = document.getElementById("pole-ilosc");
const poleCena = document.getElementById("pole-cena");
const podgladJson = document.getElementById("podglad-json");

formCzesc.addEventListener("submit", (e) => {
  // KROK 1: Zablokuj domyślne przeładowanie strony
  e.preventDefault();

  // KROK 2: Odczytaj wartości i dokonaj konwersji typów (Number dla ilości i ceny)
  // Twoje rozwiazanie:

  // KROK 3: Zbuduj obiekt modelu danych czesc z unikalnym id: Date.now()
  // oraz polami: nazwa, kategoria, stanMagazynowy, cenaNetto, dostepny (boolean)
  // Twoje rozwiazanie:

  // KROK 4: Użyj metody JSON.stringify(czesc, null, 2) do serializacji
  // i przypisz wynik do podgladJson.textContent
  // Twoje rozwiazanie:

});
