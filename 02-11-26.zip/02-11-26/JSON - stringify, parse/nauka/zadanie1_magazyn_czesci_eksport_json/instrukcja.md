# Zadanie 1: Magazyn Części — Eksport karty produktu do formatu JSON

W tym zadaniu zapoznasz się z podstawową operacją formatu JSON: **serializacją** danych za pomocą wbudowanej metody `JSON.stringify()`. Twoim celem jest pobranie danych o pojedynczej części magazynowej z formularza, utworzenie obiektu modelu danych JavaScript, a następnie przekształcenie go w sformatowany ciąg tekstowy JSON i wyświetlenie go w bloku podglądu `<pre><code>`.

---

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)

- **Systemy magazynowe WMS (np. Subiekt GT, SAP, BaseLinker):** Przygotowanie pojedynczego rekordu towaru do eksportu do pliku konfiguracyjnego lub przekazania do czytnika kodów kreskowych.
- **Formularze administracyjne sklepów e-commerce (np. Shopify, WooCommerce):** Generowanie podglądu technicznego danych produktu przed ich zatwierdzeniem.
- **Konsola deweloperska i narzędzia diagnostyczne:** Wyświetlanie aktualnego stanu formularza w czytelnej postaci tekstowej do celów testowych.

---

## Wymagania funkcjonalne

1. **Struktura strony (`index.html`):** Formularz z identyfikatorem `#form-czesc` zawierający kontrolki:
   - Nazwa części: `#pole-nazwa` (tekst, np. `Dysk SSD NVMe 1TB`),
   - Kategoria: `#wybor-kategoria` (lista rozwijana `<select>` z opcjami: `Dyski`, `Pamięci RAM`, `Karty graficzne`),
   - Ilość sztuk: `#pole-ilosc` (pole numeryczne, np. `15`),
   - Cena jednostkowa: `#pole-cena` (pole numeryczne z krokiem `0.01`, np. `329.99`),
   - Przycisk submit: `#btn-generuj` z tekstem z sekcji treści do wpisania.
   - Poniżej formularza blok podglądu `<pre><code id="podglad-json"></code></pre>`.
2. **Obsługa zdarzenia `submit` (`script.js`):**
   - Podepnij nasłuchiwanie zdarzenia `submit` na elemencie `#form-czesc`.
   - Zablokuj domyślne przeładowanie strony metodą `e.preventDefault()`.
3. **Konwersja danych i utworzenie obiektu modelu:**
   - Odczytaj wartości pól i dokonaj konwersji typów:
     - `nazwa`: `poleNazwa.value.trim()`,
     - `kategoria`: `wyborKategoria.value`,
     - `ilosc`: `Number(poleIlosc.value)`,
     - `cena`: `Number(poleCena.value)`.
   - Zbuduj obiekt JavaScript:
     ```javascript
     const czesc = {
       id: Date.now(),
       nazwa: nazwa,
       kategoria: kategoria,
       stanMagazynowy: ilosc,
       cenaNetto: cena,
       dostepny: ilosc > 0
     };
     ```
4. **Serializacja i prezentacja w DOM:**
   - Przekształć obiekt `czesc` do ciągu tekstowego JSON za pomocą metody `JSON.stringify(czesc, null, 2)` (zastosuj wcięcie 2 spacji).
   - Wstaw uzyskany ciąg do elementu `#podglad-json` za pomocą właściwości `textContent`.

---

## Treść do wpisania

Wprowadź do interfejsu następujące dosłowne napisy:
- Tytuł nagłówka `<h1>`: `"Magazyn Części Komputerowych — Eksport JSON"`
- Etykieta przycisku submit: `"Wygeneruj sformatowany podgląd JSON"`
- Początkowy tekst w bloku podglądu przed generacją: `"Kliknij przycisk, aby wygenerować ciąg JSON..."`

---

## Instrukcja krok po kroku

1. Otwórz plik `index.html` i zapoznaj się ze strukturą formularza oraz blokiem `<pre><code>`.
2. Otwórz plik `script.js` i pobierz referencje do formularza, kontrolek oraz kontenera `#podglad-json`.
3. Dodaj nasłuchiwacz zdarzenia `submit` z `e.preventDefault()`.
4. Pobierz wartości kontrolek, dokonaj jawnej konwersji liczb funkcją `Number()` i utwórz obiekt `czesc`.
5. Zastosuj metodę `JSON.stringify(czesc, null, 2)` i przypisz wynik do `textContent` bloku podglądu.
6. Otwórz stronę w przeglądarce, wypełnij pola i sprawdź, czy w podglądzie pojawia się sformatowany JSON.
