# Zadanie 4: Serwis Urządzeń — Eksport i import zgłoszeń serwisowych w formacie JSON (Zadanie integrujące)

W tym zadaniu połączysz wszystkie umiejętności poznane w zadaniach 1–3 w spójną, kompletną mini-aplikację. Stworzysz interfejs rejestracji zgłoszeń naprawy sprzętu elektronicznego, w którym stan danych przechowywany jest w tablicy obiektów w pamięci RAM. Aplikacja umożliwi dodawanie nowych urządzeń do tabeli, wyeksportowanie całej bieżącej listy do formatu JSON (`JSON.stringify`), a także wczytanie (import) zewnętrznego ciągu JSON za pomocą metody `JSON.parse()` z rygorystyczną obsługą błędów w bloku `try...catch` i dynamicznym re-renderem tabeli.

---

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)

- **Systemy serwisowe (RMA, Helpdesk):** Przekazywanie paczek zgłoszeń reklamacyjnych między oddziałami lub eksport do formatu wymiany danych.
- **Aplikacje typu Todo i Task Manager (np. Trello, Todoist):** Narzędzie „Import / Export” pozwalające użytkownikowi na pobranie kopii zapasowej swoich zadań lub zaimportowanie gotowej listy projektowej.
- **Narzędzia konfiguracji sprzętowej:** Szybkie przenoszenie listy zdiagnozowanych usterek między technikami.

---

## Wymagania funkcjonalne

1. **Struktura strony (`index.html`):**
   - Formularz dodawania zgłoszenia `#form-serwis`:
     - Klient: `<input type="text" id="pole-klient" required placeholder="np. Jan Kowalski">`,
     - Sprzęt: `<input type="text" id="pole-sprzet" required placeholder="np. Laptop Lenovo ThinkPad">`,
     - Koszt szacunkowy (zł): `<input type="number" id="pole-koszt" required min="10" value="250">`,
     - Przycisk submit: `<button type="submit" id="btn-dodaj">Dodaj zgłoszenie do listy</button>`.
   - Tabela zgłoszeń `#tabela-zgloszen` z nagłówkami: ID, Klient, Sprzęt, Szacowany koszt (zł) oraz ciałem tabeli `<tbody id="cialo-tabeli"></tbody>`.
   - Sekcja wymiany danych JSON:
     - Pole wielowierszowe: `<textarea id="pole-json" rows="6" placeholder="Tutaj pojawi się wyeksportowany JSON lub wklej dane do importu..."></textarea>`,
     - Przycisk eksportu: `<button type="button" id="btn-eksport">Eksportuj aktualną listę do JSON</button>`,
     - Przycisk importu: `<button type="button" id="btn-import">Wczytaj listę z formatu JSON</button>`,
     - Kontener na komunikaty: `<div id="komunikat-operacji" class="komunikat ukryty"></div>`.
2. **Stan aplikacji w pamięci RAM (`script.js`):**
   - Zainicjalizuj tablicę obiektów `let listaZgloszen = [];` z dwoma rekordami początkowymi.
3. **Funkcja renderująca `renderujTabele()`:**
   - Wyczyść zawartość `#cialo-tabeli` metodą `replaceChildren()`.
   - Przeiteruj po `listaZgloszen` metodą `forEach()` i dynamicznie wygeneruj wiersze `<tr>` oraz komórki `<td>`.
   - **Rygor bezpieczeństwa XSS:** Wartości tekstowe (`klient`, `sprzet`) przypisuj do komórek wyłącznie za pomocą `textContent`.
4. **Obsługa formularza dodawania rekordu (`submit`):**
   - Zablokuj domyślne przeładowanie strony metodą `e.preventDefault()`.
   - Pobierz i zwaliduj wartości kontrolek, utwórz obiekt zgłoszenia z unikalnym `id: Date.now()`, dodaj do `listaZgloszen` metodą `push()`.
   - Zresetuj formularz metodą `form.reset()` i odśwież widok tabeli.
5. **Eksport do JSON (`#btn-eksport`):**
   - Po kliknięciu wygeneruj sformatowany ciąg JSON z tablicy `listaZgloszen` za pomocą `JSON.stringify(listaZgloszen, null, 2)`.
   - Wstaw wygenerowany tekst do pola `#pole-json`.
   - Wyświetl w `#komunikat-operacji` informację o sukcesie eksportu.
6. **Import z JSON (`#btn-import`):**
   - Po kliknięciu odczytaj tekst z `#pole-json`.
   - W bloku `try`:
     - Sprawdź, czy tekst nie jest pusty (`throw new Error("Pole tekstowe JSON jest puste.")`).
     - Wywołaj `const zaimportowane = JSON.parse(tekst)`.
     - Sprawdź, czy `Array.isArray(zaimportowane)` ma wartość `true` oraz czy elementy mają pola `klient`, `sprzet`, `koszt`.
     - Jeśli walidacja się powiedzie: nadpisz `listaZgloszen = zaimportowane;`, wywołaj `renderujTabele()` i wyświetl komunikat o sukcesie importu.
   - W bloku `catch (blad)`:
     - Wyświetl komunikat błędu: `"Błąd importu JSON: " + blad.message` w `#komunikat-operacji`.

---

## Treść do wpisania

Wprowadź do interfejsu następujące dosłowne napisy:
- Tytuł nagłówka `<h1>`: `"Autoryzowany Serwis Urządzeń — Eksport i Import Zgłoszeń"`
- Tekst przycisku dodawania: `"Dodaj zgłoszenie do listy"`
- Tekst przycisku eksportu: `"Eksportuj aktualną listę do JSON"`
- Tekst przycisku importu: `"Wczytaj listę z formatu JSON"`
- Komunikat po udanym eksporcie: `"Dane zgłoszeń zostały pomyślnie wyeksportowane do formatu JSON."`
- Komunikat po udanym imporcie: `"Baza zgłoszeń została pomyślnie zaimportowana i zaktualizowana."`

---

## Instrukcja krok po kroku

1. Otwórz plik `index.html` i przejrzyj strukturę formularza, tabeli oraz sekcji JSON.
2. W pliku `script.js` zainicjalizuj tablicę `listaZgloszen` i zaimplementuj czystą funkcję `renderujTabele()`.
3. Obsłuż zdarzenie `submit` formularza: dodanie nowego obiektu i odświeżenie tabeli.
4. Obsłuż kliknięcie `#btn-eksport`: serializacja `listaZgloszen` za pomocą `JSON.stringify()` do pola `<textarea>`.
5. Obsłuż kliknięcie `#btn-import`: deserializacja tekstu z `<textarea>` za pomocą `JSON.parse()` w bloku `try...catch`.
6. Przetestuj działanie w przeglądarce: dodaj nowe zgłoszenie, kliknij eksport, zmodyfikuj dane w polu tekstowym i kliknij import. Sprawdź także reakcję na uszkodzony ciąg znaków (np. usunięcie klamry).
