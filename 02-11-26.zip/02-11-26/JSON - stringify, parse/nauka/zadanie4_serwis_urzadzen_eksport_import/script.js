// Zadanie 4: Serwis Urządzeń — Eksport i Import JSON (Szablon ucznia)

// Stan aplikacji w pamięci RAM
let listaZgloszen = [
  { id: 101, klient: "Anna Nowak", sprzet: "Smartfon Samsung Galaxy", koszt: 180 },
  { id: 102, klient: "Piotr Wiśniewski", sprzet: "Drukarka laserowa HP", koszt: 120 }
];

const formSerwis = document.getElementById("form-serwis");
const poleKlient = document.getElementById("pole-klient");
const poleSprzet = document.getElementById("pole-sprzet");
const poleKoszt = document.getElementById("pole-koszt");
const cialoTabeli = document.getElementById("cialo-tabeli");

const poleJson = document.getElementById("pole-json");
const btnEksport = document.getElementById("btn-eksport");
const btnImport = document.getElementById("btn-import");
const komunikatOperacji = document.getElementById("komunikat-operacji");

function wyswietlKomunikat(tresc, czySukces) {
  komunikatOperacji.textContent = tresc;
  komunikatOperacji.className = `komunikat ${czySukces ? "sukces" : "blad"}`;
}

// Funkcja renderująca tabelę zgłoszeń (ochrona przed XSS z textContent)
function renderujTabele() {
  cialoTabeli.replaceChildren();

  listaZgloszen.forEach(zgloszenie => {
    const wiersz = document.createElement("tr");

    const komId = document.createElement("td");
    komId.textContent = zgloszenie.id;

    const komKlient = document.createElement("td");
    komKlient.textContent = zgloszenie.klient;

    const komSprzet = document.createElement("td");
    komSprzet.textContent = zgloszenie.sprzet;

    const komKoszt = document.createElement("td");
    komKoszt.textContent = `${Number(zgloszenie.koszt).toFixed(2)} zł`;

    wiersz.append(komId, komKlient, komSprzet, komKoszt);
    cialoTabeli.append(wiersz);
  });
}

// Obsługa formularza dodawania zgłoszenia
formSerwis.addEventListener("submit", (e) => {
  e.preventDefault();

  const nowyRekord = {
    id: Date.now(),
    klient: poleKlient.value.trim(),
    sprzet: poleSprzet.value.trim(),
    koszt: Number(poleKoszt.value)
  };

  listaZgloszen.push(nowyRekord);
  formSerwis.reset();
  renderujTabele();
});

// KROK 1: TODO — Obsługa przycisku eksportu do JSON (#btn-eksport)
// 1. Użyj JSON.stringify(listaZgloszen, null, 2)
// 2. Wstaw wynik do poleJson.value
// 3. Wywołaj wyswietlKomunikat("Dane zgłoszeń zostały pomyślnie wyeksportowane do formatu JSON.", true)
btnEksport.addEventListener("click", () => {
  // Twój kod tutaj:
});

// KROK 2: TODO — Obsługa przycisku importu z JSON (#btn-import)
// 1. W bloku try odczytaj poleJson.value.trim()
// 2. Sprawdź czy tekst nie jest pusty
// 3. Wywołaj JSON.parse(tekst)
// 4. Sprawdź czy to poprawna tablica (Array.isArray)
// 5. Zaktualizuj listaZgloszen, wywołaj renderujTabele() i wyświetl komunikat sukcesu:
//    "Baza zgłoszeń została pomyślnie zaimportowana i zaktualizowana."
// 6. W bloku catch(blad) wyświetl komunikat błędu: "Błąd importu JSON: " + blad.message
btnImport.addEventListener("click", () => {
  // Twój kod tutaj:
});

// Startowe odrysowanie tabeli
renderujTabele();
