// Zadanie 5: Portal IT-Partner — Kopia Zapasowa JSON (Szablon Capstone)

// 1. Stan aplikacji w pamięci RAM (Zasada Zero Regresji)
let rejestrZlecen = [
  {
    id: 1,
    klient: "Tech-Solutions Sp. z o.o.",
    kategoria: "Administracja serwerami",
    godziny: 10,
    stawka: 160,
    priorytet: false,
    kosztLaczny: 1600.00
  },
  {
    id: 2,
    klient: "Logistyka Polska S.A.",
    kategoria: "Wdrożenie sieci LAN/WAN",
    godziny: 15,
    stawka: 180,
    priorytet: true,
    kosztLaczny: 3510.00 // 15 * 180 * 1.3
  }
];

let edytowaneZlecenieId = null;

// Referencje DOM — Formularz i Tabela
const formZlecenie = document.getElementById("form-zlecenie");
const poleKlient = document.getElementById("pole-klient");
const wyborKategorii = document.getElementById("wybor-kategorii");
const poleGodziny = document.getElementById("pole-godziny");
const poleStawka = document.getElementById("pole-stawka");
const polePriorytet = document.getElementById("pole-priorytet");
const btnZapisz = document.getElementById("btn-zapisz");
const btnAnuluj = document.getElementById("btn-anuluj");

const cialoZlecenia = document.getElementById("cialo-zlecenia");
const pasekPodsumowania = document.getElementById("pasek-podsumowania");

// Referencje DOM — Kopia Zapasowa JSON
const poleKopiaJson = document.getElementById("pole-kopia-json");
const btnKopiaEksport = document.getElementById("btn-kopia-eksport");
const btnKopiaImport = document.getElementById("btn-kopia-import");
const komunikatKopii = document.getElementById("komunikat-kopii");

function wyswietlKomunikatKopii(tresc, czySukces) {
  komunikatKopii.textContent = tresc;
  komunikatKopii.className = `komunikat ${czySukces ? "sukces" : "blad"}`;
}

// 2. Aktualizacja paska podsumowania finansowego
function aktualizujPodsumowanie() {
  const sumaWartosci = rejestrZlecen.reduce((suma, z) => suma + z.kosztLaczny, 0);
  pasekPodsumowania.textContent = `Łączna wartość aktywnych zleceń: ${sumaWartosci.toFixed(2)} zł | Liczba zleceń: ${rejestrZlecen.length}`;
}

// 3. Renderowanie widoku tabeli (ochrona przed XSS przez textContent)
function renderujZlecenia() {
  cialoZlecenia.replaceChildren();

  rejestrZlecen.forEach(zlecenie => {
    const wiersz = document.createElement("tr");

    const komId = document.createElement("td");
    komId.textContent = zlecenie.id;

    const komKlient = document.createElement("td");
    komKlient.textContent = zlecenie.klient;

    const komKategoria = document.createElement("td");
    komKategoria.textContent = zlecenie.kategoria;

    const komGodziny = document.createElement("td");
    komGodziny.textContent = zlecenie.godziny;

    const komStawka = document.createElement("td");
    komStawka.textContent = `${Number(zlecenie.stawka).toFixed(2)} zł`;

    const komKoszt = document.createElement("td");
    komKoszt.textContent = `${Number(zlecenie.kosztLaczny).toFixed(2)} zł`;

    const komOperacje = document.createElement("td");
    
    const btnEdytuj = document.createElement("button");
    btnEdytuj.type = "button";
    btnEdytuj.className = "btn-edytuj";
    btnEdytuj.textContent = "Edytuj";
    btnEdytuj.dataset.id = zlecenie.id;

    const btnUsun = document.createElement("button");
    btnUsun.type = "button";
    btnUsun.className = "btn-usun";
    btnUsun.textContent = "Usuń";
    btnUsun.dataset.id = zlecenie.id;

    komOperacje.append(btnEdytuj, btnUsun);
    wiersz.append(komId, komKlient, komKategoria, komGodziny, komStawka, komKoszt, komOperacje);
    cialoZlecenia.append(wiersz);
  });

  aktualizujPodsumowanie();
}

// 4. Delegacja zdarzeń na tabeli (Edycja i Usuwanie)
cialoZlecenia.addEventListener("click", (e) => {
  const target = e.target;

  if (target.classList.contains("btn-usun")) {
    const id = Number(target.dataset.id);
    rejestrZlecen = rejestrZlecen.filter(z => z.id !== id);
    if (edytowaneZlecenieId === id) {
      anulujEdycje();
    }
    renderujZlecenia();
  } else if (target.classList.contains("btn-edytuj")) {
    const id = Number(target.dataset.id);
    const zlecenie = rejestrZlecen.find(z => z.id === id);
    if (zlecenie) {
      edytowaneZlecenieId = id;
      poleKlient.value = zlecenie.klient;
      wyborKategorii.value = zlecenie.kategoria;
      poleGodziny.value = zlecenie.godziny;
      poleStawka.value = zlecenie.stawka;
      polePriorytet.checked = zlecenie.priorytet;

      btnZapisz.textContent = "Zapisz zmiany w zleceniu";
      btnAnuluj.classList.remove("ukryty");
    }
  }
});

function anulujEdycje() {
  edytowaneZlecenieId = null;
  formZlecenie.reset();
  btnZapisz.textContent = "Dodaj zlecenie do rejestru";
  btnAnuluj.classList.add("ukryty");
}

btnAnuluj.addEventListener("click", anulujEdycje);

// 5. Obsługa formularza dodawania i edycji (submit)
formZlecenie.addEventListener("submit", (e) => {
  e.preventDefault();

  const godziny = Number(poleGodziny.value);
  const stawka = Number(poleStawka.value);
  const priorytet = polePriorytet.checked;
  const koszt = godziny * stawka * (priorytet ? 1.3 : 1.0);

  if (edytowaneZlecenieId !== null) {
    const zlecenie = rejestrZlecen.find(z => z.id === edytowaneZlecenieId);
    if (zlecenie) {
      zlecenie.klient = poleKlient.value.trim();
      zlecenie.kategoria = wyborKategorii.value;
      zlecenie.godziny = godziny;
      zlecenie.stawka = stawka;
      zlecenie.priorytet = priorytet;
      zlecenie.kosztLaczny = koszt;
    }
    anulujEdycje();
  } else {
    const noweZlecenie = {
      id: Date.now(),
      klient: poleKlient.value.trim(),
      kategoria: wyborKategorii.value,
      godziny: godziny,
      stawka: stawka,
      priorytet: priorytet,
      kosztLaczny: koszt
    };
    rejestrZlecen.push(noweZlecenie);
    formZlecenie.reset();
  }

  renderujZlecenia();
});

// KROK 6: TODO — Obsługa przycisku eksportu kopii zapasowej (#btn-kopia-eksport)
// 1. Zserializuj tablicę rejestrZlecen za pomocą JSON.stringify(rejestrZlecen, null, 2)
// 2. Wstaw wynik do poleKopiaJson.value
// 3. Wyświetl komunikat: wyswietlKomunikatKopii("Kopia zapasowa rejestru zleceń została wygenerowana pomyślnie.", true)
btnKopiaEksport.addEventListener("click", () => {
  // Twój kod tutaj:
});

// KROK 7: TODO — Obsługa przycisku przywracania z kopii JSON (#btn-kopia-import)
// 1. W bloku try odczytaj poleKopiaJson.value.trim()
// 2. Sprawdź czy tekst nie jest pusty
// 3. Zdeserializuj metodą JSON.parse()
// 4. Zwaliduj czy sparsowana wartość to poprawna tablica zleceń
// 5. Nadpisz rejestrZlecen = zaimportowane, wywołaj renderujZlecenia() i wyświetl:
//    wyswietlKomunikatKopii("Rejestr zleceń został pomyślnie przywrócony ze zdeserializowanej kopii zapasowej.", true)
// 6. W bloku catch(blad) wyświetl błąd: wyswietlKomunikatKopii("Błąd przywracania kopii zapasowej: " + blad.message, false)
btnKopiaImport.addEventListener("click", () => {
  // Twój kod tutaj:
});

// Startowe uruchomienie
renderujZlecenia();
