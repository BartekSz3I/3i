# Zadanie 5: Portal Usługowo-Handlowy IT-Partner — Kopia zapasowa rejestru zleceń w formacie JSON (Projekt przyrostowy Capstone)

W ramach zadania wieńczącego moduł T60 rozbudujesz aplikację **Portalu Usługowo-Handlowego IT-Partner** o moduł kopii zapasowej (Backup & Restore) w formacie **JSON**. Wcześniejsza wersja aplikacji (z modułów `T57` i `T58`) realizowała pełny cykl zarządzania zleceniami B2B w pamięci operacyjnej RAM (dodawanie, wyświetlanie, edycja i usuwanie). Twoim celem jest dodanie możliwości wyeksportowania całego aktualnego stanu rejestru zleceń do sformatowanego ciągu JSON oraz odtworzenia stanu bazy z tekstu JSON z zachowaniem zasady **Zero Regresji** (wszystkie istniejące mechanizmy kalkulacji, edycji i usuwania muszą działać bez zakłóceń).

---

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)

- **Platformy B2B i panele administracyjne ERP/CRM (np. Salesforce, Odoo):** Bezpieczny zrzut bazy aktywnych spraw serwisowych do pliku JSON w celu migracji danych lub tworzenia lokalnego archiwum.
- **Systemy kasowe i sprzedażowe działające offline (POS):** Zrzucenie stanu transakcji z pamięci podręcznej RAM do pliku tekstowego w razie restartu aplikacji.
- **Narzędzia developerskie i panele konfiguracji:** Możliwość szybkiego załadowania zestawu danych testowych (seed data) za pomocą wklejenia gotowego JSON.

---

## Wymagania funkcjonalne

1. **Zasada Zero Regresji:** Zachowaj i wykorzystaj istniejący szkielet aplikacji z modułu `T58`:
   - Tablica stanu `rejestrZlecen = [...]` z początkowymi rekordami,
   - Formularz `#form-zlecenie` z kontrolkami: `#pole-klient`, `#wybor-kategorii`, `#pole-godziny`, `#pole-stawka`, `#pole-priorytet` (checkbox +30% do stawki) oraz przyciskami `#btn-zapisz` i `#btn-anuluj`,
   - Tabela `#tabela-zlecen` z ciałem `#cialo-zlecenia` oraz przyciskami `.btn-edytuj` i `.btn-usun`,
   - Pasek podsumowania `#pasek-podsumowania` wyświetlający łączną kwotę zleceń i ich liczbę za pomocą metody `reduce()`.
2. **Nowa sekcja kopii zapasowej (`index.html`):**
   - Pole tekstowe: `<textarea id="pole-kopia-json" rows="8" placeholder="Kliknij 'Utwórz kopię zapasową JSON' lub wklej własny ciąg danych..."></textarea>`,
   - Przycisk eksportu kopii: `<button type="button" id="btn-kopia-eksport">Utwórz kopię zapasową JSON</button>`,
   - Przycisk przywrócenia z kopii: `<button type="button" id="btn-kopia-import">Przywróć rejestr z kopii JSON</button>`,
   - Kontener komunikatów: `<div id="komunikat-kopii" class="komunikat ukryty"></div>`.
3. **Logika eksportu kopii zapasowej (`#btn-kopia-eksport` w `script.js`):**
   - Po kliknięciu przekształć tablicę `rejestrZlecen` w sformatowany ciąg JSON za pomocą `JSON.stringify(rejestrZlecen, null, 2)`.
   - Wstaw wygenerowany ciąg do pola `#pole-kopia-json`.
   - Wyświetl komunikat sukcesu: `"Kopia zapasowa rejestru zleceń została wygenerowana pomyślnie."`.
4. **Logika przywracania z kopii (`#btn-kopia-import` w `script.js`):**
   - Pobierz ciąg tekstowy z `#pole-kopia-json` za pomocą `.value.trim()`.
   - W bloku `try`:
     - Sprawdź, czy pole nie jest puste (`throw new Error("Pole tekstowe kopii zapasowej jest puste.")`).
     - Deserializuj tekst za pomocą `const zaimportowane = JSON.parse(surowyTekst)`.
     - Sprawdź, czy `zaimportowane` jest tablicą (`Array.isArray(zaimportowane)`) i czy każdy obiekt posiada wymagane pola: `id`, `klient`, `kategoria`, `godziny`, `stawka`, `kosztLaczny`.
     - Nadpisz stan: `rejestrZlecen = zaimportowane;`.
     - Wywołaj ponowne odrysowanie widoku: `renderujZlecenia()` oraz `aktualizujPodsumowanie()`.
     - Wyświetl komunikat sukcesu: `"Rejestr zleceń został pomyślnie przywrócony ze zdeserializowanej kopii zapasowej."`.
   - W bloku `catch (blad)`:
     - Wyświetl czytelny komunikat błędu: `"Błąd przywracania kopii zapasowej: " + blad.message`.
5. **Rygor bezpieczeństwa XSS:** W funkcji `renderujZlecenia()` nazwy klientów i kategorie wstawiaj wyłącznie przez `textContent`.

---

## Treść do wpisania

Wprowadź do interfejsu następujące dosłowne napisy:
- Tytuł nagłówka `<h1>`: `"Portal Usługowo-Handlowy IT-Partner — Kopia Zapasowa JSON"`
- Tekst przycisku eksportu kopii: `"Utwórz kopię zapasową JSON"`
- Tekst przycisku przywracania kopii: `"Przywróć rejestr z kopii JSON"`
- Komunikat po udanym eksporcie kopii: `"Kopia zapasowa rejestru zleceń została wygenerowana pomyślnie."`
- Komunikat po udanym przywróceniu: `"Rejestr zleceń został pomyślnie przywrócony ze zdeserializowanej kopii zapasowej."`

---

## Instrukcja krok po kroku

1. Otwórz plik `index.html` i zapoznaj się z sekcją formularza zleceń, tabelą oraz nową sekcją kopii zapasowej JSON.
2. W pliku `script.js` przeanalizuj istniejącą implementację CRUD z modułu T58 (zasada Zero Regresji).
3. Podepnij zdarzenie `click` pod przycisk `#btn-kopia-eksport` i zaimplementuj serializację `rejestrZlecen` za pomocą `JSON.stringify()`.
4. Podepnij zdarzenie `click` pod przycisk `#btn-kopia-import` i zaimplementuj bezpieczną deserializację `JSON.parse()` wewnątrz bloku `try...catch`.
5. Zwaliduj poprawność struktury importowanej tablicy i odśwież widok tabeli oraz pasek finansowy.
6. Przetestuj działanie w przeglądarce: utwórz kopię zapasową, usuń jedno ze zleceń w tabeli, a następnie kliknij przycisk przywrócenia i sprawdź, czy usunięty rekord powrócił do widoku.
