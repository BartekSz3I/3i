// Baza danych ofert wycieczek (Standard CKE INF.03)
const BAZA_WYCIECZEK = [
  {
    id: 1,
    kraj: "Grecja",
    miasto: "Rodos",
    cenaPln: 2450,
    dni: 7,
    lastMinute: true
  },
  {
    id: 2,
    kraj: "Hiszpania",
    miasto: "Barcelona",
    cenaPln: 3100,
    dni: 8,
    lastMinute: false
  },
  {
    id: 3,
    kraj: "Włochy",
    miasto: "Rzym",
    cenaPln: 2890,
    dni: 6,
    lastMinute: false
  },
  {
    id: 4,
    kraj: "Turcja",
    miasto: "Antalya",
    cenaPln: 1999,
    dni: 7,
    lastMinute: true
  },
  {
    id: 5,
    kraj: "Egipt",
    miasto: "Hurghada",
    cenaPln: 2150,
    dni: 10,
    lastMinute: true
  }
];
