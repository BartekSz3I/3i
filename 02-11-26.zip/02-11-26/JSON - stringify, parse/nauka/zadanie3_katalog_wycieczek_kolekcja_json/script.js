// Zadanie 3: Biuro Podróży — Filtrowanie i Eksport JSON (Szablon ucznia)

const filtrLastMinute = document.getElementById("filtr-last-minute");
const btnFiltrujEksportuj = document.getElementById("btn-filtruj-eksportuj");
const pasekPodsumowania = document.getElementById("pasek-podsumowania");
const podgladKolekcji = document.getElementById("podglad-kolekcji");

btnFiltrujEksportuj.addEventListener("click", () => {
  // KROK 1: Odczytaj stan zaznaczenia checkboxa filtrLastMinute.checked
  // Twoje rozwiazanie:

  // KROK 2: Przefiltruj tablicę BAZA_WYCIECZEK metodą filter
  // Jeśli checkbox jest zaznaczony, wybierz tylko oferty z lastMinute === true
  // Twoje rozwiazanie:

  // KROK 3: Oblicz łączną wartość wycieczek metodą reduce i wyświetl tekst w pasku podsumowania
  // Twoje rozwiazanie:

  // KROK 4: Zserializuj przefiltrowaną tablicę metodą JSON.stringify z wcięciem 2 spacji
  // i przypisz wynik do podgladKolekcji.textContent
  // Twoje rozwiazanie:

});
