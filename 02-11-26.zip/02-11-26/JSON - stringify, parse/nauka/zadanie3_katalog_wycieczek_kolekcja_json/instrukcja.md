# Zadanie 3: Biuro Podróży — Filtrowanie kolekcji i eksport do formatu JSON

W tym zadaniu przećwiczysz serializację złożonych struktur danych: **tablicy obiektów** (kolekcji). W aplikacjach internetowych bardzo często nie wysyłamy pojedynczego rekordu, lecz całą listę pozycji (np. wyfiltrowane oferty, pozycje koszyka czy raport). Nauczysz się pracować z gotowym zbiorem danych umieszczonym w pliku `dane.js` (standard CKE), filtrować kolekcję metodą tablicową `filter()`, a następnie przekształcać wynikową podtablicę w sformatowany ciąg JSON.

---

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)

- **Platformy turystyczne i rezerwacyjne (np. Booking.com, Wakacje.pl):** Eksport wyselekcjonowanych ofert Last Minute lub wyników wyszukiwania do zewnętrznych porównywarek cen.
- **Systemy ERP i fakturowe:** Generowanie pliku JPK lub zestawienia transakcji w formacie JSON dla księgowości.
- **Aplikacje analityczne:** Przygotowanie zbiorczych paczek danych (batch data) do raportowania i archiwizacji.

---

## Wymagania funkcjonalne

1. **Zbiór danych (`dane.js`):** Plik zawiera stałą `BAZA_WYCIECZEK` będącą tablicą co najmniej 5 obiektów ofert turystycznych. Każdy obiekt posiada właściwości: `id`, `kraj`, `miasto`, `cenaPln`, `dni`, `lastMinute` (boolean `true`/`false`).
2. **Struktura strony (`index.html`):**
   - W nagłówku `<head>` podepnij `style.css`.
   - Przed zamknięciem `</body>` podepnij najpierw `<script src="dane.js"></script>`, a następnie `<script src="script.js"></script>`.
   - Formularz filtrów zawierający:
     - Checkbox: `<input type="checkbox" id="filtr-last-minute">` z etykietą "Tylko oferty Last Minute",
     - Przycisk akcji: `<button type="button" id="btn-filtruj-eksportuj">Filtruj i eksportuj do JSON</button>`.
   - Blok podsumowania: `<p id="pasek-podsumowania">Liczba wycieczek: 0, łączna wartość: 0 zł</p>`.
   - Blok podglądu `<pre><code id="podglad-kolekcji">Wybierz kryteria i kliknij przycisk...</code></pre>`.
3. **Logika skryptu (`script.js`):**
   - Podepnij nasłuchiwanie zdarzenia `click` na przycisku `#btn-filtruj-eksportuj`.
   - Odczytaj stan zaznaczenia checkboxa `#filtr-last-minute` (`element.checked`).
   - Przefiltruj tablicę `BAZA_WYCIECZEK`: jeśli checkbox jest zaznaczony, wybierz tylko te obiekty, w których `oferta.lastMinute === true`. W przeciwnym razie pobierz wszystkie oferty.
   - Oblicz podsumowanie: liczbę ofert (`tablica.length`) oraz sumę cen (`reduce((suma, o) => suma + o.cenaPln, 0)`).
   - Zaktualizuj tekst w `#pasek-podsumowania` za pomocą `textContent`.
   - Wywołaj `JSON.stringify(wybraneOferty, null, 2)` i wyświetl wynikowy ciąg w `#podglad-kolekcji`.

---

## Treść do wpisania

Wprowadź do interfejsu następujące dosłowne napisy:
- Tytuł nagłówka `<h1>`: `"Biuro Podróży Słoneczne Wyprawy — Eksport Ofert JSON"`
- Etykieta checkboxa filtrów: `"Tylko oferty promocyjne Last Minute"`
- Tekst przycisku eksportu: `"Filtruj i eksportuj do JSON"`
- Początkowy tekst w bloku `<pre>`: `"Wybierz kryteria i kliknij przycisk..."`

---

## Instrukcja krok po kroku

1. Otwórz plik `dane.js` i przejrzyj strukturę tablicy `BAZA_WYCIECZEK`.
2. W pliku `index.html` upewnij się, że znacznik `<script src="dane.js"></script>` znajduje się przed `script.js`.
3. W pliku `script.js` pobierz kontrolki: checkbox, przycisk, pasek podsumowania i blok `<pre>`.
4. Podepnij zdarzenie `click` pod przycisk.
5. Użyj metody `BAZA_WYCIECZEK.filter(...)` do odfiltrowania elementów na podstawie właściwości `lastMinute`.
6. Oblicz sumę cen metodą `reduce()` i zaktualizuj pasek informacyjny.
7. Zserializuj przefiltrowaną tablicę metodą `JSON.stringify(..., null, 2)` i wstaw do bloku podglądu.
8. Przetestuj działanie w przeglądarce: sprawdź wynik z zaznaczonym i odznaczonym polem wyboru.
