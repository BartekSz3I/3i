# Zadanie 2: Konfigurator Serwera — Deserializacja JSON i obsługa try...catch

W tym zadaniu poznasz drugą kluczową operację formatu JSON: **deserializację** za pomocą metody `JSON.parse()`. Nauczysz się bezpiecznie przetwarzać ciąg tekstowy JSON wprowadzony przez użytkownika w polu wielowierszowym `<textarea>` oraz przechwytywać ewentualne błędy składniowe (`SyntaxError`) za pomocą konstrukcji `try...catch`, zapobiegając awarii skryptu.

---

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)

- **Panele zarządzania chmurą i hostingiem (np. AWS Console, Cloudflare, cPanel):** Import konfiguracji stref DNS, reguł zapory ogniowej lub parametrów kontenera z plików JSON.
- **Konfiguratory motywów i edytory kodu (np. VS Code `settings.json`):** Wczytywanie niestandardowych ustawień użytkownika z natychmiastową walidacją składni.
- **Systemy integracji API:** Wklejanie przykładowych ładunków odpowiedzi (payload) w narzędziach testowych (np. Postman).

---

## Wymagania funkcjonalne

1. **Struktura strony (`index.html`):**
   - Pole wielowierszowe `<textarea id="pole-json">` z przykładowym tekstem JSON z sekcji treści do wpisania.
   - Przycisk akcji: `<button type="button" id="btn-parsuj">Zastosuj konfigurację serwera</button>`.
   - Kontener na komunikaty błędów: `<div id="komunikat-bledu" class="komunikat ukryty"></div>`.
   - Karta informacyjna podglądu zdeserializowanego obiektu: `<div id="karta-serwera">` z elementami:
     - `#serwer-nazwa` (nazwa serwera),
     - `#serwer-ip` (adres IP),
     - `#serwer-ram` (ilość pamięci RAM),
     - `#serwer-status` (etykieta statusu).
2. **Obsługa deserializacji w `script.js`:**
   - Podepnij nasłuchiwanie zdarzenia `click` na przycisku `#btn-parsuj`.
   - Pobierz ciąg tekstowy z `#pole-json` za pomocą `poleJson.value.trim()`.
3. **Konstrukcja `try...catch` i walidacja:**
   - Wywołanie `JSON.parse(tekst)` umieść wewnątrz bloku `try { ... }`.
   - Jeśli pole jest puste, rzuć błąd `throw new Error("Pole tekstowe nie może być puste.")`.
   - Sprawdź, czy sparsowany obiekt zawiera wymagane właściwości: `nazwa`, `ip`, `ramGb`, `aktywny`. Jeśli nie, rzuć błąd `throw new Error("Brak wymaganych pól w konfiguracji serwera.")`.
   - Jeśli parsowanie i walidacja powiodą się:
     - Ukryj kontener błędu (dodaj klasę `.ukryty`, wyczyść tekst),
     - Wypełnij pola karty serwera (`#serwer-nazwa`, `#serwer-ip`, `#serwer-ram`, `#serwer-status`),
     - Wartości tekstowe wstawiaj wyłącznie za pomocą `textContent` (rygorystyczna ochrona przed XSS).
   - W bloku `catch (blad)`:
     - Wyświetl treść błędu w `#komunikat-bledu` za pomocą `komunikatBledu.textContent = "Błąd formatu JSON: " + blad.message`,
     - Pokaż kontener błędu (usuń klasę `.ukryty`).

---

## Treść do wpisania

Wprowadź do interfejsu następujące dosłowne napisy:
- Tytuł nagłówka `<h1>`: `"Konfigurator Maszyn Wirtualnych — Import JSON"`
- Tekst przycisku parsowania: `"Zastosuj konfigurację serwera"`
- Domyślna poprawna treść w polu `<textarea id="pole-json">`:
```json
{
  "nazwa": "VPS-PRO-Warszawa-01",
  "ip": "192.168.10.45",
  "ramGb": 32,
  "aktywny": true
}
```

---

## Instrukcja krok po kroku

1. Otwórz plik `index.html` i przejrzyj strukturę kontrolek oraz kontenerów informacyjnych.
2. W pliku `script.js` pobierz referencje do elementów interfejsu.
3. Zaimplementuj funkcję obsługi kliknięcia `#btn-parsuj`.
4. W bloku `try` odczytaj tekst z pola, wywołaj `JSON.parse(tekst)` i zwaliduj obecność pól.
5. Przy sukcesie wyświetl dane serwera w polach karty z użyciem `textContent`.
6. W bloku `catch` przechwyć błąd i wyświetl komunikat w `#komunikat-bledu`.
7. Przetestuj działanie w przeglądarce: najpierw z poprawnym JSON, a następnie usuń cudzysłów lub nawias i sprawdź, czy aplikacja bezpiecznie wyświetla komunikat o błędzie.
