// Zadanie 2: Konfigurator Serwera — Import JSON (Szablon ucznia)

const poleJson = document.getElementById("pole-json");
const btnParsuj = document.getElementById("btn-parsuj");
const komunikatBledu = document.getElementById("komunikat-bledu");

const serwerNazwa = document.getElementById("serwer-nazwa");
const serwerIp = document.getElementById("serwer-ip");
const serwerRam = document.getElementById("serwer-ram");
const serwerStatus = document.getElementById("serwer-status");

btnParsuj.addEventListener("click", () => {
  const surowyTekst = poleJson.value.trim();

  // KROK 1: TODO — Zastosuj konstrukcję try...catch
  // 1. W bloku try sprawdź czy surowyTekst nie jest pusty (throw new Error)
  // 2. Wywołaj JSON.parse(surowyTekst)
  // 3. Sprawdź obecność pól: nazwa, ip, ramGb, aktywny
  // 4. Przypisz wartości do serwerNazwa, serwerIp, serwerRam, serwerStatus za pomocą textContent
  // 5. Ukryj komunikatBledu (dodaj klasę 'ukryty')
  // 6. W bloku catch(blad) wyświetl komunikat błędu i usuń klasę 'ukryty'
  
  // Twój kod tutaj:

});
