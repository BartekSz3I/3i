// Zadanie 4 — Magazyn części: formularz, filtrowanie i statystyka
// Tablica `MAGAZYN_PRODUKTY` została załadowana z pliku dane.js.

// KROK 1: Zainicjalizuj centralną tablicę stanu magazynu
const stanMagazynu = typeof MAGAZYN_PRODUKTY !== "undefined" ? [...MAGAZYN_PRODUKTY] : [];

// KROK 2: Zaimplementuj funkcję `renderujWidokMagazynu(kolekcja)`
// 1. Wyczyść `#tabela-magazyn tbody` metodą `replaceChildren()`.
// 2. Przeiteruj po kolekcji za pomocą `forEach()`.
// 3. Stwórz komórki dla: ID, nazwy, kategorii, ceny jedn., ilości oraz łącznej wartości (cena * ilość).
// 4. Wywołaj `obliczStatystyki(kolekcja)`.
function renderujWidokMagazynu(kolekcja) {
  const tbody = document.querySelector("#tabela-magazyn tbody");
  if (!tbody) return;
  tbody.replaceChildren();

  // TODO: uzupełnij renderowanie tabeli i wywołaj obliczStatystyki(kolekcja)


  kolekcja.forEach(towar => {
    
    const tr = document.createElement('tr');

    const tdid = document.createElement('td');
    tdid.textContent = `${towar.id}`;
    tr.appendChild(tdid);

    const tdnazwa = document.createElement('td');
    tdnazwa.textContent = `${towar.nazwa}`;
    tr.appendChild(tdnazwa);

    const tdkat = document.createElement('td');
    tdkat.textContent = `${towar.kategoria}`;
    tr.appendChild(tdkat);

    const tdcena = document.createElement('td');
    tdcena.textContent = `${towar.cenaJednostkowa}`;
    tr.appendChild(tdcena);

    const tdilosc = document.createElement('td');
    tdilosc.textContent = `${towar.ilosc}`;
    tr.appendChild(tdilosc);

    const tdwartosc = document.createElement('td');
    tdwartosc.textContent = (towar.ilosc * towar.cenaJednostkowa).toFixed(2) + ' zł';
    tr.appendChild(tdwartosc);

    tbody.appendChild(tr);
    
  });

  obliczStatystyki(kolekcja);
}

// KROK 3: Zaimplementuj funkcję `obliczStatystyki(kolekcja)`
// Użyj metody reduce(), aby obliczyć łączną liczbę sztuk oraz łączną wartość finansową magazynu.
function obliczStatystyki(kolekcja) {
  const spanIlosc = document.querySelector("#stat-laczna-ilosc");
  const spanWartosc = document.querySelector("#stat-laczna-wartosc");
  if (!spanIlosc || !spanWartosc) return;

  // TODO: Oblicz lacznaIlosc i lacznaWartosc za pomocą reduce()

  const statystyki = kolekcja.reduce(
    (acc, towar) => {
      acc.lacznaIlosc += towar.ilosc;
      acc.lacznaWartosc += towar.ilosc * towar.cenaJednostkowa;
      return acc;
    },
    { lacznaIlosc: 0, lacznaWartosc: 0 }
  );
  spanIlosc.textContent = statystyki.lacznaIlosc;
  spanWartosc.textContent = `${statystyki.lacznaWartosc.toFixed(2)} zł`;
}

// KROK 4: Obsłuż formularz dodawania towaru `#form-magazyn`
const formMagazyn = document.querySelector("#form-magazyn");
if (formMagazyn) {
  formMagazyn.addEventListener("submit", (e) => {
    e.preventDefault();
    // TODO: Odczytaj wartości pól, stwórz obiekt z id: Date.now() i dodaj go do stanMagazynu.push()
    const nazwa = document.querySelector('#towar-nazwa').value;
    const kategoria = document.querySelector('#towar-kategoria').value;
    const cena = Number(document.querySelector('#towar-cena').value);
    const ilosc = Number(document.querySelector('#towar-ilosc').value);
    
    const nowy_towar = {id: Date.now(), nazwa: nazwa, kategoria: kategoria, cenaJednostkowa: cena, ilosc: ilosc};
    
    stanMagazynu.push(nowy_towar);
    // TODO: Zresetuj formularz i odśwież widok

    formMagazyn.reset();
    renderujWidokMagazynu(stanMagazynu);
  });
}

// KROK 5: Obsłuż filtrowanie kategorii `#filtr-kategoria` (zdarzenie change)
const selectFiltr = document.querySelector("#filtr-kategoria");
if (selectFiltr) {
  selectFiltr.addEventListener("change", () => {
    // TODO: Zastosuj metodę filter() i wywołaj renderujWidokMagazynu()

    const wybranaKategoria = selectFiltr.value;
    if (wybranaKategoria === 'wszystkie'){
      renderujWidokMagazynu(stanMagazynu);
    } else{
      const przefiltrowane = stanMagazynu.filter((item) => item.kategoria === wybranaKategoria);

      renderujWidokMagazynu(przefiltrowane);
    }

  });
}

// Inicjalne wywołanie widoku
renderujWidokMagazynu(stanMagazynu);
