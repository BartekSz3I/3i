// Baza danych początkowych — magazyn podzespołów komputerowych
const MAGAZYN_PRODUKTY = [
  {
    id: 1730000010001,
    nazwa: "Dysk SSD NVMe 1TB PCIe 4.0",
    kategoria: "dyski",
    cenaJednostkowa: 380.00,
    ilosc: 15
  },
  {
    id: 1730000010002,
    nazwa: "Karta sieciowa Wi-Fi 6E PCI-e",
    kategoria: "sieci",
    cenaJednostkowa: 145.50,
    ilosc: 8
  },
  {
    id: 1730000010003,
    nazwa: "Zasilacz modularny 750W Gold",
    kategoria: "zasilacze",
    cenaJednostkowa: 520.00,
    ilosc: 5
  }
];
