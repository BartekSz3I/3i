# Instrukcja: Zadanie 4 — Magazyn części: formularz, filtrowanie i statystyka

## Cel zadania
Zadanie integrujące łączy umiejętności nabyte w zadaniach 1, 2 i 3 w jednej, spójnej aplikacji panelu magazynowego. Uczeń tworzy system, w którym dane przechowywane są w centralnej tablicy obiektów w pamięci JS, użytkownik może wprowadzać nowe pozycje przez formularz, filtrować widok tabeli według kategorii za pomocą metody `filter()`, a także monitorować sumaryczną wartość towarów za pomocą metody `reduce()`.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy ERP i gospodarki magazynowej (np. Subiekt GT, Comarch ERP Optima):** ewidencja stanów magazynowych, gdzie pracownik dodaje nowy towar, filtruje asortyment według działu i odczytuje automatycznie sumowaną wartość magazynową.
2. **Katalogi hurtowni B2B (np. Action, AB S.A.):** dynamiczne filtrowanie podzespołów komputerowych z natychmiastowym przeliczaniem sumy wybranych pozycji.
3. **Panele inwentaryzacyjne w e-commerce:** bieżąca kontrola stanów magazynowych i wartości zapasów w magazynie głównym.

## Wymagania funkcjonalne
1. W pliku `dane.js` zdefiniuj stałą `MAGAZYN_PRODUKTY` zawierającą co najmniej 3 obiekty towarów (`id`, `nazwa`, `kategoria`, `cenaJednostkowa`, `ilosc`).
2. W pliku `script.js` zainicjalizuj tablicę `stanMagazynu` kopią `[...MAGAZYN_PRODUKTY]`.
3. Obsłuż formularz dodawania towaru o identyfikatorze `#form-magazyn`:
   - zablokuj domyślną wysyłkę (`e.preventDefault()`),
   - pobierz dane: `#towar-nazwa`, `#towar-kategoria`, `#towar-cena` (liczba), `#towar-ilosc` (liczba całkowita),
   - utwórz nowy obiekt: `id: Date.now()`, `nazwa`, `kategoria`, `cenaJednostkowa`, `ilosc`,
   - dodaj obiekt do tablicy `stanMagazynu.push(nowyTowar)`,
   - zresetuj formularz `form.reset()`,
   - odśwież widok tabeli i statystyk.
4. Zaimplementuj filtrowanie kategorii za pomocą kontrolki `<select id="filtr-kategoria">`:
   - nasłuchuj na zdarzenie `change`,
   - jeśli wybrano "wszystkie", wyświetl całą tablicę `stanMagazynu`,
   - w przeciwnym razie przefiltruj tablicę za pomocą `stanMagazynu.filter(...)` i wyświetl tylko pozycje z wybranej kategorii.
5. Zaimplementuj funkcję `obliczStatystyki(kolekcja)`, która za pomocą metody `reduce()`:
   - obliczy łączną liczbę sztuk wszystkich towarów w przekazanej kolekcji,
   - obliczy całkowitą wartość finansową magazynu (`suma + item.cenaJednostkowa * item.ilosc`),
   - wyświetli wyniki w elementach `#stat-laczna-ilosc` oraz `#stat-laczna-wartosc`.
6. Wypis danych tekstowych w tabeli `#tabela-magazyn tbody` wykonaj bezpiecznie (`textContent`), neutralizując zagrożenie XSS.

## Treść do wpisania
Przetestuj dodawanie nowego towaru magazynowego o następujących parametrach:
- Nazwa towaru: "Moduł pamięci RAM DDR5 32GB"
- Kategoria: "podzespoły"
- Cena jednostkowa: "450.00"
- Ilość na stanie: "12"
- Komunikat testowy: "Dodawanie towaru magazynowego: Moduł pamięci RAM DDR5 32GB, kategoria: podzespoły, cena jednostkowa: 450 zł, stan: 12 sztuk."

## Wskazówki implementacyjne
- Pamiętaj o dołączeniu `dane.js` przed `script.js` w pliku HTML.
- Wartość pozycji oblicza się mnożąc cenę jednostkową przez ilość: `item.cenaJednostkowa * item.ilosc`.
- W metodzie `reduce()` zawsze podawaj drugi argument `0` jako wartość początkową akumulatora:
  ```javascript
  const sumaWartosci = kolekcja.reduce((acc, el) => acc + (el.cenaJednostkowa * el.ilosc), 0);
  ```
