# Instrukcja: Zadanie 1 — Obiekt encji i karta zgłoszenia serwisowego

## Cel zadania
Celem ćwiczenia jest opanowanie fundamentu modelowania danych w języku JavaScript: utworzenia pojedynczego obiektu encji reprezentującego zgłoszenie serwisowe oraz bezpiecznego wyrenderowania jego właściwości w drzewie DOM. Uczeń uczy się definiować pola o różnych typach danych (identyfikator, tekst, liczba, wartość logiczna) oraz prezentować je w interfejsie użytkownika z wykorzystaniem bezpiecznych metod manipulacji węzłami DOM.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy helpdesk i serwisowe (np. Jira Service Management, Zendesk):** każde zgłoszenie awarii jest pojedynczym obiektem przechowującym identyfikator ticketu, nazwę urządzenia, opis usterki, szacowany koszt oraz status realizacji.
2. **Panele zamówień w sklepach internetowych (np. Allegro, Amazon):** karta szczegółów pojedynczego zamówienia prezentuje dane pobrane ze struktury obiektu zamówienia (numer zamówienia, status przesyłki, koszt).
3. **Aplikacje medyczne i rejestracje wizyt (np. ZnanyLekarz):** karta pacjenta lub wizyty to obiekt zawierający datę, imię pacjenta, typ usługi i oznaczenie opłacenia.

## Wymagania funkcjonalne
1. W pliku `script.js` utwórz obiekt `zgloszenie` zawierający następujące właściwości:
   - `id`: unikalna liczba (np. `1042`),
   - `klient`: łańcuch znaków z imieniem i nazwiskiem klienta,
   - `urzadzenie`: nazwa urządzenia (np. model laptopa),
   - `usterka`: opis problemu zgłoszonego przez klienta,
   - `kosztSzacowany`: wartość liczbowa w złotych,
   - `zrealizowane`: wartość logiczna `false`.
2. Zaimplementuj funkcję `renderujKarteZgloszenia(dane)`, która pobiera kontener `#karta-sprzetu` i tworzy w nim strukturę wizualną:
   - nagłówek `<h3>` z nazwą urządzenia oraz numerem zgłoszenia w nawiasie,
   - akapity `<p>` z nazwiskiem klienta, opisem usterki oraz szacowanym kosztem sformatowanym z dokładnością do 2 miejsc po przecinku (`.toFixed(2)`),
   - etykietę statusu `<span>` z klasą CSS `.status-oczekuje` i tekstem "W trakcie naprawy".
3. Wypis danych tekstowych z obiektu do elementów DOM musi odbywać się **wyłącznie za pomocą właściwości `textContent`**, co gwarantuje pełną ochronę przed podatnością XSS.

## Treść do wpisania
W obiekcie zgłoszenia oraz w interfejsie umieść dokładnie następujące dane:
- Klient: "Marek Wiśniewski"
- Urządzenie: "Laptop Dell XPS 15"
- Opis usterki: "Wymiana klawiatury po zalaniu oraz kompleksowe czyszczenie chłodzenia"
- Koszt szacowany: "320.00 zł"
- Nagłówek statusu: "Status realizacji zlecenia serwisowego: w trakcie naprawy"

## Wskazówki implementacyjne
- Do tworzenia elementów HTML użyj metody `document.createElement("tag")`.
- Przypisuj tekst do węzłów poprzez `element.textContent = wartosc`.
- Do połączenia stworzonych elementów wewnątrz kontenera użyj `kontener.append(...)`.
- Przed dodaniem nowych elementów upewnij się, że kontener jest wyczyszczony za pomocą `kontener.replaceChildren()`.
