// Zadanie 1 — Obiekt encji i karta zgłoszenia serwisowego
// Twój cel: Zdefiniuj obiekt modelu danych i wyrenderuj go bezpiecznie w DOM.

// KROK 1: Zdefiniuj literał obiektu `zgloszenie` z wymaganymi właściwościami:
// - id (liczba, np. 1042)
// - klient (tekst z imieniem i nazwiskiem)
// - urzadzenie (tekst z modelem urządzenia)
// - usterka (dokładny opis usterki z instrukcji)
// - kosztSzacowany (liczba, np. 320.00)
// - zrealizowane (wartość logiczna false)
const zgloszenie = {
  // TODO: uzupełnij właściwości obiektu
  id: 1042,
  klient: 'Tomasz Problem',
  urzadzenie: 'komputer stacjonarny',
  usterka: 'problem z bitlockerem',
  kosztSzacowany: 99.99,
  zrealizowane: false,
};

// KROK 2: Napisz funkcję `renderujKarteZgloszenia(dane)`
// Funkcja powinna:
// 1. Pobrać kontener o id `#karta-sprzetu`.
// 2. Wyczyścić go za pomocą `kontener.replaceChildren()`.
// 3. Stworzyć elementy DOM: nagłówek h3, akapity p oraz span dla statusu.
// 4. Przypisać wartości z obiektu `dane` do właściwości `textContent` (ochrona przed XSS!).
// 5. Dodać elementy do kontenera za pomocą `append()`.
function renderujKarteZgloszenia(dane) {
  const kontener = document.querySelector("#karta-sprzetu");
  if (!kontener || !dane.urzadzenie) return;

  // TODO: Utwórz elementy DOM za pomocą document.createElement() i wypełnij je textContent

  kontener.replaceChildren();
  
  const naglowek = document.createElement('h3');
  naglowek.textContent = `Zgłoszenie nr ${dane.id}`;
  kontener.appendChild(naglowek);

  const dane_klienta = document.createElement('p');
  const nazwisko = dane.klient.split(' ')[1];
  dane_klienta.textContent = `Nazwisko klienta: ${nazwisko}`;
  kontener.appendChild(dane_klienta);

  const purzadzenie = document.createElement('p');
  purzadzenie.textContent = `Urządzenie, którego dotyczy problem: ${dane.urzadzenie}`;
  kontener.appendChild(purzadzenie);

  const pusterka = document.createElement('p');
  pusterka.textContent = `Opis usterki: ${dane.usterka}`;
  kontener.appendChild(pusterka);

  const pkoszt = document.createElement('p');
  pkoszt.textContent = `Szacowany koszt: ${dane.kosztSzacowany.toFixed(2)}`;
  kontener.appendChild(pkoszt);

  const spanstatus = document.createElement('span');
  spanstatus.classList.add('status-oczekuje');
  spanstatus.textContent = 'W trakcie naprawy';
  kontener.appendChild(spanstatus);

}

// KROK 3: Wywołaj funkcję renderującą
renderujKarteZgloszenia(zgloszenie);
