// Zadanie 3 — Formularz rejestracji wizyt i baza danych w pamięci
// Tablica `POCZATKOWE_WIZYTY` jest załadowana z pliku dane.js.

// KROK 1: Zainicjalizuj roboczą tablicę `listaWizyt` kopią danych początkowych
const listaWizyt = typeof POCZATKOWE_WIZYTY !== "undefined" ? [...POCZATKOWE_WIZYTY] : [];

// KROK 2: Napisz funkcję `renderujListeWizyt(kolekcja)`
// Funkcja powinna wyczyścić kontener `#lista-wizyt` i dla każdego elementu stworzyć kartę
// z nagłówkiem h3 (pacjent + gatunek), akapitami (waga, właściciel) oraz statusem opłacenia.
function renderujListeWizyt(kolekcja) {
  const kontener = document.querySelector("#lista-wizyt");
  if (!kontener) return;

  // TODO: wyczyść kontener metodą replaceChildren() i przeiteruj kolekcję forEach

  kontener.replaceChildren();

  kolekcja.forEach(wizyta => {
    const karta = document.createElement('div');
    karta.classList.add('karta-wizyty');

    const naglowek = document.createElement('h3');
    naglowek.textContent = wizyta.pacjent + ', ' + wizyta.gatunek;
    karta.appendChild(naglowek);

    const pwaga = document.createElement('p');
    pwaga.textContent = `Waga pacjenta: ${wizyta.waga}`;
    karta.appendChild(pwaga);

    const pwlasciciel = document.createElement('p');
    pwlasciciel.textContent = `Właściciel: ${wizyta.wlasciciel}`;
    karta.appendChild(pwlasciciel);

    if(wizyta.oplacona === true){
      const toplacona = document.createElement('p');
      toplacona.classList.add('badge-oplacona');
      toplacona.textContent = 'Wizyta jest opłacona';
      karta.appendChild(toplacona);
    } else {
      const foplacona = document.createElement('p');
      foplacona.classList.add('badge-nieoplacona');
      foplacona.textContent = 'Wizyta nie jest opłacona';
      karta.appendChild(foplacona);
    }

    kontener.appendChild(karta);
  });

}

// KROK 3: Oprogramuj zdarzenie submit formularza `#form-wizyta`
const formularz = document.querySelector("#form-wizyta");
if (formularz) {
  formularz.addEventListener("submit", (e) => {
    e.preventDefault();

    // TODO: Pobierz wartości z kontrolek, zamień wagę na liczbę (Number)

    const imie = document.querySelector('#pacjent-imie').value;

    const gatunek = document.querySelector('#pacjent-gatunek').value;

    const waga = Number(document.querySelector('#pacjent-waga').value);

    const wlasciciel = document.querySelector('#pacjent-wlasciciel').value;

    const oplacona = document.querySelector('#pacjent-oplacona').checked;

    if(!imie || !wlasciciel || waga <= 0){
      return;
    } 

    // TODO: Zbuduj obiekt nowej wizyty z id: Date.now()

    const nowa_wizyta = {id: Date.now(), pacjent: imie, gatunek: gatunek, waga: waga, wlasciciel: wlasciciel, oplacona: oplacona};
    // TODO: Dodaj do tablicy listaWizyt.push(nowaWizyta)

    listaWizyt.push(nowa_wizyta);
    // TODO: Wyczyść formularz form.reset() i odśwież widok

    formularz.reset();
    renderujListeWizyt(listaWizyt);
  });
}

// Inicjalne wywołanie
renderujListeWizyt(listaWizyt);
