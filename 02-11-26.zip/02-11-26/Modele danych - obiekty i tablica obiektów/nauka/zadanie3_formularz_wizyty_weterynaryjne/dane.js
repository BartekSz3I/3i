// Baza danych początkowych — rejestr wizyt weterynaryjnych
const POCZATKOWE_WIZYTY = [
  {
    id: 1730000001001,
    pacjent: "Badi",
    gatunek: "Pies",
    waga: 12.4,
    wlasciciel: "Piotr Kowalczyk",
    oplacona: true
  },
  {
    id: 1730000002002,
    pacjent: "Mruczek",
    gatunek: "Kot",
    waga: 4.2,
    wlasciciel: "Katarzyna Wójcik",
    oplacona: false
  }
];
