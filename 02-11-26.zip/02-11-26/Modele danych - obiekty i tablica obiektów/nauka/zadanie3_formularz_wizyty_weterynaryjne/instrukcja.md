# Instrukcja: Zadanie 3 — Formularz rejestracji wizyt i baza danych w pamięci

## Cel zadania
Celem ćwiczenia jest połączenie formularza HTML ze strukturami danych JavaScript: odczytanie wartości pól z kontrolek formularza, rygorystyczna konwersja typów (z tekstu na liczbę oraz odczyt stanu logicznego pola wyboru), utworzenie nowego obiektu modelu danych z unikalnym identyfikatorem czasu (`Date.now()`) oraz dołączenie go do lokalnej tablicy obiektów metodą `push()`. Uczeń poznaje także egzaminacyjny wzorzec CKE z osobnym plikiem danych `dane.js` dołączanym przed głównym skryptem.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy recepcji i przychodni (np. VetManager, e-Recepcja):** rejestrator wprowadza dane nowej wizyty w formularzu, a system natychmiast dodaje nowy obiekt do widocznej listy oczekujących pacjentów.
2. **Aplikacje do zarządzania zadaniami (np. Trello, Asana):** formularz "Dodaj zadanie" tworzy obiekt reprezentujący kartę z tytułem, wykonawcą, terminem i statusem, po czym wstawia go na tablicę.
3. **Rejestracja gości hotelowych lub biletów (np. Booking.com):** po wypełnieniu formularza rezerwacji powstaje obiekt rezerwacji trafiający do bieżącego koszyka w pamięci.

## Wymagania funkcjonalne
1. W pliku `dane.js` zadeklaruj tablicę początkową `POCZATKOWE_WIZYTY` zawierającą co najmniej 2 obiekty wizyt.
2. W pliku `script.js` zainicjalizuj roboczą tablicę `listaWizyt`, kopiując elementy z `POCZATKOWE_WIZYTY` (np. `[...POCZATKOWE_WIZYTY]`).
3. Oprogramuj formularz o identyfikatorze `#form-wizyta`:
   - przechwyć zdarzenie `submit` i zablokuj przeładowanie strony za pomocą `e.preventDefault()`,
   - odczytaj wartości kontrolek: `#pacjent-imie`, `#pacjent-gatunek`, `#pacjent-waga` (liczba!), `#pacjent-wlasciciel` oraz `#pacjent-oplacona` (właściwość `.checked`),
   - sprawdź, czy imię pacjenta i właściciel nie są puste oraz czy waga jest liczbą większą od zera,
   - utwórz obiekt nowej wizyty z polami: `id: Date.now()`, `pacjent`, `gatunek`, `waga`, `wlasciciel`, `oplacona`,
   - dołącz obiekt do tablicy `listaWizyt.push(nowaWizyta)`,
   - wyczyść formularz metodą `form.reset()`,
   - wywołaj funkcję `renderujListeWizyt(listaWizyt)`.
4. Funkcja `renderujListeWizyt` czyści kontener `#lista-wizyt` (`replaceChildren()`) i tworzy dla każdego obiektu element `<div>` o klasie `.karta-wizyty` z bezpiecznie wstawionymi danymi (`textContent`).

## Treść do wpisania
Podczas testowania formularza wprowadź następujące dane nowego pacjenta:
- Imię pacjenta: "Max"
- Gatunek: "Pies"
- Waga: "18.5"
- Właściciel: "Anna Nowak"
- Opłacona: zaznaczony checkbox
- Komunikat weryfikacyjny: "Nowa rejestracja pacjenta: Pies Max, waga: 18.5 kg, właściciel: Anna Nowak, wizyta opłacona z góry."

## Wskazówki implementacyjne
- W pliku `index.html` skrypt `dane.js` musi być dołączony **przed** `script.js`:
  ```html
  <script src="dane.js"></script>
  <script src="script.js"></script>
  ```
- Wagę pacjenta zamień na liczbę za pomocą `Number(inputWaga.value)`.
- Stan opłacenia odczytaj z pola typu checkbox przez właściwość `checkbox.checked` (zwraca `true` lub `false`).
