# Instrukcja: Zadanie 5 — Przyrostowe zwieńczenie: Panel usług portalu IT-Partner

## Cel zadania
Zadanie stanowi całościowe zwieńczenie modułu T56 pod stałą marką portalu usługowo-handlowego IT-Partner. Uczeń buduje w pełni funkcjonalny, profesjonalny moduł zarządzania cennikiem i katalogiem usług informatycznych. Aplikacja łączy modelowanie obiektów encji, tablicę stanu w pamięci podręcznej, dynamiczne dodawanie rekordów przez formularz, wyszukiwanie tekstowe (`filter` / `includes`), sortowanie numeryczne (`sort`) oraz obliczenia analityczne (`reduce`) wraz z rygorystycznym zabezpieczeniem widoku przed lukami XSS.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Portale usług B2B i rynki freelancerskie (np. Useme, Oferia):** katalog oferowanych usług IT z możliwością przeszukiwania po frazie, filtrowania po dziedzinie (sieci, programowanie, chmura) oraz sortowania według stawki godzinowej.
2. **Kalkulatory wdrożeniowe i panele ofertowe software house'ów:** pracownik działu sprzedaży konfiguruje ofertę, dodaje niestandardowe usługi do bazy wyceny i na bieżąco monitoruje średnią stawkę projektu.
3. **Systemy ERP dla firm technologicznych:** centralny rejestr usług serwisowych i wdrożeniowych z podglądem dostępności specjalistów.

## Wymagania funkcjonalne
1. W pliku `dane.js` zadeklaruj stałą `USLUGI_IT` zawierającą początkową bazę co najmniej 4 usług informatycznych (`id`, `nazwa`, `kategoria`, `stawkaGodzinowa`, `szacowanyCzas`, `dostepna`).
2. W pliku `script.js` zainicjalizuj tablicę `katalogUslug` kopią `[...USLUGI_IT]`.
3. Obsłuż formularz dodawania nowej usługi (`#form-usluga`):
   - zablokuj domyślne przeładowanie metodą `e.preventDefault()`,
   - pobierz dane: nazwa, kategoria (sieci, programowanie, serwis, chmura), stawka godzinowa (liczba), szacowany czas (liczba) oraz dostępność (checkbox `.checked`),
   - utwórz obiekt z unikalnym identyfikatorem `id: Date.now()`,
   - dołącz obiekt do tablicy `katalogUslug.push(nowaUsluga)`,
   - zresetuj formularz `form.reset()`,
   - wywołaj odświeżenie widoku.
4. Zaimplementuj wyszukiwanie po nazwie (`#szukaj-uslugi`):
   - reaguj na zdarzenie `input`,
   - filtruj kolekcję za pomocą metody `filter()`, sprawdzając, czy nazwa usługi zawiera wpisany fragment (bez względu na wielkość liter: `.toLowerCase().includes(...)`),
   - odświeżaj tabelę dla przefiltrowanych wyników.
5. Zaimplementuj sortowanie według stawki godzinowej:
   - po kliknięciu przycisku `#btn-sortuj-rosnaco` posortuj aktualnie wyświetlaną kolekcję rosnąco według stawki: `(a, b) => a.stawkaGodzinowa - b.stawkaGodzinowa`,
   - po kliknięciu przycisku `#btn-sortuj-malejaco` posortuj malejąco: `(a, b) => b.stawkaGodzinowa - a.stawkaGodzinowa`.
6. Zaimplementuj funkcję statystyk `aktualizujPodsumowanie(kolekcja)`:
   - za pomocą metody `reduce()` oblicz średnią stawkę godzinową w przekazanej kolekcji,
   - za pomocą metody `filter()` zlicz liczbę usług z aktywnym statusem dostępności (`dostepna === true`),
   - wyświetl wyniki w elementach `#stat-srednia-stawka` oraz `#stat-dostepne-uslugi`.
7. W tabeli `#tabela-uslug tbody` wygeneruj wiersze z komórkami: ID, nazwa, kategoria, stawka/h, czas trwania, łączny koszt szacowany (stawka * czas) oraz status dostępności (badge z klasą `.status-dostepna` lub `.status-zajeta`). Wszystkie teksty przypisuj przez `textContent`.

## Treść do wpisania
Przetestuj dodanie nowej usługi informatycznej o następujących danych:
- Nazwa usługi: "Audyt bezpieczeństwa sieci LAN"
- Kategoria: "sieci"
- Stawka godzinowa: "250.00"
- Szacowany czas: "8"
- Dostępność: zaznaczony checkbox
- Komunikat demonstracyjny: "Rejestracja nowej usługi w portalu IT-Partner: Audyt bezpieczeństwa sieci LAN, kategoria: sieci, stawka: 250 zł/h, czas: 8h."

## Wskazówki implementacyjne
- Dołącz plik `dane.js` przed `script.js` w sekcji body dokumentu HTML.
- Podczas sortowania pamiętaj, aby sortować płytką kopię tablicy `[...kolekcja].sort(...)` lub zachować spójność ze zmienną roboczą widoku.
- Obliczając średnią stawkę w `reduce()`, zabezpiecz się przed dzieleniem przez zero w przypadku pustej listy:
  ```javascript
  const srednia = kolekcja.length > 0 ? suma / kolekcja.length : 0;
  ```
