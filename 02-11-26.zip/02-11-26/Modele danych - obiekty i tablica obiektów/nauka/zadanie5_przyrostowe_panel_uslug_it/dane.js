// Baza danych początkowych — katalog usług IT-Partner
const USLUGI_IT = [
  {
    id: 1730000050001,
    nazwa: "Konfiguracja serwera Linux Debian",
    kategoria: "serwis",
    stawkaGodzinowa: 180.00,
    szacowanyCzas: 5,
    dostepna: true
  },
  {
    id: 1730000050002,
    nazwa: "Implementacja modułu REST API w Node.js",
    kategoria: "programowanie",
    stawkaGodzinowa: 220.00,
    szacowanyCzas: 16,
    dostepna: true
  },
  {
    id: 1730000050003,
    nazwa: "Migracja infrastruktury do chmury AWS",
    kategoria: "chmura",
    stawkaGodzinowa: 280.00,
    szacowanyCzas: 24,
    dostepna: false
  },
  {
    id: 1730000050004,
    nazwa: "Instalacja i zabezpieczenie sieci Wi-Fi Mesh",
    kategoria: "sieci",
    stawkaGodzinowa: 150.00,
    szacowanyCzas: 6,
    dostepna: true
  }
];
