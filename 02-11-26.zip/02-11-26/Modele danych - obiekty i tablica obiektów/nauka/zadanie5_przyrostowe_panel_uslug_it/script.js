// Zadanie 5 — Przyrostowe zwieńczenie: Panel usług portalu IT-Partner
// Baza danych `USLUGI_IT` załadowana z pliku dane.js.

// KROK 1: Centralny stan aplikacji w pamięci
const katalogUslug = typeof USLUGI_IT !== "undefined" ? [...USLUGI_IT] : [];
let aktualnieWyswietlane = [...katalogUslug];

// KROK 2: Renderowanie tabeli usług i statystyk
function renderujKatalogUslug(kolekcja) {
  const tbody = document.querySelector("#tabela-uslug tbody");
  if (!tbody) return;

  tbody.replaceChildren();

  // TODO: Wygeneruj wiersze tabeli tr i komórki td dla każdego obiektu kolekcji
  // Pamiętaj o bezpiecznym textContent oraz obliczeniu kosztu: stawkaGodzinowa * szacowanyCzas

  aktualizujPodsumowanie(kolekcja);
}

// KROK 3: Aktualizacja statystyk za pomocą metod reduce() i filter()
function aktualizujPodsumowanie(kolekcja) {
  const spanDostepne = document.querySelector("#stat-dostepne-uslugi");
  const spanStawka = document.querySelector("#stat-srednia-stawka");
  if (!spanDostepne || !spanStawka) return;

  // TODO: Oblicz liczbę dostępnych usług (filter) oraz średnią stawkę (reduce)
}

// KROK 4: Obsługa formularza dodawania nowej usługi
const formUsluga = document.querySelector("#form-usluga");
if (formUsluga) {
  formUsluga.addEventListener("submit", (e) => {
    e.preventDefault();
    // TODO: Odczytaj wartości, stwórz obiekt z id: Date.now() i dodaj do katalogUslug
    // TODO: Zaktualizuj aktualnieWyswietlane, zresetuj formularz i odśwież widok
  });
}

// KROK 5: Wyszukiwanie na żywo (zdarzenie input)
const inputSzukaj = document.querySelector("#szukaj-uslugi");
if (inputSzukaj) {
  inputSzukaj.addEventListener("input", () => {
    // TODO: Przefiltruj katalogUslug po nazwie i zaktualizuj widok
  });
}

// KROK 6: Sortowanie według stawki godzinowej (rosnąco i malejąco)
const btnRosnaco = document.querySelector("#btn-sortuj-rosnaco");
const btnMalejaco = document.querySelector("#btn-sortuj-malejaco");
if (btnRosnaco && btnMalejaco) {
  btnRosnaco.addEventListener("click", () => {
    // TODO: Posortuj aktualnieWyswietlane rosnąco i odśwież widok
  });

  btnMalejaco.addEventListener("click", () => {
    // TODO: Posortuj aktualnieWyswietlane malejąco i odśwież widok
  });
}

// Inicjalne renderowanie
renderujKatalogUslug(aktualnieWyswietlane);
