// Zadanie 2 — Tablica obiektów i katalog wydawniczy
// Twój cel: Zdefiniuj kolekcję obiektów w tablicy i wyrenderuj wiersze tabeli za pomocą metody forEach().

// KROK 1: Zdefiniuj tablicę obiektów `katalogKsiazek`
// Umieść w niej co najmniej 3 pozycje, w tym książkę "Wprowadzenie do JavaScriptu" (autor: Jan Kowalski, cena: 69.90).
const katalogKsiazek = [
  // TODO: uzupełnij obiekty w tablicy
  {id: 1, tytul: 'Wprowadzenie do JavaScriptu', autor: "Jan Kowalski", cena: 69.90, kategoria: 'Programowanie', dostepna: true},
  {id: 2, tytul: 'Wprowadzenie do PHP', autor: "Jan Kowalski", cena: 67.00, kategoria: 'Programowanie', dostepna: false},
  {id: 3, tytul: 'Podstawy zarządzania serwerowym systemem operacyjnym Linux', autor: 'Mariusz Loryś', cena: 84.99, kategoria: 'Informatyka', dostepna: true}
];

// KROK 2: Zaimplementuj funkcję `renderujTabeleKsiazek(kolekcja)`
// 1. Pobierz element `#tabela-ksiazek tbody`.
// 2. Wyczyść go: `tbody.replaceChildren()`.
// 3. Użyj metody `kolekcja.forEach((ksiazka) => { ... })`.
// 4. Dla każdej pozycji utwórz element `<tr>` oraz komórki `<td>`.
// 5. Ustaw wartości komórek za pomocą `textContent`.
// 6. Dodaj wiersz do `tbody`.
function renderujTabeleKsiazek(kolekcja) {
  const tbody = document.querySelector("#tabela-ksiazek tbody");
  if (!tbody) return;
  tbody.replaceChildren();
  // TODO: zaimplementuj pętlę forEach i tworzenie elementów DOM
  kolekcja.forEach(ksiazka => {
  
    const tr = document.createElement('tr');
    
    const tdid = document.createElement('td');
    tdid.textContent = `Indentyfikator książki: ${ksiazka.id}`;
    tr.appendChild(tdid);

    const tdtytul = document.createElement('td');
    tdtytul.textContent = `Tytuł: ${ksiazka.tytul}`;
    tr.appendChild(tdtytul);

    const tdautor = document.createElement('td');
    tdautor.textContent = `Autor: ${ksiazka.autor}`;
    tr.appendChild(tdautor);

    const tdkategoria = document.createElement('td');
    tdkategoria.textContent = `Kategoria: ${ksiazka.kategoria}`;
    tr.appendChild(tdkategoria);

    const tdcena = document.createElement('td');
    tdcena.textContent = `Cena: ${ksiazka.cena.toFixed(2)} zł`;
    tr.appendChild(tdcena);

    const tddostepnosc = document.createElement('td');
    tddostepnosc.textContent = `Dostępność: ${ksiazka.dostepna}`;
    tr.appendChild(tddostepnosc);

    if (ksiazka.dostepna === true){
      tddostepnosc.classList.add('stan-dostepny');
    } else {
      tddostepnosc.classList.add('stan-niedostepny');
    }

    tbody.appendChild(tr);
  });
}

// KROK 3: Wywołaj funkcję renderującą
renderujTabeleKsiazek(katalogKsiazek);
