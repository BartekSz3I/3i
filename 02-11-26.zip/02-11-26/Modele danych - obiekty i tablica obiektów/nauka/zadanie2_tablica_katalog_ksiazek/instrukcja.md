# Instrukcja: Zadanie 2 — Tablica obiektów i katalog wydawniczy

## Cel zadania
Celem ćwiczenia jest opanowanie pracy z kolekcjami obiektów w języku JavaScript: zdefiniowanie jednowymiarowej tablicy obiektów reprezentującej katalog publikacji oraz iteracyjne wygenerowanie tabeli w drzewie DOM za pomocą metody `forEach()`. Uczeń poznaje wzorzec separacji danych (stan w tablicy) od widoku (elementy HTML) oraz techniki bezpiecznego wstawiania danych do komórek tabeli.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Księgarnie i biblioteki cyfrowe (np. Empik, Legimi):** lista książek, e-booków czy audiobooków jest przechowywana w pamięci jako tablica obiektów i wyświetlana w postaci tabeli lub siatki kart z tytułem, autorem, ceną i dostępnością.
2. **Katalogi produktów w e-commerce (np. x-kom, Morele):** lista towarów w danej kategorii to tablica obiektów renderowana po załadowaniu podstrony.
3. **Panele administratora CMS (np. WordPress, Strapi):** widok tabeli wpisów blogowych lub artykułów generowany jest z kolekcji obiektów zawierających tytuł, autora, datę i status publikacji.

## Wymagania funkcjonalne
1. W pliku `script.js` zadeklaruj tablicę obiektów `katalogKsiazek` zawierającą co najmniej 3 pozycje. Każdy obiekt reprezentujący książkę musi posiadać właściwości:
   - `id`: unikalny identyfikator numeryczny,
   - `tytul`: ciąg znaków z tytułem książki,
   - `autor`: ciąg znaków z imieniem i nazwiskiem autora,
   - `cena`: wartość liczbowa,
   - `kategoria`: kategoria literacka (np. "programowanie", "fantastyka", "poradnik"),
   - `dostepna`: wartość logiczna `true` lub `false`.
2. Zaimplementuj funkcję `renderujTabeleKsiazek(kolekcja)`, która:
   - pobiera element `#tabela-ksiazek tbody`,
   - czyści jego dotychczasową zawartość za pomocą `tbody.replaceChildren()`,
   - dla każdego obiektu w tablicy tworzy wiersz `<tr>` oraz komórki `<td>` dla: ID, tytułu, autora, kategorii, sformatowanej ceny (np. `69.90 zł`) oraz statusu dostępności (z odpowiednią klasą CSS `.stan-dostepny` lub `.stan-niedostepny`),
   - dołącza utworzony wiersz do `<tbody>`.
3. Wszystkie wartości tekstowe pochodzące z obiektów muszą być przypisywane **wyłącznie za pomocą `textContent`**.

## Treść do wpisania
W początkowej tablicy obiektów umieść pozycję o następujących danych:
- Tytuł: "Wprowadzenie do JavaScriptu"
- Autor: "Jan Kowalski"
- Kategoria: "programowanie"
- Cena: 69.90
- Dostępność: true
- Opis statusu w tabeli: "Katalog wydawniczy: Wprowadzenie do JavaScriptu, autor: Jan Kowalski, cena: 69.90 zł, status: dostępna w magazynie."

## Wskazówki implementacyjne
- Do iteracji po tablicy obiektów użyj metody `kolekcja.forEach((ksiazka) => { ... })`.
- Do formatowania kwot numerycznych użyj metody `ksiazka.cena.toFixed(2) + " zł"`.
- Zamiast sklejać stringi w `innerHTML`, twórz węzły `document.createElement("td")` — zapobiega to lukom bezpieczeństwa.
