# Teoria: Modele danych w JavaScript — obiekty i tablica obiektów

**Przedmiot:** Programowanie aplikacji internetowych (PAI / INF.03)  
**Semestr:** 4 (Aplikacje Frontendowe: Formularze, RegEx, CRUD, Storage)  
**Temat:** T56 — Modele danych: obiekty i tablica obiektów  

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Dlaczego potrzebujemy modeli danych w aplikacjach frontendowych?

W początkowych etapach nauki JavaScriptu częstą praktyką jest traktowanie drzewa DOM (kodu HTML wyświetlanego w przeglądarce) jako jedynego magazynu informacji. Programista pobiera tekst z elementu `<span>`, analizuje zawartość komórki tabeli `<td>`, a wynik obliczeń bezpośrednio dopisuje do innego elementu.

W profesjonalnych aplikacjach internetowych takie podejście prowadzi do chaosu i błędów. Gdy aplikacja ma kilkadziesiąt pozycji, filtrowanie, sortowanie czy przeliczanie sumy staje się uciążliwe i powolne.

Dlatego w nowoczesnym frontendzie stosujemy **separację stanu (danych) od widoku (prezentacji)**:
1. **Model danych (stan aplikacji):** wszystkie informacje przechowujemy w strukturach języka JavaScript — pojedyncze rekordy to **obiekty**, a cała kolekcja pozycji to **tablica obiektów**. To jest tzw. *Single Source of Truth* (jedyne źródło prawdy).
2. **Widok (DOM):** elementy HTML na stronie są wyłącznie graficzną prezentacją aktualnego stanu tablicy. Kiedy dane się zmieniają, aktualizujemy tablicę obiektów, a następnie na jej podstawie odświeżamy elementy widoczne dla użytkownika.

> **Po co to jest:**  
> Separacja danych od drzewa DOM pozwala na błyskawiczne sortowanie, filtrowanie i przeliczanie danych za pomocą wbudowanych metod JavaScriptu bez konieczności mozolnego i podatnego na błędy parsowania tekstu z tagów HTML.

> **Typowa pomyłka:**  
> Próba sortowania lub filtrowania listy poprzez odczytywanie tekstu bezpośrednio z elementów `<li>` lub wierszy `<tr>` w pętli. Prawidłowy wzorzec to posortowanie lub odfiltrowanie tablicy obiektów w kodzie JS i wygenerowanie świeżego widoku HTML na podstawie przefiltrowanej tablicy.

---

## 2. Literał obiektu jako encja / rekord danych

W programowaniu **encją** (lub rekordem) nazywamy pojedynczą, spójną jednostkę informacji w systemie — na przykład jeden produkt w sklepie, jedno zgłoszenie serwisowe, jednego klienta czy jeden bilet.

Do modelowania encji w języku JavaScript służy **literał obiektu**, czyli para nawiasów klamrowych `{}` zawierająca pary klucz-wartość:

```javascript
const usluga = {
  id: 101,
  nazwa: "Wymiana dysku SSD",
  kategoria: "serwis",
  cena: 180.50,
  dostepna: true,
  dataRejestracji: "2026-11-01"
};
```

### Typowanie właściwości i dostęp do pól
Właściwości obiektu mogą przechowywać dowolne typy danych:
- liczby (`number`) — np. identyfikatory, ceny, stany magazynowe,
- łańcuchy znaków (`string`) — np. nazwy, opisy, kody,
- wartości logiczne (`boolean`) — np. flagi dostępności, aktywności czy opłacenia,
- daty lub tablice powiązanych wartości.

Dostęp do właściwości obiektu realizujemy na dwa sposoby:
1. **Notacja kropkowa (*dot notation*):** `usluga.nazwa`, `usluga.cena` — czytelna i preferowana w większości sytuacji.
2. **Notacja nawiasowa (*bracket notation*):** `usluga["nazwa"]` — konieczna, gdy nazwa klucza pochodzi ze zmiennej lub zawiera znaki specjalne (np. myślnik).

```javascript
console.log(usluga.nazwa); // "Wymiana dysku SSD"

const pole = "cena";
console.log(usluga[pole]); // 180.5
```

> **Po co to jest:**  
> Literał obiektu pozwala powiązać ze sobą logicznie powiązane atrybuty pojedynczej pozycji w jeden zwarty i uporządkowany kontener danych.

> **Typowa pomyłka:**  
> Tworzenie równoległych pojedynczych tablic dla każdej właściwości (np. `let nazwy = []`, `let ceny = []`, `let statusy = []`) i próba synchronizacji ich po wspólnym indeksie `[i]`. Usunięcie lub posortowanie jednej z nich natychmiast rozsynchronizuje dane. Zawsze tworzymy **jedną tablicę obiektów**.

---

## 3. Rola jednoznacznego identyfikatora (`id`)

Każdy obiekt reprezentujący encję powinien posiadać pole `id` (klucz główny). Identyfikator ten musi być unikalny w obrębie całej kolekcji. Dzięki niemu aplikacja może bezbłędnie zidentyfikować konkretny rekord, nawet jeśli dwa produkty mają identyczną nazwę lub cenę.

Najczęściej stosowane sposoby generowania identyfikatorów w aplikacjach frontendowych:
1. **Znacznik czasu (`Date.now()`):** zwraca liczbę milisekund od 1 stycznia 1970 roku. Jest bardzo prosty i zapewnia unikalność przy ręcznym wprowadzaniu danych przez użytkownika.
2. **Licznik sekwencyjny:** zmienna pomocnicza zwiększana o 1 przy każdym dodaniu rekordu (np. `let nastepneId = 1; const id = nastepneId++;`).

```javascript
function utworzZgloszenie(klient, usterka, koszt) {
  return {
    id: Date.now(),
    klient: klient.trim(),
    usterka: usterka.trim(),
    koszt: Number(koszt),
    zrealizowane: false
  };
}
```

> **Po co to jest:**  
> Unikalne pole `id` pozwala jednoznacznie odnaleźć, sprawdzić lub powiązać dany rekord w kolekcjach danych bez ryzyka pomyłki przy powtarzających się nazwach.

> **Typowa pomyłka:**  
> Używanie indeksu tablicy (`0, 1, 2...`) jako trwałego identyfikatora obiektu. Po przefiltrowaniu lub posortowaniu tablicy indeksy ulegają zmianie, przez co indeks przestaje wskazywać na ten sam obiekt! Identyfikator `id` musi być na stałe wpisany wewnątrz obiektu.

---

## 4. Kolekcje danych: tablica obiektów

Gdy aplikacja zarządza wieloma rekordami, przechowujemy je w jednowymiarowej tablicy obiektów:

```javascript
const katalogKursow = [
  { id: 1, tytul: "Podstawy HTML i CSS", poziom: "podstawowy", godziny: 30, aktywny: true },
  { id: 2, tytul: "JavaScript w DOM", poziom: "sredni", godziny: 45, aktywny: true },
  { id: 3, tytul: "Zaawansowane RegEx", poziom: "zaawansowany", godziny: 20, aktywny: false }
];
```

Tablica ta jest centralną strukturą danych w pamięci programu. Dodawanie nowego rekordu polega na dołożeniu obiektu na koniec tablicy za pomocą metody `push()`:

```javascript
const nowyKurs = {
  id: 4,
  tytul: "Formularze i walidacja",
  poziom: "sredni",
  godziny: 25,
  aktywny: true
};

katalogKursow.push(nowyKurs);
```

> **Po co to jest:**  
> Tablica obiektów stanowi zwartą i uporządkowaną bazę danych w pamięci podręcznej przeglądarki, na której możemy wykonywać dowolne zapytania analityczne.

> **Typowa pomyłka:**  
> Próba dodania do tablicy pojedynczych pól zamiast całego obiektu (np. `tablica.push(nazwa, cena)`). Prawidłowo do tablicy przekazujemy **cały obiekt** reprezentujący rekord: `tablica.push({ id, nazwa, cena })`.

---

## 5. Przekształcanie danych z formularza w obiekt modelu

Kiedy użytkownik uzupełnia formularz na stronie WWW, przeglądarka dostarcza dane w postaci wartości tekstowych (`string`) z kontrolek formularza. Zadaniem programisty jest:
1. Zablokowanie domyślnego przeładowania strony metodą `e.preventDefault()`.
2. Pobranie referencji do kontrolek wejściowych.
3. Rygorystyczna konwersja typów (np. `Number(input.value)` dla liczb, `checkbox.checked` dające `boolean`).
4. Utworzenie obiektu encji i umieszczenie go w kolekcji.
5. Zresetowanie formularza metodą `form.reset()`.

```javascript
const formularz = document.querySelector("#formularz-produktu");
const listaProduktow = [];

formularz.addEventListener("submit", (e) => {
  e.preventDefault();

  const nazwaInput = document.querySelector("#produkt-nazwa");
  const cenaInput = document.querySelector("#produkt-cena");
  const kategoriaSelect = document.querySelector("#produkt-kategoria");
  const naStanieCheckbox = document.querySelector("#produkt-dostepny");

  // Walidacja podstawowa
  const nazwaWartosc = nazwaInput.value.trim();
  const cenaWartosc = Number(cenaInput.value);

  if (!nazwaWartosc || cenaWartosc <= 0 || isNaN(cenaWartosc)) {
    return; // Nieprawidłowe dane - przerywamy
  }

  // Tworzenie obiektu modelu danych
  const nowyProdukt = {
    id: Date.now(),
    nazwa: nazwaWartosc,
    cena: cenaWartosc,
    kategoria: kategoriaSelect.value,
    dostepny: naStanieCheckbox.checked
  };

  // Dodanie do kolekcji w pamięci
  listaProduktow.push(nowyProdukt);

  // Czyszczenie pól formularza
  formularz.reset();

  // Odświeżenie widoku na stronie
  renderujProdukty(listaProduktow);
});
```

> **Po co to jest:**  
> Jawne rzutowanie typów (`Number()`, `Boolean()`) przy tworzeniu obiektu chroni przed błędami arytmetycznymi — w JavaScript dodanie wartości tekstowych `"100" + "50"` daje `"10050"`, a nie `150`.

> **Typowa pomyłka:**  
> Zapomnienie o `Number(input.value)` i pozostawienie liczby jako tekstu. Przy późniejszym sortowaniu teksty `"10"`, `"100"`, `"2"` zostaną posortowane leksykograficznie jako `10, 100, 2`, a nie numerycznie jako `2, 10, 100`.

---

## 6. Przetwarzanie kolekcji metodami funkcyjnymi tablic

JavaScript oferuje zestaw potężnych metod tablicowych, które ułatwiają operacje na kolekcjach obiektów:

### 6.1. Iteracja: `forEach()`
Służy do wykonania operacji dla każdego elementu tablicy (np. generowania widoku):
```javascript
katalogKursow.forEach((kurs) => {
  console.log(`Kurs: ${kurs.tytul}, Czas: ${kurs.godziny}h`);
});
```

### 6.2. Filtrowanie: `filter()`
Tworzy nową tablicę zawierającą tylko te obiekty, które spełniają zadany warunek (zwracają `true` w funkcji testującej):
```javascript
// Tylko kursy aktywne o wymiarze powyżej 20 godzin
const dlugieAktywne = katalogKursow.filter((kurs) => kurs.aktywny && kurs.godziny > 20);
```

### 6.3. Wyszukiwanie: `find()` oraz `findIndex()`
- `find()` zwraca **pierwszy obiekt** spełniający kryterium (lub `undefined`, jeśli nie znaleziono).
- `findIndex()` zwraca indeks znalezionego obiektu (lub `-1`).
```javascript
const szukanyKurs = katalogKursow.find((kurs) => kurs.id === 2);
if (szukanyKurs) {
  console.log("Znaleziono:", szukanyKurs.tytul);
}
```

### 6.4. Sortowanie: `sort()` oraz `toSorted()`
Sortowanie obiektów wymaga przekazania **funkcji komparatora** `(a, b) => ...`:
- Dla liczb: `(a, b) => a.cena - b.cena` (rosnąco) lub `b.cena - a.cena` (malejąco).
- Dla łańcuchów znaków: `(a, b) => a.nazwa.localeCompare(b.nazwa)`.

```javascript
// Sortowanie rosnąco według liczby godzin
const posortowaneGodziny = [...katalogKursow].sort((a, b) => a.godziny - b.godziny);

// Sortowanie alfabetycznie według tytułu (z uwzględnieniem polskich znaków)
const posortowaneTytuly = [...katalogKursow].sort((a, b) => a.tytul.localeCompare(b.tytul));
```
*Wskazówka:* Użycie operatora spread `[...tablica]` tworzy płytką kopię, dzięki czemu oryginalna tablica zachowuje pierwotną kolejność dodawania elementów.

### 6.5. Agregacja i statystyka: `reduce()`
Przetwarza tablicę do pojedynczej wartości zbiorczej (suma, średnia, licznik):
```javascript
// Suma godzin wszystkich kursów
const lacznyCzas = katalogKursow.reduce((suma, kurs) => suma + kurs.godziny, 0);

// Średni czas trwania
const sredniCzas = katalogKursow.length > 0 ? (lacznyCzas / katalogKursow.length).toFixed(1) : 0;
```

> **Po co to jest:**  
> Metody `filter()`, `find()`, `sort()` i `reduce()` umożliwiają deklaratywne operowanie na danych biznesowych — kod jest zwięzły, samouzasadniający się i odporny na pomyłki indeksowania w klasycznych pętlach `for`.

> **Typowa pomyłka:**  
> Brak wartości początkowej w `reduce()` (drugi argument po funkcji zwrotnej, np. `, 0`). Bez zera jako akumulatora, pierwszym akumulatorem stanie się cały pierwszy obiekt `{ id: 1, ... }`, co doprowadzi do błędu `[object Object]45`.

---

## 7. Renderowanie kolekcji w DOM i ochrona przed XSS

Najważniejszym obowiązkiem programisty podczas renderowania danych w przeglądarce jest **ochrona przed atakiem Cross-Site Scripting (XSS)**.

Gdy dane pochodzą z pól formularza wpisywanych przez użytkownika, złośliwy użytkownik może wpisać jako nazwę produktu:
```html
<img src="x" onerror="alert('Atak XSS!')">
```
Jeśli wstrzykniemy ten tekst bezpośrednio do `innerHTML`, przeglądarka zinterpretuje go jako kod HTML i wykona wstrzyknięty skrypt!

### Dwa bezpieczne wzorce renderowania widoku:

#### Wzorzec A: Bezpieczne tworzenie węzłów (`document.createElement`)
To najbardziej niezawodny standard CKE i kwalifikacji INF.03:

```javascript
function renderujTabele(elementy) {
  const tbody = document.querySelector("#tabela-danych tbody");
  tbody.replaceChildren(); // Bezpieczne wyczyszczenie poprzedniej zawartości

  elementy.forEach((item) => {
    const tr = document.createElement("tr");

    const tdId = document.createElement("td");
    tdId.textContent = item.id;

    const tdNazwa = document.createElement("td");
    tdNazwa.textContent = item.nazwa; // Zabezpiecza przed XSS! Tekst jest bezpiecznie kodowany

    const tdCena = document.createElement("td");
    tdCena.textContent = `${item.cena.toFixed(2)} zł`;

    const tdStatus = document.createElement("td");
    tdStatus.textContent = item.dostepny ? "Dostępny" : "Niedostępny";

    tr.append(tdId, tdNazwa, tdCena, tdStatus);
    tbody.append(tr);
  });
}
```

#### Wzorzec B: Kontrolowany szablon z bezpiecznym traktowaniem tekstu
Jeśli stosujemy szablony w `innerHTML`, surowe wartości użytkownika wolno wstawiać **wyłącznie** po ich sanityzacji lub poprzez tworzenie węzłów z właściwością `textContent`:

```javascript
// Bezpieczne wstawianie statycznej struktury z węzłami dynamicznymi
function renderujKarty(elementy) {
  const kontener = document.querySelector("#kontener-kart");
  kontener.replaceChildren();

  elementy.forEach((item) => {
    const karta = document.createElement("div");
    karta.className = "karta-pozycji";

    const tytul = document.createElement("h3");
    tytul.textContent = item.nazwa; // Bezpiecznie!

    const opis = document.createElement("p");
    opis.textContent = `Cena: ${item.cena.toFixed(2)} PLN | Status: ${item.dostepny ? "Aktywny" : "Wstrzymany"}`;

    karta.append(tytul, opis);
    kontener.append(karta);
  });
}
```

> **Po co to jest:**  
> Właściwość `textContent` traktuje wprowadzony ciąg ściśle jako tekst znakowy, automatycznie neutralizując znaczniki `<script>`, `<img>`, tagi HTML oraz znaki specjalne `<` i `>`.

> **Typowa pomyłka:**  
> Stosowanie zapisu `tr.innerHTML = "<td>" + item.nazwa + "</td>"`. Jeżeli `item.nazwa` zawiera kod HTML lub złośliwy skrypt, strona staje się podatna na krytyczną lukę bezpieczeństwa XSS.

---

## 8. Zestawienie standardów i ograniczeń w module T56

| Zagadnienie | Dozwolone i zalecane w T56 | Bezwzględnie zabronione w T56 |
|-------------|----------------------------|-------------------------------|
| **Model danych** | Obiekt z kluczem `id`, typowane pola (`number`, `string`, `boolean`) | Równoległe tablice zamiast obiektów, brak `id` |
| **Kolekcja** | Jednowymiarowa tablica obiektów `[{}, {}]` | Trzymanie danych wyłącznie w drzewie DOM |
| **Pobieranie danych** | `form.addEventListener('submit')` z `e.preventDefault()`, konwersja `Number()`, `.trim()` | Odczyt bez blokady przeładowania, brak rzutowania typów |
| **Operacje na danych** | Metody `forEach`, `filter`, `find`, `sort`, `reduce` | Modyfikacja widoku bez aktualizacji tablicy danych |
| **Wypis i DOM** | `replaceChildren()`, `createElement()`, `textContent`, `append()` | Wstrzykiwanie tekstu użytkownika do `innerHTML` |
| **Pamięć trwała** | Zmienne w pamięci JS (`const`, `let`) | `localStorage`, `sessionStorage` (tematy T60–T61) |
| **Ciasteczka i sieć** | Logika w pamięci przeglądarki | `document.cookie` (T62), `fetch`, REST API, Node/PHP |
| **Styl kodu** | `const`, `let`, funkcje strzałkowe, `addEventListener` | `var`, zdarzenia inline `onclick`, `alert()`, `prompt()` |
