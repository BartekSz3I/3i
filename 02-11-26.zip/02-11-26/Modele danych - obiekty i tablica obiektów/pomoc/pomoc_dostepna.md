# Pomoc dostępna: Przewodnik krok po kroku

Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

Ten dokument opisuje krok po kroku, w jaki sposób wykonywać zadania z działu T56. Każdy krok zawiera jedną konkretną czynność do zrobienia.

---

## 1. Słowniczek pojęć tego działu

- **Obiekt (literał obiektu):** kontener w języku JavaScript zapisywany w nawiasach klamrowych `{}`. Zawiera właściwości opisujące jeden element, na przykład cenę i nazwę produktu.
- **Właściwość obiektu:** pojedyncza informacja zapisana w obiekcie jako para klucz i wartość, na przykład `cena: 150`.
- **Identyfikator (`id`):** unikalny numer przypisany do każdego obiektu w programie. Pozwala jednoznacznie rozróżnić dwa rekordy, nawet gdy mają taką samą nazwę.
- **Tablica obiektów:** lista zapisana w nawiasach kwadratowych `[]`, która przechowuje wiele obiektów jeden po drugim.
- **Renderowanie:** proces tworzenia lub aktualizowania widocznych elementów HTML na stronie na podstawie danych zapisanych w pamięci programu.
- **XSS (Cross-Site Scripting):** błąd bezpieczeństwa polegający na wstrzyknięciu obcego skryptu do strony. Zapobiegamy mu, wpisując tekst użytkownika wyłącznie przez właściwość `textContent`.

---

## 2. Stała kolejność pracy nad każdym zadaniem

Podczas pracy nad dowolnym zadaniem z tego modułu wykonuj poniższe kroki w podanej kolejności.

1. **Krok 1: Przeczytaj plik `instrukcja.md` w folderze zadania.**  
   Dowiesz się z niego, jaki program masz napisać, jakie kontrolki znajdują się w formularzu oraz jakie pola powinien zawierać obiekt danych.

2. **Krok 2: Otwórz plik `index.html` w przeglądarce i edytorze kodu.**  
   Zobacz, jak strona wygląda przed wprowadzeniem zmian. W pliku HTML odszukaj identyfikatory elementów (`id`), z którymi będziesz pracować.

3. **Krok 3: Otwórz plik `script.js` w edytorze kodu.**  
   W pliku skryptu znajdziesz komentarze wskazujące miejsca na Twój kod, na przykład `// KROK 1:` lub `// Twoje rozwiazanie`.

4. **Krok 4: Wpisz kod obsługi zdarzenia i tworzenia obiektu.**  
   Pobierz wartości z pól, przekonwertuj liczby za pomocą funkcji `Number()`, utwórz obiekt i dodaj go do tablicy metodą `push()`.

5. **Krok 5: Zapisz plik i odśwież stronę w przeglądarce.**  
   Wypełnij formularz przykładowymi danymi i naciśnij przycisk zatwierdzający. Sprawdź, czy dane poprawnie pojawiły się na liście lub w tabeli.

6. **Krok 6: Otwórz konsolę deweloperską przeglądarki (klawisz F12).**  
   Upewnij się, że w zakładce *Console* nie wyświetlają się żadne czerwone komunikaty o błędach.

7. **Krok 7: Porównaj swój kod z folderem `rozwiazanie/`.**  
   Dopiero po samodzielnej próbie rozwiązania zadania otwórz pliki z folderu `rozwiazanie/`. Sprawdź, czy Twój kod realizuje wszystkie wymagania.

---

## 3. Oznaczenia miejsc pracy w plikach

W plikach szablonu zadania miejsca wymagające Twojego działania są wyraźnie oznaczone komentarzami.

W plikach HTML miejsce na nowe elementy oznacza komentarz:
```html
<!-- KROK 1: Tutaj dodaj kod formularza -->
```

W plikach JavaScript Twoje instrukcje wpisuj bezpośrednio pod komentarzem:
```javascript
// KROK 1: Pobierz referencje do pól formularza
const inputNazwa = document.querySelector("#nazwa");

// KROK 2: Obsłuż zdarzenie submit
formularz.addEventListener("submit", (e) => {
  e.preventDefault();
  // Twoje rozwiazanie
});
```

---

## 4. Zasady dostępności i czytelności (a11y) w tym dziale

1. **Etykiety pól formularza:** Każde pole wejściowe `<input>` lub `<select>` musi posiadać przypisaną etykietę `<label>`. Identyfikator w atrybucie `for` etykiety musi być dokładnie taki sam jak atrybut `id` w polu.
2. **Nagłówki w tabelach danych:** W tabelach generowanych przez JavaScript komórki nagłówkowe zapisuj jako `<th>` z atrybutem `scope="col"`. Dzięki temu czytniki ekranu poprawnie odczytają kolumny osobom niewidomym.
3. **Walidacja w T56:** Gdy dane z formularza są niepoprawne, w tym module wystarczy **przerwać obsługę** (`return`) bez dodawania rekordu — bez `alert()` i bez obowiązkowego komunikatu na stronie. Komunikat w elemencie z `role="alert"` albo klasa `.blad-walidacji` są opcjonalne i stosujesz je tylko wtedy, gdy dana `instrukcja.md` wyraźnie tego wymaga.
