# Pomoc: Szybka ściąga i zestawienie szablon vs rozwiązanie

**Moduł:** T56 — Modele danych: obiekty i tablica obiektów  
**Przeznaczenie:** Podręczna pomoc dydaktyczna do pracy warsztatowej na lekcji  

---

## 1. Zestawienie: Szablon startowy vs Folder `rozwiazanie/`

Każde zadanie w katalogu `nauka/` oraz `sprawdzian/` posiada gotowy szablon roboczy dla ucznia oraz wzorcowy katalog referencyjny:

| Element | Szablon w katalogu zadania (dla ucznia) | Katalog referencyjny `rozwiazanie/` |
|---------|-----------------------------------------|--------------------------------------|
| `index.html` | Kompletna, semantyczna struktura strony z formularzem, tabelą lub kontenerem widoku; podpięte pliki `style.css` oraz `script.js`. | Identyczna struktura HTML z podpiętymi skryptami rozwiązania. |
| `style.css` | Gotowe reguły układu (CSS Grid / Flexbox), klasy stanu (`.ukryty`, `.blad-walidacji`, `.aktywny`) oraz formatowanie tabel. | Pełne style wizualne odpowiadające szablonowi roboczemu. |
| `script.js` | Gotowe selektory DOM, zdefiniowane stałe lub komentarze instruktażowe `// KROK 1: ...`; miejsce na Twoją implementację. | Kompletny, w 100% działający kod JavaScript bez braków i atrap logicznych. |
| `dane.js` *(gdy dotyczy)* | Plik z bazową tablicą obiektów w formacie `UPPER_SNAKE_CASE` linkowany przed `script.js`. | Ten sam plik `dane.js` wykorzystywany do zasilenia aplikacji w rozwiązaniu. |

---

## 2. Podręczna ściąga składniowa modułu T56

### Definicja modelu obiektu i tablicy
```javascript
// 1. Obiekt pojedynczego rekordu (encja)
const rekord = {
  id: Date.now(),             // Unikalny identyfikator
  nazwa: "Projekt graficzny", // Ciąg znaków
  cena: 450.00,               // Liczba
  aktywny: true               // Wartość logiczna (boolean)
};

// 2. Tablica obiektów (Single Source of Truth)
const bazaProjektow = [];
bazaProjektow.push(rekord);
```

### Obsługa formularza i tworzenie nowego rekordu
```javascript
formularz.addEventListener("submit", (e) => {
  e.preventDefault(); // Blokada przeładowania strony!

  const nowyWpis = {
    id: Date.now(),
    tytul: inputTytul.value.trim(),
    stawka: Number(inputStawka.value), // Obowiązkowa konwersja do liczby!
    priorytet: selectPriorytet.value,
    oplacone: checkboxOplacone.checked // Wartość boolean true/false
  };

  bazaProjektow.push(nowyWpis);
  formularz.reset(); // Czyszczenie kontrolek
  renderujWidok(bazaProjektow);
});
```

### Metody tablicowe — operacje na kolekcji
```javascript
// Filtrowanie (zwraca nową tablicę spełniającą warunek)
const tylkoOplacone = bazaProjektow.filter((item) => item.oplacone);

// Wyszukiwanie pojedynczego rekordu po ID
const znaleziony = bazaProjektow.find((item) => item.id === szukaneId);

// Sortowanie rosnąco według liczby (bezpieczna kopia niemutująca oryginału)
const posortowaneCeny = [...bazaProjektow].sort((a, b) => a.stawka - b.stawka);

// Sortowanie alfabetyczne według tekstu
const alfabetycznie = [...bazaProjektow].sort((a, b) => a.tytul.localeCompare(b.tytul));

// Agregacja / suma (reduce z wartością początkową 0)
const lacznyKoszt = bazaProjektow.reduce((suma, item) => suma + item.stawka, 0);
```

### Bezpieczne renderowanie widoku w DOM (ochrona przed XSS)
```javascript
function renderujWidok(kolekcja) {
  const tbody = document.querySelector("#tabela-danych tbody");
  tbody.replaceChildren(); // Czyszczenie poprzednich wierszy

  kolekcja.forEach((item) => {
    const tr = document.createElement("tr");

    const tdTytul = document.createElement("td");
    tdTytul.textContent = item.tytul; // ZABEZPIECZENIE PRZED XSS!

    const tdStawka = document.createElement("td");
    tdStawka.textContent = `${item.stawka.toFixed(2)} zł`;

    const tdStatus = document.createElement("td");
    tdStatus.textContent = item.oplacone ? "Opłacone" : "Oczekuje";

    tr.append(tdTytul, tdStawka, tdStatus);
    tbody.append(tr);
  });
}
```

---

## 3. Szybkie przypomnienie — 5 zasad dobrego kodu

1. **Konsola DevTools (F12) to Twój pierwszy doradca:** Jeśli po kliknięciu przycisku nic się nie dzieje, otwórz zakładkę *Console*. Czerwony komunikat wskaże dokładny numer linii z błędem.
2. **Sprawdzaj typy danych (`typeof`):** Wartość odczytana z `input.value` jest zawsze ciągiem znaków (`string`). Zawsze używaj `Number(input.value)` lub `input.valueAsNumber` przed operacjami arytmetycznymi.
3. **Nie sortuj oryginału bez potrzeby:** Metoda `sort()` modyfikuje tablicę w miejscu. Aby zachować pierwotną kolejność dodawania, twórz płytką kopię: `[...tablica].sort(...)`.
4. **Zawsze podawaj `0` w `reduce()`:** `tablica.reduce((acc, el) => acc + el.cena, 0)` — brak drugiego argumentu skutkuje potraktowaniem pierwszego obiektu jako liczby, co daje błąd `[object Object]`.
5. **Nigdy nie wstrzykuj tekstu użytkownika do `innerHTML`:** Wypisuj dane przez `element.textContent` lub twórz węzły `document.createElement()`. To gwarantuje 100% odporności na ataki XSS.
