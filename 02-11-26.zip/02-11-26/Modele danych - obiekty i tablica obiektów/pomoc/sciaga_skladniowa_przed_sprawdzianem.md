# Ściąga składniowa T56 — materiał przed sprawdzianem

**Przeznaczenie:** powtórka na lekcji / przygotowanie ucznia **przed** sprawdzianem.  
**Na czas sprawdzianu:** nie udostępniać (tryb egzaminacyjny: behawioralne kryteria + ID + komunikaty, bez przepisu kodu).

---

## Literał obiektu i unikalne ID

```javascript
const rekord = {
  id: Date.now(),
  nazwa: inputNazwa.value.trim(),
  cena: Number(inputCena.value),
  aktywny: checkbox.checked
};
```

## Tablica obiektów i dodawanie pozycji

```javascript
const kolekcja = [];
kolekcja.push(rekord);
```

## Filtrowanie kolekcji (`filter`)

```javascript
const przefiltrowane = kolekcja.filter((item) => item.kategoria === wybranaKategoria);
```

## Agregacja i sumowanie (`reduce`)

```javascript
const suma = kolekcja.reduce((acc, item) => acc + (item.cena * item.ilosc), 0);
```

## Bezpieczne renderowanie w DOM

```javascript
const tbody = document.querySelector("#tabela tbody");
tbody.replaceChildren();

kolekcja.forEach((item) => {
  const tr = document.createElement("tr");

  const tdNazwa = document.createElement("td");
  tdNazwa.textContent = item.nazwa;

  const tdCena = document.createElement("td");
  tdCena.textContent = `${item.cena.toFixed(2)} zł`;

  tr.append(tdNazwa, tdCena);
  tbody.append(tr);
});
```
