# Instrukcja krok po kroku — Moduł T04: Obiekt Math

> Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

Niniejszy materiał przedstawia proces realizacji każdego ćwiczenia w sposób dosłowny i uporządkowany. Każdy krok zawiera jedną konkretną czynność do wykonania w edytorze kodu lub przeglądarce internetowej.

---

## 1. Słowniczek pojęć używanych w tym dziale

- **`Math.random()`** — wbudowana funkcja, która losuje liczbę ułamkową większą lub równą 0 i mniejszą od 1.
- **`Math.floor(x)`** — funkcja zaokrąglająca podaną liczbę w dół do najbliższej liczby całkowitej.
- **`Math.min(a, b)`** — funkcja wybierająca i zwracająca najmniejszą liczbę spośród podanych argumentów.
- **`Math.max(a, b)`** — funkcja wybierająca i zwracająca największą liczbę spośród podanych argumentów.
- **`return`** — instrukcja wewnątrz funkcji, która odsyła wyliczony wynik do miejsca, w którym funkcja została wywołana.
- **`textContent`** — właściwość elementu HTML służąca do bezpiecznego wpisania czystego tekstu na stronę WWW.

---

## 2. Standardowy schemat pracy nad zadaniem

Wykonuj poniższe kroki po kolei dla każdego zadania:

1. **Krok 1: Otwórz plik `instrukcja.md` w folderze zadania.**  
   Przeczytaj sekcję z opisem problemu oraz sekcję z danymi wejściowymi. Zwróć uwagę na dokładne wartości liczbowe, które należy wylosować.

2. **Krok 2: Otwórz plik `script.js` w swoim edytorze kodu.**  
   Znajdź w kodzie komentarze `// Twoje rozwiazanie` lub oznaczenia kroków. W tych wyznaczonych miejscach będziesz dopisywać swój kod JavaScript.

3. **Krok 3: Napisz funkcję losującą zgodnie z wzorem.**  
   Wpisz deklarację funkcji z parametrami `min` oraz `max`. Użyj instrukcji `return Math.floor(Math.random() * (max - min + 1)) + min;`.

4. **Krok 4: Wywołaj funkcję i zapisz wynik do zmiennej.**  
   Stwórz zmienną za pomocą słowa `const` i przypisz do niej wynik wywołania swojej funkcji z wymaganymi liczbami.

5. **Krok 5: Przygotuj tekst raportu.**  
   Zbuduj łańcuch tekstowy zawierający opis i wylosowane liczby. Użyj znaku `\n`, aby przenieść kolejny wiersz do nowej linii.

6. **Krok 6: Wypisz wynik na stronę WWW.**  
   Odszukaj kontener wyjściowy za pomocą `document.getElementById("wynik")`. Przypisz przygotowany tekst do jego właściwości `textContent`.

7. **Krok 7: Zapisz plik i otwórz `index.html` w przeglądarce.**  
   Naciśnij skrót klawiszowy Ctrl+S, aby zapisać kod. Uruchom plik `index.html` w przeglądarce i naciśnij klawisz F12, aby sprawdzić, czy w konsoli nie ma czerwonych błędów.

8. **Krok 8: Porównaj działanie z folderem `rozwiazanie/`.**  
   Dopiero po zakończeniu własnej próby otwórz plik `script.js` w podkatalogu `rozwiazanie/`. Porównaj strukturę kodu i upewnij się, że Twoje rozwiązanie zwraca oczekiwane wyniki.

---

## 3. Ważne zasady tworzenia czytelnego kodu (Dostępność i A11y)

- Element wyjściowy na stronie posiada identyfikator `id="wynik"`. W pliku HTML oznaczony jest komentarzem `<!-- KROK N: Miejsce na wynik skryptu -->`.
- Wszystkie teksty prezentowane użytkownikowi muszą mieć wysoki kontrast względem tła (ciemny tekst na jasnym tle lub jasny na ciemnym).
- Nagłówki stron muszą zachowywać prawidłową hierarchię: najpierw `<h1>`, a pod nim sekcje `<h2>`. Nie wolno pomijać poziomów nagłówków.
- Wypisywany tekst powinien być prosty i czytelny, z wyraźnym oznaczeniem jednostek miary (np. „PLN”, „szt.”, „kg”).

---

## 4. Strategia pracy z Zadaniem Przyrostowym (Capstone)

Zadanie 5 (Zadanie Przyrostowe: Portal Usługowo-Handlowy IT-Partner) rozwija jedną, spójną aplikację biznesową przez cały semestr. Aby rozwiązać je krok po kroku i bez trudności, stosuj poniższą metodę 4 kroków:

1. **Zasada jednej funkcji na raz:**  
   Nie pisz całego programu od razu. W pierwszej kolejności zaimplementuj i przetestuj pojedynczą funkcję pomocniczą (np. losowanie kodu weryfikacyjnego lub wyznaczanie limitów przez `Math.min` i `Math.max`). Przetestuj jej wynik w konsoli przeglądarki (`F12`).

2. **Łączenie klocków (przepływ danych):**  
   Główna funkcja generująca raport wywołuje wcześniejsze funkcje pomocnicze, przekazując im dane wejściowe. Wyniki zwracane przez instrukcję `return` z funkcji pomocniczych zapisuj do lokalnych stałych (`const`).

3. **Dosłowna struktura raportu z instrukcji:**  
   Otwórz plik `instrukcja.md` zadania 5 i odszukaj sekcję `## Treść do wpisania`. Skopiuj strukturę etykiet tekstowych, a w wyznaczone miejsca wstaw wartości swoich zmiennych za pomocą szablonu w grawisach (backticki `` `...` `` i `${zmienna}`).

4. **Weryfikacja w przeglądarce i konsoli deweloperskiej:**  
   Zapisz plik `script.js` i odśwież stronę `index.html`. Otwórz konsolę klawiszem `F12`. Upewnij się, że nie pojawiają się czerwone błędy (`Uncaught SyntaxError` lub `ReferenceError`), a w bloku `#wynik` wyświetla się pełny raport.
