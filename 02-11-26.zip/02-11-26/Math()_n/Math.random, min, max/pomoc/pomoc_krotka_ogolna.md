# Szybka pomoc ogólna — Moduł T04: Obiekt Math (losowość, min, max)

Przewodnik podręczny dla uczniów realizujących ćwiczenia laboratoryjne i sprawdzian praktyczny z modułu T04.

---

## 1. Struktura plików: szablon startowy a folder `rozwiazanie/`

Każde zadanie w module posiada przejrzystą strukturę plików:

| Element / Plik | Rola w katalogu zadania | Rola w podkatalogu `rozwiazanie/` |
|:---------------|:------------------------|:-----------------------------------|
| `instrukcja.md` | Pełna treść zadania, dane wejściowe, cele i wymagania techniczne. | Kopia referencyjna instrukcji. |
| `index.html` | Gotowa struktura strony z elementem `<pre id="wynik"></pre>` lub `<div id="wynik"></div>` i podpiętym skryptem. | Wzorcowy plik HTML powiązany z działającym rozwiązaniem. |
| `style.css` | Kompletny arkusz stylów definiujący m.in. `white-space: pre-wrap` dla `#wynik`. | Ten sam arkusz stylów zapewniający poprawną prezentację. |
| `script.js` | Plik roboczy ucznia — zawiera komentarze prowadzące i miejsca na samodzielną implementację. | Kompletny, w 100% działający kod wzorcowy przygotowany przez nauczyciela. |

---

## 2. Ściąga składniowa i kanoniczne wzorce modułu T04

### Losowanie liczby całkowitej z przedziału `[min, max]`
```javascript
// Uniwersalny wzór z zachowaniem równego prawdopodobieństwa
function losujCalkowita(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Przykład użycia: rzut kostką (od 1 do 6)
const wynikKostki = losujCalkowita(1, 6);
```

### Losowanie liczby zmiennoprzecinkowej z formatowaniem miejsc po przecinku
```javascript
// Losowanie liczby ułamkowej i formatowanie do 2 miejsc po przecinku
const losujUlamek = (min, max) => {
  const wartosc = Math.random() * (max - min) + min;
  return parseFloat(wartosc.toFixed(2));
};

// Przykład: wylosowanie temperatury od 18.5 do 24.5 stopnia Celsjusza
const temperatura = losujUlamek(18.5, 24.5);
```

### Wyznaczanie wartości skrajnych za pomocą `Math.min()` i `Math.max()`
```javascript
const pomiarA = 14;
const pomiarB = 29;
const pomiarC = 8;

const najmniejszy = Math.min(pomiarA, pomiarB, pomiarC); // 8
const najwiekszy = Math.max(pomiarA, pomiarB, pomiarC);   // 29
```

### Standard wyprowadzania wyników na stronę (Semestr 2)
```javascript
const elWynik = document.getElementById("wynik");
let raport = "RAPORT ZADANIA:\n";
raport += `Wylosowana wartość: ${wynikKostki}\n`;
raport += `Temperatura: ${temperatura} °C\n`;

// Bezpieczny wypis tekstu do DOM
elWynik.textContent = raport;

// Diagnostyka w konsoli
console.log(raport);
```

---

## 3. Szybkie przypomnienie procedur laboratoryjnych

1. **Konsola DevTools (klawisz F12):** Zawsze otwieraj narzędzia deweloperskie w przeglądarce przed uruchomieniem strony. Zakładka *Console* natychmiast wskaże ewentualne błędy składniowe (np. `Uncaught ReferenceError` lub brakujący nawias).
2. **Weryfikacja ścieżek relatywnych:** Upewnij się, że znacznik `<script src="script.js"></script>` znajduje się tuż przed zamykającym znacznikiem `</body>`, a plik `style.css` jest poprawnie zaimportowany w `<head>`.
3. **Formatowanie nowej linii:** Właściwość `textContent` nie interpretuje znaczników `<br>`. Nowy wiersz tworzymy wyłącznie za pomocą znaku `\n` w szablonie tekstowym (template literal) lub konkatenacji.
4. **Konwersja po `.toFixed()`:** Pamiętaj, że metoda `.toFixed(2)` zwraca wartość typu `string`. Jeśli zamierzasz dodać do niej inną liczbę, użyj `parseFloat()`, aby uniknąć sklejenia napisów.
5. **Autonomia funkcji obliczeniowych:** Funkcja narzędziowa powinna przyjmować dane przez parametry i zwracać wynik przez `return`. Nie pobieraj elementów HTML ani nie modyfikuj DOM wewnątrz ciała funkcji losującej.
