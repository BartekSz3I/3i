# Zadanie 1: Losowanie dziennego wolumenu wypieków w piekarni rzemieślniczej

## Cel zadania
Celem ćwiczenia jest opanowanie bazowego wzoru matematycznego na losowanie liczb całkowitych w obustronnie domkniętym przedziale `[min, max]` z wykorzystaniem metody `Math.random()` oraz `Math.floor()`. Zaimplementujesz funkcję symulującą poranny wypiek chleba w piekarni i wypiszesz sformatowany raport na stronę WWW.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy ERP dla gastronomii i piekarni (np. Dotykacka, Gastro):** Szacowanie zapotrzebowania na surowce (mąka, woda, drożdże) w oparciu o prognozowany, zmienny popyt.
2. **Gry komputerowe i symulatory ekonomiczne:** Generowanie dziennych dostaw towarów do magazynu lub wahań liczby odwiedzających klientów.
3. **Aplikacje testowe:** Generowanie losowych ilości zamówień do automatycznych testów obciążeniowych bazy danych.

## Wymagania funkcjonalne
1. W pliku `script.js` utwórz nazwaną funkcję `losujLiczbeCalkowita(min, max)` przyjmującą dwa parametry: dolną i górną granicę przedziału.
2. Wewnątrz funkcji oblicz liczbę pseudolosową całkowitą według uniwersalnego wzoru:
   `Math.floor(Math.random() * (max - min + 1)) + min`
   i zwróć ją za pomocą instrukcji `return`.
3. Za pomocą utworzonej funkcji wylosuj liczbę bochenków chleba żytniego z przedziału od `120` do `250` sztuk.
4. Zbuduj wielowierszowy raport tekstowy zawierający nagłówek, wylosowaną liczbę bochenków oraz informację o statusie produkcji.
5. Przypisz przygotowany raport do właściwości `textContent` elementu o identyfikatorze `id="wynik"` oraz wyświetl go w konsoli przeglądarki za pomocą `console.log`.

## Treść do wpisania
W skrypcie umieść dokładnie następujące napisy stałe w generowanym raporcie:
- Nagłówek raportu: `"=== Piekarnia Rzemieślnicza Chleb Mistrza ==="`
- Etykieta planu produkcji: `"Planowany wypiek chleba żytniego:"`
- Informacja o statusie: `"Status pieca: Gotowy do załadunku porannej partii wypieku."`
- Podsumowanie kontrolne: `"Kontrola surowców: Zapas mąki i zakwasu jest wystarczający."`

## Podpowiedź / Wskazówki składniowe
- Pamiętaj, aby funkcja zwracała wartość przez `return`, a nie wypisywała jej bezpośrednio:
  ```javascript
  function losujLiczbeCalkowita(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  ```
- Wypis na stronę wykonaj po wywołaniu funkcji:
  ```javascript
  const wynikElement = document.getElementById("wynik");
  wynikElement.textContent = raport;
  ```
