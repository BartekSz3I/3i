// Plik roboczy ucznia: zadanie 1 - Piekarnia Chleb Mistrza

// KROK 1: Zdefiniuj funkcję losujLiczbeCalkowita(min, max), która zwraca
// liczbę całkowitą z przedziału [min, max] przy użyciu Math.random() i Math.floor()
// Twoje rozwiazanie:


// KROK 2: Wylosuj liczbę bochenków chleba żytniego w przedziale od 120 do 250


// KROK 3: Przygotuj wielowierszowy tekst raportu i wypisz go do #wynik oraz konsoli
// Teksty obowiązkowe z sekcji "Treść do wpisania":
// "=== Piekarnia Rzemieślnicza Chleb Mistrza ==="
// "Planowany wypiek chleba żytniego:"
// "Status pieca: Gotowy do załadunku porannej partii wypieku."
// "Kontrola surowców: Zapas mąki i zakwasu jest wystarczający."

