// Plik roboczy ucznia: zadanie 4 - Centrum Logistyczne EuroLogistyka

// KROK 1: Zdefiniuj funkcję losujCalkowita(min, max)
// Twoje rozwiazanie:


// KROK 2: Zdefiniuj funkcję losujUlamek(min, max) zaokrąglającą do 2 miejsc
// Twoje rozwiazanie:


// KROK 3: Wykonaj symulację: paczki [15-60], średnia waga [2.50-12.00] kg,
// czasy ramp 1, 2, 3 [12.00-38.00] min.


// KROK 4: Oblicz łączną masę ładunku oraz wyznacz min i max czas rampy


// KROK 5: Zbuduj raport i wypisz do #wynik oraz console.log
// Teksty z sekcji "Treść do wpisania":
// "=== Centrum Logistyczne EuroLogistyka ==="
// "Zestawienie ładunku paletowego strefy A:"
// "Szacowane czasy obsługi ramp przeładunkowych (min):"
// "DYSPOZYCJA: Partia towarowa zweryfikowana pomyślnie. Zezwolono na załadunek naczepy."

