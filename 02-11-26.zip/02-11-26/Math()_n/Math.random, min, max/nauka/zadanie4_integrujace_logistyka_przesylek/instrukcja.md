# Zadanie 4: Zintegrowany kalkulator dyspozytorski centrum logistycznego

## Cel zadania
Celem zadania integrującego jest połączenie w jednej spójnej aplikacji poznanych mechanizmów obiektu `Math`: losowania liczb całkowitych za pomocą `Math.floor()` i `Math.random()`, generowania i formatowania ułamków zmiennoprzecinkowych z użyciem `.toFixed(2)` i `parseFloat()`, a także analizy wartości skrajnych za pomocą `Math.min()` oraz `Math.max()`.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Systemy zarządzania magazynem WMS (np. SAP EWM, Manhattan Associates):** Symulowanie obłożenia doków załadunkowych oraz szacowanie tonażu odprawianych tirów.
2. **Platformy kurierskie (np. DPD, InPost, DHL):** Przydzielanie przesyłek do stref tranzytowych i obliczanie średniej wagi jednostkowej palet.
3. **Logistyka lotnicza cargo:** Bilansowanie masy ładunku i wyznaczanie skrajnych czasów obsługi naziemnej kontenerów.

## Wymagania funkcjonalne
1. W pliku `script.js` utwórz funkcję `losujCalkowita(min, max)`, która zwraca liczbę całkowitą z domkniętego przedziału `[min, max]`.
2. Utwórz funkcję `losujUlamek(min, max)`, która zwraca liczbę zmiennoprzecinkową z przedziału `[min, max]` zaokrągloną do 2 miejsc po przecinku (jako typ `number`).
3. Przeprowadź symulację odprawy partii ładunku:
   - Wylosuj liczbę paczek na palecie w przedziale od `15` do `60` sztuk.
   - Wylosuj średnią wagę pojedynczej paczki w przedziale od `2.50` do `12.00` kg.
   - Oblicz łączną masę ładunku: `masaLaczna = parseFloat((liczbaPaczek * sredniaWaga).toFixed(2))`.
4. Wygeneruj szacowane czasy operacyjne dla 3 ramp załadunkowych (Rampa 1, Rampa 2, Rampa 3) w przedziale od `12.0` do `38.0` minut za pomocą `losujUlamek`.
5. Za pomocą `Math.min()` i `Math.max()` wyznacz najkrótszy oraz najdłuższy czas załadunku spośród 3 ramp.
6. Sformatuj czytelny, wielowierszowy raport dyspozytorski i wypisz go do elementu `document.getElementById("wynik").textContent` oraz do konsoli przez `console.log`.

## Treść do wpisania
W skrypcie umieść dokładnie następujące napisy stałe w generowanym raporcie:
- Nagłówek dyspozytora: `"=== Centrum Logistyczne EuroLogistyka ==="`
- Etykieta paletyzacji: `"Zestawienie ładunku paletowego strefy A:"`
- Etykieta czasów ramp: `"Szacowane czasy obsługi ramp przeładunkowych (min):"`
- Informacja o odprawie: `"DYSPOZYCJA: Partia towarowa zweryfikowana pomyślnie. Zezwolono na załadunek naczepy."`

## Podpowiedź / Wskazówki składniowe
- Połącz wszystkie elementy w przejrzystą sekwencję:
  ```javascript
  const paczki = losujCalkowita(15, 60);
  const waga = losujUlamek(2.5, 12.0);
  const lacznaMasa = parseFloat((paczki * waga).toFixed(2));
  ```
- Wszystkie wyliczenia i raport sformatuj w czytelny sposób za pomocą znaków `\n`.
