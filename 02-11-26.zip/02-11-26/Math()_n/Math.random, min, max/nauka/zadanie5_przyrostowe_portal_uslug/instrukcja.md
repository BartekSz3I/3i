# Zadanie 5: Moduł estymacji kosztów i rejestracji zgłoszeń w portalu usługowym

## Cel zadania
Celem zadania przyrostowego podsumowującego moduł T04 jest zaimplementowanie kompleksowego podsystemu szacowania kosztów ekspertyz technicznych oraz rejestracji zgłoszeń w Portalu Usługowo-Handlowym IT-Partner. Wykorzystasz pełne spektrum metod obiektu `Math`: losowanie identyfikatorów całkowitych, losowanie zmiennoprzecinkowych stawek godzinowych, zaokrąglanie i formatowanie walutowe oraz ograniczanie (clamping) wartości zaliczki za pomocą `Math.min()` i `Math.max()`.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Miejskie portale usług i platformy obywatelskie (np. mObywatel, ePUAP):** Generowanie unikalnych numerów referencyjnych spraw i wstępna estymacja opłat urzędowych.
2. **Platformy ubezpieczeniowe i likwidacji szkód (np. PZU, Warta):** Przydzielanie rzeczoznawców, losowanie numerów protokołów i wyliczanie zaliczek odszkodowawczych w bezpiecznych widełkach.
3. **Systemy helpdesk i serwisy techniczne (np. Jira Service Desk, Zendesk):** Szacowanie czasu rozwiązania zgłoszenia (SLA) i kalkulacja kosztów roboczogodzin.

## Wymagania funkcjonalne
1. W pliku `script.js` utwórz funkcję `generujNumerZgloszenia(prefiks, min, max)`, która generuje unikalny kod sprawy złożony z podanego prefiksu tekstowego oraz wylosowanej liczby całkowitej z przedziału `[min, max]` (np. `"PO-4821"`).
2. Zdefiniuj funkcję `losujStawke(min, max)`, która losuje stawkę godzinową rzeczoznawcy z przedziału `[min, max]` i zwraca ją jako liczbę z dwoma miejscami po przecinku (`parseFloat(wartosc.toFixed(2))`).
3. Wygeneruj zgłoszenie serwisowe:
   - Numer sprawy z prefiksem `"ZGL"` i zakresem od `1000` do `9999`.
   - Czas realizacji ekspertyzy: liczba całkowita od `2` do `24` godzin.
   - Stawkę rzeczoznawcy: liczba zmiennoprzecinkowa od `75.00` do `160.00` PLN/h.
4. Oblicz szacunkowy koszt bazowy ekspertyzy: `kosztBazowy = parseFloat((czas * stawka).toFixed(2))`.
5. Oblicz sugerowaną zaliczkę wynoszącą 25% kosztu bazowego (`kosztBazowy * 0.25`), a następnie za pomocą kombinacji metod `Math.min()` oraz `Math.max()` ogranicz ją (clamping) do dopuszczalnych widełek regulaminowych:
   - Zaliczka nie może być mniejsza niż `100.00` PLN (`Math.max(zaliczka, 100.00)`).
   - Zaliczka nie może być większa niż `500.00` PLN (`Math.min(..., 500.00)`).
6. Przygotuj oficjalny, sformatowany dokument potwierdzenia zgłoszenia i przypisz go do `document.getElementById("wynik").textContent` oraz wyświetl w konsoli przez `console.log`.

## Treść do wpisania
W skrypcie umieść dokładnie następujące napisy stałe w generowanym raporcie:
- Nagłówek portalu: `"=== Portal Usługowo-Handlowy IT-Partner — Rejestracja Zgłoszeń Technicznych ==="`
- Etykieta potwierdzenia: `"Potwierdzenie rejestracji zgłoszenia serwisowego IT:"`
- Etykieta kalkulacji kosztów: `"Kalkulacja kosztorysu inżyniera wsparcia:"`
- Klauzula regulaminowa zaliczki: `"Regulaminowa zaliczka (widełki 100.00 - 500.00 PLN):"`
- Status wniosku: `"DECYZJA: Zlecenie przyjęte do realizacji. Oczekiwanie na wpłatę zaliczki."`

## Podpowiedź / Wskazówki składniowe
- Ograniczenie wartości (clamping) w widełkach `[minLimit, maxLimit]`:
  ```javascript
  const bezpiecznaZaliczka = Math.min(Math.max(wyliczonaZaliczka, 100.0), 500.0);
  ```
- Wszystkie wyliczenia i raport sformatuj w czytelny sposób za pomocą znaków `\n`.
