// Plik roboczy ucznia: zadanie 5 (przyrostowe Capstone) - Portal Usługowo-Handlowy IT-Partner
// KROK 1: Zaimplementuj funkcję generujNumerZgloszenia(prefiks, min, max)
// Twoje rozwiazanie:


// KROK 2: Zaimplementuj funkcję losujStawke(min, max)
// Twoje rozwiazanie:


// KROK 3: Wygeneruj numer sprawy (ZGL, 1000-9999), czas realizacji (2-24 h),
// stawkę rzeczoznawcy (75.00-160.00 PLN/h).


// KROK 4: Oblicz koszt bazowy oraz bezpieczną zaliczkę z widełkami [100.00 - 500.00 PLN]
// przy użyciu Math.min() i Math.max()


// KROK 5: Zbuduj raport potwierdzenia i wypisz do #wynik oraz konsoli
// Teksty z sekcji "Treść do wpisania":
// "=== Portal Usługowo-Handlowy IT-Partner — Rejestracja Zgłoszeń Technicznych ==="
// "Potwierdzenie rejestracji zgłoszenia serwisowego IT:"
// "Kalkulacja kosztorysu inżyniera wsparcia:"
// "Regulaminowa zaliczka (widełki 100.00 - 500.00 PLN):"
// "DECYZJA: Zlecenie przyjęte do realizacji. Oczekiwanie na wpłatę zaliczki."

