# Zadanie 3: Analiza wartości skrajnych Math.min i Math.max w diagnostyce pojazdowej

## Cel zadania
Celem ćwiczenia jest opanowanie wyznaczania wartości minimalnych i maksymalnych za pomocą wbudowanych metod statycznych `Math.min()` oraz `Math.max()`, a także obliczanie rozstępu pomiarowego i weryfikacja stabilności układu za pomocą flagi logicznej. Zastosujesz również pobranie identyfikatora stanowiska przez `prompt()` z wartością domyślną.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Oprogramowanie warsztatowe i stacje kontroli pojazdów (np. Bosch ESI[tronic], Texa):** Analiza stabilności ciśnienia na szynie wtryskowej (Common Rail) lub w układzie smarowania silnika.
2. **Systemy monitorowania serwerowni i telemetria IoT:** Badanie wahań napięcia zasilania w celu wykrywania niebezpiecznych skoków i spadków.
3. **Aplikacje giełdowe i finansowe:** Wyznaczanie kursu minimalnego i maksymalnego (Low / High) w danej sesji giełdowej.

## Wymagania funkcjonalne
1. W pliku `script.js` pobierz oznaczenie stanowiska serwisowego za pomocą funkcji `prompt()` z **obowiązkową wartością domyślną**:
   ```javascript
   const wejscieStanowisko = prompt("Podaj oznaczenie stanowiska diagnostycznego:", "STAN-04");
   ```
   Pamiętaj, że wywołanie `prompt()` musi znajdować się **wyłącznie poza ciałem funkcji**. Jeśli użytkownik pozostawi pole puste albo anuluje okno dialogowe (`null`), przyjmij `"STAN-01"`. Nie używaj metod obiektu `String` (np. `trim`) — wystarczy porównanie z `null` i pustym napisem:
   ```javascript
   const wejscieStanowisko = prompt("Podaj oznaczenie stanowiska diagnostycznego:", "STAN-04");
   let oznaczenieStanowiska = "STAN-01";
   if (wejscieStanowisko !== null && wejscieStanowisko !== "") {
     oznaczenieStanowiska = wejscieStanowisko;
   }
   ```
2. Zaimplementuj funkcję `losujCisnienie(min, max)`, która losuje wartość ciśnienia oleju z przedziału `[min, max]` w barach i zwraca ją z dokładnością do 2 miejsc po przecinku jako typ `number`:
   `parseFloat((Math.random() * (max - min) + min).toFixed(2))`
3. Wygeneruj 3 niezależne próby pomiarowe w przedziale od `1.80` do `4.20` bar: `proba1`, `proba2`, `proba3`.
4. Za pomocą metody `Math.min()` wyznacz najniższe zarejestrowane ciśnienie, a za pomocą `Math.max()` — najwyższe zarejestrowane ciśnienie w teście.
5. Oblicz rozstęp ciśnień: `rozstep = parseFloat((maksymalne - minimalne).toFixed(2))`.
6. Zdefiniuj zmienną logiczną (flagę) `czyStabilne = rozstep <= 0.80`. Na jej podstawie ustal komunikat diagnostyczny:
   - Jeżeli `czyStabilne` ma wartość `true`: pompa pracuje w dopuszczalnym zakresie wahań.
   - W przeciwnym razie: wahania ciśnienia przekraczają normę serwisową.
7. Zbuduj sformatowany raport i przypisz go do `document.getElementById("wynik").textContent` oraz wyświetl w konsoli za pomocą `console.log`.

## Treść do wpisania
W skrypcie umieść dokładnie następujące napisy stałe w generowanym raporcie:
- Nagłówek serwisu: `"=== Centrum Diagnostyki Pojazdowej AutoTest ==="`
- Etykieta prób: `"Pomiary ciśnienia w magistrali olejowej (bar):"`
- Komunikat o stabilności: `"WYNIK DIAGNOSTYKI: Układ smarowania stabilny. Wahania ciśnienia w normie."`
- Komunikat o usterce: `"WYNIK DIAGNOSTYKI: UWAGA! Nadmierne wahania ciśnienia. Zalecana inspekcja zaworu."`

## Podpowiedź / Wskazówki składniowe
- Walidacja wyniku `prompt()` bez metod `String` (puste pole lub Anuluj → wartość zapasowa):
  ```javascript
  let oznaczenieStanowiska = "STAN-01";
  if (wejscieStanowisko !== null && wejscieStanowisko !== "") {
    oznaczenieStanowiska = wejscieStanowisko;
  }
  ```
- Wyznaczanie wartości skrajnych z wielu zmiennych:
  ```javascript
  const minWartosc = Math.min(proba1, proba2, proba3);
  const maxWartosc = Math.max(proba1, proba2, proba3);
  ```
- Wszystkie wyliczenia i raport sformatuj w czytelny sposób za pomocą znaków `\n`.
