// Plik roboczy ucznia: zadanie 3 - Centrum Diagnostyki Pojazdowej AutoTest

// KROK 1: Pobierz oznaczenie stanowiska diagnostycznego przez prompt() z wartością domyślną "STAN-04"
// Pamiętaj: wywołanie prompt() musi być poza ciałem funkcji!
// Gdy wynik to null (Anuluj) lub "" (puste pole), ustaw "STAN-01" — bez metod String (np. bez trim).


// KROK 2: Zdefiniuj funkcję losujCisnienie(min, max), która losuje ułamek w [min, max],
// zaokrągla do 2 miejsc (.toFixed(2)) i konwertuje na number przez parseFloat().
// Twoje rozwiazanie:


// KROK 3: Wygeneruj 3 próby ciśnienia w zakresie 1.80 - 4.20 bar


// KROK 4: Wyznacz min i max za pomocą Math.min() i Math.max() oraz oblicz rozstęp


// KROK 5: Ustal flagę czyStabilne = rozstep <= 0.80 i przygotuj raport
// Teksty z sekcji "Treść do wpisania":
// "=== Centrum Diagnostyki Pojazdowej AutoTest ==="
// "Pomiary ciśnienia w magistrali olejowej (bar):"
// "WYNIK DIAGNOSTYKI: Układ smarowania stabilny. Wahania ciśnienia w normie."
// "WYNIK DIAGNOSTYKI: UWAGA! Nadmierne wahania ciśnienia. Zalecana inspekcja zaworu."

