// Plik roboczy ucznia: zadanie 2 - Stacja Agrometeorologiczna AgroPogoda

// KROK 1: Pobierz od użytkownika próg alarmowy przez prompt() z wartością domyślną "25.0"
// Pamiętaj: wywołanie prompt() musi być poza ciałem funkcji!


// KROK 2: Zdefiniuj funkcję strzałkową losujWilgotnosc(min, max), która
// losuje ułamek z [min, max], formatuje go do 2 miejsc po przecinku za pomocą .toFixed(2)
// i konwertuje wynik na typ number za pomocą parseFloat().
// Twoje rozwiazanie:


// KROK 3: Wylosuj wilgotność z zakresu 15.0 - 45.0 i sprawdź warunek if / else


// KROK 4: Wypisz raport do #wynik i console.log
// Teksty z sekcji "Treść do wpisania":
// "=== Stacja Agrometeorologiczna AgroPogoda ==="
// "Bieżący odczyt sensora wilgotności gleby:"
// "STATUS: ALARM - Wilgotność poniżej normy! Uruchomiono sekcję nawadniania kropelkowego."
// "STATUS: NORMA - Poziom wilgotności gleby jest optymalny dla upraw polowych."

