# Zadanie 2: Losowanie liczb zmiennoprzecinkowych i monitorowanie wilgotności gleby

## Cel zadania
Celem ćwiczenia jest opanowanie generowania liczb zmiennoprzecinkowych z zadanego przedziału ciągłego `[min, max]`, ich precyzyjnego zaokrąglania za pomocą metody `.toFixed(2)` oraz konwersji łańcucha tekstowego na liczbę przy użyciu `parseFloat()`. Wprowadzisz także obsługę parametru progowego pobieranego od użytkownika przez `prompt()` z obowiązkową wartością domyślną.

## Gdzie to się stosuje? (Przykłady ze świata aplikacji)
1. **Rolnictwo precyzyjne i stacje meteo (np. Pessl Instruments, iMetos):** Automatyczna analiza pomiarów wilgotności i temperatury gleby sterująca elektrozaworami nawadniającymi.
2. **Klimatyzacja i inteligentne budynki (BMS):** Odczyty z czujników wilgotności względnej powietrza i uruchamianie osuszaczy lub nawilżaczy.
3. **Magazyny farmaceutyczne:** Monitorowanie warunków przechowywania leków wrażliwych na wilgoć.

## Wymagania funkcjonalne
1. W pliku `script.js` pobierz próg alarmowy od użytkownika za pomocą funkcji `prompt()` z **obowiązkową wartością domyślną**:
   ```javascript
   const wejscieProg = prompt("Podaj minimalny dopuszczalny próg wilgotności gleby (%):", "25.0");
   ```
   Pamiętaj, że wywołanie `prompt()` musi znajdować się **wyłącznie poza ciałem funkcji**. Skonwertuj pobraną wartość na liczbę zmiennoprzecinkową za pomocą `parseFloat(wejscieProg)`. W przypadku podania wartości niepoprawnej (`isNaN` lub `< 0`) przyjmij wartość domyślną `25.0`.
2. Zdefiniuj funkcję strzałkową `losujWilgotnosc(min, max)`, która generuje liczbę zmiennoprzecinkową w przedziale od `min` do `max`, zaokrągla ją do dwóch miejsc po przecinku i zwraca jako typ liczbowy (`number`):
   `parseFloat((Math.random() * (max - min) + min).toFixed(2))`
3. Wylosuj aktualną wilgotność gleby z przedziału od `15.0` do `45.0` procent.
4. Za pomocą instrukcji warunkowej `if / else` porównaj wylosowaną wilgotność z progiem alarmowym:
   - Jeśli wilgotność jest mniejsza od progu: wygeneruj alert o konieczności uruchomienia zraszaczy.
   - W przeciwnym razie: poinformuj o prawidłowym poziomie nawodnienia.
5. Przygotuj sformatowany raport wieloliniowy i wypisz go do `document.getElementById("wynik").textContent` oraz do konsoli przez `console.log`.

## Treść do wpisania
W skrypcie umieść dokładnie następujące napisy stałe w generowanym raporcie:
- Tytuł stacji: `"=== Stacja Agrometeorologiczna AgroPogoda ==="`
- Etykieta odczytu: `"Bieżący odczyt sensora wilgotności gleby:"`
- Komunikat alarmowy (gdy poniżej progu): `"STATUS: ALARM - Wilgotność poniżej normy! Uruchomiono sekcję nawadniania kropelkowego."`
- Komunikat optymalny (gdy powyżej lub równo): `"STATUS: NORMA - Poziom wilgotności gleby jest optymalny dla upraw polowych."`

## Podpowiedź / Wskazówki składniowe
- Pamiętaj o kolejności operacji: `.toFixed(2)` zwraca typ `string`, dlatego należy go objąć funkcją `parseFloat()`, aby móc porównywać wynik z progiem liczbowym:
  ```javascript
  const losujWilgotnosc = (min, max) => {
    const wartosc = Math.random() * (max - min) + min;
    return parseFloat(wartosc.toFixed(2));
  };
  ```
- Wszystkie zmienne definiuj za pomocą `const` lub `let`.
