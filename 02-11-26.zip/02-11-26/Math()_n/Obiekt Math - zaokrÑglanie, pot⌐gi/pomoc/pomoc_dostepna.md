# Pomoc dostępna: Moduł T03 — Obiekt Math: zaokrąglanie, potęgi

Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

---

## 1. Słowniczek pojęć tego działu

- **Obiekt `Math`:** wbudowane w przeglądarkę narzędzie dostarczające gotowe funkcje matematyczne. Obiekt ten jest zawsze dostępny i nie tworzy się go przez słowo `new`.
- **`Math.round()`:** funkcja zaokrąglająca liczbę do najbliższej liczby całkowitej. Jeśli część ułamkowa wynosi `0.5` lub więcej, zaokrągla w górę.
- **`Math.floor()`:** funkcja zaokrąglająca liczbę zawsze w dół. Dla liczby dodatniej `4.9` zwraca `4`, a dla ujemnej `-4.1` zwraca `-5`.
- **`Math.ceil()`:** funkcja zaokrąglająca liczbę zawsze w górę. Dla liczby `4.1` zwraca `5`.
- **`Math.trunc()`:** funkcja odcinająca część ułamkową liczby. Po prostu usuwa wszystkie cyfry po przecinku.
- **`Math.pow()` oraz operator `**`:** narzędzia podnoszące liczbę do podanej potęgi. Zapis `Math.pow(2, 3)` oraz `2 ** 3` oznacza dwa do potęgi trzeciej i daje wynik osiem.
- **`Math.sqrt()`:** funkcja obliczająca pierwiastek kwadratowy z podanej liczby.
- **`Math.random()`:** funkcja generująca losową liczbę ułamkową większą lub równą zero i mniejszą od jeden.
- **`Math.PI`:** stała liczbowa przechowująca przybliżoną wartość liczby Pi równą około `3.14159`.
- **`textContent`:** właściwość elementu HTML służąca do wstawiania czystego tekstu na stronę bez formatowania znacznikami.
- **`toFixed(2)`:** metoda liczby formatująca zapis do dwóch miejsc po przecinku na potrzeby wypisu (zwraca ciąg znaków). Dzięki niej w raporcie pojawia się `2.50`, a nie `2.5`.

---

## 2. Kolejność wykonywania każdego zadania (krok po kroku)

Wykonuj zadania w podanej kolejności, realizując po jednym kroku naraz:

1. Otwórz plik `instrukcja.md` znajdujący się w katalogu danego zadania. Przeczytaj uważnie cel zadania oraz tabelę parametrów wejściowych.
2. Otwórz plik `script.js` w swoim edytorze kodu. Odszukaj komentarz `// Twoje rozwiazanie`, który wskazuje dokładne miejsce na wpisanie Twojego kodu.
3. Jeśli zadanie wymaga modyfikacji pliku `index.html`, odszukaj w nim komentarze o strukturze `<!-- KROK N: ... -->` i dopisz wymagane znaczniki.
4. Zdefiniuj wymaganą funkcję obliczeniową. Wewnątrz funkcji użyj odpowiednich metod obiektu `Math` oraz zwróć wynik instrukcją `return`.
5. Pobierz element wyjściowy za pomocą instrukcji `document.getElementById("wynik")`.
6. Przypisz przygotowany tekst podsumowania do właściwości `textContent` pobranego elementu. Jeśli przykład pokazuje wartości w postaci `xx.xx` (np. `2.50 PLN`), przy składaniu tekstu użyj `.toFixed(2)`.
7. Zapisz plik i otwórz plik `index.html` w przeglądarce internetowej. Sprawdź, czy w ramce wyniku pojawiły się poprawne dane liczbowe.
8. Naciśnij klawisz `F12` i przejdź do zakładki *Konsola*. Upewnij się, że nie wyświetlają się żadne czerwone komunikaty o błędach.
9. Po zakończeniu własnej próby otwórz podfolder `rozwiazanie/`. Porównaj swój kod z plikiem `rozwiazanie/script.js` i przeanalizuj ewentualne różnice.

---

## 3. Wskazówki dotyczące dostępności i czytelności (a11y)

1. **Czytelny kontrast tekstu:**  
   Tekst wynikowy wyświetlany w elemencie `#wynik` posiada ciemną barwę na jasnym tle. Ułatwia to odczytanie liczb osobom słabowidzącym.
2. **Zachowanie podziału na wiersze:**  
   Dzięki regule CSS `white-space: pre-wrap;` każdy znak nowej linii `\n` tworzy czytelny odstęp pionowy. Oddzielaj poszczególne parametry do osobnych wierszy, aby ułatwić czytanie syntezatorom mowy.
3. **Jednoznaczne etykiety danych:**  
   Zawsze poprzedzaj wyświetlaną liczbę nazwą parametru i jednostką (na przykład: `Cena brutto: 24.50 PLN` zamiast samej liczby `24.50`).

---

## 4. Strategia pracy z Zadaniem Przyrostowym (Capstone)

Zadanie 5 (Zadanie Przyrostowe: Portal Usługowo-Handlowy IT-Partner) rozwija jedną, spójną aplikację biznesową przez cały semestr. Aby rozwiązać je krok po kroku i bez trudności, stosuj poniższą metodę 4 kroków:

1. **Zasada jednej funkcji na raz:**  
   Nie pisz całego programu od razu. W pierwszej kolejności zaimplementuj i przetestuj pojedynczą funkcję pomocniczą (np. zaokrąglanie kwot za pomocą `Math.round()` lub przeliczanie opłat abonamentowych). Przetestuj jej wynik w konsoli przeglądarki (`F12`).

2. **Łączenie klocków (przepływ danych):**  
   Główna funkcja generująca raport wywołuje wcześniejsze funkcje pomocnicze, przekazując im dane wejściowe. Wyniki zwracane przez instrukcję `return` z funkcji pomocniczych zapisuj do lokalnych stałych (`const`).

3. **Dosłowna struktura raportu z instrukcji:**  
   Otwórz plik `instrukcja.md` zadania 5 i odszukaj sekcję `## Treść do wpisania`. Skopiuj strukturę etykiet tekstowych, a w wyznaczone miejsca wstaw wartości swoich zmiennych za pomocą szablonu w grawisach (backticki `` `...` `` i `${zmienna}`).

4. **Weryfikacja w przeglądarce i konsoli deweloperskiej:**  
   Zapisz plik `script.js` i odśwież stronę `index.html`. Otwórz konsolę klawiszem `F12`. Upewnij się, że nie pojawiają się czerwone błędy (`Uncaught SyntaxError` lub `ReferenceError`), a w bloku `#wynik` wyświetla się pełny raport.
