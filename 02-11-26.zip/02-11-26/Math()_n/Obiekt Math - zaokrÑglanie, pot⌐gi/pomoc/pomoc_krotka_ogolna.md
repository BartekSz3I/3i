# Pomoc ogólna: Moduł T03 — Obiekt Math: zaokrąglanie, potęgi

Materiały pomocnicze, zestawienie struktur plików oraz syntaktyczna ściąga z metod obiektu `Math`.

---

## 1. Struktura katalogu roboczego zadania

Każde zadanie w module posiada dwa równoległe foldery: folder roboczy ucznia oraz folder referencyjny z wzorcowym rozwiązaniem.

| Element | Folder zadania (Twoje miejsce pracy) | Folder `rozwiazanie/` (Wzorzec) |
|---|---|---|
| **Plik HTML (`index.html`)** | Gotowy szkielet interfejsu z kontenerem wyjściowym `#wynik` | Kompletny plik HTML powiązany z arkuszem i skryptem |
| **Plik stylów (`style.css`)** | Gotowe style wizualne z obsługą reguły `white-space: pre-wrap` | Kompletny arkusz stylów CSS |
| **Plik skryptu (`script.js`)** | Przygotowane miejsce na implementację: komentarze `// Twoje rozwiazanie` | W pełni działający kod z implementacją funkcji i metod `Math` |
| **Instrukcja (`instrukcja.md`)** | Opis zadania, cel, reguły, dane i treść do wpisania | Wzorzec instruktażowy dla nauczyciela i ucznia |

---

## 2. Ściąga składniowa obiektu Math

### Stałe matematyczne
```javascript
Math.PI // 3.141592653589793
Math.E  // 2.718281828459045
```

### Zaokrąglanie i ucinanie części ułamkowej
```javascript
Math.round(4.5);  // 5 (zaokrąglenie do najbliższej liczby całkowitej, od 0.5 w górę)
Math.floor(4.9);  // 4 (zaokrąglenie zawsze w dół w kierunku -nieskończoności)
Math.floor(-4.1); // -5 (uwaga: przesuwa w lewo na osi liczbowej!)
Math.ceil(4.1);   // 5 (zaokrąglenie zawsze w górę w kierunku +nieskończoności)
Math.trunc(4.9);  // 4 (odrzuca część po przecinku, bez względu na znak)
Math.trunc(-4.9); // -4
```

### Zaokrąglanie do 2 miejsc po przecinku (wzór arytmetyczny)
```javascript
const zaokraglonaKwota = Math.round(wartosc * 100) / 100; // nadal liczba
```

### Prezentacja z dwoma miejscami po przecinku (wypis tekstu)
```javascript
// toFixed(2) zwraca string — używaj przy składaniu tekstu do #wynik
(19.63).toFixed(2); // "19.63"
(2.5).toFixed(2);   // "2.50" (dopisuje końcowe zero)
```

### Potęgowanie, pierwiastkowanie, wartość bezwzględna
```javascript
Math.pow(podstawa, wykladnik); // np. Math.pow(2, 3) = 8
podstawa ** wykladnik;         // np. 2 ** 3 = 8 (nowoczesny operator)
Math.sqrt(liczba);             // np. Math.sqrt(49) = 7
Math.abs(liczba);              // np. Math.abs(-15) = 15
Math.min(a, b, c);             // najmniejsza wartość ze zbioru
Math.max(a, b, c);             // największa wartość ze zbioru
```

### Losowanie liczb całkowitych w przedziale [min, max]
```javascript
function losuj(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
```

---

## 3. Szybkie przypomnienie techniczne (5 punktów)

1. **Standard wyjścia semestru 2:**  
   Wszelkie rezultaty obliczeń zapisujemy do elementu `#wynik` za pomocą właściwości `textContent`:
   `document.getElementById("wynik").textContent = "Twój wynik...";`
2. **Zachowanie formatowania tekstu w CSS:**  
   Element wyjściowy `#wynik` posiada w pliku `style.css` regułę `white-space: pre-wrap;`. Umożliwia to stosowanie znaków nowej linii `\n` w template literals (np. `` `Wiersz 1\nWiersz 2` ``).
3. **Funkcje czyste z instrukcją return:**  
   Procedury logiczne definiuj z użyciem parametrów i słowa kluczowego `return`. Pobieranie elementu DOM i przypisanie wyniku wykonuj poza ciałem funkcji.
4. **Narzędzia deweloperskie (DevTools):**  
   Naciśnij klawisz `F12` w przeglądarce i przejdź do zakładki *Console*, aby kontrolować wyniki pomocniczych poleceń `console.log()` oraz diagnozować ewentualne komunikaty o błędach.
5. **Relatywne ścieżki plików:**  
   Pliki `index.html`, `style.css` i `script.js` znajdują się w tym samym katalogu roboczym zadania, dlatego znacznik skryptu w HTML zawsze ma postać `<script src="script.js"></script>`.
