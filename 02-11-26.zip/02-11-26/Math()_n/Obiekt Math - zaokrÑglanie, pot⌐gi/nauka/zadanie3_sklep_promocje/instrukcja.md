# Zadanie 3: Sklep internetowy — generator kuponów i bezpieczne progi rabatowe

## Cel
Celem zadania jest utworzenie zestawu funkcji obsługujących kampanię promocyjną w sklepie internetowym: losowanie unikalnego numerycznego kodu PIN kuponu z przedziału od 1000 do 9999 przy użyciu `Math.random()` i `Math.floor()`, ograniczenie rabatu do dopuszczalnych widełek polityki cenowej za pomocą `Math.min()` i `Math.max()` oraz wyznaczenie różnicy rabatu przy użyciu `Math.abs()`. Sukcesem jest poprawne zwrócenie sformatowanego podsumowania i jego prezentacja w elemencie `#wynik`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Platformy e-commerce generujące jednorazowe kody weryfikacyjne SMS lub PIN-y rabatowe.
- Moduły koszykowe ograniczające maksymalny sumaryczny upust (tzw. clamping limitu rabatowego), aby zapobiec stratom handlowym.
- Gry przeglądarkowe losujące poziomy nagród lub punkty doświadczenia z określonych przedziałów.

## Wskazówki aktywizujące
- Przeczytaj sekcję 5, 6 i 7 w pliku `teoria.md` omawiającą metody `Math.abs()`, `Math.min()`, `Math.max()` oraz wzór na losowanie w przedziale `[min, max]`.
- Zastanów się: dlaczego przy losowaniu kodów całkowitych używamy `Math.floor()`, a nie `Math.round()`?
- Wpisz w konsoli przeglądarki `Math.min(Math.max(35, 5), 25)` i zaobserwuj, jak wartość 35 zostaje przycięta do górnego limitu 25.

## Treść do wpisania
W skrypcie umieść i sformatuj dokładnie następujące teksty potwierdzenia promocji:
„Elektroniczny Kupon Rabatowy — Sklep Odzieżowy TrendVibe”
„Wnioskowany rabat procentowy: 35%”
„Maksymalny dozwolony limit rabatu w systemie: 25%”
„------------------------------------------------------------” (separator sekcji wynikowej)
„Zatwierdzony bezpieczny rabat (po walidacji Math.min/max): 25%”
„Korekta rabatu (różnica bezwzględna Math.abs): 10 punktów procentowych”
„Wygenerowany czterocyfrowy kod PIN kuponu (1000-9999):”

Pytanie w oknie dialogowym prompt:
„Podaj proponowany rabat procentowy dla klienta VIP:”
Wartość domyślna w oknie dialogowym prompt:
„35”

## Wymagania
1. Pobierz proponowany rabat za pomocą `prompt("Podaj proponowany rabat procentowy dla klienta VIP:", "35")` umieszczonego **poza ciałem funkcji**. Skonwertuj wartość na liczbę za pomocą `Number()`.
2. Zdefiniuj funkcję strzałkową `losujKodPin = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min`.
3. Zdefiniuj funkcję `przygotujKupon(wnioskowanyRabat, minDozwolony, maxDozwolony)`, która:
   - Oblicza zatwierdzony rabat z użyciem `Math.min(Math.max(wnioskowanyRabat, minDozwolony), maxDozwolony)`,
   - Wylicza różnicę między rabatem wnioskowanym a zatwierdzonym z użyciem `Math.abs(wnioskowanyRabat - zatwierdzonyRabat)`,
   - Losuje 4-cyfrowy kod PIN za pomocą funkcji `losujKodPin(1000, 9999)`,
   - Zwraca sformatowany tekst podsumowania ze znakami nowej linii `\n`.
4. Wywołaj funkcję `przygotujKupon` dla wartości `wnioskowanyRabat`, `minDozwolony = 5` oraz `maxDozwolony = 25`.
5. Przypisz zwrócony tekst do właściwości `textContent` elementu `#wynik` oraz wypisz go do konsoli przez `console.log()`.

## Przykład
Dla wnioskowanego rabatu 35% w kontenerze `#wynik` pojawi się:
```text
Elektroniczny Kupon Rabatowy — Sklep Odzieżowy TrendVibe
Wnioskowany rabat procentowy: 35%
Maksymalny dozwolony limit rabatu w systemie: 25%
------------------------------------------------------------
Zatwierdzony bezpieczny rabat (po walidacji Math.min/max): 25%
Korekta rabatu (różnica bezwzględna Math.abs): 10 punktów procentowych
Wygenerowany czterocyfrowy kod PIN kuponu (1000-9999): 7421
```
*(Uwaga: kod PIN jest losowy i przyjmuje wartości z przedziału 1000–9999)*
