// Zadanie 3: Sklep internetowy — generator kuponów i bezpieczne progi rabatowe
// Twoje rozwiazanie

// KROK 1: Zdefiniuj funkcję strzałkową losujKodPin(min, max) zwracającą losową liczbę całkowitą
const losujKodPin = (min, max) => {
  // Oblicz losową liczbę całkowitą z przedziału [min, max] przy użyciu Math.random() i Math.floor()
};

function przygotujKupon(wnioskowanyRabat, minDozwolony, maxDozwolony) {
  // KROK 2: Ogranicz rabat do widełek [minDozwolony, maxDozwolony] za pomocą Math.min() i Math.max()
  
  // KROK 3: Wyznacz różnicę bezwzględną między rabatem wnioskowanym a zatwierdzonym za pomocą Math.abs()
  
  // KROK 4: Wylosuj 4-cyfrowy kod PIN kuponu (od 1000 do 9999) wywołując funkcję losujKodPin
  
  // KROK 5: Zwróć za pomocą return sformatowane potwierdzenie promocyjne ze znakami \n
}

// Pobranie danych poza ciałem funkcji z domyślną wartością:
const rabatWejsciowy = Number(prompt("Podaj proponowany rabat procentowy dla klienta VIP:", "35"));
const limitMin = 5;
const limitMax = 25;

// KROK 6: Wywołaj funkcję przygotujKupon i przypisz wynik do textContent elementu #wynik
