// Zadanie 1: Magazyn i logistyka — obliczanie zapotrzebowania paletowego
// Twoje rozwiazanie

function obliczPalety(liczbaKartonow, pojemnoscPalety) {
  // KROK 1: Oblicz wymagane europalety zaokrąglając wynik dzielenia w górę (Math.ceil)
  
  // KROK 2: Oblicz liczbę palet w pełni zapełnionych zaokrąglając wynik dzielenia w dół (Math.floor)
  
  // KROK 3: Oblicz szacunek arytmetyczny za pomocą standardowego zaokrąglenia (Math.round)
  
  // KROK 4: Zwróć za pomocą return sformatowany tekst podsumowania ze znakami \n
}

// Dane wejściowe:
const liczbaKartonow = 145;
const pojemnoscPalety = 40;

// KROK 5: Wywołaj funkcję obliczPalety(liczbaKartonow, pojemnoscPalety)
// i przypisz zwrócony ciąg znaków do właściwości textContent elementu #wynik
