# Zadanie 1: Magazyn i logistyka — obliczanie zapotrzebowania paletowego

## Cel
Celem zadania jest utworzenie funkcji obliczeniowej, która na podstawie liczby składowanych kartonów oraz pojemności pojedynczej palety wyznacza całkowitą liczbę potrzebnych palet (zaokrąglenie w górę), liczbę w pełni zapełnionych palet (zaokrąglenie w dół) oraz standardowe zaokrąglenie statystyczne. Sukcesem jest poprawne zwrócenie wyników za pomocą instrukcji `return` oraz ich czytelna prezentacja w elemencie `#wynik`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Systemy WMS (Warehouse Management System) do automatycznego planowania powierzchni załadunkowej w dokach przeładunkowych.
- Kalkulatory pakowania w hurtowniach materiałów budowlanych do zamawiania palet z pustakami lub cementem.
- Centra dystrybucyjne e-commerce przy konsolidacji przesyłek drobnicowych do transportu całopojazdowego.

## Wskazówki aktywizujące
- Przeczytaj sekcję 3 w pliku `teoria.md` opisującą różnice w działaniu metod `Math.ceil()`, `Math.floor()` oraz `Math.round()`.
- Zastanów się: dlaczego przy planowaniu transportu fizycznych towarów bezpieczniej jest użyć zaokrąglenia w górę (`Math.ceil`) niż standardowego zaokrąglenia arytmetycznego?
- Otwórz konsolę DevTools (`F12`) i sprawdź wynik operacji: `Math.ceil(145 / 40)` oraz `Math.floor(145 / 40)`.

## Treść do wpisania
W skrypcie umieść i sformatuj dokładnie następujące teksty raportu magazynowego:
„Raport Zapotrzebowania Magazynowego — Centrum Dystrybucyjne Północ”
„Liczba kartonów w partii towaru: 145 sztuk”
„Pojemność pojedynczej europalety: 40 sztuk”
„------------------------------------------------------------” (separator sekcji wynikowej)
„Wymagane europalety (zaokrąglenie w górę - Math.ceil): 4 palety”
„Palety w pełni zapełnione (zaokrąglenie w dół - Math.floor): 3 palety”
„Szacunek arytmetyczny (zaokrąglenie standardowe - Math.round): 4 palety”

## Wymagania
1. Zdefiniuj funkcję `obliczPalety(liczbaKartonow, pojemnoscPalety)`, która przyjmuje dwa parametry liczbowe.
2. Wewnątrz funkcji oblicz:
   - `wymaganePalety` przy użyciu `Math.ceil(liczbaKartonow / pojemnoscPalety)`,
   - `pelnePalety` przy użyciu `Math.floor(liczbaKartonow / pojemnoscPalety)`,
   - `sredniaZaokraglona` przy użyciu `Math.round(liczbaKartonow / pojemnoscPalety)`.
3. Funkcja musi zwracać sformatowany ciąg tekstowy zawierający wszystkie trzy wyliczone wartości oddzielone znakami nowej linii `\n`.
4. Poza ciałem funkcji zadeklaruj stałe `liczbaKartonow = 145` oraz `pojemnoscPalety = 40`.
5. Wywołaj funkcję `obliczPalety`, a uzyskany rezultat przypisz do właściwości `textContent` elementu o identyfikatorze `#wynik`.
6. Wynik zweryfikuj także pomocniczo w konsoli przeglądarki za pomocą `console.log()`.

## Przykład
Po załadowaniu strony w przeglądarce w kontenerze `#wynik` wyświetla się raport:
```text
Raport Zapotrzebowania Magazynowego — Centrum Dystrybucyjne Północ
Liczba kartonów w partii towaru: 145 sztuk
Pojemność pojedynczej europalety: 40 sztuk
------------------------------------------------------------
Wymagane europalety (zaokrąglenie w górę - Math.ceil): 4 palety
Palety w pełni zapełnione (zaokrąglenie w dół - Math.floor): 3 palety
Szacunek arytmetyczny (zaokrąglenie standardowe - Math.round): 4 palety
```
