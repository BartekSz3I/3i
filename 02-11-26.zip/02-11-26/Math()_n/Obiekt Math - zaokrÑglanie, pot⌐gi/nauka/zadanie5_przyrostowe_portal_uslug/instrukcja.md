# Zadanie 5 (Przyrostowe Capstone): Portal Usług — Moduł zaawansowanej estymacji i zaokrągleń

## Cel
Celem zadania wieńczącego dział jest rozbudowa Portalu Usług o moduł szacowania nakładów materiałowych i kosztów infrastrukturalnych. Wykorzystasz w nim metody obiektu `Math`: wyznaczenie zapotrzebowania na jednostki serwerowe (zaokrąglenie w górę `Math.ceil`), kalkulację mocy obliczeniowej w modelu wykładniczym (potęgowanie `**`), ograniczenie progów opustu handlowego (`Math.min` i `Math.max`) oraz generowanie losowego numeru referencyjnego zamówienia (`Math.random` i `Math.floor`). Sukcesem jest wygenerowanie kompletnego raportu kosztorysowego portalu w elemencie `#wynik`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Portale chmurowe (np. AWS Pricing Calculator, Azure Portal) szacujące koszty instancji wirtualnych na podstawie mocy i pamięci.
- Systemy ERP zarządzające wyceną usług instalacyjnych i zaokrąglaniem jednostek rozliczeniowych.
- Platformy SaaS wyliczające miesięczne plany subskrypcyjne w zależności od estymowanego ruchu sieciowego.

## Wskazówki aktywizujące
- Zastosuj `Math.ceil()`, aby każda rozpoczęta jednostka zasobów (np. blok obliczeniowy) została zaokrąglona do pełnej jednostki rozliczeniowej.
- Użyj `Math.min(Math.max(rabat, min), max)` do zabezpieczenia polityki rabatowej portalu.
- Sprawdź w konsoli DevTools (`F12`) wzór losowania z przedziału `[1000, 9999]`: `Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000`.

## Treść do wpisania
W skrypcie umieść i sformatuj dokładnie następujące teksty kosztorysu portalu:
„Portal Usługowo-Handlowy IT-Partner — Moduł Estymacji Zasobów i Kosztorysowania”
„Szacowana liczba operacji w procesie: 12500 zapytań/h”
„Liczba węzłów obliczeniowych (zaokrąglenie w górę Math.ceil): 5 jednostek”
„Moc przeliczeniowa klastra (wzór wykładniczy 2^n): 32 vCPU”
„------------------------------------------------------------” (separator sekcji wynikowej)
„Koszt bazowy infrastruktury: 480.00 PLN”
„Przyznany bezpieczny rabat lojalnościowy (Math.min/max): 15%”
„Ostateczny kosztorys wdrożenia netto: 408.00 PLN”
„Numer referencyjny zlecenia portalu (1000-9999):”

## Wymagania
1. Zadeklaruj stałe wejściowe portalu: `liczbaZapytan = 12500`, `przepustowoscWezla = 2800`, `stawkaZaWezel = 96.00` oraz `proponowanyRabat = 22`.
2. Zdefiniuj funkcję `obliczZasobyPortalu(zapytania, pojemnoscWezla)` zwracającą liczbę potrzebnych jednostek obliczeniowych za pomocą `Math.ceil(zapytania / pojemnoscWezla)`.
3. Zdefiniuj funkcję `obliczMocKlastra(liczbaWezlow)` zwracającą moc obliczeniową klastra w vCPU za pomocą potęgowania: `2 ** liczbaWezlow`.
4. Zdefiniuj funkcję `kalkulujKosztorys(zapytania, wezly, mocVCPU, stawka, rabatProcent, minRabat, maxRabat)`, która:
   - Oblicza koszt bazowy: `kosztBazowy = wezly * stawka`,
   - Ustala bezpieczną stopę rabatu za pomocą `Math.min(Math.max(rabatProcent, minRabat), maxRabat)`,
   - Wylicza koszt końcowy netto: `kosztKoncowy = kosztBazowy * (1 - bezpiecznyRabat / 100)`,
   - Losuje 4-cyfrowy numer referencyjny zlecenia: `Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000`,
   - Zwraca gotowy sformatowany ciąg raportu ze znakami `\n` (bez literału obiektu `{}` — zgodnie z granicami modułu),
   - Kwoty w tekście raportu wypisz z dwoma miejscami po przecinku (`.toFixed(2)`).
5. Wywołaj kolejno `obliczZasobyPortalu`, `obliczMocKlastra` oraz `kalkulujKosztorys`, przekazując progi rabatu `5` i `15` jako argumenty.
6. Przypisz kompletny raport do właściwości `textContent` elementu o identyfikatorze `#wynik`.
7. Wypisz raport pomocniczo do konsoli za pomocą `console.log()`.

## Przykład
Dla zadanych parametrów w kontenerze `#wynik` wyświetla się:
```text
Portal Usługowo-Handlowy IT-Partner — Moduł Estymacji Zasobów i Kosztorysowania
Szacowana liczba operacji w procesie: 12500 zapytań/h
Liczba węzłów obliczeniowych (zaokrąglenie w górę Math.ceil): 5 jednostek
Moc przeliczeniowa klastra (wzór wykładniczy 2^n): 32 vCPU
------------------------------------------------------------
Koszt bazowy infrastruktury: 480.00 PLN
Przyznany bezpieczny rabat lojalnościowy (Math.min/max): 15%
Ostateczny kosztorys wdrożenia netto: 408.00 PLN
Numer referencyjny zlecenia portalu (1000-9999): 4819
```
