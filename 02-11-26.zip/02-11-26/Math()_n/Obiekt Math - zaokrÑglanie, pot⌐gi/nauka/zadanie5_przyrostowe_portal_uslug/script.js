// Portal Usługowo-Handlowy IT-Partner — Moduł Estymacji Zasobów i Kosztorysowania
// Zadanie przyrostowe: zaokrąglanie Math.ceil, potęgowanie **, clamping Math.min/max i losowanie

// Stałe wejściowe portalu:
const liczbaZapytan = 12500;
const przepustowoscWezla = 2800;
const stawkaZaWezel = 96.00;
const proponowanyRabat = 22;

// Twoje rozwiazanie
// KROK 1: Zdefiniuj funkcję obliczZasobyPortalu(zapytania, pojemnoscWezla)
// Oblicz liczbę węzłów zaokrąglając wynik dzielenia w górę (Math.ceil)


// KROK 2: Zdefiniuj funkcję obliczMocKlastra(liczbaWezlow)
// Oblicz moc w vCPU ze wzoru 2 ** liczbaWezlow


// KROK 3: Zdefiniuj funkcję
// kalkulujKosztorys(zapytania, wezly, mocVCPU, stawka, rabatProcent, minRabat, maxRabat)
// Oblicz koszt bazowy, ogranicz rabat (Math.min/max), koszt netto, wylosuj numer zlecenia
// i zwróć gotowy tekst raportu (string ze znakami \n) — bez literału obiektu {}


// KROK 4: Wywołaj obliczZasobyPortalu, obliczMocKlastra, kalkulujKosztorys
// (progi rabatu jako argumenty: 5 i 15; kwoty: .toFixed(2))
// i przypisz raport do document.getElementById("wynik").textContent
