// Zadanie 2: Warsztat techniczny — kubatura cylindrycznych zbiorników paliwowych
// Twoje rozwiazanie

function obliczCylinder(promien, wysokosc) {
  // KROK 1: Oblicz pole podstawy koła ze wzoru π * r² przy użyciu Math.PI i potęgowania **
  
  // KROK 2: Oblicz kubaturę zbiornika mnożąc pole podstawy przez wysokość
  
  // KROK 3: Odtwórz promień ze wzoru r = √(Pp / π) przy użyciu Math.sqrt()
  
  // KROK 4: Zwróć za pomocą return sformatowany tekst karty technicznej ze znakami \n
}

// Pobranie danych wejściowych od użytkownika z wartością domyślną (poza ciałem funkcji):
const promienWejsciowy = Number(prompt("Podaj promień podstawy cylindra w metrach:", "2.5"));
const wysokoscWalca = 6.0;

// KROK 5: Wywołaj funkcję obliczCylinder i przypisz wynik do właściwości textContent elementu #wynik
