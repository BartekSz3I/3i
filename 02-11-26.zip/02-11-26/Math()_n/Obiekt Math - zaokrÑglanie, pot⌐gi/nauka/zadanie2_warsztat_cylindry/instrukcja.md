# Zadanie 2: Warsztat techniczny — kubatura cylindrycznych zbiorników paliwowych

## Cel
Celem zadania jest napisanie funkcji inżynierskiej, która oblicza pole powierzchni podstawy, objętość (kubaturę) cylindrycznego zbiornika oraz weryfikuje promień na podstawie zadanej powierzchni z wykorzystaniem stałej `Math.PI`, operatora potęgowania `**` oraz pierwiastkowania `Math.sqrt()`. Sukcesem jest precyzyjne zaokrąglenie wyników do dwóch miejsc po przecinku i ich prezentacja w elemencie `#wynik`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Oprogramowanie CAD/CAM do automatycznego wyliczania pojemności silosów zbożowych i zbiorników ciśnieniowych.
- Systemy bilansowania surowców płynnych w rafineriach i zakładach chemicznych.
- Kalkulatory inżynierii sanitarnej wyliczające przepustowość rurociągów o przekroju kołowym.

## Wskazówki aktywizujące
- Zapoznaj się z sekcją 2 i 4 w pliku `teoria.md` omawiającą stałą `Math.PI`, potęgowanie oraz funkcję `Math.sqrt()`.
- Pamiętaj, że `Math.PI` jest stałą liczbową, a nie funkcją — nie dodawaj nawiasów okrągłych.
- Wpisz w konsoli przeglądarki `(2.5 ** 2) * Math.PI` i sprawdź precyzję otrzymanego wyniku.

## Treść do wpisania
W skrypcie umieść i sformatuj dokładnie następujące teksty specyfikacji technicznej:
„Karta Techniczna Zbiornika Paliwowego — Zbiornik Walcowy ZW-400”
„Wprowadzony promień podstawy (r): 2.50 m”
„Wysokość robocza walca (h): 6.00 m”
„------------------------------------------------------------” (separator sekcji wynikowej)
„Pole powierzchni podstawy walca (Pp = π * r²): 19.63 m²”
„Kubatura robocza zbiornika (V = Pp * h): 117.81 m³”
„Weryfikacja promienia ze wzoru r = √(Pp / π): 2.50 m”

Pytanie w oknie dialogowym prompt:
„Podaj promień podstawy cylindra w metrach:”
Wartość domyślna w oknie dialogowym prompt:
„2.5”

## Wymagania
1. Pobierz promień od użytkownika za pomocą funkcji `prompt("Podaj promień podstawy cylindra w metrach:", "2.5")` umieszczonej **wyłącznie poza ciałem funkcji**.
2. Skonwertuj pobraną wartość do typu liczbowego za pomocą funkcji `Number()` lub `parseFloat()`.
3. Zdefiniuj stałą `wysokosc = 6.0`.
4. Utwórz funkcję `obliczCylinder(promien, wysokosc)`, która:
   - Oblicza pole podstawy: `polePodstawy = Math.PI * (promien ** 2)`,
   - Oblicza objętość: `objetosc = polePodstawy * wysokosc`,
   - Weryfikuje promień z pola: `odtworzonyPromien = Math.sqrt(polePodstawy / Math.PI)`,
   - Zaokrągla wyniki do dwóch miejsc po przecinku wzorem `Math.round(wartosc * 100) / 100`,
   - Przy składaniu tekstu raportu wypisuje liczby z dwoma miejscami po przecinku metodą `.toFixed(2)` (np. `2.50 m`, `19.63 m²`),
   - Zwraca sformatowany tekst podsumowania ze znakami nowej linii `\n`.
5. Wywołaj funkcję `obliczCylinder`, a zwrócony wynik przypisz do właściwości `textContent` elementu `#wynik`.
6. Wyświetl wynik pomocniczo w konsoli za pomocą `console.log()`.

## Przykład
Dla promienia równego 2.5 m oraz wysokości 6.0 m w kontenerze `#wynik` pojawi się:
```text
Karta Techniczna Zbiornika Paliwowego — Zbiornik Walcowy ZW-400
Wprowadzony promień podstawy (r): 2.50 m
Wysokość robocza walca (h): 6.00 m
------------------------------------------------------------
Pole powierzchni podstawy walca (Pp = π * r²): 19.63 m²
Kubatura robocza zbiornika (V = Pp * h): 117.81 m³
Weryfikacja promienia ze wzoru r = √(Pp / π): 2.50 m
```
