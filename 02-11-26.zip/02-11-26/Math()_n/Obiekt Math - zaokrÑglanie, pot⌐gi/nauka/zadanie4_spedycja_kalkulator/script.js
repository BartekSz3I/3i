// Zadanie 4: Spedycja i transport — zintegrowany kalkulator frachtu przesyłek
// Twoje rozwiazanie

function obliczFracht(dx, dy, stawkaKm, minOplata, vat) {
  // KROK 1: Oblicz odległość geometryczną d = √(dx² + dy²) przy użyciu Math.sqrt i potęgowania **
  
  // KROK 2: Wylicz koszt bazowy mnożąc odległość przez stawkę kilometrową
  
  // KROK 3: Zastosuj próg opłaty minimalnej za pomocą Math.max(kosztBazowy, minOplata)
  
  // KROK 4: Oblicz opłatę brutto i zaokrąglij ją w górę do pełnego złotego za pomocą Math.ceil()
  
  // KROK 5: Wylosuj 5-cyfrowy numer listu przewozowego z przedziału [10000, 99999] przy użyciu Math.random i Math.floor
  
  // KROK 6: Zwróć za pomocą return sformatowany list przewozowy ze znakami \n
}

// Parametry zlecenia:
const deltaX = 30;
const deltaY = 40;
const stawkaZaKm = 0.90;
const oplataMinimalna = 55.00;
const stawkaVat = 0.23;

// KROK 7: Wywołaj funkcję obliczFracht i przypisz zwrócony ciąg do textContent elementu #wynik
