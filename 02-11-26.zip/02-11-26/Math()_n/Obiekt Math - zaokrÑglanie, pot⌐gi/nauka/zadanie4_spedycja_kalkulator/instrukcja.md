# Zadanie 4: Spedycja i transport — zintegrowany kalkulator frachtu przesyłek

## Cel
Celem zadania integrującego jest połączenie zagadnień poznanych w zadaniach 1–3 w spójnym module spedycyjnym: wyznaczenie odległości drogowej na podstawie współrzędnych z użyciem twierdzenia Pitagorasa (`Math.sqrt` i potęgowanie `**`), naliczenie opłaty frachtowej z uwzględnieniem stawki minimalnej (`Math.max`), zaokrąglenie kosztu w górę do pełnych złotych (`Math.ceil`) oraz wylosowanie unikalnego numeru listu przewozowego (`Math.random` i `Math.floor`). Sukcesem jest wygenerowanie kompletnego listu przewozowego w elemencie `#wynik`.

Gdzie to się stosuje? (Przykłady ze świata aplikacji):
- Platformy brokerskie kurierów (np. Furgonetka, Apaczka) automatycznie szacujące koszt nadania paczki.
- Systemy dyspozytorskie firm przewozowych przeliczające odległości i nadające unikalne numery trackingowe.
- Aplikacje dostaw miejskich (np. Uber Eats, Glovo) naliczające minimalną opłatę za dostawę na podstawie dystansu.

## Wskazówki aktywizujące
- Połącz wiedzę z zadań 1, 2 i 3: odległość liczysz ze wzoru `Math.sqrt(deltaX ** 2 + deltaY ** 2)`.
- Zastosuj `Math.max(wyliczonyKoszt, minimalnaStawka)`, aby zabezpieczyć firmę przed realizacją kursów poniżej kosztów bazowych.
- Wpisz w konsoli przeglądarki `Math.ceil(24.15)` oraz `Math.floor(Math.random() * (99999 - 10000 + 1)) + 10000`, aby przetestować generator numeru przesyłki.

## Treść do wpisania
W skrypcie umieść i sformatuj dokładnie następujące teksty specyfikacji frachtowej:
„List Przewozowy i Wycena Spedycyjna — Trans-Logistyka Express”
„Odległość geometryczna trasy (d = √(Δx² + Δy²)): 50.00 km”
„Wycena bazowa według stawki kilometrowej: 45.00 PLN”
„Minimalna gwarantowana opłata frachtowa: 55.00 PLN”
„------------------------------------------------------------” (separator sekcji wynikowej)
„Zatwierdzony koszt zlecenia (po uwzględnieniu Math.max): 55.00 PLN”
„Opłata końcowa brutto po zaokrągleniu w górę (Math.ceil): 68.00 PLN”
„Unikalny numer identyfikacyjny listu przewozowego (10000-99999):”

## Wymagania
1. Zadeklaruj stałe opisujące współrzędne bazy i punktu docelowego: `deltaX = 30` oraz `deltaY = 40` (trójkąt pitagorejski: 30² + 40² = 900 + 1600 = 2500, pierwiastek = 50).
2. Zadeklaruj stałe finansowe: `stawkaZaKm = 0.90`, `oplataMinimalna = 55.00` oraz `stawkaVat = 0.23`.
3. Zdefiniuj funkcję `obliczFracht(dx, dy, stawkaKm, minOplata, vat)`, która:
   - Oblicza odległość: `odleglosc = Math.sqrt((dx ** 2) + (dy ** 2))`,
   - Oblicza koszt bazowy: `kosztBazowy = odleglosc * stawkaKm`,
   - Ustala zatwierdzony koszt netto z uwzględnieniem progu minimalnego: `kosztNetto = Math.max(kosztBazowy, minOplata)`,
   - Wylicza koszt brutto i zaokrągla go w górę do pełnego złotego: `kosztBruttoZaokraglony = Math.ceil(kosztNetto * (1 + vat))`,
   - Losuje 5-cyfrowy numer listu przewozowego z przedziału `[10000, 99999]` wzorem `Math.floor(Math.random() * (99999 - 10000 + 1)) + 10000`,
   - Przy składaniu raportu wypisuje odległości i kwoty z dwoma miejscami po przecinku (`.toFixed(2)`),
   - Zwraca sformatowany tekst podsumowania z użyciem znaków nowej linii `\n`.
4. Wywołaj funkcję `obliczFracht` ze zdefiniowanymi parametrami.
5. Przypisz zwrócony ciąg znaków do właściwości `textContent` kontenera `#wynik` oraz wypisz go do konsoli `console.log()`.

## Przykład
Dla współrzędnych 30 km i 40 km w kontenerze `#wynik` pojawi się:
```text
List Przewozowy i Wycena Spedycyjna — Trans-Logistyka Express
Odległość geometryczna trasy (d = √(Δx² + Δy²)): 50.00 km
Wycena bazowa według stawki kilometrowej: 45.00 PLN
Minimalna gwarantowana opłata frachtowa: 55.00 PLN
------------------------------------------------------------
Zatwierdzony koszt zlecenia (po uwzględnieniu Math.max): 55.00 PLN
Opłata końcowa brutto po zaokrągleniu w górę (Math.ceil): 68.00 PLN
Unikalny numer identyfikacyjny listu przewozowego (10000-99999): 83241
```
