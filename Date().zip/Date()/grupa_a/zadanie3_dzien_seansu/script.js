// Twoje rozwiazanie

const display = document.querySelector('#wynik');

const rok = prompt('Wpisz rok');
const miesiac = prompt('Wpisz miesiac') -1;
const dzien = prompt('Wpisz dzien');


const data = new Date(rok, miesiac, dzien);

const mm = String(data.getMonth()+1).padStart(2, '0');
const dd = String(data.getDate()).padStart(2, '0');

let dzientygodnia;

switch (data.getDay()) {
    case 0: 
        dzientygodnia = 'niedziela';
        break;
    case 1:
        dzientygodnia = 'poniedzialek';
        break;
    case 2:
        dzientygodnia = 'wtorek';
        break;
    case 3:
        dzientygodnia = 'sroda';
        break;
    case 4:
        dzientygodnia = 'czwartek';
        break;
    case 5:
        dzientygodnia = 'piatek';
        break;
    case 6:
        dzientygodnia = 'sobota';
        break;
}

display.textContent = dd + '.' + mm + '.' + data.getFullYear() + ', ' + dzientygodnia;