// Twoje rozwiazanie

const display = document.querySelector('#wynik');

const data = new Date(2026, 7, 8);

const dd = String(data.getDate()).padStart(2, '0');

const mm = String(data.getMonth()).padStart(2, '0');

display.textContent = dd + '.' + mm + '.' + data.getFullYear();