// Twoje rozwiazanie

const display = document.querySelector('#wynik');

let data = new Date();

data.setDate(prompt("Podaj dzień"));
data.setMonth(prompt("Podaj miesiąc") - 1);
data.setFullYear(prompt("Podaj rok"));

console.log(data);

display.innerText = `Rok: ${data.getFullYear()} \n Miesiąc: ${data.getMonth()} \n Dzień: ${data.getDate()}`;