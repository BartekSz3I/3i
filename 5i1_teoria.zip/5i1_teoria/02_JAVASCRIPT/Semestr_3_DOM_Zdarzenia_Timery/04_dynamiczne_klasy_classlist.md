# Teoria: Dynamiczne klasy CSS i interfejs classList

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Architektura aplikacji frontendowej: separacja odpowiedzialności

W nowoczesnym tworzeniu stron i aplikacji internetowych obowiązuje zasada rozdzielenia odpowiedzialności:
- **HTML** odpowiada wyłącznie za strukturę dokumentu i semantykę treści.
- **CSS** odpowiada za prezentację, układ graficzny, kolory, typografię oraz animacje.
- **JavaScript** odpowiada za logikę biznesową, obsługę zdarzeń i manipulację stanem elementów.

Gdy chcemy zmienić wygląd elementu w odpowiedzi na akcję użytkownika (np. kliknięcie przycisku, wpisanie błędnych danych do formularza czy rozwinięcie menu), najgorszą praktyką jest bezpośrednie przypisywanie wartości stylów liniowych w kodzie JavaScript, np.:

```javascript
// ZŁA PRAKTYKA: Mieszanie stylów CSS wewnątrz logiki JavaScript
const komunikat = document.querySelector("#komunikat-status");
komunikat.style.backgroundColor = "#fee2e2";
komunikat.style.color = "#991b1b";
komunikat.style.border = "1px solid #f87171";
komunikat.style.display = "block";
```

Podejście to powoduje powstawanie tzw. "spaghetti code", utrudnia utrzymanie spójnego wyglądu strony oraz nadpisuje reguły z zewnętrznych arkuszy stylów wysokim priorytetem stylów liniowych.

Prawidłowe podejście polega na zdefiniowaniu wszystkich wariantów wizualnych w pliku CSS za pomocą klas, a w JavaScript manipulujemy jedynie obecnością tych klas na elemencie:

```css
/* Plik style.css */
.blad-walidacji {
    background-color: #fee2e2;
    color: #991b1b;
    border: 1px solid #f87171;
    display: block;
}
```

```javascript
// DOBRA PRAKTYKA: Zarządzanie klasą semantyczną w JavaScript
const komunikat = document.querySelector("#komunikat-status");
komunikat.classList.add("blad-walidacji");
```

**Po co to jest:** Umożliwia zachowanie czystego kodu, w którym grafik lub programista CSS modyfikuje reguły w jednym arkuszu, a programista JavaScript steruje stanami aplikacji bez wnikania w konkretne wartości kolorów czy marginesów.

**Typowa pomyłka:** Próba stylowania każdego elementu za pomocą właściwości `element.style.color = "red"` zamiast przygotowania klasy `.blad` w pliku CSS i włączenia jej w skrypcie.

---

## 2. Właściwość classList i obiekt DOMTokenList

Każdy element pobrany z drzewa DOM (np. przez `document.querySelector`) posiada właściwość `classList`. Jest to właściwość tylko do odczytu, która zwraca specjalny obiekt typu `DOMTokenList`. Obiekt ten reprezentuje listę tokenów (nazw klas) rozdzielonych spacjami, które aktualnie posiada dany element.

W starszym kodzie JavaScript stosowano właściwość `element.className`, która była zwykłym ciągiem znaków (stringiem). Modyfikacja `className` wymagała ręcznego sklejania ciągów lub używania skomplikowanych operacji na stringach, co prowadziło do przypadkowego usuwania innych klas. Obiekt `classList` rozwiązuje ten problem, dostarczając dedykowane metody.

---

## 3. Metoda classList.add() – dodawanie klas

Metoda `classList.add()` dodaje jedną lub więcej klas do listy klas elementu. Jeżeli klasa już znajduje się na elemencie, metoda nie doda jej powtórnie (zapobiega duplikatom).

### Składnia i przykład:
```javascript
const przycisk = document.querySelector("#btn-wyslij");
const baner = document.querySelector("#baner-promocyjny");

// Dodanie pojedynczej klasy
przycisk.classList.add("aktywny");

// Dodanie wielu klas jednocześnie
baner.classList.add("widoczny", "podswietlony");
```

**Po co to jest:** Służy do natychmiastowego aktywowania nowego stanu elementu, np. zaznaczenia wybranej zakładki w menu, podświetlenia aktywnego kafelka lub pokazania komunikatu.

**Typowa pomyłka:** Podawanie nazwy klasy z kropką, np. `przycisk.classList.add(".aktywny")`. Kropkę stosujemy wyłącznie w selektorach CSS (w `querySelector`), natomiast do metod `classList` przekazujemy samą czystą nazwę klasy jako łańcuch znaków (`"aktywny"`).

---

## 4. Metoda classList.remove() – usuwanie klas

Metoda `classList.remove()` usuwa wskazaną klasę (lub klasy) z elementu. Jeśli wskazana klasa nie istnieje na elemencie, metoda po prostu nic nie robi i nie generuje błędu.

### Składnia i przykład:
```javascript
const powiadomienie = document.querySelector("#powiadomienie-sukces");

// Usunięcie klasy ukrywającej
powiadomienie.classList.remove("ukryty");

// Usunięcie kilku klas jednocześnie
powiadomienie.classList.remove("blad-walidacji", "stary-komunikat");
```

**Po co to jest:** Pozwala zresetować stan elementu, np. usunąć oznaczenie błędu po poprawieniu wartości przez użytkownika albo usunąć klasę `.ukryty`, aby pokazać wcześniej niewidoczne okno dialogowe.

**Typowa pomyłka:** Próba usuwania klas przez przypisanie pustego ciągu: `element.classList = ""`, co jest błędem składniowym (właściwość `classList` jest tylko do odczytu) – należy użyć `element.classList.remove(...)` lub jeśli chcemy wyczyścić wszystko, odwołać się do `element.className = ""`.

---

## 5. Metoda classList.toggle() – inteligentne przełączanie stanu

Metoda `classList.toggle()` sprawdza, czy dana klasa znajduje się na elemencie:
- Jeśli klasa **istnieje** – zostaje usunięta, a metoda zwraca `false`.
- Jeśli klasy **nie ma** – zostaje dodana, a metoda zwraca `true`.

Dodatkowo metoda przyjmuje opcjonalny drugi argument (tzw. `force` – wartość logiczną `true` lub `false`). Gdy przekażemy drugi parametr:
- Jeśli parametr to `true` – klasa zostanie dodana (niezależnie od tego, czy była).
- Jeśli parametr to `false` – klasa zostanie usunięta.

### Składnia i przykład:
```javascript
const menuGlowne = document.querySelector("#menu-nawigacji");
const btnMenu = document.querySelector("#btn-toggle-menu");

btnMenu.addEventListener("click", () => {
    // Proste przełączanie: włącz/wyłącz klasę
    const czyOtwarte = menuGlowne.classList.toggle("otwarte");
    console.log("Czy menu jest otwarte:", czyOtwarte);
});

// Wymuszenie stanu na podstawie warunku logicznego (force):
const poleWiek = document.querySelector("#wiek");
const czyPelnoletni = Number(poleWiek.value) >= 18;
poleWiek.classList.toggle("sukces-walidacji", czyPelnoletni);
```

**Po co to jest:** Zastępuje długie instrukcje warunkowe `if (contains) remove else add` jedną zwięzłą linijką, idealną do obsługi przycisków typu "Pokaż/Ukryj", przełączników trybu ciemnego (Dark Mode) czy akordeonów FAQ.

**Typowa pomyłka:** Ręczne pisanie sprawdzania warunku `if (el.classList.contains("x")) { el.classList.remove("x"); } else { el.classList.add("x"); }` w miejscach, gdzie pojedyncze wywołanie `el.classList.toggle("x")` robi dokładnie to samo w czytelniejszy sposób.

---

## 6. Metoda classList.contains() – sprawdzanie obecności klasy

Metoda `classList.contains()` weryfikuje, czy element posiada zadaną klasę. Zwraca wartość typu boolean: `true` jeżeli klasa istnieje na elemencie, lub `false` w przeciwnym razie.

### Składnia i przykład:
```javascript
const sekcjaOferta = document.querySelector("#sekcja-oferta");
const btnSzczegoly = document.querySelector("#btn-szczegoly");

btnSzczegoly.addEventListener("click", () => {
    if (sekcjaOferta.classList.contains("ukryty")) {
        sekcjaOferta.classList.remove("ukryty");
        btnSzczegoly.textContent = "Zwiń ofertę";
    } else {
        sekcjaOferta.classList.add("ukryty");
        btnSzczegoly.textContent = "Rozwiń ofertę";
    }
});
```

**Po co to jest:** Umożliwia uzależnienie dalszych akcji aplikacji (np. zmiany etykiety przycisku, wykonania obliczeń lub uruchomienia licznika) od aktualnego stanu wizualnego elementu.

**Typowa pomyłka:** Zapominanie, że `contains()` zwraca wartość logiczną i próba wywołania jej tak, jakby modyfikowała element. Pamiętaj: `contains()` tylko bada stan, nie wprowadza żadnych zmian.

---

## 7. Metoda classList.replace() – zamiana jednej klasy na drugą

Metoda `classList.replace(staraKlasa, nowaKlasa)` wyszukuje na elemencie klasę `staraKlasa` i podmienia ją na `nowaKlasa`. Jeśli `staraKlasa` nie występowała na elemencie, podmiana nie następuje, a metoda zwraca `false` (w przypadku sukcesu zwraca `true`).

### Składnia i przykład:
```javascript
const poleEmail = document.querySelector("#email");

// Zamiana stanu błędu na stan sukcesu po poprawieniu danych
if (poleEmail.classList.contains("blad-walidacji")) {
    poleEmail.classList.replace("blad-walidacji", "sukces-walidacji");
} else {
    poleEmail.classList.add("sukces-walidacji");
}
```

**Po co to jest:** Pozwala elegancko przełączać stany wzajemnie wykluczające się (np. `.motyw-jasny` na `.motyw-ciemny`, `.status-oczekiwanie` na `.status-zatwierdzony`, `.blad-walidacji` na `.sukces-walidacji`) bez konieczności osobnego wywoływania `remove()` i `add()`.

**Typowa pomyłka:** Mylenie kolejności argumentów w `replace()`. Pierwszym argumentem jest klasa usuwana (stara), a drugim klasa wstawiana (nowa): `replace("stara-klasa", "nowa-klasa")`.

---

## 8. Iteracja i praca z kolekcjami elementów (`querySelectorAll`)

Często zachodzi potrzeba zmiany klas na grupie elementów, na przykład odznaczenia wszystkich kart i zaznaczenia tylko klikniętej. Wynikiem wywołania `document.querySelectorAll()` jest obiekt `NodeList`, po którym możemy iterować za pomocą metody `forEach()`.

```javascript
const wszystkieKarty = document.querySelectorAll(".karta-produktu");

wszystkieKarty.forEach((karta) => {
    karta.addEventListener("click", () => {
        // Krok 1: Usunięcie klasy aktywnej ze wszystkich kart
        wszystkieKarty.forEach((k) => k.classList.remove("aktywny"));

        // Krok 2: Dodanie klasy aktywnej tylko do klikniętej karty
        karta.classList.add("aktywny");
    });
});
```

**Po co to jest:** Standardowy wzorzec obsługi zakładek (tabs), akordeonów, list wyboru oraz galerii miniaturek w aplikacjach webowych.

**Typowa pomyłka:** Próba wywołania `wszystkieKarty.classList.add("aktywny")` bezpośrednio na wyniku `querySelectorAll`. Obiekt `NodeList` nie posiada właściwości `classList` – musimy przejść przez każdy element w pętli `forEach`.

---

## 9. Standardowe klasy w projekcie egzaminacyjnym (Kontrakt DOM)

W zadaniach egzaminacyjnych oraz projektach zaliczeniowych stosujemy ustandaryzowane nazewnictwo klas pomocniczych:
- `.ukryty` – ukrywa element (np. reguła CSS `display: none;` lub `visibility: hidden;`).
- `.aktywny` – oznacza aktualnie wybrany element, aktywną zakładkę lub wciśnięty przycisk.
- `.blad-walidacji` – oznacza pole formularza zawierające nieprawidłowe dane (czerwona ramka, tło).
- `.sukces-walidacji` – oznacza poprawnie zweryfikowane pole (zielona ramka).
- `.motyw-ciemny` / `.motyw-jasny` – steruje kolorystyką kontenera głównego aplikacji.
