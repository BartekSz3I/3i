# Atrybuty elementów i obsługa kontrolek formularza w drzewie DOM

W aplikacjach internetowych formularze stanowią podstawowy kanał komunikacji między użytkownikiem a systemem. W modelu DOM każdy element formularza (`<input>`, `<select>`, `<textarea>`, `<button>`) jest reprezentowany przez dedykowany obiekt JavaScript posiadający właściwości odzwierciedlające jego bieżący stan. Ponadto każdy węzeł drzewa DOM udostępnia uniwersalne metody do odczytywania i modyfikowania swoich atrybutów HTML.

---

## 1. Właściwości kontrolek formularza: odczyt i zapis danych

### Pola tekstowe i liczbowe (`value`)
W przeciwieństwie do zwykłych kontenerów takich jak `<div>` czy `<p>`, które przechowują treść we właściwości `textContent`, kontrolki formularza przechowują wpisaną zawartość we właściwości `value`.

```javascript
// Pobranie pola tekstowego
const poleImie = document.getElementById("imie");

// Odczyt aktualnej wartości
const wpisaneImie = poleImie.value;
console.log("Wprowadzone imię:", wpisaneImie);

// Zapis nowej wartości
poleImie.value = "Jan Kowalski";
```

Wartość zwracana przez właściwość `value` jest **zawsze typu tekstowego (`string`)**, nawet jeśli pole ma typ liczbowy (`<input type="number">`). W przypadku konieczności wykonania obliczeń matematycznych należy dokonać jawnej konwersji:

```javascript
const poleIlosc = document.getElementById("ilosc");
const liczbaSztuk = Number(poleIlosc.value); // lub parseInt(poleIlosc.value, 10)
```

> **Po co to jest?**
> Właściwość `value` pozwala skryptom odczytywać dane wprowadzone przez użytkownika w polach tekstowych, wyszukiwarkach i kalkulatorach oraz dynamicznie podstawiać wartości domyślne.
>
> **Typowa pomyłka:**
> Próba użycia `poleImie.textContent` zamiast `poleImie.value`. Znacznik `<input>` jest elementem samozamykającym się i nie posiada węzła tekstowego wewnątrz — odczytanie `textContent` z pola wejściowego zwróci pusty ciąg.

---

### Pola wyboru z listy rozwijanej (`<select>`)
Element `<select>` udostępnia wartość aktualnie zaznaczonej opcji poprzez swoją własną właściwość `value`:

```javascript
const listaUslug = document.getElementById("usluga");

// Odczyt wartości wybranej opcji (atrybut value znacznika <option>)
const wybranaWartosc = listaUslug.value;

// Dostęp do widocznego tekstu wybranej opcji
const wybranyIndeks = listaUslug.selectedIndex;
const widocznyTekst = listaUslug.options[wybranyIndeks].text;
```

> **Po co to jest?**
> Umożliwia pobranie kodu identyfikacyjnego lub taryfy wybranej przez użytkownika w menu rozwijanym.
>
> **Typowa pomyłka:**
> Zakładanie, że `select.value` zwraca tekst wyświetlany na ekranie. Jeśli znacznik ma postać `<option value="srv-01">Audyt sieci</option>`, właściwość `listaUslug.value` zwróci `"srv-01"`, a nie `"Audyt sieci"`.

---

## 2. Stany logiczne i kontrola dostępności kontrolek

### Pola typu checkbox i radio (`checked`)
Pola wyboru wielokrotnego (`checkbox`) oraz jednokrotnego (`radio`) posiadają właściwość logiczną `checked`, która przyjmuje wartość `true` (gdy pole jest zaznaczone) lub `false` (gdy pole pozostaje puste):

```javascript
const zgodaRegulamin = document.getElementById("regulamin");

// Odczyt stanu
if (zgodaRegulamin.checked) {
  console.log("Regulamin zaakceptowany");
} else {
  console.log("Wymagana akceptacja regulaminu");
}

// Programowa zmiana stanu zaznaczenia
zgodaRegulamin.checked = true;
```

> **Po co to jest?**
> Pozwala sprawdzić zgody formalne, filtry wyszukiwania oraz wybór opcji opcjonalnych w koszyku zamówień.
>
> **Typowa pomyłka:**
> Odczytywanie `zgodaRegulamin.value` zamiast `zgodaRegulamin.checked`. Wartość `value` w polu typu checkbox jest stałym ciągiem (domyślnie `"on"`) i nie zmienia się po odznaczeniu pola.

---

### Blokowanie kontrolek (`disabled` oraz `readOnly`)
Elementy formularza można zablokować przed interakcją lub edycją za pomocą właściwości logicznych:

```javascript
const przyciskOblicz = document.getElementById("btn-oblicz");
const poleRabat = document.getElementById("rabat");

// Zablokowanie przycisku
przyciskOblicz.disabled = true;

// Odblokowanie przycisku
przyciskOblicz.disabled = false;

// Ustawienie pola w tryb tylko do odczytu
poleRabat.readOnly = true;
```

> **Po co to jest?**
> Chroni aplikację przed wysłaniem formularza, dopóki użytkownik nie spełni warunków formalnych (np. brak akceptacji regulaminu blokuje przycisk).
>
> **Typowa pomyłka:**
> Przypisanie ciągu znaków `przycisk.disabled = "false"`. W języku JavaScript niepusty ciąg znaków jest traktowany w kontekście logicznym jako prawda (`true`), więc przycisk pozostanie zablokowany. Należy zawsze przypisywać wartość logiczną `false`.

---

### Dynamiczna zmiana typu kontrolki (`type`)
Właściwość `type` elementu `<input>` jest modyfikowalna w czasie działania aplikacji:

```javascript
const poleHaslo = document.getElementById("haslo");

// Podgląd hasła: zmiana z kropkowanego na jawny tekst
poleHaslo.type = "text";

// Ponowne ukrycie hasła
poleHaslo.type = "password";
```

> **Po co to jest?**
> Standardowy mechanizm "pokaż/ukryj hasło" spotykany w formularzach logowania i rejestracji.

---

## 3. Uniwersalne metody manipulacji atrybutami HTML

Każdy element drzewa DOM udostępnia metody do bezpośredniej obsługi swoich atrybutów:

```javascript
const baner = document.getElementById("baner");

// 1. Sprawdzenie czy atrybut istnieje
if (baner.hasAttribute("title")) {
  console.log("Baner posiada podpis title");
}

// 2. Odczytanie wartości atrybutu
const adresObrazka = baner.getAttribute("src");

// 3. Ustawienie lub nadpisanie atrybutu
baner.setAttribute("src", "obrazy/baner_nocny.webp");
baner.setAttribute("alt", "Nowy baner informacyjny");

// 4. Usunięcie atrybutu
baner.removeAttribute("title");
```

> **Po co to jest?**
> Metody te pozwalają na manipulację dowolnym atrybutem HTML, w tym atrybutami dla których nie zdefiniowano dedykowanych właściwości w specyfikacji języka.
>
> **Typowa pomyłka:**
> Podawanie wartości logicznej w drugim argumencie `setAttribute("disabled", false)`. Metoda `setAttribute` konwertuje drugi argument na ciąg znaków, co skutkuje wstawieniem atrybutu `disabled="false"` — a w HTML sama obecność atrybutu oznacza blokadę elementu. Aby usunąć blokadę, należy użyć `removeAttribute("disabled")` lub `element.disabled = false`.

---

## 4. Różnica między atrybutem HTML a właściwością DOM

Jest to jedna z najważniejszych koncepcji w architekturze DOM:
1. **Atrybut HTML (`getAttribute` / `setAttribute`):** reprezentuje stan początkowy zapisany w kodzie źródłowym HTML.
2. **Właściwość DOM (`element.value`, `element.checked`):** reprezentuje bieżący stan kontrolki w pamięci przeglądarki.

```javascript
// Załóżmy kod HTML: <input id="kod" value="START">
const poleKod = document.getElementById("kod");

// Użytkownik wpisuje w przeglądarce tekst "NOWY_KOD"
console.log(poleKod.value); // "NOWY_KOD" (bieżący stan)
console.log(poleKod.getAttribute("value")); // "START" (wartość początkowa)
```

---

## 5. Atrybuty niestandardowe HTML5 i właściwość dataset

Standard HTML5 umożliwia dołączanie własnych danych do dowolnego znacznika za pomocą atrybutów z prefiksem `data-*`. W skryptach JavaScript odczytujemy je za pomocą właściwości `dataset`:

```html
<div id="pakiet-serwisowy" data-kod="SRV-BASIC" data-cena="250" data-kategoria="sieci">
  Pakiet Podstawowy
</div>
```

```javascript
const pakiet = document.getElementById("pakiet-serwisowy");

// Odczyt danych z obiektu dataset
const kod = pakiet.dataset.kod; // "SRV-BASIC"
const cena = Number(pakiet.dataset.cena); // 250
const kategoria = pakiet.dataset.kategoria; // "sieci"

// Modyfikacja lub dodanie nowej danej
pakiet.dataset.promocja = "aktywna"; // utworzy atrybut data-promocja="aktywna"
```

Nazwy wieloczłonowe z myślnikiem są automatycznie konwertowane na konwencję camelCase:
* Atrybut w HTML: `data-czas-realizacji="24h"`
* Dostęp w JS: `pakiet.dataset.czasRealizacji`

> **Po co to jest?**
> Umożliwia bezpieczne wiązanie parametrów biznesowych (ceny, kody kreskowe, identyfikatory bazodanowe) bezpośrednio ze strukturą wizualną strony bez konieczności parsowania tekstu.
