# Teoria: Dynamiczne style CSS z poziomu JavaScript (element.style)

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Właściwość element.style i obiekt CSSStyleDeclaration

Każdy węzeł drzewa DOM reprezentujący element HTML posiada właściwość `style`. Właściwość ta zwraca obiekt typu `CSSStyleDeclaration`, który odpowiada atrybutowi liniowemu `style="..."` w kodzie HTML danego elementu.

Bezpośrednia modyfikacja `element.style` pozwala na dynamiczne zmienianie wyglądu elementu w czasie rzeczywistym z poziomu kodu JavaScript.

```javascript
const baner = document.querySelector("#baner-reklamowy");

// Nadanie koloru tła za pomocą stylu liniowego
baner.style.backgroundColor = "#2563eb";
```

W wyniku powyższego wywołania przeglądarka zmodyfikuje kod HTML elementu, dodając styl inline: `<div id="baner-reklamowy" style="background-color: rgb(37, 99, 235);">`.

**Po co to jest:** Umożliwia natychmiastową, dynamiczną zmianę wyglądu elementu, zwłaszcza gdy wartości stylu nie są z góry znane i zależą od zmiennych w kodzie, obliczeń matematycznych lub danych wprowadzonych przez użytkownika (np. pozycji kursora myszy, wartości z suwaka czy wybranego koloru z próbnika).

**Typowa pomyłka:** Zakładanie, że właściwość `element.style` zawiera wszystkie style zdefiniowane w zewnętrznym pliku CSS (`style.css`). Obiekt `element.style` reprezentuje wyłącznie style liniowe danego elementu (zdefiniowane w atrybucie `style` lub dodane przez JS). Jeśli właściwość została określona w zewnętrznym arkuszu CSS, odczytanie `element.style.color` zwróci pusty ciąg znaków (`""`).

---

## 2. Reguła notacji: z kebab-case na camelCase

W języku CSS nazwy właściwości wielowyrazowych zapisywane są z użyciem dywizu (tzw. kebab-case), np. `background-color`, `font-size`, `border-radius`, `z-index`. W języku JavaScript znak minus (`-`) jest operatorem odejmowania, dlatego zapis taki jak `element.style.background-color` spowodowałby błąd składniowy (`SyntaxError`).

Z tego względu w obiekcie `element.style` obowiązuje reguła konwersji do notacji wielbłądziej (**camelCase**):
- Usuwamy myślnik, a pierwszą literę kolejnego słowa zapisujemy jako wielką.

| Właściwość w CSS (kebab-case) | Właściwość w JavaScript (camelCase) | Przykład wartości |
|---|---|---|
| `background-color` | `backgroundColor` | `"#10b981"` |
| `font-size` | `fontSize` | `"18px"` |
| `border-radius` | `borderRadius` | `"8px"` |
| `margin-top` | `marginTop` | `"20px"` |
| `z-index` | `zIndex` | `"10"` |
| `box-shadow` | `boxShadow` | `"0 4px 6px rgba(0, 0, 0, 0.1)"` |
| `text-align` | `textAlign` | `"center"` |

### Przykład kodu:
```javascript
const komunikat = document.querySelector("#komunikat-sukces");

komunikat.style.backgroundColor = "#dcfce7";
komunikat.style.fontSize = "16px";
komunikat.style.borderRadius = "6px";
komunikat.style.textAlign = "center";
```

**Po co to jest:** Pozwala programiście na bezpośredni dostęp do konkretnych właściwości CSS jako właściwości obiektu JavaScript w sposób zgodny ze składnią języka.

**Typowa pomyłka:** Zapisywanie nazw właściwości z myślnikiem, np. `element.style.font-size = "20px"`, co wywołuje błąd parsera, albo zapisywanie z myślnikiem w nawiasie kwadratowym `element.style["font-size"]`, co choć technicznie działa, jest uznawane za gorszą praktykę w porównaniu z czytelnym `element.style.fontSize`.

---

## 3. Bezwzględna konieczność podawania jednostek miar

Wszystkie wartości przypisywane do właściwości w `element.style` muszą być łańcuchami znaków (typ `string`). Jeśli właściwość CSS wymaga jednostki miary (np. `px`, `%`, `rem`, `deg`, `s`), należy tę jednostkę bezwzględnie dokleić do wartości liczbowej.

Przypisanie samej liczby do właściwości wymagającej jednostki zostanie przez przeglądarkę zignorowane jako nieprawidłowa wartość CSS.

### Przykład z łączeniem jednostek:
```javascript
const suwakSzerokosci = document.querySelector("#suwak-szerokosc");
const pudelko = document.querySelector("#podglad-pudelko");

suwakSzerokosci.addEventListener("input", () => {
    const nowaSzerokosc = suwakSzerokosci.value;
    
    // PRAWIDŁOWO: Wartość liczbowa połączona z jednostką "px" za pomocą template literal
    pudelko.style.width = `${nowaSzerokosc}px`;
    
    // LUB tradycyjne łączenie ciągów:
    // pudelko.style.width = nowaSzerokosc + "px";
});
```

Wyjątkiem od reguły podawania jednostek są nieliczne właściwości bezwymiarowe w CSS, takie jak `opacity` (zakres 0 do 1), `zIndex`, `lineHeight` czy `flexGrow`:
```javascript
pudelko.style.opacity = "0.75"; // Liczba bez jednostki jest poprawna
pudelko.style.zIndex = "5";
```

**Po co to jest:** Silnik renderujący przeglądarki rygorystycznie sprawdza poprawność składni CSS. Brak jednostki uniemożliwiłby przeglądarce ustalenie, czy chodzi o piksele, procenty czy punkty typograficzne.

**Typowa pomyłka:** Przypisanie samej wartości liczbowej: `pudelko.style.width = 300;` albo `pudelko.style.fontSize = 24;`. Kod wykona się bez błędu w konsoli JS, ale przeglądarka odrzuci niepoprawną regułę CSS i styl nie ulegnie żadnej zmianie.

---

## 4. Resetowanie i usuwanie stylów liniowych

Aby usunąć styl liniowy nadany wcześniej przez JavaScript i przywrócić domyślne reguły określone w zewnętrznym arkuszu stylów CSS, wystarczy przypisać do właściwości pusty ciąg znaków (`""`) lub użyć metody `removeProperty()`.

```javascript
const przycisk = document.querySelector("#btn-resetuj-wyglad");
const wizytowka = document.querySelector("#podglad-wizytowka");

przycisk.addEventListener("click", () => {
    // Sposób 1: Przypisanie pustego ciągu znaków
    wizytowka.style.backgroundColor = "";
    wizytowka.style.fontSize = "";
    
    // Sposób 2: Użycie metody removeProperty (wymaga nazwy w formacie kebab-case)
    wizytowka.style.removeProperty("border-radius");
});
```

Przypisanie pustego łańcucha usuwa daną deklarację z atrybutu `style` w HTML, dzięki czemu element z powrotem przejmuje styl z pliku `.css` lub styl domyślny przeglądarki.

**Po co to jest:** Pozwala zaimplementować przyciski "Wyczyść dostosowanie", "Przywróć domyślny wygląd" oraz usuwać tymczasowe wyróżnienia bez konieczności pamiętania pierwotnych wartości kolorów czy rozmiarów.

**Typowa pomyłka:** Przypisanie wartości `null`, `undefined` lub słowa `"none"` zamiast pustego ciągu `""`. Przypisanie `"none"` do `backgroundColor` nie przywraca stylu z pliku CSS, lecz jest niepoprawną wartością koloru.

---

## 5. Kiedy używać element.style, a kiedy element.classList?

Zarówno `element.style`, jak i `element.classList` służą do wpływania na wygląd elementów, jednak mają zupełnie inne przeznaczenie architektoniczne:

| Aspekt | `element.classList` | `element.style` |
|---|---|---|
| **Kiedy stosować?** | Stany binarne i skończone warianty (np. `.ukryty`, `.aktywny`, `.blad-walidacji`, zmiana motywu). | Wartości płynne, ciągłe i dynamicznie wyliczane (np. suwak rozmiaru czcionki, wybór koloru z próbnika, pasek postępu w %, pozycjonowanie na podstawie współrzędnych kursora). |
| **Gdzie leżą reguły?** | Wszystkie reguły wizualne znajdują się w zewnętrznym pliku CSS. | Reguły są generowane w locie i wstrzykiwane jako styl liniowy w atrybucie `style`. |
| **Priorytet CSS** | Standardowy priorytet selektora klasy. | Bardzo wysoki priorytet stylu liniowego (nadpisuje reguły z arkuszy CSS). |

### Złota zasada architektoniczna:
Jeśli wygląd elementu można opisać z góry skończoną liczbą klas (np. 3 poziomy ostrzeżeń, 2 stany widoczności, 2 motywy graficzne) – **zawsze wybieraj `classList`**.  
Jeśli parametr ma nieskończoną liczbę możliwych wartości wyliczanych w czasie działania programu (np. szerokość paska postępu od `0%` do `100%`, kolor RGB generowany z trzech suwaków) – **użyj `element.style`**.

**Po co to jest:** Zapobiega zaśmiecaniu arkusza CSS tysiącami sztucznych klas w rodzaju `.szerokosc-1px`, `.szerokosc-2px`, a z drugiej strony chroni przed utratą czytelności kodu i łamaniem separacji stylów przy prostych zmianach stanów.

**Typowa pomyłka:** Używanie `element.style.display = "none"` i `element.style.display = "block"` do pokazywania i ukrywania elementów zamiast semantycznej klasy `.ukryty` zarządzanej przez `classList.toggle("ukryty")`.

---

## 6. Praca z kontrolkami formularzy: dynamiczne generowanie stylów

Najczęstszym zastosowaniem `element.style` w zadaniach egzaminacyjnych i projektach webowych jest integracja z polami typu `<input type="range">`, `<input type="color">` lub `<input type="number">`.

```javascript
const probnikKoloru = document.querySelector("#kolor-tla");
const suwakKrycia = document.querySelector("#krycie");
const podglad = document.querySelector("#wynik-podglad");

probnikKoloru.addEventListener("input", () => {
    podglad.style.backgroundColor = probnikKoloru.value;
});

suwakKrycia.addEventListener("input", () => {
    // Opacity przyjmuje wartość z zakresu 0.0 - 1.0 (wartość bez jednostki)
    podglad.style.opacity = suwakKrycia.value;
});
```

Zdarzenie `input` wyzwala się natychmiast podczas przesuwania suwaka lub wybierania barwy, co zapewnia płynną interakcję bez konieczności klikania osobnego przycisku zatwierdzającego.
