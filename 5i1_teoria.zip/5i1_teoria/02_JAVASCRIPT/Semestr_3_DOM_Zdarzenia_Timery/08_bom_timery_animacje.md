# Teoria: Obiekt BOM, timery i animacje interfejsu (setTimeout, setInterval)

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Czym jest BOM i obiekt `window`?

W dotychczasowych działach manipulowaliśmy dokumentem za pomocą obiektu `document` (drzewo DOM – Document Object Model). Przeglądarka internetowa udostępnia jednak również nadrzędny model obiektowy środowiska, czyli **BOM (Browser Object Model)**. Głównym punktem dostępowym do tego modelu jest globalny obiekt `window`.

Obiekt `window` reprezentuje okno przeglądarki lub pojedynczą kartę, w której uruchomiony jest nasz skrypt. Wszystkie zmienne i funkcje zadeklarowane w zasięgu globalnym stają się w środowisku przeglądarki właściwościami i metodami obiektu `window`. Co więcej, sam obiekt `document` jest w rzeczywistości właściwością `window.document`. Ze względu na wygodę zapisu przedrostek `window.` jest zazwyczaj pomijany – piszemy po prostu `alert(...)` lub `setTimeout(...)` zamiast `window.alert(...)` czy `window.setTimeout(...)`.

Wybrane przydatne właściwości obiektu `window`:
- `window.innerWidth` oraz `window.innerHeight` – zwracają aktualną szerokość i wysokość obszaru roboczego widoku (viewport) w pikselach.
- `window.scroll(x, y)` lub `window.scrollTo(x, y)` – umożliwia przewinięcie okna do wskazanych współrzędnych.

```javascript
// Odczyt aktualnej szerokości okna przeglądarki
const szerokoscOkna = window.innerWidth;
console.log("Szerokość obszaru roboczego:", szerokoscOkna);
```

**Po co to jest:**
Obiekt `window` stanowi fundament całego środowiska uruchomieniowego w przeglądarce i udostępnia interfejsy wykraczające poza sam kod HTML, takie jak mierzenie upływu czasu czy obsługa wymiarów ekranu.

**Typowa pomyłka:**
Próba odwołania się do właściwości takich jak `document.innerWidth` zamiast `window.innerWidth`. Obiekt `document` opisuje strukturę znaczników HTML, natomiast `window` odpowiada za okno przeglądarki.

---

## 2. Jednorazowe opóźnienia: `setTimeout()` i `clearTimeout()`

Funkcja `setTimeout()` pozwala zaplanować jednorazowe wykonanie przekazanej funkcji zwrotnej (callback) po upływie określonej liczby milisekund. Jeden tysiąc milisekund odpowiada dokładnie jednej sekundzie (1000 ms = 1 s).

### Składnia funkcji `setTimeout`:
```javascript
const idTimera = setTimeout(funkcjaZwrotna, opoznienieWMilisekundach);
```

Funkcja `setTimeout()` nie wstrzymuje wykonywania kolejnych linii skryptu. Kod JavaScript kontynuuje swoje działanie natychmiast, a przeglądarka w tle odlicza zadany czas i umieszcza wywołanie funkcji zwrotnej w kolejce zadań.

```javascript
const komunikat = document.querySelector("#komunikat-sukces");

// Pokazujemy komunikat natychmiast
komunikat.classList.remove("ukryty");

// Planujemy ukrycie komunikatu po 3 sekundach (3000 ms)
const idZamykania = setTimeout(() => {
  komunikat.classList.add("ukryty");
  console.log("Komunikat został automatycznie ukryty.");
}, 3000);
```

**Po co to jest:**
`setTimeout()` pozwala na planowanie opóźnionych reakcji interfejsu użytkownika, takich jak automatyczne znikanie powiadomień toast, ukrywanie podpowiedzi lub opóźniona reakcja po kliknięciu.

**Typowa pomyłka:**
Dopisanie nawiasów wywołania przy przekazywaniu nazwy funkcji, np. `setTimeout(ukryjKomunikat(), 3000)`. Taki zapis spowoduje natychmiastowe wykonanie funkcji `ukryjKomunikat` podczas parsowania kodu, a do `setTimeout` trafi wartość zwrócona przez tę funkcję (najczęściej `undefined`), w wyniku czego opóźnienie nie zadziała. Poprawny zapis to `setTimeout(ukryjKomunikat, 3000)` lub `setTimeout(() => ukryjKomunikat(), 3000)`.

### Anulowanie opóźnienia za pomocą `clearTimeout`:
Funkcja `setTimeout()` zwraca unikalny identyfikator liczbowy (tzw. timer ID). Jeśli przed upływem wyznaczonego czasu zechcemy zrezygnować z zaplanowanej akcji, przekazujemy ten identyfikator do funkcji `clearTimeout()`.

```javascript
const btnAnuluj = document.querySelector("#btn-anuluj");

btnAnuluj.addEventListener("click", () => {
  clearTimeout(idZamykania);
  console.log("Zaplanowane ukrycie komunikatu zostało anulowane.");
});
```

**Po co to jest:**
`clearTimeout()` zapobiega wykonaniu nieaktualnej lub niepożądanej operacji, na przykład gdy użytkownik najechał kursorem na znikające powiadomienie i chce je przeczytać bez pośpiechu.

**Typowa pomyłka:**
Zapomnienie o zapisaniu identyfikatora zwróconego przez `setTimeout()` do zmiennej. Bez zapisanego identyfikatora nie ma możliwości anulowania zaplanowanego zadania.

---

## 3. Cykliczne wywołania: `setInterval()` i `clearInterval()`

Gdy zachodzi potrzeba powtarzania określonej czynności w stałych odstępach czasu (np. co sekundę lub co 50 milisekund), stosuje się funkcję `setInterval()`.

### Składnia funkcji `setInterval`:
```javascript
const idInterwalu = setInterval(funkcjaZwrotna, odstepWMilisekundach);
```

Funkcja przekazana do `setInterval()` będzie wykonywana cyklicznie tak długo, aż skrypt wywoła `clearInterval(idInterwalu)` lub strona zostanie zamknięta przez użytkownika.

```javascript
let licznikSekund = 10;
const poleLicznik = document.querySelector("#licznik");
const btnStart = document.querySelector("#btn-start");

const idOdliczania = setInterval(() => {
  licznikSekund--;
  poleLicznik.textContent = "Pozostało sekund: " + licznikSekund;

  if (licznikSekund <= 0) {
    clearInterval(idOdliczania);
    poleLicznik.textContent = "Czas minął!";
  }
}, 1000);
```

**Po co to jest:**
`setInterval()` jest podstawowym mechanizmem budowy zegarów cyfrowych, stoperów, liczników czasu promocji oraz prostych pętli odświeżania stanu aplikacji.

**Typowa pomyłka:**
Brak warunku zatrzymania `clearInterval()` wewnątrz pętli. Interwał będzie wtedy działał w nieskończoność, a wartość zmiennej liczbowej spadnie do liczb ujemnych (`-1`, `-2`, ...), marnując zasoby procesora przeglądarki.

### Zatrzymywanie interwału za pomocą `clearInterval`:
Identycznie jak w przypadku `setTimeout`, funkcja `setInterval()` zwraca identyfikator. Przekazanie go do `clearInterval()` natychmiast zatrzymuje dalsze cykliczne wywołania.

```javascript
let timerId = null;

function zatrzymajZegar() {
  if (timerId !== null) {
    clearInterval(timerId);
    timerId = null;
  }
}
```

**Po co to jest:**
`clearInterval()` chroni aplikację przed wyciekami pamięci i niekontrolowanym działaniem procesów w tle, kiedy ich zadanie dobiegło końca.

**Typowa pomyłka:**
Przekazanie do `clearInterval()` nazwy samej funkcji zamiast zmiennej przechowującej identyfikator zwrócony z `setInterval()`, np. `clearInterval(odliczaj)`. Taki zapis niczego nie zatrzyma, ponieważ funkcja oczekuje identyfikatora liczbowego.

---

## 4. Problem wielokrotnego uruchamiania timerów (wyścigi i przyspieszanie)

Jednym z najczęstszych problemów w aplikacjach z timerami jest sytuacja, w której użytkownik klika przycisk uruchamiający licznik wielokrotnie. Każde kliknięcie bez odpowiedniego zabezpieczenia tworzy nowy, niezależny interwał. W efekcie po kilku kliknięciach licznik zaczyna odliczać wielokrotnie szybciej, a zmienna przechowująca identyfikator zostaje nadpisana ostatnim numerem, co uniemożliwia zatrzymanie wcześniej uruchomionych timerów.

### Rozwiązanie wzorcowe: kontrola stanu i blokada przycisku
```javascript
const btnStart = document.querySelector("#btn-start");
const btnStop = document.querySelector("#btn-stop");
const poleCzas = document.querySelector("#wynik");

let stoperId = null;
let sekundy = 0;

btnStart.addEventListener("click", () => {
  // Zabezpieczenie: jeśli stoper już działa, nic nie robimy
  if (stoperId !== null) {
    return;
  }

  btnStart.disabled = true;
  btnStop.disabled = false;

  stoperId = setInterval(() => {
    sekundy++;
    poleCzas.textContent = "Sekundy: " + sekundy;
  }, 1000);
});

btnStop.addEventListener("click", () => {
  clearInterval(stoperId);
  stoperId = null; // Resetujemy zmienną przechowującą identyfikator

  btnStart.disabled = false;
  btnStop.disabled = true;
});
```

**Po co to jest:**
Sprawdzanie warunku `stoperId !== null` lub blokowanie przycisku właściwością `disabled = true` gwarantuje, że w danym momencie aktywny jest dokładnie jeden egzemplarz interwału.

**Typowa pomyłka:**
Brak wyzerowania zmiennej `stoperId = null` po zatrzymaniu interwału funkcją `clearInterval`. Choć sam interwał zostaje wstrzymany, zmienna nadal zawiera starą liczbę całkowitą, co uniemożliwi ponowne uruchomienie odliczania, jeśli w warunku sprawdzamy obecność wartości różnej od `null`.

---

## 5. Animacje interfejsu napędzane czasem (Progress Bar i ruch)

W połączeniu ze stylami CSS (właściwość `.style` elementu DOM) funkcja `setInterval()` pozwala na realizację płynnych animacji interfejsu. Klasycznym przykładem jest pasek postępu (progress bar), którego szerokość stopniowo wzrasta od 0% do 100%.

```javascript
const pasekPostepu = document.querySelector("#pasek-wskaznik");
const napisProcent = document.querySelector("#pasek-procent");
let szerokoscProcent = 0;

const idAnimacji = setInterval(() => {
  szerokoscProcent += 2;
  pasekPostepu.style.width = szerokoscProcent + "%";
  napisProcent.textContent = szerokoscProcent + "%";

  if (szerokoscProcent >= 100) {
    clearInterval(idAnimacji);
    console.log("Animacja postępu została ukończona.");
  }
}, 50); // Wywołanie co 50 milisekund daje 20 klatek na sekundę
```

Równie częstym zastosowaniem jest przesuwanie elementu w poziomie lub pionie za pomocą manipulacji właściwościami pozycji (`left`, `top`) w połączeniu z pozycjonowaniem relatywnym lub absolutnym w CSS.

```javascript
const obiektRuchomy = document.querySelector("#obiekt-ruchomy");
let pozycjaX = 0;

const idRuchu = setInterval(() => {
  pozycjaX += 5;
  obiektRuchomy.style.left = pozycjaX + "px";

  if (pozycjaX >= 300) {
    clearInterval(idRuchu);
  }
}, 20);
```

**Po co to jest:**
Sterowanie stylami inline z poziomu funkcji czasowej pozwala tworzyć interaktywne symulacje, paski ładowania danych oraz wizualizacje procesów biznesowych bez konieczności sięgania po zewnętrzne silniki animacji.

**Typowa pomyłka:**
Zapomnienie o dopisaniu jednostki miary CSS (np. `+ "%"` lub `+ "px"`). Przeglądarka zignoruje przypisanie wartości liczbowej bez jednostki do właściwości takich jak `width`, `height`, `left` czy `top`, przez co element pozostanie nieruchomy.

---

## 6. Podsumowanie dobrych praktyk z timerami

1. **Zawsze przechowuj timer ID w zmiennej:** Zarówno `setTimeout`, jak i `setInterval` zwracają unikalną wartość liczbową niezbędną do zatrzymania timera.
2. **Pamiętaj o jednostkach:** Drugi parametr obu funkcji to zawsze milisekundy (`1000 ms = 1 s`).
3. **Zarządzaj stanem przycisków:** Blokuj przycisk startujący (`disabled = true`) w trakcie trwania odliczania, aby uniemożliwić nakładanie się interwałów.
4. **Pamiętaj o czyszczeniu:** Każdy `setInterval` powinien posiadać jednoznaczny warunek zakończenia wywołujący `clearInterval` oraz ewentualne zerowanie zmiennej identyfikatora (`timerId = null`).
