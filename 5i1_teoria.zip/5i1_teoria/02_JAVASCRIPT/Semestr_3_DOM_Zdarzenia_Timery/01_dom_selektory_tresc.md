# Document Object Model (DOM): Drzewo dokumentu, selektory i manipulacja treścią

Document Object Model (DOM) to obiektowa reprezentacja dokumentu HTML w pamięci przeglądarki. Po pobraniu pliku HTML silnik przeglądarki przetwarza kod źródłowy i buduje strukturę hierarchicznego drzewa obiektów. Dzięki temu JavaScript zyskuje możliwość odczytywania, modyfikowania, dodawania i usuwania elementów strony w czasie rzeczywistym.

---

## 1. Koncepcja drzewa DOM i obiekt `document`

Głównym punktem wejścia do pracy z dokumentem HTML jest obiekt globalny `document`. Reprezentuje on całą załadowaną stronę internetową.

W drzewie DOM każdy fragment strony jest węzłem (`Node`):
1. **Węzły elementów (`Element`):** odpowiadają znacznikom HTML, np. `<html>`, `<body>`, `<h1>`, `<div>`, `<p>`.
2. **Węzły tekstowe (`Text`):** zawierają tekst umieszczony wewnątrz znaczników HTML.
3. **Węzły komentarzy (`Comment`):** komentarze umieszczone w kodzie HTML.

### Położenie skryptu w dokumencie HTML
Aby JavaScript mógł odnaleźć elementy w drzewie DOM, przeglądarka musi je najpierw sparsować. Z tego powodu pliki skryptów podłączamy tuż przed znacznikiem zamykającym `</body>`:

```html
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Portal Techniczny</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1 id="tytul-glowny">Stanowisko Diagnostyczne</h1>
  <p class="komunikat">System gotowy do pracy.</p>

  <!-- Skrypt umieszczony na końcu body ma dostęp do całego DOM -->
  <script src="script.js"></script>
</body>
</html>
```

> **Po co to jest:** Umieszczenie znacznika `<script>` na końcu znacznika `<body>` gwarantuje, że wszystkie elementy HTML powyżej skryptu zostały już utworzone w pamięci DOM i są dostępne dla metod wyszukiwania.  
> **Typowa pomyłka:** Umieszczenie skryptu w sekcji `<head>` bez atrybutu `defer`. W takim przypadku `document.querySelector()` zwraca wartość `null`, a próba odczytu właściwości kończy się błędem `TypeError: Cannot read properties of null`.

---

## 2. Metody wyszukiwania elementów w DOM

JavaScript dostarcza zestaw standardowych metod do lokalizowania elementów w dokumencie.

### A. `document.getElementById(id)`
Pobiera dokładnie jeden element na podstawie atrybutu `id`. Jest to najszybsza metoda wyszukiwania.

```javascript
const naglowek = document.getElementById("tytul-glowny");
console.log(naglowek); // Wypisuje referencję do węzła HTML
```

> **Po co to jest:** Pozwala błyskawicznie odnaleźć kluczowy, unikalny element interfejsu (np. nagłówek, kontener wynikowy).  
> **Typowa pomyłka:** Wpisywanie znaku `#` w argumencie, np. `document.getElementById("#tytul-glowny")`. Metoda ta przyjmuje samą nazwę identyfikatora bez kratki!

---

### B. `document.querySelector(selektorCSS)`
Uniwersalna metoda wyszukująca **pierwszy** element w dokumencie pasujący do podanego selektora CSS.

```javascript
// Wyszukiwanie po identyfikatorze (wymaga znaku #)
const naglowekId = document.querySelector("#tytul-glowny");

// Wyszukiwanie po klasie (wymaga kropki .)
const pierwszyKomunikat = document.querySelector(".komunikat");

// Wyszukiwanie po nazwie znacznika
const pierwszyAkapit = document.querySelector("p");

// Selektor złożony i relacyjny (potomek)
const waznaInformacja = document.querySelector(".sekcja-statusu .alert-wazny");
```

Jeśli żaden element w dokumencie nie pasuje do selektora, metoda zwraca wartość `null`.

> **Po co to jest:** Zapewnia pełną elastyczność i możliwość korzystania ze wszystkich selektorów znanych z języka CSS (selektory potomków, klas, pseudoklas).  
> **Typowa pomyłka:** Zapomnienie kropki przed nazwą klasy (`querySelector("komunikat")` zamiast `querySelector(".komunikat")`). W takim przypadku przeglądarka szuka nieistniejącego znacznika `<komunikat>`.

---

### C. `document.querySelectorAll(selektorCSS)` i kolekcja `NodeList`
Pobiera **wszystkie** elementy spełniające kryterium selektora CSS i zwraca je w postaci statycznej kolekcji obiektów `NodeList`.

```javascript
const wszystkieAkapity = document.querySelectorAll(".komunikat");

console.log("Liczba elementów:", wszystkieAkapity.length);

// Dostęp przez indeks tablicowy
const pierwszy = wszystkieAkapity[0];

// Iteracja metodą forEach
wszystkieAkapity.forEach((element, indeks) => {
  console.log(`Element ${indeks + 1}:`, element.textContent);
});

// Iteracja klasyczną pętlą for...of
for (const element of wszystkieAkapity) {
  console.log("Treść elementu:", element.textContent);
}
```

> **Po co to jest:** Umożliwia hurtowe przetwarzanie grup elementów interfejsu (wierszy tabeli, pozycji list, kart produktowych).  
> **Typowa pomyłka:** Próba bezpośredniego wywołania właściwości lub metody na całej kolekcji, np. `wszystkieAkapity.textContent = "Tekst"`. Właściwość `textContent` należy do pojedynczego elementu, więc trzeba przeiterować kolekcję w pętli.

---

## 3. Odczyt i modyfikacja zawartości: `textContent`, `innerText`, `innerHTML`

Gdy posiadamy referencję do węzła, możemy manipulować jego wnętrzem za pomocą trzech podstawowych właściwości.

| Właściwość | Typ zwracany | Interpretacja HTML | Uwzględnia style CSS | Zagrożenie XSS |
| :--- | :--- | :--- | :--- | :--- |
| `textContent` | tekst (`string`) | Traktuje jako czysty tekst (kod HTML jest escapowany) | Nie (widzi ukryty tekst) | Całkowicie bezpieczna |
| `innerText` | tekst (`string`) | Traktuje jako czysty tekst | Tak (pomija `display: none`, wymusza reflow) | Bezpieczna |
| `innerHTML` | tekst/HTML (`string`) | Parsuje kod HTML i tworzy węzły potomne | Tak | Wysokie (podatność XSS) |

---

### A. Właściwość `textContent` (Preferowany standard)
Zwraca całą zawartość tekstową węzła i jego potomków lub zastępuje ją nowym ciągiem znaków.

```javascript
const info = document.getElementById("komunikat-statusu");

// Odczyt treści
console.log(info.textContent);

// Zapis nowej treści
info.textContent = "Zgłoszenie serwisowe zostało pomyślnie zrealizowane.";
```

Jeśli do `textContent` przypiszemy ciąg zawierający znaczniki HTML (np. `<b>Ważne</b>`), przeglądarka wyświetli te znaczniki dosłownie jako znaki tekstu, nie tworząc pogrubienia.

> **Po co to jest:** Jest to najszybsza i najbardziej bezpieczna metoda wprowadzania danych tekstowych. Zabezpiecza aplikację przed atakami typu Cross-Site Scripting (XSS).  
> **Typowa pomyłka:** Przypisywanie znaczników formatujących do `textContent` i oczekiwanie, że przeglądarka je ostyluje.

---

### B. Właściwość `innerHTML` (Wstrzykiwanie kodu HTML)
Zwraca zawartość elementu jako ciąg znaków reprezentujący strukturę HTML lub parsuje przekazany ciąg i wstawia nowe węzły potomne.

```javascript
const kontenerWyniku = document.getElementById("wynik");

// Wstrzykiwanie sformatowanego bloku HTML
kontenerWyniku.innerHTML = "<p class='sukces'><strong>Status:</strong> Operacja zakończona sukcesem!</p>";
```

> **Po co to jest:** Pozwala łatwo wstawić złożoną strukturę znaczników (np. pogrubienia, znaczniki `<span>` z klasami, elementy listy `<li>`) za jednym razem.  
> **Typowa pomyłka:** Nadpisywanie całej dotychczasowej zawartości przez operator `=` zamiast dopisywania `+=` (bądź odwrotnie — niekontrolowane dopisywanie wielokrotne), oraz wstrzykiwanie niesprawdzonych danych użytkownika bezpośrednio do `innerHTML`.

---

## 4. Bezpieczeństwo i podatność XSS (Cross-Site Scripting)

Atak typu **Cross-Site Scripting (XSS)** polega na wstrzyknięciu złośliwego kodu (np. znacznika `<script>` lub `<img src="x" onerror="...">`) do struktury strony internetowej.

```javascript
// PRZYKŁAD ZAGROŻENIA:
const zlosliwyTekst = "<img src='brak' onerror='alert("Atak XSS!")'>";

// ZŁE PODEJŚCIE - kod zostanie sparsowany i wykonany:
// document.getElementById("wynik").innerHTML = zlosliwyTekst;

// PRAWIDŁOWE I BEZPIECZNE PODEJŚCIE:
document.getElementById("wynik").textContent = zlosliwyTekst;
// W przeglądarce pojawi się bezpieczny napis, a skrypt nie zostanie uruchomiony!
```

Złota reguła tworzenia bezpiecznych aplikacji internetowych brzmi: **Do wprowadzania czystego tekstu i danych pochodzących od użytkownika zawsze stosuj `textContent`. Używaj `innerHTML` wyłącznie wtedy, gdy świadomie wstawiasz własne, bezpieczne znaczniki formatujące HTML.**

---

## 5. Wyszukiwanie w kontekście elementu (Scoped Query)

Metody `querySelector` oraz `querySelectorAll` można wywoływać nie tylko na obiekcie `document`, ale także na dowolnym pojedynczym węźle elementu. Pozwala to ograniczyć przeszukiwanie do wybranego fragmentu strony.

```javascript
const kartaKonta = document.querySelector("#karta-klienta");

// Wyszukujemy nagłówek wyłącznie wewnątrz karty klienta
const naglowekKarty = kartaKonta.querySelector(".naglowek");
naglowekKarty.textContent = "Profil Administratora";
```

> **Po co to jest:** Umożliwia precyzyjną pracę z modularnymi komponentami (np. kartami w panelu administracyjnym) bez ryzyka omyłkowej modyfikacji elementów o takich samych klasach znajdujących się w innych sekcjach.  
> **Typowa pomyłka:** Próba wywołania `kartaKonta.getElementById()` — metoda `getElementById` istnieje wyłącznie na obiekcie `document`, nie na pojedynczych elementach!
