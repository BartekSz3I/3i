# Teoria: Zdarzenia w przeglądarce i addEventListener

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Wprowadzenie: Programowanie sterowane zdarzeniami

Tradycyjne programowanie imperatywne polega na wykonywaniu instrukcji od góry do dołu pliku źródłowego. W przeglądarce internetowej interfejs użytkownika działa jednak w modelu **sterowanym zdarzeniami (event-driven architecture)**. Po wyrenderowaniu strony silnik JavaScript przechodzi w stan oczekiwania, reagując na sygnały wysyłane przez użytkownika: kliknięcie myszą, naciśnięcie klawisza, wprowadzenie tekstu czy przesłanie formularza.

## 2. Od `onclick` w HTML do `addEventListener`

Historycznie w aplikacjach webowych stosowano atrybuty inline w kodzie HTML lub bezpośrednie przypisania do właściwości obiektu DOM:

```html
<!-- Zapis przestarzały (inline HTML) - odradzany w nowoczesnym kodzie -->
<button onclick="obliczCene()">Oblicz</button>
```

```javascript
// Bezpośrednie przypisanie właściwości w JavaScript
const przycisk = document.querySelector("#btn-oblicz");
przycisk.onclick = function() {
  console.log("Kliknięto przycisk");
};
```

Takie podejście ma fundamentalną wadę: do jednej właściwości `onclick` można przypisać tylko jedną funkcję obsługi. Każde kolejne przypisanie nadpisuje poprzednie.

Standard DOM Level 2 wprowadził metodę `addEventListener()`, która umożliwia:
1. Rejestrowanie wielu niezależnych funkcji obsługi dla tego samego zdarzenia na jednym elemencie.
2. Całkowite odseparowanie warstwy prezentacji (HTML) od logiki działania (JavaScript).
3. Precyzyjne sterowanie cyklem propagacji zdarzenia oraz jego usuwanie (`removeEventListener`).

```javascript
const przycisk = document.querySelector("#btn-oblicz");

function rejestrujLog() {
  console.log("Zarejestrowano interakcję użytkownika.");
}

function wyswietlKomunikat() {
  const wynik = document.querySelector("#wynik");
  wynik.textContent = "Obliczenia zostały rozpoczęte.";
}

przycisk.addEventListener("click", rejestrujLog);
przycisk.addEventListener("click", wyswietlKomunikat);
```

**Po co to jest:**  
Metoda `addEventListener()` pozwala budować modularny kod, w którym różne moduły aplikacji mogą nasłuchiwać tej samej akcji użytkownika bez ryzyka nadpisania logiki przygotowanej przez inny fragment programu.

**Typowa pomyłka:**  
Dopisanie nawiasów wywołania `()` przy nazwie funkcji przekazywanej do `addEventListener`:  
`przycisk.addEventListener("click", obliczCene());` // BŁĄD!  
Taki zapis wywołuje funkcję natychmiast podczas ładowania skryptu i przekazuje do nasłuchiwacza wynik jej działania (`undefined`), zamiast samej referencji do funkcji. Prawidłowy zapis to `przycisk.addEventListener("click", obliczCene);`.

## 3. Anatomia metody `addEventListener`

Składnia metody wygląda następująco:

```javascript
element.addEventListener(typZdarzenia, funkcjaZwrotna, opcje);
```

Parametry:
- `typZdarzenia` (ciąg znaków, np. `"click"`, `"input"`, `"submit"`): nazwa zdarzenia bez przedrostka `on`.
- `funkcjaZwrotna` (ang. *callback*): funkcja wywoływana przez silnik przeglądarki w momencie wystąpienia zdarzenia. Może to być funkcja nazwana, wyrażenie funkcyjne lub funkcja strzałkowa.
- `opcje` (opcjonalny obiekt lub wartość logiczna): parametry konfiguracyjne (np. faza przechwytywania, jednorazowe wykonanie `{ once: true }`).

Przykład z funkcją strzałkową oraz tradycyjną funkcją anonimową:

```javascript
const przyciskZapisz = document.querySelector("#btn-zapisz");

// Zapis z funkcją strzałkową (krótki, nowoczesny)
przyciskZapisz.addEventListener("click", () => {
  document.querySelector("#komunikat-status").textContent = "Zapisano dane.";
});

// Zapis z funkcją anonimową function (równoważny)
przyciskZapisz.addEventListener("click", function() {
  document.querySelector("#komunikat-status").textContent = "Zapisano dane.";
});
```

**Po co to jest:**  
Funkcje anonimowe i strzałkowe przekazywane inline przyspieszają pisanie zwięzłych procedur obsługi interfejsu, gdy dana funkcja nie musi być wywoływana w żadnym innym miejscu skryptu.

**Typowa pomyłka:**  
Używanie słowa kluczowego `this` w funkcji strzałkowej w oczekiwaniu, że wskaże ono kliknięty element DOM. Funkcja strzałkowa nie tworzy własnego wiązania `this` (przejmuje kontekst leksykalny). Do wskazywania elementu należy używać obiektu zdarzenia `event.currentTarget` lub tradycyjnej funkcji `function`.

## 4. Obiekt zdarzenia (`Event`) i jego właściwości

Gdy następuje zdarzenie, przeglądarka tworzy specjalny obiekt reprezentujący to zdarzenie i przekazuje go jako pierwszy argument do funkcji zwrotnej. Tradycyjnie nazywamy ten parametr `e` lub `event`.

```javascript
const poleTekstowe = document.querySelector("#imie");

poleTekstowe.addEventListener("input", (event) => {
  console.log("Typ zdarzenia:", event.type);
  console.log("Element wyzwalający:", event.target);
  console.log("Bieżąca wartość pola:", event.target.value);
});
```

Kluczowe właściwości obiektu `Event`:
- `event.target`: element DOM, na którym bezpośrednio zainicjowano zdarzenie (np. kliknięty znacznik).
- `event.currentTarget`: element DOM, do którego aktualnie przypisany jest nasłuchiwacz (`addEventListener`).
- `event.type`: nazwa wywołanego zdarzenia (np. `"click"`).
- `event.timeStamp`: czas w milisekundach od momentu załadowania dokumentu, w którym wystąpiło zdarzenie.

**Po co to jest:**  
Obiekt zdarzenia dostarcza pełny kontekst akcji użytkownika: współrzędne kursora, wciśnięty klawisz, stan klawiszy funkcyjnych (Shift, Ctrl, Alt) czy dostęp do danych wprowadzonych do kontrolki formularza.

**Typowa pomyłka:**  
Mylenie `event.target` z `event.currentTarget`. W przypadku zagnieżdżonych struktur (np. ikona wewnątrz przycisku `<button><span>OK</span></button>`) kliknięcie w ikonę sprawi, że `event.target` wskaże na `<span>`, a `event.currentTarget` na `<button>`.

## 5. Blokowanie domyślnej akcji: `event.preventDefault()`

Niektóre elementy HTML posiadają wbudowane domyślne akcje przeglądarki:
- Formularz `<form>` po naciśnięciu przycisku wysłania odświeża stronę i wysyła zapytanie HTTP GET/POST.
- Odsyłacz `<a href="...">` powoduje przejście pod wskazany adres URL.
- Pole wyboru `<input type="checkbox">` zmienia stan zaznaczenia.

Metoda `event.preventDefault()` powstrzymuje domyślną reakcję przeglądarki, pozwalając na obsłużenie akcji w całości przez kod JavaScript.

```javascript
const formularz = document.querySelector("#form-zamowienie");

formularz.addEventListener("submit", (event) => {
  // Blokujemy domyślne przeładowanie całej strony
  event.preventDefault();

  const ilosc = Number(document.querySelector("#ilosc").value);
  const wynik = document.querySelector("#wynik");

  if (ilosc <= 0) {
    wynik.textContent = "Podaj prawidłową liczbę produktów większą od 0.";
    return;
  }

  wynik.textContent = "Zamówienie przyjęte do realizacji.";
});
```

**Po co to jest:**  
`event.preventDefault()` jest fundamentem aplikacji typu Single Page Application (SPA) oraz formularzy sprawdzanych po stronie klienta – zapobiega niekontrolowanemu resetowaniu stanu strony.

**Typowa pomyłka:**  
Próba wywołania `event.preventDefault()` bez zadeklarowania parametru `event` w sygnaturze funkcji:  
`formularz.addEventListener("submit", () => { preventDefault(); });` // BŁĄD! `preventDefault` nie jest zmienną globalną.

## 6. Przegląd najpopularniejszych zdarzeń w egzaminie INF.03

### A. Zdarzenia myszy (MouseEvent)
- `"click"` – kliknięcie lewym przyciskiem myszy (wciśnięcie i puszczenie).
- `"dblclick"` – dwukrotne szybkie kliknięcie.
- `"mouseenter"` – kursor myszy wchodzi na obszar elementu (nie bąbelkuje).
- `"mouseleave"` – kursor myszy opuszcza obszar elementu.

```javascript
const blok = document.querySelector("#panel-pomoc");

blok.addEventListener("mouseenter", () => {
  blok.classList.add("aktywny");
});

blok.addEventListener("mouseleave", () => {
  blok.classList.remove("aktywny");
});
```

### B. Zdarzenia formularzy
- `"input"` – natychmiastowa zmiana wartości pola tekstowego lub suwaka (podczas wpisywania każdego kolejnego znaku).
- `"change"` – zmiana wartości zatwierdzona przez użytkownika (dla pól tekstowych po opuszczeniu pola `blur`, dla list `<select>` i pól wyboru natychmiast po zmianie wyboru).
- `"submit"` – próba wysłania formularza (kliknięcie przycisku submit lub wciśnięcie Enter w polu tekstowym).
- `"reset"` – przywrócenie formularza do stanu początkowego.

```javascript
const poleUslugi = document.querySelector("#usluga");
const podsumowanie = document.querySelector("#podsumowanie");

poleUslugi.addEventListener("change", (e) => {
  podsumowanie.textContent = "Wybrano usługę: " + e.target.value;
});
```

### C. Zdarzenia klawiatury (KeyboardEvent)
- `"keydown"` – wciśnięcie dowolnego klawisza na klawiaturze (reaguje również na klawisze funkcyjne, strzałki, Escape).
- `"keyup"` – puszczenie klawisza.

Właściwości obiektu klawiatury:
- `event.key` – reprezentacja znakowa klawisza (np. `"Enter"`, `"a"`, `"Escape"`, `"ArrowUp"`).
- `event.code` – fizyczny kod klawisza na klawiaturze (np. `"KeyA"`, `"Space"`, `"Digit1"`).

```javascript
const poleWyszukiwania = document.querySelector("#szukaj");

poleWyszukiwania.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    console.log("Zatwierdzono frazę wyszukiwania:", e.target.value);
  }
});
```

**Po co to jest:**  
Zdarzenia klawiatury umożliwiają implementację skrótów klawiszowych, nawigacji dostępnej (a11y) oraz natychmiastowej reakcji na akcje użytkownika bez konieczności sięgania po mysz.

**Typowa pomyłka:**  
Korzystanie z przestarzałej właściwości `event.keyCode` (zwracającej kody liczbowe, np. `13` dla Enter). Nowoczesny standard wymaga używania czytelnej właściwości tekstowej `event.key`.

## 7. Obsługa wielu elementów za pomocą `querySelectorAll` i pętli `forEach`

Gdy na stronie znajduje się grupa jednakowych elementów (np. lista przycisków w menu lub kafelków w galerii), metoda `querySelector` pobiera tylko pierwszy z nich. Aby przypisać zdarzenie do każdego elementu z osobna, pobieramy listę węzłów (`NodeList`) i iterujemy po niej za pomocą `forEach`:

```javascript
const przyciski = document.querySelectorAll(".btn-opcja");

przyciski.forEach((przycisk) => {
  przycisk.addEventListener("click", (e) => {
    // Usuwamy klasę aktywny ze wszystkich przycisków
    przyciski.forEach((btn) => btn.classList.remove("aktywny"));
    
    // Dodajemy klasę aktywny do klikniętego przycisku
    e.currentTarget.classList.add("aktywny");
  });
});
```

**Po co to jest:**  
Pozwala to ożywić powtarzalne komponenty interfejsu (karty, zakładki, filtry, miniatury) bez powielania kodu dla każdego elementu z osobnym identyfikatorem.

**Typowa pomyłka:**  
Próba wywołania `addEventListener` bezpośrednio na wyniku `querySelectorAll`:  
`document.querySelectorAll(".btn-opcja").addEventListener("click", ...);` // BŁĄD! `NodeList` nie posiada metody `addEventListener` – trzeba przejść pętlą po każdym elemencie.

## 8. Wypis na stronę w Semestrze 3

W trzecim semestrze całkowicie rezygnujemy z wypisu konsolowego jako jedynego kanału komunikacji z użytkownikiem oraz z przestarzałego `document.write()`. Wszystkie rezultaty, komunikaty o błędach i podsumowania obliczeń trafiają bezpośrednio do struktury DOM strony za pomocą właściwości `textContent` lub `innerHTML` na wyselekcjonowanych węzłach kontenerów (np. `#wynik`, `#podsumowanie`, `#komunikat-walidacji`).
