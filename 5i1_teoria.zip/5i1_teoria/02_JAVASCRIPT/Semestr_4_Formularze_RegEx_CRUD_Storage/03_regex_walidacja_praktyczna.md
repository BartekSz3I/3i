# Teoria: Wyrażenia regularne (RegEx) i praktyczna walidacja w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Czym jest wyrażenie regularne (RegExp)?

Wyrażenie regularne (ang. *regular expression*, w skrócie **RegEx** lub **RegExp**) to specjalny wzorzec tekstowy, który służy do wyszukiwania, dopasowywania i weryfikowania ciągów znaków. W tworzeniu aplikacji internetowych jest to podstawowe narzędzie służące do sprawdzania, czy dane wpisane przez użytkownika w formularzu spełniają wymagany format (np. czy kod pocztowy ma dokładnie postać dwóch cyfr, myślnika i trzech cyfr).

Bez wyrażeń regularnych weryfikacja poprawności formatu wymagałaby pisania wielopoziomowych pętli badających kody ASCII każdego pojedynczego znaku oraz licznych instrukcji warunkowych `if`. RegEx pozwala zamknąć tę regułę w jednym, czytelnym i uniwersalnym wzorcu.

W języku JavaScript wyrażenie regularne jest pełnoprawnym obiektem wbudowanym typu `RegExp`.

---

## 2. Tworzenie wyrażeń regularnych w JavaScript

W JavaScript wyrażenie regularne można utworzyć na dwa sposoby: za pomocą literału lub konstruktora `RegExp`.

### 2.1. Literał wyrażenia regularnego (rekomendowany)

Literał zapisujemy pomiędzy dwoma ukośnikami `/wzorzec/flagi`:

```javascript
const wzorzecKodu = /^[0-9]{2}-[0-9]{3}$/;
```

**Po co to jest:**
Literał jest kompilowany w momencie przetwarzania skryptu. Jest to najbardziej czytelna, najszybsza i preferowana forma zapisu wzorców stałych, których struktura jest znana z góry podczas pisania programu.

**Typowa pomyłka:**
Umieszczanie wzorca w cudzysłowach, np. `const w = "/[0-9]/";`. Taki zapis tworzy zwykły łańcuch znaków (`string`), a nie obiekt `RegExp`. Na obiekcie `string` wywołanie metody `.test()` zakończy się błędem wykonania `TypeError: w.test is not a function`.

### 2.2. Konstruktor `new RegExp()`

Konstruktor przyjmuje wzorzec w postaci łańcucha znaków oraz opcjonalne flagi jako drugi argument:

```javascript
const wzorzecKodu = new RegExp("^[0-9]{2}-[0-9]{3}$");
```

**Po co to jest:**
Konstruktor jest niezbędny wyłącznie wtedy, gdy wzorzec jest budowany dynamicznie w trakcie działania programu (np. na podstawie zmiennej pochodzącej z innego źródła).

**Typowa pomyłka:**
Pominięcie podwójnego znaku ucieczki (ang. *escape*) w łańcuchu tekstowym. W literale piszemy `/\d/`, natomiast w konstruktorze `new RegExp("\\d")`, ponieważ pierwszy ukośnik jest znakiem ucieczki samego łańcucha tekstowego JavaScript.

---

## 3. Elementy składowe wzorca: kotwice, klasy i kwantyfikatory

### 3.1. Kotwice początku i końca (`^` oraz `$`)

Kotwice nie reprezentują żadnego znaku, lecz pozycję w badanym tekście:
- `^` — oznacza początek badanego łańcucha tekstu.
- `$` — oznacza koniec badanego łańcucha tekstu.

```javascript
const tylkoCyfry = /^\d+$/;
console.log(tylkoCyfry.test("12345")); // true
console.log(tylkoCyfry.test("abc 12345 xyz")); // false
```

**Po co to jest:**
Kotwice wymuszają, aby badany wzorzec pasował do **całego** łańcucha znaków, a nie tylko do jego dowolnego fragmentu. W walidacji formularzy niemal każdy wzorzec musi zaczynać się od `^` i kończyć na `$`.

**Typowa pomyłka:**
Pominięcie kotwic `^` i `$`. Wzorzec `/\d{2}-\d{3}/` bez kotwic zwróci `true` dla niepoprawnego tekstu `"kod: 00-950 Warszawa"`, ponieważ dopasuje 5 znaków w środku łańcucha. Z kotwicami `/^\d{2}-\d{3}$/` sprawdzana jest ścisła zgodność od pierwszego do ostatniego znaku.

### 3.2. Klasy znaków i zakresy

Klasy znaków określają, jakie znaki mogą wystąpić na danej pozycji:
- `[0-9]` lub `\d` — dowolna cyfra od 0 do 9.
- `\D` — dowolny znak niebędący cyfrą.
- `[a-z]` — dowolna mała litera alfabetu łacińskiego.
- `[A-Z]` — dowolna wielka litera alfabetu łacińskiego.
- `[a-zA-Z]` — dowolna litera bez polskich znaków diakrytycznych.
- `[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]` — litery wraz z polskimi znakami diakrytycznymi.
- `\w` — znak alfanumeryczny (`[a-zA-Z0-9_]`).
- `\W` — znak niebędący znakiem alfanumerycznym.
- `\s` — dowolny biały znak (spacja, tabulacja, znak nowej linii).
- `\S` — dowolny znak niebędący białym znakiem.
- `.` — dowolny pojedynczy znak (oprócz znaku nowej linii).

```javascript
const literyICyfry = /^[a-zA-Z0-9]+$/;
```

**Po co to jest:**
Klasy znaków pozwalają ograniczyć dozwolony zestaw znaków wyłącznie do znaków pożądanych w danym polu biznesowym, zapobiegając wstrzykiwaniu niedozwolonych symboli.

**Typowa pomyłka:**
Zapominanie o polskich znakach narodowych w klasach typu `[a-z]`. Wpisanie nazwiska "Zażółć" we wzorzec `/^[a-zA-Z]+$/` spowoduje odrzucenie danych jako błędne.

### 3.3. Znaki specjalne i znak ucieczki (ang. *escaping*)

Niektóre znaki mają w składni RegEx specjalne znaczenie techniczne: `^`, `$`, `.`, `*`, `+`, `?`, `(`, `)`, `[`, `]`, `{`, `}`, `|`, `\`, `/`. Jeśli chcemy potraktować je dosłownie (np. sprawdzić obecność kropki lub ukośnika), musimy poprzedzić je ukośnikiem odwróconym `\`:

```javascript
// Sprawdzenie adresu ze znakiem kropki i małpy
const wzorzecDomena = /\.[a-z]{2,4}$/;
```

**Po co to jest:**
Znak `.` bez ucieczki oznacza "dowolny znak". Dopiero `\.` oznacza dosłowny znak kropki.

**Typowa pomyłka:**
Zapis `/^[a-z]+\.[a-z]+$/` bez ukośnika przed kropką: `/^[a-z]+.[a-z]+$/`. Wtedy ciąg `"janXkowalski"` zostanie uznany za poprawny, bo kropka dopasowała dowolny znak `"X"`.

### 3.4. Kwantyfikatory (liczba powtórzeń)

Kwantyfikator określa, ile razy poprzedzający go element może lub musi wystąpić:
- `{n}` — dokładnie `n` razy (np. `\d{9}` oznacza dokładnie 9 cyfr).
- `{min,max}` — od `min` do `max` razy włącznie (np. `[a-z]{2,30}` oznacza od 2 do 30 liter).
- `{min,}` — co najmniej `min` razy.
- `+` — co najmniej 1 raz (odpowiednik `{1,}`).
- `*` — 0 lub więcej razy (odpowiednik `{0,}`).
- `?` — 0 lub 1 raz (element opcjonalny, odpowiednik `{0,1}`).

```javascript
// Kod pocztowy: dokładnie 2 cyfry, myślnik, dokładnie 3 cyfry
const wzorzecKod = /^\d{2}-\d{3}$/;

// Numer telefonu z opcjonalnym prefiksem kraju +48
const wzorzecTel = /^(\+48\s?)?\d{9}$/;
```

**Po co to jest:**
Kwantyfikatory określają wymaganą długość wpisu oraz dopuszczają elementy opcjonalne bez konieczności powielania całego wzorca.

**Typowa pomyłka:**
Wstawianie spacji wewnątrz nawiasów klamrowych kwantyfikatora, np. `{\d{2, 5}}`. W JavaScript spacja wewnątrz `{2, 5}` sprawia, że wyrażenie traktuje to dosłownie lub ulega uszkodzeniu składniowemu. Należy zawsze pisać `{2,5}` bez spacji.

---

## 4. Metody w JavaScript: `.test()` oraz `.match()`

### 4.1. Metoda `RegExp.prototype.test()`

Metoda wywoływana na obiekcie wyrażenia regularnego, przyjmująca jako argument badany łańcuch tekstowy:

```javascript
const wzorzec = /^\d{3}$/;
const czyPoprawne = wzorzec.test("123"); // zwraca true
const czyBledne = wzorzec.test("abc");   // zwraca false
```

**Po co to jest:**
Metoda `.test()` jest najszybszym i najbardziej bezpośrednim narzędziem do walidacji w instrukcjach warunkowych `if`. Zwraca wartość logiczną `boolean` (`true` lub `false`).

**Typowa pomyłka:**
Mylenie kolejności wywołania obiektu i argumentu. Prawidłowo: `wzorzec.test(tekst)`. Błędnie: `tekst.test(wzorzec)` — łańcuch znaków nie posiada metody `.test()`.

### 4.2. Metoda `String.prototype.match()`

Metoda wywoływana na łańcuchu znaków, przyjmująca jako argument wyrażenie regularne:

```javascript
const tekst = "Kontakt: 123456789 oraz 987654321";
const dopasowania = tekst.match(/\d{9}/g);
console.log(dopasowania); // ["123456789", "987654321"]
```

Gdy flaga globalna `g` nie jest użyta, `.match()` zwraca tablicę z pierwszym znalezionym dopasowaniem i grupami przechwytującymi, lub `null` w przypadku braku dopasowania.

**Po co to jest:**
Metoda `.match()` służy do wyciągania dopasowanych fragmentów tekstu, a nie tylko do prostego sprawdzenia logicznego.

**Typowa pomyłka:**
Próba bezpośredniego traktowania wyniku `tekst.match(wzorzec)` jako wartości `boolean` w skomplikowanych warunkach bez uwzględnienia, że brak dopasowania zwraca `null`. W samej walidacji formularzy należy preferować jednoznaczną metodę `.test()`.

---

## 5. Praktyczne wzorce w formularzach webowych

### 5.1. Kod pocztowy w formacie polskim
```javascript
const regexKodPocztowy = /^[0-9]{2}-[0-9]{3}$/;
```
Wzorzec wymaga dokładnie dwóch cyfr, dosłownego myślnika i dokładnie trzech cyfr.

### 5.2. Numer telefonu
```javascript
// Wariant podstawowy: dokładnie 9 cyfr
const regexTelefonProsty = /^[0-9]{9}$/;

// Wariant ze spacjami lub myślnikami: np. 123 456 789 lub 123-456-789
const regexTelefonFormat = /^[0-9]{3}[-\s]?[0-9]{3}[-\s]?[0-9]{3}$/;
```

### 5.3. Numer PESEL
```javascript
const regexPesel = /^[0-9]{11}$/;
```
Numer PESEL składa się ściśle z jedenastu cyfr. W zaawansowanej logice biznesowej weryfikuje się również sumę kontrolną algorytmem wagowym.

### 5.4. Adres e-mail
```javascript
const regexEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
```
Wzorzec weryfikuje część lokalną przed znakiem `@`, nazwę domeny oraz domenę najwyższego poziomu (TLD) o długości minimum 2 znaków.

### 5.5. Złożoność hasła
Zamiast budować jeden gigantyczny i nieczytelny wzorzec, w praktyce biznesowej stosuje się zestaw prostych, przejrzystych reguł sprawdzanych po kolei:
```javascript
function sprawdzHaslo(haslo) {
    const maDlugosc = haslo.length >= 8;
    const maWielkaLitere = /[A-Z]/.test(haslo);
    const maMalaLitere = /[a-z]/.test(haslo);
    const maCyfre = /[0-9]/.test(haslo);
    const maZnakSpecjalny = /[!@#$%^&*]/.test(haslo);

    return maDlugosc && maWielkaLitere && maMalaLitere && maCyfre && maZnakSpecjalny;
}
```

---

## 6. Integracja walidacji z formularzem i obiektem zdarzenia

### 6.1. Przechwytywanie wysyłki formularza i `preventDefault()`

Gdy użytkownik klika przycisk typu `submit` w formularzu, domyślnym zachowaniem przeglądarki jest wysłanie żądania HTTP i przeładowanie całej strony. W aplikacjach frontendowych to skrypt JavaScript decyduje, czy dane są poprawne.

```javascript
const formularz = document.querySelector("#formularz-rejestracji");

formularz.addEventListener("submit", function (event) {
    // 1. Zablokowanie domyślnego przeładowania strony
    event.preventDefault();

    // 2. Pobranie pól i walidacja
    const poleEmail = document.querySelector("#email");
    const regexEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!regexEmail.test(poleEmail.value.trim())) {
        poleEmail.classList.add("blad-walidacji");
        poleEmail.classList.remove("sukces-walidacji");
        document.querySelector("#komunikat-email").textContent = "Podaj poprawny adres e-mail.";
    } else {
        poleEmail.classList.remove("blad-walidacji");
        poleEmail.classList.add("sukces-walidacji");
        document.querySelector("#komunikat-email").textContent = "";
    }
});
```

**Po co to jest:**
Instrukcja `event.preventDefault()` zapobiega utracie wpisanych danych i pozwala na ich pełną weryfikację w JavaScript przed podjęciem dalszych kroków.

**Typowa pomyłka:**
Przypisanie zdarzenia `click` do przycisku typu `submit` zamiast zdarzenia `submit` do całego elementu `<form>`. Formularz można wysłać również klawiszem Enter w dowolnym polu tekstowym — zdarzenie `submit` na formularzu przechwytuje każdą formę wysłania, podczas gdy `click` na przycisku pominie wciśnięcie klawisza Enter.

### 6.2. Walidacja w czasie rzeczywistym (`input` i `blur`)

Dla zapewnienia doskonałego doświadczenia użytkownika (UX), weryfikację formatu warto uruchamiać natychmiast:
- Zdarzenie `input` — wyzwalane przy każdym wpisaniu, usunięciu lub wklejeniu znaku.
- Zdarzenie `blur` — wyzwalane w momencie, gdy użytkownik opuszcza dane pole (traci ono fokus).

```javascript
const poleKod = document.querySelector("#kod-pocztowy");
const regexKod = /^\d{2}-\d{3}$/;

poleKod.addEventListener("input", function () {
    const wartosc = poleKod.value.trim();
    if (regexKod.test(wartosc)) {
        poleKod.classList.remove("blad-walidacji");
        poleKod.classList.add("sukces-walidacji");
    } else {
        poleKod.classList.add("blad-walidacji");
        poleKod.classList.remove("sukces-walidacji");
    }
});
```

---

## 7. Informacja zwrotna i dostępność cyfrowa (a11y)

Profesjonalna walidacja nie polega wyłącznie na zmianie koloru ramki na czerwony. Kolor nie może być jedynym nośnikiem informacji (zasada WCAG).

Zasady dobrej praktyki:
1. Każde pole musi mieć przypisany jednoznaczny tekstowy element błędu (np. `<span id="komunikat-kod" class="komunikat-bledu"></span>`).
2. Pole formularza powinno być powiązane ze swoją etykietą przez parę atrybutów `<label for="kod-pocztowy">` oraz `<input id="kod-pocztowy">`.
3. Komunikaty o błędach powinny precyzyjnie wyjaśniać oczekiwany format (np. "Wymagany format: 00-000"), a nie ograniczać się do słowa "Błąd".
