# Teoria: Wyrażenia regularne w JavaScript — składnia i podstawy walidacji

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Czym jest wyrażenie regularne (RegExp)?

Wyrażenie regularne (ang. *regular expression*, w skrócie **RegEx** lub **RegExp**) to formalny wzorzec opisujący strukturę ciągu znaków. W tworzeniu aplikacji internetowych wyrażenia regularne stanowią podstawowe narzędzie do weryfikacji poprawności danych wprowadzanych przez użytkownika w polach formularzy HTML (np. numerów telefonów, kodów pocztowych, identyfikatorów zamówień czy loginów).

Zamiast pisać wielopoziomowe pętle sprawdzające każdy znak z osobna, programista definiuje regułę w zwięzłej formie wzorca i przekazuje ją silnikowi JavaScript do ewaluacji.

---

## 2. Tworzenie wyrażeń regularnych w JavaScript

W języku JavaScript obiekt wyrażenia regularnego można utworzyć na dwa sposoby: za pomocą **literału** lub za pomocą **konstruktora** `RegExp`.

```javascript
// Sposób 1: Literał wyrażenia regularnego (zalecany w większości zastosowań)
const wzorKod = /^\d{2}-\d{3}$/;

// Sposób 2: Konstruktor obiektu RegExp (używany przy dynamicznym składaniu wzorca)
const wzorKodDynamiczny = new RegExp('^\\d{2}-\\d{3}$');
```

**Po co to jest:**  
Literał wyrażenia regularnego (`/.../`) jest kompilowany podczas parsowania skryptu, dzięki czemu działa szybciej i nie wymaga wielokrotnego uciekania ukośników. Konstruktor `new RegExp()` jest wykorzystywany wtedy, gdy wzorzec jest budowany dynamicznie na podstawie zmiennej tekstowej w trakcie działania programu.

**Typowa pomyłka:**  
Zapomnienie o podwójnym ukośniku odwrotnym (`\\`) w łańcuchu przekazywanym do konstruktora `new RegExp('^\\d{2}-\\d{3}$')`. W zwykłym tekście pojedynczy `\` jest interpretowany jako znak ucieczki łańcucha znaków, co prowadzi do błędnego wzorca.

---

## 3. Sprawdzanie dopasowania — metoda `test()`

Podstawową metodą obiektu wyrażenia regularnego służącą do walidacji danych jest metoda `test()`. Przyjmuje ona sprawdzany łańcuch tekstowy i zwraca wartość logiczną `true` (gdy tekst spełnia wzorzec) lub `false` (gdy tekst nie pasuje).

```javascript
const wzorTelefon = /^\d{9}$/;
const wpisanyNumer = '501234567';

if (wzorTelefon.test(wpisanyNumer)) {
    console.log('Numer telefonu jest poprawny');
} else {
    console.log('Niepoprawny format numeru');
}
```

**Po co to jest:**  
Metoda `test()` pozwala w warunku instrukcji `if` błyskawicznie podjąć decyzję, czy formularz może zostać zatwierdzony, czy należy wyświetlić użytkownikowi komunikat o błędzie.

**Typowa pomyłka:**  
Mylenie kolejności wywołania: próba wywołania `tekst.test(regex)` zamiast `regex.test(tekst)`. Metoda `test()` należy do obiektu wyrażenia regularnego, a nie do obiektu `String`.

---

## 4. Kotwice: początek (`^`) i koniec (`$`) łańcucha znaków

Domyślnie wyrażenie regularne szuka dopasowania w **dowolnym fragmencie** tekstu. Aby upewnić się, że cała zawartość pola formularza odpowiada wzorcowi, stosuje się kotwice:
- `^` — oznacza początek badanego tekstu,
- `$` — oznacza koniec badanego tekstu.

```javascript
// Bez kotwic - sprawdza, czy w tekście GDZIEKOLWIEK występuje 5 cyfr
const wzorBezKotwic = /\d{5}/;
console.log(wzorBezKotwic.test('abc12345xyz')); // true (błąd logiczny walidacji!)

// Z kotwicami - tekst musi składać się DOKŁADNIE i WYŁĄCZNIE z 5 cyfr
const wzorZKotwicami = /^\d{5}$/;
console.log(wzorZKotwicami.test('abc12345xyz')); // false
console.log(wzorZKotwicami.test('12345'));      // true
```

**Po co to jest:**  
Kotwice wymuszają walidację całego ciągu znaków od pierwszego do ostatniego znaku, uniemożliwiając wstrzyknięcie niepożądanych liter lub spacji przed i po oczekiwanym formacie.

**Typowa pomyłka:**  
Pominięcie kotwicy `^` lub `$` przy walidacji formularzy. Bez nich wzorzec `/^\d{2}-\d{3}/` zaakceptuje ciąg `00-123Warszawa`, ponieważ początek pasuje do wzorca.

---

## 5. Predefiniowane klasy znaków

Wzorzec może zawierać skrótowe oznaczenia najczęściej używanych grup znaków:

| Klasa znaków | Znaczenie | Odpowiednik w nawiasach kwadratowych |
|:---:|---|---|
| `\d` | Dowolna cyfra dziesiętna (od 0 do 9) | `[0-9]` |
| `\D` | Dowolny znak, który NIE jest cyfrą | `[^0-9]` |
| `\w` | Znak słowa: litera (angielska), cyfra lub znak podkreślenia `_` | `[a-zA-Z0-9_]` |
| `\W` | Dowolny znak, który NIE jest znakiem słowa | `[^a-zA-Z0-9_]` |
| `\s` | Dowolny biały znak (spacja, tabulacja, znak nowej linii) | `[ \t\r\n\f]` |
| `\S` | Dowolny znak, który NIE jest białym znakiem | `[^ \t\r\n\f]` |
| `.` | Dowolny pojedynczy znak (poza znakiem nowej linii) | — |

```javascript
// Przykład: trzycyfrowy kod, myślnik, dwie litery/cyfry
const wzorIdentyfikatora = /^\d{3}-\w{2}$/;

console.log(wzorIdentyfikatora.test('123-AB')); // true
console.log(wzorIdentyfikatora.test('123-A_')); // true
console.log(wzorIdentyfikatora.test('12A-AB')); // false
```

**Po co to jest:**  
Klasy skrótowe znacznie upraszczają zapis wzorców i zwiększają ich czytelność, zastępując długie wyliczenia znaków.

**Typowa pomyłka:**  
Mylenie małych i wielkich liter: użycie `\d` (cyfra) zamiast `\D` (nie-cyfra) lub odwrotnie. Wielka litera zawsze oznacza zaprzeczenie danej klasy.

---

## 6. Własne klasy znaków i zakresy: `[...]` oraz `[^...]`

Nawiasy kwadratowe definiują zestaw znaków, z którego **dokładnie jeden** znak musi pojawić się w danym miejscu.

- `[abc]` — dopasowuje wyłącznie literę `a`, `b` lub `c`.
- `[a-z]` — dopasowuje dowolną małą literę z alfabetu łacińskiego.
- `[A-Z]` — dopasowuje dowolną wielką literę z alfabetu łacińskiego.
- `[0-9]` — dopasowuje dowolną cyfrę.
- `[A-Za-z0-9]` — dopasowuje dowolną literę lub cyfrę.
- `[^0-9]` — znak daszka `^` na samym początku nawiasu kwadratowego oznacza **negację**: dowolny znak oprócz cyfry.

```javascript
// Przykład: kod działu zaczynający się od litery A, B lub C, po której następuje cyfra
const wzorDzial = /^[ABC][1-9]$/;

console.log(wzorDzial.test('A1')); // true
console.log(wzorDzial.test('D1')); // false
console.log(wzorDzial.test('A0')); // false
```

**Po co to jest:**  
Własne klasy pozwalają precyzyjnie ograniczyć dozwolone znaki, np. wykluczyć cyfrę zero na początku numeru albo ograniczyć wprowadzany identyfikator do konkretnych symboli.

**Typowa pomyłka:**  
Mylenie funkcji znaku `^`. Na początku całego wyrażenia regularnego (`/^.../`) oznacza kotwicę początku tekstu, natomiast wewnątrz nawiasów kwadratowych na pierwszej pozycji (`/[^...]/`) oznacza negację zestawu znaków.

---

## 7. Kwantyfikatory (krotność wystąpień)

Kwantyfikator określa, ile razy element znajdujący się bezpośrednio przed nim może lub musi się powtórzyć.

| Kwantyfikator | Znaczenie | Przykład |
|:---:|---|---|
| `*` | 0 lub więcej razy (dowolna liczba powtórzeń, w tym brak znaku) | `/a*/` |
| `+` | 1 lub więcej razy (przynajmniej raz) | `/a+/` |
| `?` | 0 lub 1 raz (element opcjonalny) | `/a?/` |
| `{n}` | Dokładnie `n` razy | `/a{4}/` (dokładnie 4 razy 'a') |
| `{min,}` | Co najmniej `min` razy | `/a{2,}/` (2 lub więcej) |
| `{min,max}` | Od `min` do `max` razy | `/a{2,5}/` (od 2 do 5 razy) |

```javascript
// Przykład 1: Kod pocztowy (dokładnie 2 cyfry, myślnik, dokładnie 3 cyfry)
const wzorKodPocztowy = /^\d{2}-\d{3}$/;

// Przykład 2: Login (litera, po której następuje od 3 do 15 liter lub cyfr)
const wzorLogin = /^[a-zA-Z][a-zA-Z0-9]{3,15}$/;

// Przykład 3: Numer telefonu z opcjonalnym myślnikiem po prefiksie
const wzorPrefiks = /^\d{3}-?\d{6}$/;
```

**Po co to jest:**  
Kwantyfikatory pozwalają określić dokładną długość pól formularza (np. 11 cyfr numeru PESEL, 9 cyfr numeru telefonu) oraz definiować elementy opcjonalne za pomocą znaku zapytania `?`.

**Typowa pomyłka:**  
Wstawianie spacji wewnątrz nawiasów klamrowych, np. `{2, 5}` zamiast `{2,5}`. W wyrażeniach regularnych spacja jest traktowana jako dosłowny znak, co powoduje, że silnik nie zinterpretuje zapisu jako kwantyfikatora.

---

## 8. Znak ucieczki (ang. *escaping*)

Niektóre znaki mają w wyrażeniach regularnych specjalne znaczenie (metaznaki): `.`, `*`, `+`, `?`, `^`, `$`, `(`, `)`, `[`, `]`, `{`, `}`, `|`, `\`, `/`.  
Jeśli chcemy dopasować dosłowny znak będący metaznakiem (np. prawdziwą kropkę w domenie lub myślnik), musimy poprzedzić go ukośnikiem odwrotnym `\`.

```javascript
// Wzorzec pliku graficznego z rozszerzeniem .png lub .jpg
// Kropka musi być poprzedzona ukośnikiem: \.
const wzorPlikPng = /^[a-z0-9_-]+\.png$/;

console.log(wzorPlikPng.test('zdjecie.png')); // true
console.log(wzorPlikPng.test('zdjecieapng')); // false (zwykła kropka dopasowałaby literę 'a')
```

**Po co to jest:**  
Znak ucieczki neutralizuje specjalne znaczenie metaznaku, nakazując silnikowi traktowanie go jako zwykłego, dosłownego symbolu.

**Typowa pomyłka:**  
Pozostawienie kropki bez ukośnika odwrotnego w adresach e-mail lub nazwach plików. Wzorzec `/plik.txt/` dopasuje zarówno `plik.txt`, jak i `plikAtxt`, `plik-txt` oraz `plik0txt`.

---

## 9. Flagi wyrażeń regularnych

Flagi modyfikują sposób działania całego wzorca. Umieszcza się je za zamykającym ukośnikiem literału: `/wzor/flagi`.

Najważniejsze podstawowe flagi:
- `i` (*ignore case*) — ignoruje wielkość liter (wzorzec dopasowuje zarówno małe, jak i wielkie litery).
- `g` (*global*) — dopasowanie globalne (znajduje wszystkie wystąpienia, a nie tylko pierwsze).

```javascript
// Flaga 'i' sprawia, że wzorzec dopasuje słowo niezależnie od wielkości liter
const wzorTak = /^tak$/i;

console.log(wzorTak.test('tak')); // true
console.log(wzorTak.test('TAK')); // true
console.log(wzorTak.test('Tak')); // true
```

**Po co to jest:**  
Flaga `i` ułatwia weryfikację tekstów, w których wielkość liter nie ma znaczenia biznesowego (np. wpisanie kodu rabatowego czy potwierdzenia słownego).

**Typowa pomyłka:**  
Wstawianie flag wewnątrz ukośników literału, np. `/itak/` zamiad `/tak/i`.

---

## 10. Integracja walidacji z formularzem HTML

W aplikacjach frontendowych walidacja wyrażeniami regularnymi odbywa się najczęściej w reakcji na zdarzenie zatwierdzenia formularza (`submit`) lub zdarzenie wprowadzania danych (`input`).

```javascript
const formularz = document.querySelector('#form-rejestracja');
const poleKod = document.querySelector('#kod-pocztowy');
const komunikatKod = document.querySelector('#komunikat-kod');

formularz.addEventListener('submit', function (event) {
    const wzorKod = /^\d{2}-\d{3}$/;
    const wartosc = poleKod.value.trim();

    if (!wzorKod.test(wartosc)) {
        event.preventDefault(); // Zatrzymujemy domyślną wysyłkę formularza
        poleKod.classList.remove('sukces-walidacji');
        poleKod.classList.add('blad-walidacji');
        komunikatKod.textContent = 'Niepoprawny format kodu pocztowego (wymagany: 00-000).';
        komunikatKod.classList.remove('ukryty');
    } else {
        poleKod.classList.remove('blad-walidacji');
        poleKod.classList.add('sukces-walidacji');
        komunikatKod.classList.add('ukryty');
    }
});
```

**Po co to jest:**  
Połączenie metody `test()` ze zdarzeniem `submit` oraz manipulacją klasami CSS umożliwia natychmiastowe poinformowanie użytkownika o poprawności lub błędach w formularzu bez odświeżania strony.

**Typowa pomyłka:**  
Zapomnienie o wywołaniu `event.preventDefault()` w przypadku niepowodzenia walidacji, przez co formularz zostanie wysłany mimo błędnych danych.
