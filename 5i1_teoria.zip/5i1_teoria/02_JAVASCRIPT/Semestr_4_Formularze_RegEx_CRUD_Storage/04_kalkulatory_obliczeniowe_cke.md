# Teoria: Kalkulatory obliczeniowe w arkuszach egzaminacyjnych CKE INF.03

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Wstęp: Specyfika kalkulatorów egzaminacyjnych CKE

W arkuszach egzaminacyjnych kwalifikacji INF.03 zadania praktyczne z JavaScript bardzo często przyjmują postać interaktywnego kalkulatora. Egzaminator ocenia:
1. Pobranie danych wejściowych z formularza bez przeładowania strony.
2. Bezpieczną konwersję typów (`string` na `number`).
3. Obliczenie wartości zgodnie z algorytmem (uwzględniając stawki, rabaty, mnożniki, opcje dodatkowe).
4. Sformatowanie wyniku i wypisanie go w dedykowanym elemencie blokowym lub paragrafie.

---

## 2. Pobieranie wartości i konwersja typów liczbowych

Właściwość `.value` każdego elementu `<input>` w drzewie DOM zwraca **zawsze łańcuch znaków (`string`)**, nawet jeśli znacznik posiada atrybut `type="number"` lub `type="range"`. Dodanie dwóch takich wartości za pomocą operatora `+` spowoduje konkatenację tekstową zamiast dodawania matematycznego (np. `"10" + "5"` daje `"105"`, a nie `15`).

### 2.1. Metody konwersji: `parseFloat()`, `parseInt()`, `Number()`

```javascript
const poleMetraz = document.querySelector('#metraz');
const polePokoje = document.querySelector('#pokoje');

const metraz = parseFloat(poleMetraz.value);
const pokoje = parseInt(polePokoje.value, 10);

if (Number.isNaN(metraz) || metraz <= 0) {
    console.error('Wprowadzono niepoprawny metraż');
}
```

- **Po co to jest:**  
  Jawna konwersja `parseFloat()` i `parseInt()` przekształca łańcuch znaków pobrany z formularza na rzeczywistą liczbę zmiennoprzecinkową lub całkowitą, co umożliwia wykonywanie poprawnych operacji arytmetycznych.
- **Typowa pomyłka:**  
  Użycie operatora `+` na wartościach `.value` bez konwersji, co prowadzi do błędnego łączenia tekstów, albo pominięcie drugiego parametru (systemu liczbowego `10`) w funkcji `parseInt()`.

---

## 3. Zabezpieczenie przed wartością `NaN` i walidacja wejścia

Jeśli użytkownik pozostawi pole puste lub wpisze niedozwolone znaki, `parseFloat("")` zwróci wartość specjalną `NaN` (*Not a Number*). Wszelkie dalsze działania na `NaN` dadzą wynik `NaN`.

```javascript
function obliczKoszt() {
    const wartosc = parseFloat(document.querySelector('#ilosc').value);

    if (Number.isNaN(wartosc) || wartosc < 0) {
        const wynik = document.querySelector('#wynik');
        wynik.textContent = 'Błąd: Proszę wprowadzić poprawną liczbę dodatnią.';
        return;
    }

    const cenaJednostkowa = 25.50;
    const kosztCalkowity = wartosc * cenaJednostkowa;
    document.querySelector('#wynik').textContent = `Koszt całkowity: ${kosztCalkowity.toFixed(2)} zł`;
}
```

- **Po co to jest:**  
  Sprawdzenie `Number.isNaN()` oraz warunków progowych (`wartosc < 0`) zapobiega wyświetleniu użytkownikowi bezużytecznego komunikatu typu `Koszt: NaN zł` i chroni logikę kalkulatora przed błędnymi danymi.
- **Typowa pomyłka:**  
  Porównywanie wartości z `NaN` za pomocą operatora równości `wartosc === NaN`, co zawsze zwraca `false` (w JavaScript `NaN` nie jest równe samemu sobie). Należy zawsze używać `Number.isNaN(wartosc)`.

---

## 4. Obsługa kontrolek formularza: `checkbox`, `radio`, `select`

Kalkulatory CKE często operują na cenie bazowej powiększanej o opcje dodatkowe lub zależnej od wybranego wariantu.

### 4.1. Pola wyboru jednokrotnego (`<input type="radio">`) i lista rozwijana (`<select>`)

Dla grupy przycisków radiowych odczytujemy zaznaczoną opcję za pomocą selektora pseudo-klasy `:checked`:

```javascript
const wybranyPakiet = document.querySelector('input[name="pakiet"]:checked');
const cenaPakietu = wybranyPakiet ? parseFloat(wybranyPakiet.value) : 0;

const selectUsluga = document.querySelector('#usluga');
const cenaUslugi = parseFloat(selectUsluga.value);
```

- **Po co to jest:**  
  Selektor `input[name="pakiet"]:checked` pozwala błyskawicznie ustalić, który z wariantów usługi został wybrany przez użytkownika, eliminując potrzebę ręcznego iterowania pętlą po wszystkich kontrolkach.
- **Typowa pomyłka:**  
  Brak sprawdzenia, czy `document.querySelector('input[name="pakiet"]:checked')` nie zwrócił `null` (gdy żaden radiobutton nie został domyślnie zaznaczony atrybutem `checked`).

### 4.2. Pola wyboru wielokrotnego (`<input type="checkbox">`)

Pole wyboru reprezentuje wartość logiczną we właściwości `.checked`:

```javascript
const chkMontaz = document.querySelector('#montaz');
const chkWniesienie = document.querySelector('#wniesienie');

let doplata = 0;
if (chkMontaz.checked) {
    doplata += 120.00;
}
if (chkWniesienie.checked) {
    doplata += 40.00;
}
```

- **Po co to jest:**  
  Właściwość `.checked` zwraca `true` lub `false`, co pozwala na proste warunkowe doliczanie opłat za usługi dodatkowe zaznaczone przez klienta.
- **Typowa pomyłka:**  
  Sprawdzanie właściwości `.value` zamiast `.checked`. Niezaznaczony checkbox nadal ma przypisaną wartość we właściwości `.value` (domyślnie `"on"`).

---

## 5. Suwaki (`<input type="range">`) i zdarzenie `input`

W nowoczesnych interfejsach kalkulatorów CKE wymaga się natychmiastowej reakcji suwaka na przesuwanie bez konieczności klikania przycisku.

```javascript
const suwakDystans = document.querySelector('#dystans');
const etykietaDystans = document.querySelector('#etykieta-dystans');

suwakDystans.addEventListener('input', () => {
    etykietaDystans.textContent = `${suwakDystans.value} km`;
    przeliczKosztPrzejazdu();
});
```

- **Po co to jest:**  
  Zdarzenie `input` jest wywoływane synchronicznie w trakcie każdego ruchu suwaka, co zapewnia natychmiastowe sprzężenie zwrotne dla użytkownika w interfejsie.
- **Typowa pomyłka:**  
  Zastosowanie zdarzenia `change` zamiast `input`. Zdarzenie `change` odpala się dopiero po puszczeniu przycisku myszy, co daje wrażenie opóźnionego lub zaciętego interfejsu.

---

## 6. Zdarzenie `submit` i blokowanie przeładowania: `e.preventDefault()`

Gdy kalkulator umieszczony jest wewnątrz znacznika `<form>`, kliknięcie przycisku `<button type="submit">` lub wciśnięcie klawisza Enter powoduje wysłanie formularza i przeładowanie strony, co czyści stan obliczeń.

```javascript
const formularzKalkulatora = document.querySelector('#form-kalkulator');

formularzKalkulatora.addEventListener('submit', (event) => {
    event.preventDefault(); // Zatrzymanie odświeżenia strony
    
    // Logika kalkulacyjna
    obliczWyceneKoncowa();
});
```

- **Po co to jest:**  
  Metoda `event.preventDefault()` anuluje domyślną akcję przeglądarki polegającą na przesłaniu formularza pod adres URL, pozwalając na pełną obsługę kalkulatora w JavaScript po stronie klienta.
- **Typowa pomyłka:**  
  Obsługa zdarzenia `click` na przycisku zamiast zdarzenia `submit` na formularzu, przez co wciśnięcie klawisza Enter w polu tekstowym i tak przeładowuje stronę.

---

## 7. Formatowanie walutowe i zaokrąglanie wyników

W zadaniach egzaminacyjnych CKE standardem jest prezentacja wyników finansowych z dokładnością do dwóch miejsc po przecinku oraz dodanie jednostki walutowej (`zł`).

### 7.1. Metoda `toFixed(2)`

```javascript
const kwotaNetto = 149.9;
const stawkaVat = 0.23;
const kwotaBrutto = kwotaNetto * (1 + stawkaVat);

const sformatowanaKwota = kwotaBrutto.toFixed(2); // "184.38"
document.querySelector('#wynik').textContent = `Do zapłaty: ${sformatowanaKwota} zł`;
```

### 7.2. Narzędzie `Intl.NumberFormat` (standard lokalizacyjny)

```javascript
const formaterWaluty = new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN'
});

const wynikLokalny = formaterWaluty.format(kwotaBrutto); // "184,38 zł"
document.querySelector('#wynik').textContent = `Do zapłaty: ${wynikLokalny}`;
```

- **Po co to jest:**  
  Metoda `toFixed(2)` gwarantuje, że kwoty takie jak `10.5` zostaną poprawnie wyświetlone jako `10.50`, unikając niedokładności wynikających z arytmetyki zmiennoprzecinkowej IEEE 754.
- **Typowa pomyłka:**  
  Próba dalszych obliczeń arytmetycznych na wyniku `toFixed(2)` bez ponownej konwersji — `toFixed()` zwraca łańcuch znaków (`string`).

---

## 8. Obsługa resetowania formularza: zdarzenie `reset`

Przyciski czyszczące `<button type="reset">` przywracają kontrolki do ich wartości domyślnych w HTML, ale nie czyszczą automatycznie elementów wyjściowych (`#wynik`, etykiet suwaków), które zostały wygenerowane skryptem.

```javascript
formularzKalkulatora.addEventListener('reset', () => {
    // Odczekanie mikrosekundy lub jawne zresetowanie kontenera wynikowego
    setTimeout(() => {
        document.querySelector('#wynik').textContent = 'Wprowadź dane i kliknij oblicz.';
        document.querySelector('#etykieta-dystans').textContent = '0 km';
    }, 0);
});
```

- **Po co to jest:**  
  Zdarzenie `reset` pozwala zsynchronizować stan dynamicznych elementów tekstowych i kontenerów wynikowych z domyślnym stanem formularza.
- **Typowa pomyłka:**  
  Modyfikowanie wartości pól formularza w momencie obsługi `reset` przed zakończeniem domyślnej akcji przeglądarki, co powoduje nadpisanie ich starymi wartościami.
