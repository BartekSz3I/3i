# Teoria: Architektura CRUD w pamięci przeglądarki

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Wprowadzenie do wzorca CRUD

Każda interaktywna aplikacja internetowa — od prostego rejestru zleceń warsztatowych po rozbudowany system e-commerce — opiera się na czterech podstawowych operacjach na danych. Zestaw ten określa się międzynarodowym akronimem **CRUD**:

- **C — Create (Tworzenie):** Dodawanie nowych rekordów do zbioru danych (np. dodanie nowego klienta lub towaru).
- **R — Read (Odczyt):** Pobieranie, filtrowanie i prezentowanie danych użytkownikowi na ekranie (np. wygenerowanie wierszy w tabeli HTML).
- **U — Update (Aktualizacja):** Modyfikowanie wartości istniejącego już rekordu (np. zmiana ceny produktu lub adresu e-mail).
- **D — Delete (Usuwanie):** Trwałe usuwanie wskazanego rekordu ze zbioru (np. wycofanie nieaktualnego zamówienia).

W profesjonalnej architekturze frontendowej kluczową zasadą jest **separacja odpowiedzialności**: oddzielenie danych (stanu aplikacji) od ich graficznej reprezentacji w drzewie DOM.

```javascript
// Przykład operacji CRUD w czystym kodzie JavaScript
const magazyn = [
  { id: 1, nazwa: "Klawiatura mechaniczna", cena: 249 }
];

// C: Create
magazyn.push({ id: 2, nazwa: "Mysz bezprzewodowa", cena: 129 });

// R: Read
const szukany = magazyn.find(produkt => produkt.id === 1);

// U: Update
szukany.cena = 229;

// D: Delete
const poUsunieciu = magazyn.filter(produkt => produkt.id !== 2);
```

**Po co to jest:** Standard CRUD porządkuje architekturę skryptu na przewidywalne, powtarzalne operacje, co zapobiega chaosowi w kodzie i ułatwia późniejsze podłączenie magazynów danych.

**Typowa pomyłka:** Próba traktowania kodu HTML jako bazy danych — czyli odczytywanie cen lub nazw bezpośrednio z właściwości `textContent` komórek `<td>` zamiast z obiektów w JavaScript.

---

## 2. Stan aplikacji jako jedyne źródło prawdy (Single Source of Truth)

Pojęcie **stanu aplikacji** (*State*) oznacza aktualny zbiór wszystkich zmiennych i struktur przechowujących dane programu w danej chwili. W architekturze opartej na pamięci operacyjnej RAM centralnym punktem jest globalna lub modułowa tablica obiektów:

```javascript
// Centralny stan aplikacji w pamięci RAM
let bazaZamowien = [
  { id: 1, klient: "Jan Kowalski", usluga: "Wymiana dysku SSD", koszt: 150 },
  { id: 2, klient: "Anna Nowak", usluga: "Czyszczenie układu chłodzenia", koszt: 90 }
];
```

Gdy stan jest **jedynym źródłem prawdy**, każda akcja użytkownika (kliknięcie przycisku, wysłanie formularza) przebiega według ścisłego schematu trójfazowego:
1. Pobranie danych od użytkownika i zmiana w tablicy stanu w JavaScript.
2. Zaktualizowanie struktury danych w pamięci RAM.
3. Ponowne odrysowanie (re-render) widoku w drzewie DOM na podstawie nowej zawartości tablicy.

### Generowanie unikalnego identyfikatora (`id`)

Każdy obiekt w tablicy musi posiadać unikalny identyfikator, który jednoznacznie odróżnia go od pozostałych rekordów, nawet jeśli mają identyczne nazwy czy wartości.

```javascript
function wygenerujNoweId(tablica) {
  if (tablica.length === 0) {
    return 1;
  }
  const najwyzszeId = Math.max(...tablica.map(element => element.id));
  return najwyzszeId + 1;
}
```

**Po co to jest:** Nadanie rekordu unikalnego `id` pozwala bezbłędnie namierzyć konkretny obiekt w tablicy podczas usuwania lub edycji, bez ryzyka zmodyfikowania innego elementu o takich samych właściwościach.

**Typowa pomyłka:** Używanie bieżącego indeksu tablicy (`index`) jako identyfikatora rekordu. Po usunięciu jednego elementu lub po posortowaniu tablicy indeksy wszystkich pozostałych elementów ulegają przesunięciu, co prowadzi do błędów podczas kolejnych operacji.

---

## 3. Operacja READ: Odczyt i funkcja renderująca widok

Zamiast ręcznie wstawiać pojedyncze elementy `<tr`> w różnych miejscach kodu, tworzymy jedną dedykowaną funkcję renderującą. Funkcja ta czyści bieżącą zawartość kontenera tabeli `<tbody>` i buduje widok od nowa na podstawie przekazanej tablicy danych.

```javascript
const tabelaCialo = document.querySelector("#tabela-zamowien tbody");

function renderujTabele(listaDanych) {
  tabelaCialo.innerHTML = "";

  if (listaDanych.length === 0) {
    const wierszPusty = document.createElement("tr");
    wierszPusty.innerHTML = `<td colspan="5" class="tekst-pusty">Brak rekordów do wyświetlenia</td>`;
    tabelaCialo.appendChild(wierszPusty);
    return;
  }

  listaDanych.forEach(rekord => {
    const wiersz = document.createElement("tr");
    wiersz.innerHTML = `
      <td>${rekord.id}</td>
      <td>${rekord.klient}</td>
      <td>${rekord.usluga}</td>
      <td>${rekord.koszt.toFixed(2)} zł</td>
      <td>
        <button type="button" class="btn-edytuj" data-id="${rekord.id}">Edytuj</button>
        <button type="button" class="btn-usun" data-id="${rekord.id}">Usuń</button>
      </td>
    `;
    tabelaCialo.appendChild(wiersz);
  });
}
```

**Po co to jest:** Centralna funkcja renderująca zapewnia, że interfejs użytkownika jest w 100% zsynchronizowany ze stanem w pamięci. Zmiana widoku zawsze wynika wprost z nowej postaci danych w tablicy.

**Typowa pomyłka:** Zapomnienie o wyczyszczeniu kontenera (`tabelaCialo.innerHTML = ""`) przed generowaniem nowych wierszy, co skutkuje wielokrotnym duplikowaniem całej zawartości tabeli przy każdym odświeżeniu.

---

## 4. Operacja CREATE: Dodawanie nowego rekordu

Dodawanie nowego rekordu odbywa się za pośrednictwem formularza HTML `<form>`. Podstawą jest przechwycenie zdarzenia `submit` oraz natychmiastowe zablokowanie domyślnej akcji przeglądarki za pomocą `event.preventDefault()`.

```javascript
const formularz = document.querySelector("#formularz-zamowienia");
const poleKlient = document.querySelector("#klient");
const poleUsluga = document.querySelector("#usluga");
const poleKoszt = document.querySelector("#koszt");

formularz.addEventListener("submit", function (zdarzenie) {
  zdarzenie.preventDefault();

  const wartoscKlient = poleKlient.value.trim();
  const wartoscUsluga = poleUsluga.value.trim();
  const wartoscKoszt = parseFloat(poleKoszt.value);

  if (wartoscKlient === "" || wartoscUsluga === "" || isNaN(wartoscKoszt) || wartoscKoszt <= 0) {
    alert("Wypełnij poprawnie wszystkie pola formularza.");
    return;
  }

  const nowyRekord = {
    id: wygenerujNoweId(bazaZamowien),
    klient: wartoscKlient,
    usluga: wartoscUsluga,
    koszt: wartoscKoszt
  };

  bazaZamowien.push(nowyRekord);
  renderujTabele(bazaZamowien);
  formularz.reset();
  poleKlient.focus();
});
```

**Po co to jest:** Metoda `push()` dodaje nowy obiekt na koniec tablicy stanu, a wywołanie `renderujTabele()` natychmiast odzwierciedla nowy stan na ekranie bez przeładowywania strony.

**Typowa pomyłka:** Zapisywanie wartości liczbowych z pól formularza jako typ `String` (np. `"150"` zamiast liczby `150`). Brak konwersji za pomocą `parseFloat()` lub `Number()` powoduje błędy przy późniejszym sumowaniu i sortowaniu.

---

## 5. Operacja DELETE: Bezpieczne usuwanie rekordu

Usuwanie rekordu realizujemy najczęściej za pomocą niemutującej metody tablicowej `filter()`, która zwraca nową tablicę zawierającą wszystkie elementy oprócz rekordu o wskazanym identyfikatorze. Do powiązania przycisku z identyfikatorem wykorzystujemy atrybut `data-id`.

```javascript
tabelaCialo.addEventListener("click", function (zdarzenie) {
  const przyciskUsun = zdarzenie.target.closest(".btn-usun");
  if (!przyciskUsun) return;

  const idDoUsuniecia = parseInt(przyciskUsun.dataset.id, 10);
  bazaZamowien = bazaZamowien.filter(rekord => rekord.id !== idDoUsuniecia);

  renderujTabele(bazaZamowien);
});
```

**Po co to jest:** Delegacja zdarzeń na elemencie rodzica `<tbody>` pozwala obsłużyć kliknięcia we wszystkie dynamicznie dodawane przyciski usuwania bez konieczności rejestrowania osobnego `addEventListener` dla każdego wiersza z osobna.

**Typowa pomyłka:** Porównywanie typów bez rzutowania (`rekord.id !== przyciskUsun.dataset.id`). Ponieważ atrybuty `dataset` zwracają zawsze ciąg tekstowy (`String`), brak `parseInt()` skutkuje niespełnieniem warunku ostrej nierówności (`!==`) z liczbowym `id`.

---

## 6. Operacja UPDATE: Edycja istniejącego rekordu

Aktualizacja rekordu wymaga obsługi dwóch stanów formularza:
1. **Tryb dodawania (domyślny):** Formularz tworzy nowy rekord z nowym `id`.
2. **Tryb edycji:** Formularz wypełnia się danymi istniejącego obiektu, a przycisk zatwierdzenia aktualizuje obiekt w tablicy stanu zamiast tworzyć duplikat.

Do zarządzania trybem stosuje się zmienną pomocniczą `aktualnieEdytowaneId` lub ukryte pole formularza `<input type="hidden" id="edytowane-id">`.

```javascript
let edytowaneId = null;
const przyciskZatwierdz = document.querySelector("#btn-zatwierdz");
const przyciskAnuluj = document.querySelector("#btn-anuluj");

// 1. Wejście w tryb edycji po kliknięciu przycisku w tabeli
tabelaCialo.addEventListener("click", function (zdarzenie) {
  const przyciskEdytuj = zdarzenie.target.closest(".btn-edytuj");
  if (!przyciskEdytuj) return;

  const id = parseInt(przyciskEdytuj.dataset.id, 10);
  const znaleziony = bazaZamowien.find(el => el.id === id);

  if (znaleziony) {
    edytowaneId = znaleziony.id;
    poleKlient.value = znaleziony.klient;
    poleUsluga.value = znaleziony.usluga;
    poleKoszt.value = znaleziony.koszt;

    przyciskZatwierdz.textContent = "Zapisz zmiany";
    przyciskAnuluj.classList.remove("ukryty");
  }
});

// 2. Obsługa zapisu w formularzu (wspólny submit)
function zapiszFormularz(zdarzenie) {
  zdarzenie.preventDefault();

  if (edytowaneId !== null) {
    // UPDATE: modyfikacja istniejącego rekordu
    const index = bazaZamowien.findIndex(el => el.id === edytowaneId);
    if (index !== -1) {
      bazaZamowien[index].klient = poleKlient.value.trim();
      bazaZamowien[index].usluga = poleUsluga.value.trim();
      bazaZamowien[index].koszt = parseFloat(poleKoszt.value);
    }
    zresetujTrybEdycji();
  } else {
    // CREATE: dodanie nowego rekordu
    // ... logika push ...
  }
  renderujTabele(bazaZamowien);
}

function zresetujTrybEdycji() {
  edytowaneId = null;
  formularz.reset();
  przyciskZatwierdz.textContent = "Dodaj do rejestru";
  przyciskAnuluj.classList.add("ukryty");
}
```

**Po co to jest:** Zmienna stanu edycji pozwala wykorzystać jeden i ten sam formularz zarówno do wprowadzania nowych wpisów, jak i do korekty istniejących danych, co zapewnia ergonomię interfejsu.

**Typowa pomyłka:** Brak mechanizmu anulowania edycji lub brak resetowania identyfikatora `edytowaneId = null` po zapisie, przez co każde kolejne wysłanie formularza nadpisuje ten sam rekord zamiast dodać nowy.

---

## 7. Wyszukiwanie i filtrowanie w pamięci (Operacje Read z kryteriami)

Ponieważ wszystkie dane przechowujemy w oryginalnej tablicy `bazaZamowien`, filtrowanie i wyszukiwanie nie wymaga niszczenia danych. Wystarczy przekazać przefiltrowaną kopię do funkcji `renderujTabele()`:

```javascript
const poleSzukaj = document.querySelector("#filtr-szukaj");

poleSzukaj.addEventListener("input", function () {
  const szukanaFraza = poleSzukaj.value.trim().toLowerCase();

  const wyniki = bazaZamowien.filter(rekord => {
    const pasujeKlient = rekord.klient.toLowerCase().includes(szukanaFraza);
    const pasujeUsluga = rekord.usluga.toLowerCase().includes(szukanaFraza);
    return pasujeKlient || pasujeUsluga;
  });

  renderujTabele(wyniki);
});
```

**Po co to jest:** Filtrowanie w locie z zachowaniem oryginalnej tablicy pozwala użytkownikowi w każdej chwili wyczyścić filtr i natychmiast powrócić do pełnego zestawu danych bez konieczności ponownego ich wprowadzania.

**Typowa pomyłka:** Przypisywanie przefiltrowanej tablicy bezpośrednio do głównej zmiennej (`bazaZamowien = bazaZamowien.filter(...)`). Prowadzi to do bezpowrotnego skasowania z pamięci wszystkich rekordów, które nie pasowały do bieżącego filtra.

---

## 8. Wypis na stronę w Semestrze 4 i granice architektoniczne

W Semestrze 4 obowiązuje pełna manipulacja drzewem DOM w połączeniu z architekturą opartą na zdarzeniach formularza (`submit`, `input`, `click`).

- **Gdzie trafia wypis:** Zmiany prezentujemy w ustrukturyzowanych kontenerach tabelarycznych (`#tabela-danych tbody`), listach kafelkowych (`#lista-zamowien`) lub dedykowanych blokach podsumowania (`#podsumowanie`, `#wynik`).
- **Dlaczego tylko w pamięci RAM:** Zrozumienie czystej architektury CRUD w pamięci operacyjnej jest niezbędnym fundamentem przed dodaniem warstwy trwałości. W kolejnym module (`07_json_i_localstorage`) nauczymy się zapisywać stan w magazynie przeglądarki, dzięki czemu rekordy nie znikną po odświeżeniu witryny.
