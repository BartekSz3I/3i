# Teoria: Modele obiektowe danych w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Czym jest model obiektowy danych i dlaczego zastępuje luźne zmienne?

W prostych skryptach dane pobrane z formularza często przechowuje się w osobnych zmiennych, na przykład `imieKlienta`, `wybranaUsluga` czy `liczbaGodzin`. Takie podejście przestaje jednak wystarczać w momencie, gdy aplikacja musi obsłużyć listę wielu zamówień, katalog towarów w sklepie lub rejestr zgłoszeń w serwisie komputerowym. Utrzymywanie kilku równoległych tablic (jednej na nazwy, drugiej na ceny, trzeciej na stany magazynowe) szybko prowadzi do błędów synchronizacji indeksów.

**Model obiektowy danych** to uporządkowana struktura w pamięci programu (obiekt JavaScript), która łączy w jedną całość wszystkie cechy pojedynczego bytu (nazywanego **encją** lub **rekordem**) oraz funkcje, które potrafią na tych cechach wykonywać obliczenia lub zmieniać stan tego rekordu. W aplikacji frontendowej model stanowi pomost między formularzem (źródłem surowych tekstów wpisywanych przez użytkownika) a drzewem DOM (tabelą `#tabela-danych` lub listą `#lista-zamowien`, w której prezentujemy wyniki).

```javascript
// Zamiast rozproszonych zmiennych tworzymy jeden spójny obiekt modelu:
const zamowienie = {
  id: 101,
  klient: "Anna Nowak",
  usluga: "Serwis laptopa",
  ilosc: 2,
  cenaJednostkowa: 150,
  oplacone: false
};
```

**Po co to jest:** Zgrupowanie wszystkich właściwości jednego zamówienia w pojedynczym obiekcie sprawia, że cały rekord można łatwo przekazać jako jeden argument do funkcji, zapisać w tablicy zamówień lub wyświetlić w wierszu tabeli HTML bez ryzyka pomylenia danych różnych klientów.

**Typowa pomyłka:** Używanie znaku równości `=` zamiast dwukropka `:` wewnątrz nawiasów klamrowych literału obiektowego (np. `id = 101` zamiast `id: 101`) lub stawianie średników `;` zamiast przecinków `,` pomiędzy kolejnymi polami obiektu, co skutkuje błędem składniowym `SyntaxError`.

---

## 2. Dostęp do właściwości modelu i metody wewnętrzne (`this`)

Obiekt w języku JavaScript może przechowywać nie tylko dane (liczby, teksty, wartości logiczne), ale również funkcje. Funkcję przypisaną do klucza wewnątrz obiektu nazywamy **metodą**. Aby metoda mogła odczytać lub zmienić inne pola tego samego obiektu, do którego należy, wykorzystuje specjalne słowo kluczowe `this` (oznaczające funkcjonalnie: „ten konkretny obiekt, na którym wywołano metodę”).

```javascript
const produktMagazynowy = {
  id: 1,
  nazwa: "Monitor biurowy 24 cale",
  cenaNetto: 600,
  stawkaVat: 0.23,
  stanMagazynowy: 5,

  obliczCeneBrutto() {
    return +(this.cenaNetto * (1 + this.stawkaVat)).toFixed(2);
  },

  czyDostepny() {
    return this.stanMagazynowy > 0;
  },

  wydajZMagazynu(sztuki) {
    if (sztuki > 0 && sztuki <= this.stanMagazynowy) {
      this.stanMagazynowy -= sztuki;
      return true;
    }
    return false;
  },

  pobierzEtykiete() {
    const status = this.czyDostepny() ? `Dostępny (${this.stanMagazynowy} szt.)` : "Brak w magazynie";
    return `${this.nazwa} — ${this.obliczCeneBrutto().toFixed(2)} zł brutto [${status}]`;
  }
};

console.log(produktMagazynowy.pobierzEtykiete());
produktMagazynowy.wydajZMagazynu(2);
console.log(produktMagazynowy.stanMagazynowy); // 3
```

**Po co to jest:** Umieszczenie logiki obliczeniowej (np. `obliczCeneBrutto()`) oraz logiki zmiany stanu (`wydajZMagazynu()`) bezpośrednio wewnątrz modelu gwarantuje, że w każdym miejscu aplikacji cena brutto i dostępność towaru są wyliczane dokładnie według tych samych reguł.

**Typowa pomyłka:** Pominięcie słowa kluczowego `this.` przy odwołaniu do właściwości wewnątrz metody (np. napisanie `return cenaNetto * 1.23` zamiast `return this.cenaNetto * 1.23`), co powoduje błąd `ReferenceError: cenaNetto is not defined`, ponieważ silnik JavaScript szuka zmiennej lokalnej zamiast pola obiektu. Drugą częstą pomyłką jest zapisanie metody obiektu jako funkcji strzałkowej `() => {}`, która nie posiada własnego wiązania `this` i nie widzi właściwości obiektu.

---

## 3. Funkcje fabrykujące (Factory Functions)

Gdy aplikacja pozwala użytkownikowi dodawać kolejne pozycje przez formularz `<form>`, ręczne pisanie literałów obiektowych w kodzie nie jest możliwe — potrzebujemy mechanizmu, który wyprodukuje nowy obiekt o identycznej strukturze za każdym razem, gdy użytkownik kliknie przycisk zatwierdzający. Pierwszym sposobem rozwiązania tego problemu jest **funkcja fabrykująca** (ang. *factory function*), czyli zwykła funkcja, która przyjmuje parametry i zwraca gotowy obiekt.

```javascript
let licznikIdBiletow = 1;

function utworzRezerwacjeBiletu(imie, nazwisko, trasa, liczbaMiejsc, cenaBazowa, ulgaSzkolna) {
  return {
    id: licznikIdBiletow++,
    pasazer: `${imie.trim()} ${nazwisko.trim()}`,
    trasa: trasa,
    liczbaMiejsc: Number(liczbaMiejsc),
    cenaBazowa: Number(cenaBazowa),
    ulgaSzkolna: Boolean(ulgaSzkolna),

    obliczKosztCalkowity() {
      const mnoznik = this.ulgaSzkolna ? 0.5 : 1.0;
      return +(this.liczbaMiejsc * this.cenaBazowa * mnoznik).toFixed(2);
    },

    formatujPodsumowanie() {
      const typBiletu = this.ulgaSzkolna ? "ulgowy (-50%)" : "normalny";
      return `#${this.id} | ${this.pasazer} | Trasa: ${this.trasa} | Miejsca: ${this.liczbaMiejsc} (${typBiletu}) | Do zapłaty: ${this.obliczKosztCalkowity().toFixed(2)} zł`;
    }
  };
}

const bilet1 = utworzRezerwacjeBiletu("Jan", "Kowalski", "Warszawa - Gdańsk", 2, 80, true);
const bilet2 = utworzRezerwacjeBiletu("Maria", "Zielińska", "Kraków - Wrocław", 1, 65, false);
```

**Po co to jest:** Funkcja fabrykująca ujednolica tworzenie rekordów, automatycznie nadaje każdemu obiektowi kolejny unikalny identyfikator `id` oraz od razu konwertuje typy danych (np. napis z pola `<input type="number">` na typ `Number`), chroniąc resztę aplikacji przed błędami konkatenacji tekstów zamiast dodawania liczb.

**Typowa pomyłka:** Zapomnienie o jawnej konwersji wartości pobranych z formularza za pomocą `Number()` lub `parseFloat()`. Wartość właściwości `.value` odczytana z elementu `<input>` jest zawsze tekstem (`string`), więc bez konwersji zapisanie jej w modelu może doprowadzić do błędnych obliczeń przy sumowaniu kosztów.

---

## 4. Klasy ES6 (`class` i `constructor`) — standard budowy modeli

We współczesnym języku JavaScript (od standardu ES6) podstawowym narzędziem do definiowania modeli obiektowych jest składnia klasowa `class`. **Klasa** pełni funkcję formalnego szablonu (projektu architektonicznego), natomiast konkretny obiekt utworzony na podstawie tej klasy za pomocą operatora `new` nazywamy **instancją** (egzemplarzem) klasy.

Kluczowym elementem klasy jest specjalna metoda o nazwie `constructor`. Uruchamia się ona automatycznie w chwili wywołania `new NazwaKlasy(...)` i służy do zainicjowania właściwości nowego egzemplarza za pomocą słowa kluczowego `this`. Pozostałe metody zapisujemy w ciele klasy bezpośrednio pod konstruktorem (bez słowa `function` i bez przecinków między metodami).

```javascript
class ZlecenieSerwisowe {
  constructor(id, klient, telefon, urzadzenie, kosztRobocizny, kosztCzesci, priorytet) {
    this.id = id;
    this.klient = klient.trim();
    this.telefon = telefon.trim();
    this.urzadzenie = urzadzenie.trim();
    this.kosztRobocizny = Number(kosztRobocizny);
    this.kosztCzesci = Number(kosztCzesci);
    this.priorytet = Boolean(priorytet);
    this.status = "Przyjęte";
  }

  obliczWycene() {
    const podstawa = this.kosztRobocizny + this.kosztCzesci;
    const doplataEkspres = this.priorytet ? podstawa * 0.20 : 0;
    return +(podstawa + doplataEkspres).toFixed(2);
  }

  zmienStatus(nowyStatus) {
    const dozwoloneStatusy = ["Przyjęte", "W naprawie", "Gotowe do odbioru", "Wydane"];
    if (dozwoloneStatusy.includes(nowyStatus)) {
      this.status = nowyStatus;
      return true;
    }
    return false;
  }

  pobierzWierszTekstowy() {
    const oznaczenie = this.priorytet ? "[EKSPRES +20%]" : "[STANDARD]";
    return `Zlecenie #${this.id}: ${this.urzadzenie} (${this.klient}, tel. ${this.telefon}) — ${this.obliczWycene().toFixed(2)} zł ${oznaczenie} — Status: ${this.status}`;
  }
}

// Tworzenie dwóch niezależnych instancji modelu za pomocą operatora new:
const zlecenieA = new ZlecenieSerwisowe(1, "Piotr Wiśniewski", "500-600-700", "Drukarka laserowa", 120, 80, true);
const zlecenieB = new ZlecenieSerwisowe(2, "Katarzyna Dąbrowska", "600-700-800", "Laptop игровой", 200, 0, false);

zlecenieA.zmienStatus("W naprawie");
console.log(zlecenieA.pobierzWierszTekstowy());
```

**Po co to jest:** Zastosowanie klasy `class` wyraźnie oddziela inicjalizację pól danych (w metodzie `constructor`) od zachowań modelu (pozostałych metod). Ponadto metody zdefiniowane w klasie są współdzielone w pamięci przez wszystkie instancje, zamiast być kopiowane do każdego obiektu z osobna, co zapewnia porządek architektoniczny i czytelność kodu na egzaminie oraz w projektach zespołowych.

**Typowa pomyłka:** Wywołanie klasy jak zwykłej funkcji bez operatora `new` (np. `const z = ZlecenieSerwisowe(...)`), co w JavaScript kończy się natychmiastowym błędem wykonania `TypeError: Class constructor cannot be invoked without 'new'`. Równie częstym błędem jest literówka w nazwie metody `constructor` (np. napisanie `konstruktor` lub `construct`), przez co pola obiektu w ogóle nie zostają przypisane.

---

## 5. Nadawanie unikalnych identyfikatorów (`id`) w modelach

Każdy model obiektowy przechowywany w kolekcji musi posiadać cechę, która jednoznacznie odróżnia go od wszystkich pozostałych rekordów — nawet wtedy, gdy dwóch klientów o tym samym imieniu i nazwisku zamówi dokładnie tę samą usługę. W aplikacjach klienckich stosujemy dwa niezawodne sposoby generowania unikalnego klucza `id`:

1. **Sekwencyjny licznik w zmiennej lub właściwości pomocniczej** (`1, 2, 3...`) — czytelny dla użytkownika w tabeli lub na wydruku zamówienia.
2. **Znacznik czasu w milisekundach (`Date.now()`)** lub jego połączenie z licznikiem — szybki sposób na uzyskanie unikalnej liczby określającej moment utworzenia rekordu.

```javascript
class PozycjaKoszyka {
  constructor(id, nazwaProduktu, ilosc, cenaJednostkowa) {
    this.id = id;
    this.nazwaProduktu = nazwaProduktu;
    this.ilosc = Number(ilosc);
    this.cenaJednostkowa = Number(cenaJednostkowa);
  }

  obliczWartosc() {
    return +(this.ilosc * this.cenaJednostkowa).toFixed(2);
  }
}

// Zarządzanie licznikiem ID podczas dodawania kolejnych modeli:
let kolejneIdPozycji = 1;
const koszyk = [];

function dodajDoKoszyka(nazwa, ilosc, cena) {
  const nowaPozycja = new PozycjaKoszyka(kolejneIdPozycji++, nazwa, ilosc, cena);
  koszyk.push(nowaPozycja);
  return nowaPozycja;
}
```

**Po co to jest:** Unikalne pole `id` pozwala bezbłędnie wskazać konkretny obiekt w tablicy podczas wyszukiwania (`find`), filtrowania (`filter`) czy aktualizacji stanu wybranej pozycji za pomocą atrybutu `data-id` w drzewie DOM.

**Typowa pomyłka:** Używanie aktualnej długości tablicy `koszyk.length + 1` jako identyfikatora `id`. Jeśli w przyszłości z tablicy zostanie usunięty środkowy element, długość tablicy zmniejszy się i kolejny dodany obiekt otrzyma identyfikator, który już istnieje w kolekcji, co spowoduje duplikację kluczy `id`.

---

## 6. Kolekcja modeli jako stan aplikacji i współpraca z formularzem

W dobrze zaprojektowanej aplikacji frontendowej drzewo DOM (czyli to, co widać w tabeli `<table>` lub na liście `<ul>`) nie jest miejscem przechowywania danych, lecz jedynie **widokiem** odzwierciedlającym aktualny stan tablicy obiektów w pamięci skryptu. Przepływ danych po zatwierdzeniu formularza przebiega zawsze w czterech uporządkowanych krokach:

1. Przechwycenie zdarzenia `submit` na formularzu i zatrzymanie przeładowania strony za pomocą `event.preventDefault()`.
2. Odczytanie wartości z kontrolek formularza (`#imie`, `#email`, `#usluga`, `#ilosc` itd.) oraz wykonanie walidacji (w tym wyrażeń regularnych `RegExp`).
3. Utworzenie nowej instancji modelu (`new ...`) i dopisanie jej metodą `.push()` do tablicy przechowującej kolekcję obiektów.
4. Wywołanie funkcji renderującej, która czyści kontener wynikowy (`#tabela-danych` lub `#lista-zamowien`) i na nowo buduje elementy HTML na podstawie tablicy modeli oraz wylicza statystyki w `#podsumowanie`.

```javascript
class ZamowienieKurierskie {
  constructor(id, nadawca, kodPocztowy, wagaKg, ubezpieczenie) {
    this.id = id;
    this.nadawca = nadawca.trim();
    this.kodPocztowy = kodPocztowy.trim();
    this.wagaKg = Number(wagaKg);
    this.ubezpieczenie = Boolean(ubezpieczenie);
  }

  obliczKosztWysylki() {
    let koszt = this.wagaKg <= 5 ? 19.99 : 19.99 + (this.wagaKg - 5) * 3.50;
    if (this.ubezpieczenie) {
      koszt += 12.00;
    }
    return +koszt.toFixed(2);
  }
}

const rejestrPrzesylek = [];
let nastepneId = 1;

const formularz = document.querySelector("#formularz-przesylki");
const tabelaCialo = document.querySelector("#tabela-danych");
const polePodsumowanie = document.querySelector("#podsumowanie");
const komunikatBledu = document.querySelector("#komunikat-bledu");

function renderujWidok() {
  tabelaCialo.innerHTML = "";

  rejestrPrzesylek.forEach((przesylka) => {
    const wiersz = document.createElement("tr");

    const tdId = document.createElement("td");
    tdId.textContent = przesylka.id;

    const tdNadawca = document.createElement("td");
    tdNadawca.textContent = przesylka.nadawca;

    const tdKod = document.createElement("td");
    tdKod.textContent = przesylka.kodPocztowy;

    const tdWaga = document.createElement("td");
    tdWaga.textContent = `${przesylka.wagaKg} kg`;

    const tdKoszt = document.createElement("td");
    tdKoszt.textContent = `${przesylka.obliczKosztWysylki().toFixed(2)} zł`;

    wiersz.append(tdId, tdNadawca, tdKod, tdWaga, tdKoszt);
    tabelaCialo.appendChild(wiersz);
  });

  const sumaKosztow = rejestrPrzesylek.reduce((suma, p) => suma + p.obliczKosztWysylki(), 0);
  polePodsumowanie.textContent = `Liczba przesyłek: ${rejestrPrzesylek.length} | Łączny koszt: ${sumaKosztow.toFixed(2)} zł`;
}

formularz.addEventListener("submit", (event) => {
  event.preventDefault();

  const nadawca = document.querySelector("#imie").value.trim();
  const kod = document.querySelector("#kod-pocztowy").value.trim();
  const waga = parseFloat(document.querySelector("#ilosc").value);
  const ubezpieczenie = document.querySelector("#regulamin").checked;

  const wzorzecKodu = /^\d{2}-\d{3}$/;
  if (nadawca.length < 3 || !wzorzecKodu.test(kod) || isNaN(waga) || waga <= 0) {
    komunikatBledu.textContent = "Wprowadź poprawne dane nadawcy, kod XX-XXX oraz dodatnią wagę.";
    komunikatBledu.classList.remove("ukryty");
    return;
  }

  komunikatBledu.classList.add("ukryty");
  const nowyModel = new ZamowienieKurierskie(nastepneId++, nadawca, kod, waga, ubezpieczenie);
  rejestrPrzesylek.push(nowyModel);

  renderujWidok();
  formularz.reset();
});
```

**Po co to jest:** Oddzielenie tablicy modeli (`rejestrPrzesylek`) od funkcji rysującej interfejs (`renderujWidok()`) pozwala w dowolnym momencie przefiltrować, posortować lub podsumować wszystkie obiekty za pomocą metod tablicowych (`filter`, `reduce`, `find`), bez konieczności żmudnego odczytywania i parsowania tekstów z komórek `<td>` w drzewie DOM.

**Typowa pomyłka:** Dopisywanie nowego wiersza `<tr>` bezpośrednio do tabeli bez zapisania obiektu w tablicy modeli lub odwrotnie — dodanie obiektu do tablicy, ale zapomnienie o wyczyszczeniu `tabelaCialo.innerHTML = ""` przed pętlą `forEach` w funkcji renderującej, co powoduje wielokrotne duplikowanie wcześniej dodanych wierszy na ekranie.

---

## 7. Operacje na kolekcji modeli: wyszukiwanie, filtrowanie i agregacja

Kiedy stan aplikacji jest przechowywany jako tablica instancji klasy, możemy w pełni wykorzystać wbudowane metody tablicowe JavaScript, wywołując wewnątrz ich funkcji zwrotnych metody naszych modeli obiektowych:

- **`tablica.find(model => model.id === szukaneId)`** — zwraca referencję do pierwszego obiektu spełniającego warunek (lub `undefined`, jeśli takiego obiektu nie ma). Pozwala to np. znaleźć konkretny rekord i wywołać na nim metodę zmieniającą jego status.
- **`tablica.filter(model => model.czyAktywny())`** — zwraca nową tablicę zawierającą wyłącznie te modele, dla których warunek lub metoda modelu zwróciła prawdę (`true`). Przydaje się do filtrowania widoku bez niszczenia oryginalnej kolekcji.
- **`tablica.reduce((akumulator, model) => akumulator + model.obliczWartosc(), 0)`** — pozwala zsumować wartości wyliczane dynamicznie przez metodę każdego obiektu w kolekcji.

```javascript
// Wyszukanie modelu po identyfikatorze i wywołanie jego metody:
function oznaczJakoWydane(idZlecenia, kolekcjaZlecen) {
  const znalezioneZlecenie = kolekcjaZlecen.find((element) => element.id === Number(idZlecenia));
  if (znalezioneZlecenie) {
    znalezioneZlecenie.zmienStatus("Wydane");
    return true;
  }
  return false;
}

// Pobranie wyłącznie zleceń ekspresowych o wartości powyżej 200 zł:
function filtrujDrogieEkspresy(kolekcjaZlecen) {
  return kolekcjaZlecen.filter((element) => element.priorytet && element.obliczWycene() > 200);
}
```

**Po co to jest:** Ponieważ `find()` zwraca bezpośrednią referencję do obiektu znajdującego się w tablicy, wywołanie metody `znalezioneZlecenie.zmienStatus("Wydane")` natychmiast aktualizuje ten obiekt wewnątrz głównej kolekcji — wystarczy potem wywołać funkcję odświeżającą widok DOM.

**Typowa pomyłka:** Porównywanie identyfikatora `model.id` (będącego liczbą `Number`) z atrybutem odczytanym z elementu HTML (np. `button.dataset.id` lub `input.value`, które są typu `string`) za pomocą ścisłego operatora `===` bez rzutowania `Number()`. W efekcie `1 === "1"` daje wynik `false` i metoda `find()` zwraca `undefined`.
