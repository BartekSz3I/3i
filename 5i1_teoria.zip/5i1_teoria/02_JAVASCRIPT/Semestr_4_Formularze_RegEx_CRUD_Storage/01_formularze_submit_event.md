# Teoria: Zdarzenie submit, zatrzymanie przeładowania (preventDefault) i obsługa formularzy DOM

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

**Kwalifikacja:** INF.03 | **Semestr:** 4 | **Moduł:** 01 — Formularze i zdarzenie `submit`

---

## 1. Cykl życia formularza w przeglądarce

Formularz HTML zdefiniowany za pomocą znacznika `<form>` jest jednym z najstarszych i najważniejszych elementów sieci WWW. Jego pierwotnym zadaniem było zbieranie danych od użytkownika i przesyłanie ich na serwer za pośrednictwem żądania HTTP (GET lub POST), co wiązało się z natychmiastowym przeładowaniem całej strony.

W nowoczesnych aplikacjach internetowych (Single Page Application oraz interfejsach dynamicznych) dane z formularza są weryfikowane, przetwarzane lub wyświetlane bezpośrednio w przeglądarce klienta za pomocą języka JavaScript, bez odświeżania okna.

### Co wyzwala zatwierdzenie formularza?

Formularz wysyła zdarzenie `submit` w dwóch typowych sytuacjach:
1. Użytkownik klika przycisk typu submit: `<button type="submit">` lub `<input type="submit">`. Warto pamiętać, że każdy zwykły `<button>` wewnątrz formularza, który nie ma jawnie zdefiniowanego atrybutu `type="button"`, domyślnie zachowuje się jak przycisk wysyłający.
2. Użytkownik naciska klawisz Enter podczas edycji dowolnego jednoliniowego pola tekstowego (`<input type="text">`, `<input type="number">` itp.).

```html
<form id="formularz-kontaktowy">
    <label for="imie">Imię:</label>
    <input type="text" id="imie" name="imie" required>

    <button type="submit" id="btn-wyslij">Zatwierdź</button>
</form>
```

**Po co to jest:**  
Znacznik `<form>` grupuje logicznie powiązane pola danych, umożliwia automatyczną obsługę nawigacji klawiaturą (np. przejście klawiszem Tab i wysłanie klawiszem Enter) oraz stanowi punkt zaczepienia dla procedur walidacyjnych.

**Typowa pomyłka:**  
Projektowanie pól wejściowych luzem w znaczniku `<div>` z przyciskiem nasłuchującym na zdarzenie `click`. Użytkownik traci wówczas możliwość wysłania danych klawiszem Enter, a przeglądarka nie może skorzystać z wbudowanych mechanizmów semantycznych.

---

## 2. Zdarzenie submit i metoda event.preventDefault()

Aby przejąć pełną kontrolę nad procesem wysyłki w JavaScript, nasłuchujemy zdarzenia `submit` na elemencie formularza, a nie zdarzenia `click` na przycisku.

Obiekt zdarzenia (zazwyczaj oznaczany jako `event` lub `e`) przekazywany do funkcji obsługującej zawiera metodę `preventDefault()`. Jej wywołanie informuje silnik przeglądarki, że domyślna akcja powiązana z tym zdarzeniem (czyli wysłanie żądania sieciowego i odświeżenie witryny) ma zostać zablokowana.

```javascript
const formularz = document.querySelector('#formularz-kontaktowy');

formularz.addEventListener('submit', function (event) {
    // 1. Zatrzymanie domyślnego przeładowania strony
    event.preventDefault();

    // 2. Własna logika przetwarzania danych
    console.log('Formularz zatwierdzony bez przeładowania strony.');
});
```

**Po co to jest:**  
Wywołanie `event.preventDefault()` zapobiega utracie stanu aplikacji. Bez tej instrukcji strona przeładowałaby się natychmiast, konsola deweloperska zostałaby wyczyszczona, a użytkownik straciłby wszystkie wpisane dane i wygenerowane wyniki.

**Typowa pomyłka:**  
Przypisywanie zdarzenia `click` do przycisku wysyłającego zamiast zdarzenia `submit` do formularza. Gdy użytkownik zatwierdzi formularz klawiszem Enter, procedura przypięta do `click` w ogóle się nie wykona, a strona ulegnie niepożądanemu przeładowaniu. Inną częstą pomyłką jest zapomnienie o nawiasach wywołania metody, np. napisanie `event.preventDefault;` zamiast `event.preventDefault()`.

---

## 3. Odczyt danych z kontrolek formularza

Po zablokowaniu domyślnej wysyłki przechodzimy do pobrania informacji wprowadzonych przez użytkownika. W JavaScript mamy do dyspozycji dwie główne metody odwoływania się do kontrolek:

### Sposób A: Bezpośrednie selektory DOM (`document.querySelector`)
Pobieramy elementy za pomocą ich identyfikatorów zdefiniowanych w HTML. Jest to podejście zalecane w standardzie INF.03:

```javascript
const poleImie = document.querySelector('#imie');
const wartoscImienia = poleImie.value.trim();
```

### Sposób B: Kolekcja `form.elements`
Obiekt formularza udostępnia właściwość `elements`, która przechowuje referencje do wszystkich kontrolek formularza zindeksowanych według ich atrybutu `name` lub `id`:

```javascript
const imieWartosc = event.target.elements['imie'].value.trim();
```

---

## 4. Przegląd typów kontrolek i ich właściwości

Różne typy elementów wejściowych przechowują stan w odmiennych właściwościach:

### Pola tekstowe (`<input type="text">`, `<input type="email">`, `<input type="password">`, `<textarea>`)
Dane tekstowe odczytujemy z właściwości `.value`. Dobrą praktyką jest natychmiastowe użycie metody `.trim()`, która usuwa przypadkowe białe znaki (spacje, tabulatory) z początku i końca tekstu.

```javascript
const email = document.querySelector('#email').value.trim();
const uwagi = document.querySelector('#uwagi').value.trim();
```

### Pola liczbowe (`<input type="number">`)
Właściwość `.value` zawsze zwraca ciąg znaków (string), nawet jeśli pole jest typu numerycznego. Aby wykonać operacje matematyczne, należy dokonać jawnej konwersji lub użyć właściwości `.valueAsNumber`:

```javascript
const poleIlosc = document.querySelector('#ilosc');

// Sposób 1: konwersja za pomocą konstruktora Number
const ilosc = Number(poleIlosc.value);

// Sposób 2: właściwość wbudowana zwracająca liczbę lub NaN
const iloscLiczba = poleIlosc.valueAsNumber;
```

### Pola wyboru jednokrotnego (`<input type="radio">`) i wielokrotnego (`<input type="checkbox">`)
Pola wyboru nie przechowują swojego zaznaczenia w tekście wartości, lecz we właściwości logicznej `.checked`, która przyjmuje wartość `true` lub `false`:

```javascript
const regulaminAkceptacja = document.querySelector('#regulamin').checked;

if (!regulaminAkceptacja) {
    console.log('Musisz zaakceptować regulamin.');
}
```

Dla grupy przycisków opcji (`radio`) o wspólnym atrybucie `name`, wybraną opcję znajdujemy za pomocą selektora `:checked`:

```javascript
const wybranaOpcja = document.querySelector('input[name="platnosc"]:checked');
if (wybranaOpcja) {
    const metodaPlatnosci = wybranaOpcja.value;
}
```

### Listy rozwijane (`<select>`)
Wartość wybranej opcji `<option>` odczytujemy bezpośrednio z właściwości `.value` elementu nadrzędnego `<select>`:

```javascript
const selectUsluga = document.querySelector('#usluga');
const wybranaUsluga = selectUsluga.value;
```

**Po co to jest:**  
Zrozumienie, która właściwość (`.value`, `.valueAsNumber` czy `.checked`) odpowiada za dany typ kontrolki, umożliwia bezbłędne przetwarzanie danych wejściowych dowolnego formularza.

**Typowa pomyłka:**  
Próba sprawdzenia zaznaczenia pola typu `checkbox` za pomocą `checkbox.value`. Wartość ta niemal zawsze zwraca domyślny ciąg znaków `"on"`, niezależnie od tego, czy pole jest faktycznie zaznaczone, co prowadzi do błędów logicznych. Należy zawsze używać właściwości logicznej `.checked`.

---

## 5. Czyszczenie formularza: metoda form.reset()

Formularz HTML udostępnia wbudowaną metodę `.reset()`, która przywraca wszystkie kontrolki wewnątrz formularza do ich wartości początkowych (domyślnych).

```javascript
const formularz = document.querySelector('#formularz-zamowienia');

// Wyczyszczenie wszystkich pól w formularzu
formularz.reset();
```

**Po co to jest:**  
Metoda `form.reset()` pozwala jednym poleceniem przywrócić czysty stan interfejsu po pomyślnym zatwierdzeniu danych, bez konieczności ręcznego przypisywania pustego ciągu `pole.value = ''` do każdego elementu z osobna.

**Typowa pomyłka:**  
Mylenie metody JavaScript `formularz.reset()` ze zdarzeniem `reset`. Metoda wywołuje zresetowanie pól. Ponadto, wywołanie `form.reset()` czyści wyłącznie wartości kontrolek formularza, ale nie usuwa wygenerowanych wcześniej komunikatów tekstowych w elementach `<div>` czy `<p>` poza formularzem — te komunikaty należy wyczyścić w kodzie ręcznie.

---

## 6. Podstawowa walidacja danych przy wysyłce

Zanim dane zostaną przetworzone i wyświetlone w podsumowaniu, należy upewnić się, że spełniają podstawowe kryteria formalne:
1. Pola wymagane nie mogą być puste po odcięciu spacji (`wartosc.trim() === ''`).
2. Wartości liczbowe muszą być prawidłowe (`!isNaN(liczba)` oraz np. `liczba > 0`).
3. Wymagane zgody prawne i regulaminy muszą być zaznaczone (`checkbox.checked === true`).

Przykładowa funkcja obsługi z walidacją:

```javascript
const formularz = document.querySelector('#formularz-rejestracji');
const wynikKomunikat = document.querySelector('#wynik');

formularz.addEventListener('submit', function (event) {
    event.preventDefault();

    const imie = document.querySelector('#imie').value.trim();
    const ilosc = Number(document.querySelector('#ilosc').value);
    const regulamin = document.querySelector('#regulamin').checked;

    // Tablica na komunikaty błędów
    const bledy = [];

    if (imie === '') {
        bledy.push('Pole imię nie może być puste.');
    }

    if (isNaN(ilosc) || ilosc <= 0) {
        bledy.push('Ilość musi być liczbą większą od zera.');
    }

    if (!regulamin) {
        bledy.push('Wymagana jest akceptacja regulaminu.');
    }

    if (bledy.length > 0) {
        wynikKomunikat.className = 'blad-walidacji';
        wynikKomunikat.innerHTML = bledy.join('<br>');
    } else {
        wynikKomunikat.className = 'sukces-walidacji';
        wynikKomunikat.textContent = `Formularz wysłany poprawnie. Witaj, ${imie}!`;
        formularz.reset();
    }
});
```

**Po co to jest:**  
Zatrzymanie przetwarzania niepełnych lub błędnych danych chroni aplikację przed błędami logicznymi i daje użytkownikowi natychmiastową, jasną informację, które elementy wymagają poprawy.

**Typowa pomyłka:**  
Sprawdzanie obecności tekstu wyłącznie warunkiem `if (imie.value == null)` lub brak użycia metody `.trim()`. Jeśli użytkownik wpisze w polu same spacje, warunek `if (imie.value === '')` bez `.trim()` uzna pole za wypełnione.

---

## 7. Standard wypisu na stronę i kontrakt DOM w Semestrze 4

W semestrze 4 obowiązuje pełna manipulacja drzewem DOM, ukierunkowana na obsługę formularzy i prezentację dynamicznych danych. 

Zgodnie ze standardem egzaminacyjnym INF.03 stosujemy następujący kontrakt identyfikatorów i klas:

### Standardowe identyfikatory kontrolek wejściowych:
- `#imie`, `#nazwisko`, `#email`, `#haslo`, `#telefon`, `#kod-pocztowy`, `#pesel`
- `#usluga`, `#ilosc`, `#regulamin`
- Przyciski funkcyjne: `#btn-zapisz`, `#btn-oblicz`, `#btn-resetuj`, `#btn-wyslij`

### Standardowe identyfikatory elementów wynikowych:
- `#wynik` — główny blok informacji zwrotnej lub kalkulacji.
- `#podsumowanie` — zestawienie wprowadzonych danych.
- `#komunikat-blad` / `#komunikat-sukces` — dedykowane bloki powiadomień.
- `#lista-zamowien`, `#tabela-danych` — kontenery do prezentacji wieloelementowej.

### Standardowe klasy stylizujące stan:
- `.ukryty` — ukrycie elementu w CSS (`display: none;`).
- `.blad-walidacji` — oznaczenie pola lub komunikatu o błędzie (np. czerwona ramka, czerwony tekst).
- `.sukces-walidacji` — oznaczenie poprawnego zatwierdzenia (np. zielony tekst).
- `.aktywny` — wyróżnienie elementu aktywnego.

Prezentacja wyniku odbywa się poprzez modyfikację właściwości `.textContent` (dla bezpiecznego tekstu niesformatowanego) lub `.innerHTML` (gdy tworzymy sformatowane listy lub wiersze tabeli).
