# Podręcznik: Tablice dwuwymiarowe (2D) i macierze w JavaScript

Witaj w module poświęconym strukturom wielowymiarowym w języku JavaScript! Do tej pory pracowałeś z tablicami jednowymiarowymi — przypominały one pojedynczy rząd szafek szkolnych lub listę zakupów. 

W rzeczywistych projektach informatycznych dane rzadko układają się w jedną linię. Zdecydowanie częściej spotkasz się z danymi tabelarycznymi: arkuszami ocen, siatkami pikseli na ekranie, planszami do gier (szachy, kółko i krzyżyk), kalendarzami czy wielopoziomowymi stanami magazynowymi. Do reprezentacji takich struktur służą **tablice dwuwymiarowe (tablice 2D / macierze)**.

---

## 1. Dlaczego pojedyncza tablica nie wystarcza? (Problem inżynierski)

Wyobraź sobie, że piszesz system dla hurtowni komputerowej, która posiada 3 regały magazynowe, a na każdym z nich znajdują się 4 półki z towarem. 

Gdybyś próbował zapisać to w jednej tablicy:
```javascript
const magazyn = [12, 5, 8, 14, 3, 0, 19, 7, 22, 15, 6, 11];
```
Musiałbyś ręcznie przeliczać matematycznie, pod którym indeksem leży regał nr 2 i półka nr 3:
$$\text{indeks} = \text{nr\_regału} \cdot 4 + \text{nr\_półki}$$
Taki kod jest nieczytelny, podatny na błędy przesunięcia o jeden (*off-by-one error*) i niezwykle trudny w utrzymaniu.

Rozwiązaniem jest **tablica tablic** — czyli struktura, w której każdy element tablicy zewnętrznej jest osobną, wewnętrzną tablicą reprezentującą jeden wiersz.

---

## 2. Architektura tablicy 2D: Wiersze i Kolumny

W języku JavaScript nie istnieje specjalne słowo kluczowe `matrix` ani typ `Array2D`. Tablica dwuwymiarowa to po prostu zwykła tablica, której elementami są inne tablice:

```javascript
const magazyn = [
  [12, 5, 8, 14],  // Wiersz 0 (Regał 0): 4 półki (kolumny 0, 1, 2, 3)
  [3, 0, 19, 7],   // Wiersz 1 (Regał 1): 4 półki (kolumny 0, 1, 2, 3)
  [22, 15, 6, 11]  // Wiersz 2 (Regał 2): 4 półki (kolumny 0, 1, 2, 3)
];
```

Wizualizacja pamięciowa:

```text
               Kolumna 0   Kolumna 1   Kolumna 2   Kolumna 3
             ┌───────────┬───────────┬───────────┬───────────┐
  Wiersz 0   │    12     │     5     │     8     │    14     │
             ├───────────┼───────────┼───────────┼───────────┤
  Wiersz 1   │     3     │     0     │    19     │     7     │
             ├───────────┼───────────┼───────────┼───────────┤
  Wiersz 2   │    22     │    15     │     6     │    11     │
             └───────────┴───────────┴───────────┴───────────┘
```

> **Po co to jest?**
> Uporządkowanie danych w macierz pozwala zachować naturalną topologię przestrzenną problemu. Kod odzwierciedla układ fizyczny regałów, sali kinowej czy planszy.
>
> **Typowa pomyłka:**
> Zapominanie o przecinkach oddzielających wewnętrzne tablice w definicji literału `[[...], [...], [...]]`. Brak przecinka po nawiasie zamykającym `]` powoduje błąd składni `SyntaxError: Unexpected token '['`.

---

## 3. Podwójne indeksowanie: Odczyt i modyfikacja komórek

Aby sięgnąć po konkretną liczbę w siatce, stosujemy dwa kolejne nawiasy kwadratowe:
$$\text{tablica}[\text{indeksWiersza}][\text{indeksKolumny}]$$

1. **Pierwszy indeks (`tablica[w]`)** — wybiera wiersz (całą tablicę wewnętrzną).
2. **Drugi indeks (`...[k]`)** — wybiera komórkę wewnątrz tego wybranego wiersza.

### Przykład odczytu:
```javascript
// Chcemy pobrać stan towaru z Regału 1, Półki 2:
const stan = magazyn[1][2]; // Zwraca 19
console.log(stan);
```

### Przykład modyfikacji:
```javascript
// Na Regał 1, Półkę 1 przyjechała dostawa 10 sztuk towaru (wcześniej było 0):
magazyn[1][1] = 10;
console.log(magazyn[1][1]); // Zwraca 10
```

### Wymiary macierzy:
- Liczba wierszy: `magazyn.length` (tutaj: 3).
- Liczba kolumn w wierszu 0: `magazyn[0].length` (tutaj: 4).

> **Po co to jest?**
> Dostęp do komórki w czasie stałym $O(1)$ pozwala błyskawicznie aktualizować stan dowolnego punktu w układzie bez konieczności przeszukiwania całej tablicy pętlą.
>
> **Typowa pomyłka:**
> Odwrócenie kolejności indeksów: zapis `magazyn[kolumna][wiersz]`. Pamiętaj regułę: **najpierw poziomo (wiersz), potem pionowo (kolumna)**. Jeśli napiszesz `magazyn[3][1]`, JavaScript spróbuje odczytać wiersz o indeksie 3 (którego nie ma), co zwróci `undefined`, a kolejna próba `undefined[1]` zakończy się błędem krytycznym: `TypeError: Cannot read properties of undefined (reading '1')`.

---

## 4. Przeglądanie macierzy: Podwójna pętla `for`

Aby wyświetlić lub przetworzyć wszystkie komórki tablicy 2D, musimy zastosować **pętlę zagnieżdżoną (pętlę w pętli)**:
- **Pętla zewnętrzna (`w`)** — odpowiada za przechodzenie od wiersza 0 do ostatniego wiersza.
- **Pętla wewnętrzna (`k`)** — dla każdego bieżącego wiersza przechodzi przez wszystkie jego kolumny.

```javascript
const plansza = [
  ["A", "B", "C"],
  ["D", "E", "F"]
];

let raport = "";

for (let w = 0; w < plansza.length; w++) {
  for (let k = 0; k < plansza[w].length; k++) {
    raport += `Pozycja [${w}][${k}] = ${plansza[w][k]}\n`;
  }
}

document.getElementById("wynik").textContent = raport;
```

> **Po co to jest?**
> Podwójna pętla pozwala zautomatyzować przetwarzanie dowolnie dużych zbiorów danych (np. macierz 100x100) przy użyciu kilku linijek czytelnego kodu.
>
> **Typowa pomyłka:**
> Użycie w warunku pętli wewnętrznej `k < plansza.length` zamiast `k < plansza[w].length`. Jeśli macierz nie jest kwadratowa (np. ma 2 wiersze i 5 kolumn), pętla wewnętrzna zatrzyma się za wcześnie i pominie kolumny od indeksu 2 wzwyż!

---

## 5. Agregacja danych: Sumy cząstkowe wierszy a suma łączna

Jednym z najważniejszych zagadnień egzaminacyjnych w kwalifikacji INF.03 jest obliczanie sum lub średnich dla poszczególnych rzędów danych (np. utarg każdego sprzedawcy, suma punktów każdego ucznia).

### Kluczowa reguła architektury pętli:
- **Zmienna sumy łącznej (`lacznaSuma`)** musi być zadeklarowana **przed obiema pętlami**.
- **Zmienna sumy pojedynczego wiersza (`sumaWiersza`)** musi być zerowana **wewnątrz pętli zewnętrznej**, tuż przed wejściem do pętli wewnętrznej!

```javascript
const punktyUczniow = [
  [15, 20, 18], // Uczeń 1
  [12, 14, 10], // Uczeń 2
  [25, 22, 24]  // Uczeń 3
];

let lacznaSumaWszystkich = 0;
let raportWynikow = "ZESTAWIENIE PUNKTACJI UCZNIÓW:\n";
raportWynikow += "---------------------------------\n";

for (let w = 0; w < punktyUczniow.length; w++) {
  let sumaUcznia = 0; // KRYTYCZNE ZEROWANIE PRZED KAŻDYM WIERSZEM

  for (let k = 0; k < punktyUczniow[w].length; k++) {
    sumaUcznia += punktyUczniow[w][k];
  }

  lacznaSumaWszystkich += sumaUcznia;
  const srednia = (sumaUcznia / punktyUczniow[w].length).toFixed(2);
  raportWynikow += `Uczeń nr ${w + 1}: ${sumaUcznia} pkt (średnia: ${srednia})\n`;
}

raportWynikow += "---------------------------------\n";
raportWynikow += `Łącznie zdobytych punktów: ${lacznaSumaWszystkich} pkt`;

document.getElementById("wynik").textContent = raportWynikow;
```

> **Po co to jest?**
> Umieszczenie deklaracji `let sumaUcznia = 0;` wewnątrz pętli zewnętrznej sprawia, że przy przejściu do kolejnego ucznia licznik startuje od czystego zera, gwarantując rzetelność obliczeń cząstkowych.
>
> **Typowa pomyłka:**
> Zadeklarowanie `let sumaUcznia = 0;` na samym początku skryptu (przed pętlami). Wtedy uczeń nr 2 otrzyma punkty swoje ORAZ ucznia nr 1, a uczeń nr 3 sumę wszystkich trzech, co całkowicie fałszuje raport!

---

## 6. Przetwarzanie kolumnowe (Agregacja w pionie)

Czasami zadanie wymaga zsumowania danych pionowo — na przykład policzenia łącznego utargu w poniedziałki ze wszystkich sklepów:
- Wtedy pętla zewnętrzna iteruje po kolumnach (`k`),
- A pętla wewnętrzna iteruje po wierszach (`w`), pobierając komórkę `macierz[w][k]`.

```javascript
const sprzedazDni = [
  [100, 200, 150], // Sklep 1: Pon, Wt, Śr
  [300, 100, 250]  // Sklep 2: Pon, Wt, Śr
];

const liczbaDni = sprzedazDni[0].length;
let raportDni = "UTARG DZIENNY CAŁEJ SIECI:\n";

for (let k = 0; k < liczbaDni; k++) {
  let sumaDnia = 0;
  for (let w = 0; w < sprzedazDni.length; w++) {
    sumaDnia += sprzedazDni[w][k];
  }
  raportDni += `Dzień nr ${k + 1}: ${sumaDnia} zł\n`;
}
```

---

## 7. Wyszukiwanie wartości skrajnych (Min / Max) w macierzy

Aby znaleźć najwyższą lub najniższą wartość w całej tablicy 2D:
1. Inicjalizujemy zmienną `max = -Infinity` (lub wartością pierwszej komórki `macierz[0][0]`).
2. W podwójnej pętli porównujemy każdą komórkę z dotychczasowym rekordem.
3. Jeśli komórka jest większa, aktualizujemy `max` oraz zapamiętujemy jej współrzędne `[w][k]`.

```javascript
let maxWartosc = -Infinity;
let wierszMax = -1;
let kolumnaMax = -1;

for (let w = 0; w < macierz.length; w++) {
  for (let k = 0; k < macierz[w].length; k++) {
    if (macierz[w][k] > maxWartosc) {
      maxWartosc = macierz[w][k];
      wierszMax = w;
      kolumnaMax = k;
    }
  }
}
```

---

## 8. Standard wyjścia danych w Semestrze 2

Zgodnie z rygorem metodycznym Semestru 2 kwalifikacji INF.03:
1. Wyniki prezentujemy wyłącznie w elemencie wyjściowym:
   ```javascript
   document.getElementById("wynik").textContent = raportTekstowy;
   ```
2. Wszystkie przejścia linii realizujemy znakiem nowego wiersza `\n`.
3. Odstępy i wyrównanie kolumn w raportach tabelarycznych formatujemy metodą `String.prototype.padEnd()` lub `padStart()` (np. `nazwa.padEnd(16, " ")`).
4. W arkuszu stylów CSS element wyjściowy posiada regułę:
   ```css
   #wynik {
     white-space: pre-wrap;
     font-family: Consolas, monospace;
   }
   ```
   Dzięki temu przeglądarka renderuje tekst dokładnie w takim układzie kolumn, w jakim został sformatowany w skrypcie JS.
