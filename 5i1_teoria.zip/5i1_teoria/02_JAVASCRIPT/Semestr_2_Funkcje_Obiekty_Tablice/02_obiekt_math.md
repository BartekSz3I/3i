# Teoria: Obiekt wbudowany Math w języku JavaScript (INF.03 Semestr 2)

Podręcznik metodyczny dla uczniów technikum informatycznego i programistycznego. Omawia strukturę statycznego obiektu `Math`, stałe matematyczne, metody zaokrąglania, operacje algebraiczne, generowanie liczb losowych oraz dobre praktyki czystej architektury funkcji.

---

## 1. Wprowadzenie — Czym jest obiekt Math?

W języku JavaScript obiekt `Math` jest **wbudowanym obiektem globalnym**, który udostępnia zestaw stałych matematycznych oraz funkcji obliczeniowych. W przeciwieństwie do innych obiektów (np. `Date` czy własnych klas), obiekt `Math` **nie jest funkcją konstruktora**. Oznacza to, że nie tworzy się jego instancji za pomocą słowa kluczowego `new`:

```javascript
// BŁĄD SKŁADNIOWY/LOGICZNY:
// let m = new Math(); // TypeError: Math is not a constructor

// POPRAWNE UŻYCIE (metody statyczne):
let promien = 5;
let poleKola = Math.PI * Math.pow(promien, 2);
```

Wszystkie właściwości i metody obiektu `Math` wywołuje się bezpośrednio z jego przestrzeni nazw: `Math.nazwaMetody(...)`.

> **Po co to jest:** Zapewnia scentralizowany, szybki i zoptymalizowany silnik obliczeniowy dostępny natywnie w każdym środowisku JavaScript (przeglądarka, Node.js) bez potrzeby importowania zewnętrznych bibliotek.
>
> **Typowa pomyłka:** Próba wywołania funkcji `round(4.5)` lub `sqrt(16)` bez przedrostka `Math.`. JavaScript rzuci wówczas błąd `ReferenceError: round is not defined`.

---

## 2. Stałe matematyczne

Obiekt `Math` udostępnia niemutowalne stałe numeryczne o podwójnej precyzji:

| Właściwość | Przybliżona wartość | Zastosowanie inżynierskie |
| :--- | :--- | :--- |
| `Math.PI` | `3.141592653589793` | Obliczenia geometrii kół, walców, fal elektromagnetycznych |
| `Math.E` | `2.718281828459045` | Podstawa logarytmu naturalnego, wzrost wykładniczy, tłumienie sygnałów |
| `Math.LN2` | `0.6931471805599453` | Logarytm naturalny z 2, algorytmy binarne i czas połowicznego rozpadu |
| `Math.LN10` | `2.302585092994046` | Logarytm naturalny z 10, skalowanie decybelowe (dB) |
| `Math.SQRT2` | `1.4142135623730951` | Pierwiastek kwadratowy z 2, formaty papieru ISO (A4) i napięcia skuteczne |

```javascript
function obliczObwodOkregu(promien) {
  return 2 * Math.PI * promien;
}

let obwod = obliczObwodOkregu(10); // ok. 62.83185307179586
```

> **Po co to jest:** Chroni przed wpisywaniem ręcznych przybliżeń (np. `let pi = 3.14`), które wprowadzają błędy zaokrągleń w złożonych obliczeniach inżynierskich i geodezyjnych.
>
> **Typowa pomyłka:** Próba nadpisania stałej `Math.PI = 3;`. Właściwość ta jest tylko do odczytu (`read-only`), więc przypisanie w trybie ścisłym (`use strict`) rzuci błąd lub zostanie zignorowane.

---

## 3. Metody zaokrąglania liczb zmiennoprzecinkowych

Zaokrąglanie wartości jest jedną z najczęstszych operacji w arkuszach egzaminacyjnych CKE oraz aplikacjach biznesowych. JavaScript oferuje 4 odmienne metody:

```
Liczba:     -3.7   -3.2    3.2    3.7
--------------------------------------
Math.round:   -4     -3      3      4   (do najbliższej całkowitej, .5 w górę)
Math.floor:   -4     -4      3      3   (w dół — w stronę -nieskończoności)
Math.ceil:    -3     -3      4      4   (w górę — w stronę +nieskończoności)
Math.trunc:   -3     -3      3      3   (obcięcie części ułamkowej ku zeru)
```

### 3.1 `Math.round(x)` — Zaokrąglenie arytmetyczne
Zaokrągla do najbliższej liczby całkowitej. Jeśli część ułamkowa wynosi dokładnie `0.5`, zaokrągla w kierunku dodatniej nieskończoności:
```javascript
Math.round(4.4); // 4
Math.round(4.5); // 5
Math.round(-4.5); // -4 (uwaga: w kierunku dodatnim!)
Math.round(-4.51); // -5
```

### 3.2 `Math.floor(x)` — Zaokrąglenie w dół (podłoga)
Zwraca największą liczbę całkowitą mniejszą lub równą argumentowi:
```javascript
Math.floor(4.9); // 4
Math.floor(-4.1); // -5 (zawsze w dół osi liczbowej!)
```

### 3.3 `Math.ceil(x)` — Zaokrąglenie w górę (sufit)
Zwraca najmniejszą liczbę całkowitą większą lub równą argumentowi. Kluczowa przy kalkulacji zasobów (np. liczba palet, opakowań, stron wyników):
```javascript
Math.ceil(4.1); // 5
Math.ceil(-4.9); // -4
```

### 3.4 `Math.trunc(x)` — Obcięcie części ułamkowej
Usuwa część dziesiętną bez względu na znak liczby (zwraca samą część całkowitą):
```javascript
Math.trunc(4.9); // 4
Math.trunc(-4.9); // -4
```

> **Po co to jest:** Precyzyjne sterowanie logiką pakowania i naliczania opłat. Jeżeli klient kupuje 11 licencji w paczkach po 5, użycie `Math.ceil(11 / 5)` da wymaganą liczbę 3 paczek. Użycie `Math.round` dałoby błędne 2 paczki (brak licencji dla 1 użytkownika!).
>
> **Typowa pomyłka:** Stosowanie `Math.floor` zamiast `Math.trunc` dla liczb ujemnych. Dla długu `-4.1` zł, `Math.floor` daje `-5`, natomiast `Math.trunc` daje `-4`.

---

## 4. Ekstrema i wartości skrajne: `Math.min()` i `Math.max()`

Metody `Math.min()` i `Math.max()` przyjmują dowolną liczbę argumentów liczbowych i zwracają odpowiednio najmniejszą lub największą wartość:

```javascript
let najnizsza = Math.min(12, 5, 89, -3, 24); // -3
let najwyzsza = Math.max(12, 5, 89, -3, 24); // 89
```

### Wzorzec: Ograniczanie wartości (Clamping)
Częstym zadaniem w programowaniu jest utrzymanie wartości w bezpiecznym zakresie `[min, max]`, np. jasność ekranu od 0 do 100:

```javascript
function ograniczZakres(wartosc, min, max) {
  return Math.min(Math.max(wartosc, min), max);
}

let wynik1 = ograniczZakres(120, 0, 100); // 100
let wynik2 = ograniczZakres(-15, 0, 100); // 0
let wynik3 = ograniczZakres(45, 0, 100);  // 45
```

> **Po co to jest:** Zapobiega przekroczeniu parametrów technicznych urządzeń (np. przeciążenie przetwornika, prędkość obrotowa, skrajne współrzędne ekranu).
>
> **Typowa pomyłka:** Wywołanie `Math.min()` bez argumentów zwraca `Infinity`, a `Math.max()` bez argumentów zwraca `-Infinity`. Jeżeli którykolwiek z argumentów nie jest liczbą i nie da się go skonwertować, wynikiem będzie `NaN`.

---

## 5. Potęgowanie, pierwiastkowanie i wartość bezwzględna

### 5.1 `Math.abs(x)` — Wartość bezwzględna (moduł)
Zwraca dodatnią odległość liczby od zera. Przydatna przy liczeniu odchyłek, błędów pomiarowych i różnic temperatur:
```javascript
function obliczRozniceTemperatur(t1, t2) {
  return Math.abs(t1 - t2);
}
let delta = obliczRozniceTemperatur(21.5, 24.8); // 3.3
```

### 5.2 `Math.pow(podstawa, wykladnik)` oraz operator `**`
Podnosi podstawę do danej potęgi:
```javascript
let potega = Math.pow(2, 8); // 256
let potegaOperator = 2 ** 8; // 256
```

### 5.3 `Math.sqrt(x)` — Pierwiastek kwadratowy
Zwraca pierwiastek kwadratowy liczby. Dla liczb ujemnych zwraca `NaN`:
```javascript
function obliczPrzekatnaProstokata(a, b) {
  return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
}
let przekatna = obliczPrzekatnaProstokata(3, 4); // 5
```

> **Po co to jest:** Niezbędne w twierdzeniu Pitagorasa, obliczaniu odległości euklidesowej w przestrzeni, wyliczaniu odchylenia standardowego i praw fizyki.
>
> **Typowa pomyłka:** Przekazanie liczby ujemnej do `Math.sqrt(-9)`, co daje `NaN`. W kodzie zawsze należy sprawdzić znak argumentu lub zastosować `Math.sqrt(Math.abs(x))`.

---

## 6. Generowanie liczb pseudolosowych: `Math.random()`

Metoda `Math.random()` zwraca liczbę pseudolosową zmiennoprzecinkową z przedziału **lewostronnie domkniętego, prawostronnie otwartego**:
$$\text{wynik} \in [0, 1) \quad (0 \le x < 1)$$

Oznacza to, że metoda może zwrócić dokładnie `0`, ale **nigdy nie zwróci dokładnie `1`**.

### Kanoniczny wzorzec losowania liczby całkowitej z przedziału `[min, max]`
Aby wylosować liczbę całkowitą z domkniętego przedziału od `min` do `max` włącznie (np. rzut kostką `[1, 6]`):

```javascript
function losujCalkowita(min, max) {
  // Rozpiętość przedziału to (max - min + 1)
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

let oczkaKostki = losujCalkowita(1, 6);
let kodAutoryzacji = losujCalkowita(1000, 9999);
```

### Wyjaśnienie matematyczne krok po kroku:
1. `Math.random()` $\to [0, 1)$
2. `Math.random() * 6` $\to [0, 6)$ (maksymalnie np. `5.999999...`)
3. `Math.floor(Math.random() * 6)` $\to$ liczby całkowite `{0, 1, 2, 3, 4, 5}`
4. `+ 1` $\to$ przesunięcie przedziału do `{1, 2, 3, 4, 5, 6}`

> **Po co to jest:** Kluczowe w generowaniu kodów PIN, symulacjach testowych, losowaniu próbek do badania jakości oraz grach logicznych.
>
> **Typowa pomyłka:** Użycie `Math.round(Math.random() * (max - min)) + min`. Zastosowanie `round` powoduje, że skrajne wartości `min` i `max` mają **dwukrotnie mniejsze prawdopodobieństwo** wylosowania niż wartości środkowe! Zawsze należy stosować `Math.floor` z mnożnikiem `(max - min + 1)`.

---

## 7. Rygory architektoniczne i zasady M10–M12 w Semestrze 2

Przy pisaniu skryptów w tym dziale obowiązują żelazne zasady standardu edukacyjnego:

1. **Czysta architektura funkcji (Zasada M11):**
   * Funkcja jest samowystarczalnym blokiem logicznym. Wszystkie zmienne wejściowe otrzymuje **wyłącznie przez nawias argumentów**.
   * Obowiązuje **bezwzględny zakaz wywoływania `prompt()` wewnątrz ciała funkcji!**
   * Funkcja zwraca rezultat przez `return`.
   * Interakcję z użytkownikiem (`prompt(...)` z wartością domyślną i konwersją `Number()`) prowadzimy w kodzie głównym skryptu.
2. **Prezentacja danych:**
   * Wynik zapisujemy do właściwości `.textContent` elementu `#wynik`.
   * Wielowierszowe tabele i zestawienia formatujemy za pomocą znaków nowej linii `\n`.
   * W arkuszu CSS kontener `#wynik` ma nadaną regułę `white-space: pre-wrap; font-family: monospace;`.
3. **Czyste nagłówki (Zasada M10):**
   * Tytuły `<h1>` i `<title>` mają charakter czysto inżynierski i biznesowy (bez prefiksów `Zadanie X` ani żargonu egzaminacyjnego CKE).
4. **Ciemny motyw Dark Theme (Zasada M12):**
   * Laboratoria 1–7 i sprawdziany stosują motyw deweloperski (`#0b0f19` / `#1e293b`), natomiast zadanie 8 Capstone zachowuje jasny motyw portalu `IT-Partner PRO`.
