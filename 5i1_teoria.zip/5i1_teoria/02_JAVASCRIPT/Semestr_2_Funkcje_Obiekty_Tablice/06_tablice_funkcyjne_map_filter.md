# Podręcznik: Nowoczesne metody funkcyjne tablic w JavaScript

Witaj w module poświęconym funkcyjnym metodom przetwarzania tablic w języku JavaScript. Poznasz techniki, które stanowią standard współczesnego programowania frontendowego i backendowego: metody wyższego rzędu takie jak `forEach`, `map`, `filter` oraz `reduce`.

Dzięki nim Twój kod stanie się bardziej zwięzły, czytelny i mniej podatny na błędy indeksowania.

---

## 1. Paradygmat funkcyjny a podejście imperatywne

Do tej pory, aby przetworzyć kolekcję danych, stosowaliśmy podejście **imperatywne** za pomocą klasycznej pętli `for` lub `while`. W podejściu imperatywnym programista musi precyzyjnie zarządzać każdym krokiem wykonania:
1. Zainicjalizować zmienną indeksu (`let i = 0`).
2. Zdefiniować warunek zatrzymania (`i < tablica.length`).
3. Zwiększać indeks w każdym kroku (`i++`).
4. Utworzyć osobną tablicę wynikową i ręcznie dodawać do niej elementy (`wynik.push(...)`).

```javascript
// Podejście imperatywne (klasyczne)
const cenyNetto = [100, 250, 400];
const cenyBrutto = [];

for (let i = 0; i < cenyNetto.length; i++) {
  cenyBrutto.push(cenyNetto[i] * 1.23);
}
```

W podejściu **deklaratywnym (funkcyjnym)** opisujemy **co** chcemy osiągnąć, zamiast **jak** krok po kroku sterować wskaźnikiem:

```javascript
// Podejście deklaratywne (funkcyjne)
const cenyNetto = [100, 250, 400];
const cenyBrutto = cenyNetto.map(cena => cena * 1.23);
```

> **Po co to jest?**
> Kod funkcyjny eliminuje ryzyko typowych błędów typu *off-by-one* (pomyłki o jeden element przy warunku `i <= tablica.length`) oraz odciąża programistę z zarządzania tymczasowymi zmiennymi sterującymi.
>
> **Typowa pomyłka:**
> Próba ręcznego inkrementowania indeksu wewnątrz metod funkcyjnych lub modyfikowanie tablicy wejściowej podczas jej iterowania.

---

## 2. Funkcje zwrotne (Callback) i funkcje strzałkowe (Arrow Functions)

Każda z omawianych metod tablicowych jest **funkcją wyższego rzędu** — oznacza to, że jako argument przyjmuje inną funkcję, zwaną **funkcją zwrotną (callback)**.

JavaScript wywołuje przekazaną funkcję automatycznie dla każdego elementu tablicy, przekazując do niej parametry:
1. `element` – bieżący element tablicy.
2. `indeks` – opcjonalny indeks bieżącego elementu (od 0 do length - 1).
3. `tablica` – opcjonalna referencja do całej przetwarzanej tablicy.

### Zapis tradycyjny a zapis strzałkowy
Wszystkie poniższe zapisy działają identycznie, jednak standardem branżowym jest zwięzła funkcja strzałkowa:

```javascript
const liczby = [1, 2, 3];

// 1. Z tradycyjną funkcją anonimową:
const podwojone1 = liczby.map(function(x) {
  return x * 2;
});

// 2. Z funkcją strzałkową z jawnym return:
const podwojone2 = liczby.map((x) => {
  return x * 2;
});

// 3. Ze skróconą funkcją strzałkową (niejawny return):
const podwojone3 = liczby.map(x => x * 2);
```

> **Po co to jest?**
> Skrócony zapis strzałkowy `x => x * 2` pozwala zapisać całą transformację w jednej linijce bez zbędnych klamer i słowa `return`.
>
> **Typowa pomyłka:**
> Postawienie nawiasów klamrowych `{}` w funkcji strzałkowej i zapomnienie o słowie kluczowym `return`:  
> `liczby.map(x => { x * 2 })` $\to$ zwróci tablicę `[undefined, undefined, undefined]`!

---

## 3. Przeglądanie elementów: metoda `.forEach()`

Metoda `.forEach()` służy do wykonania określonej operacji dla każdego elementu tablicy. **Nie zwraca żadnej wartości** (zwraca `undefined`).

```javascript
const kursanci = ["Anna", "Bartek", "Celina"];

kursanci.forEach((imie, indeks) => {
  console.log(`${indeks + 1}. ${imie}`);
});
```

> **Po co to jest?**
> Używaj `.forEach()`, gdy chcesz wywołać efekt uboczny (np. wypisać dane do konsoli, zsumować wartości do zewnętrznej zmiennej lub zbudować raport tekstowy).
>
> **Typowa pomyłka:**
> Przypisywanie wyniku `.forEach()` do nowej zmiennej w oczekiwaniu nowej tablicy (`const wynik = tab.forEach(...)` zawsze przypisze `undefined`). Jeśli potrzebujesz nowej tablicy z przetworzonymi danymi, użyj `.map()`.

---

## 4. Transformacja danych: metoda `.map()`

Metoda `.map()` tworzy **nową tablicę** o dokładnie takiej samej liczbie elementów jak tablica wejściowa, w której każdy element jest rezultatem wywołania funkcji zwrotnej.

```javascript
const temperaturyC = [0, 15, 25, 30];

// Przeliczenie stopni Celsjusza na Fahrenheita (C * 1.8 + 32)
const temperaturyF = temperaturyC.map(temp => temp * 1.8 + 32);
// Wynik: [32, 59, 77, 86]
```

### Ekstrakcja danych z rekordów obiektowych
Gdy pracujemy z tablicą rekordów (np. cennikiem lub bazą produktów), `.map()` idealnie nadaje się do wyciągnięcia pojedynczej właściwości:

```javascript
const produkty = [
  { nazwa: "Klawiatura", cena: 120 },
  { nazwa: "Mysz", cena: 60 },
  { nazwa: "Monitor", cena: 800 }
];

const cennikTekstowy = produkty.map(prod => `${prod.nazwa}: ${prod.cena} zł`);
```

> **Po co to jest?**
> `.map()` pozwala na czystą transformację danych z formatu surowego na format prezentacyjny lub obliczeniowy bez modyfikowania tablicy źródłowej.
>
> **Typowa pomyłka:**
> Używanie `.map()` do filtrowania elementów — jeśli funkcja zwrotna nie zwróci wartości dla danego elementu, w wynikowej tablicy pojawi się `undefined`, a rozmiar tablicy nie ulegnie zmniejszeniu.

---

## 5. Wybieranie elementów: metoda `.filter()`

Metoda `.filter()` tworzy **nową tablicę**, zawierającą wyłącznie te elementy tablicy źródłowej, dla których funkcja zwrotna zwróciła wartość logiczną `true`. Jeśli żaden element nie spełnia warunku, metoda zwraca pustą tablicę `[]`.

```javascript
const oceny = [2, 5, 3, 4, 1, 6, 2];

// Wybór ocen pozytywnych (ocena >= 2)
const pozytywne = oceny.filter(ocena => ocena >= 2);

// Wybór ocen niedostatecznych
const jedynki = oceny.filter(ocena => ocena === 1);
```

### Filtrowanie obiektów
```javascript
const bilety = [
  { relacja: "Kraków - Warszawa", ulgowy: true, cena: 45 },
  { relacja: "Kraków - Katowice", ulgowy: false, cena: 24 },
  { relacja: "Kraków - Gdańsk", ulgowy: true, cena: 85 }
];

const biletyUlgowe = bilety.filter(bilet => bilet.ulgowy === true);
```

> **Po co to jest?**
> `.filter()` pozwala na precyzyjną selekcję rekordów w systemach wyszukiwania, tabelach i cennikach bez potrzeby pisania instrukcji warunkowych `if` wewnątrz pętli.
>
> **Typowa pomyłka:**
> Zwracanie przekształconej wartości zamiast wartości logicznej (`true`/`false`) w funkcji zwrotnej.

---

## 6. Wyszukiwanie pojedyncze i weryfikacja: `.find()`, `.findIndex()`, `.some()`, `.every()`

W sytuacjach, w których nie potrzebujemy całej tablicy, a jedynie pojedynczej informacji, stosujemy wyspecjalizowane metody przeszukujące:

### A. `.find()` – pierwszy pasujący element
Zwraca **pierwszy element**, który spełnia warunek. Jeśli żaden element nie spełnia warunku, zwraca `undefined`.
```javascript
const pracownicy = [
  { id: 101, nazwisko: "Nowak", dzial: "IT" },
  { id: 102, nazwisko: "Kowalski", dzial: "Sprzedaż" },
  { id: 103, nazwisko: "Wiśniewska", dzial: "IT" }
];

const pierwszyZIT = pracownicy.find(p => p.dzial === "IT");
// Wynik: { id: 101, nazwisko: "Nowak", dzial: "IT" }
```

### B. `.findIndex()` – indeks pierwszego pasującego elementu
Zwraca indeks elementu (od 0 do length - 1) lub liczbę `-1`, jeśli elementu nie odnaleziono.
```javascript
const indeksKowalskiego = pracownicy.findIndex(p => p.id === 102); // 1
const brakujacy = pracownicy.findIndex(p => p.id === 999);         // -1
```

### C. `.some()` – czy chociaż jeden element spełnia warunek?
Zwraca `true`, jeśli co najmniej jeden element spełnia predykat, w przeciwnym razie `false`.
```javascript
const pakietyWag = [12, 18, 25, 42, 15];
const czySaPrzeladowane = pakietyWag.some(waga => waga > 40); // true
```

### D. `.every()` – czy każdy element spełnia warunek?
Zwraca `true`, jeśli wszystkie elementy bez wyjątku spełniają predykat.
```javascript
const czyWszystkieBezpieczne = pakietyWag.every(waga => waga <= 50); // true
```

> **Po co to jest?**
> Metody `.some()` i `.every()` pozwalają na błyskawiczną walidację poprawności zbiorów danych (np. czy wszystkie formularze zostały wypełnione, czy którykolwiek produkt ma stan magazynowy równy zero). Działają optymalnie — przerywają sprawdzanie od razu po znalezieniu pierwszego elementu potwierdzającego lub negującego warunek.

---

## 7. Agregacja wartości: metoda `.reduce()`

Metoda `.reduce()` służy do zredukowania (zwinięcia) całej tablicy do pojedynczej wartości wyjściowej — może to być liczba (suma, średnia, maksimum), ciąg tekstowy lub obiekt zagregowany.

### Składnia metody:
```javascript
tablica.reduce((akumulator, biezacy, indeks, tablica) => {
  return nowaWartoscAkumulatora;
}, wartoscPoczatkowa);
```

* **`akumulator`** – zmienna przechowująca wynik cząstkowy zwracany przez poprzednią iterację. W pierwszym kroku przyjmuje wartość zdefiniowaną jako `wartoscPoczatkowa`.
* **`biezacy`** – aktualnie przetwarzany element tablicy.
* **`wartoscPoczatkowa`** – drugi argument metody `.reduce()`. **Zawsze podawaj wartość początkową** (np. `0` przy sumowaniu liczb).

### Przykład 1: Suma liczb
```javascript
const wydatki = [45, 120, 30, 85];

const sumaWydatkow = wydatki.reduce((suma, kwota) => suma + kwota, 0);
// Przebieg:
// Krok 1: suma = 0,   kwota = 45  -> 45
// Krok 2: suma = 45,  kwota = 120 -> 165
// Krok 3: suma = 165, kwota = 30  -> 195
// Krok 4: suma = 195, kwota = 85  -> 280
```

### Przykład 2: Wyszukiwanie wartości maksymalnej
```javascript
const pomiary = [14.2, 19.8, 12.1, 23.5, 18.0];

const maksPomiar = pomiary.reduce((maks, pomiar) => {
  return pomiar > maks ? pomiar : maks;
}, pomiary[0]);
```

> **Po co to jest?**
> `.reduce()` to najbardziej uniwersalna metoda tablicowa w JavaScript. Zastępuje konieczność tworzenia zewnętrznych zmiennych sumujących przed pętlą (`let suma = 0;`).
>
> **Typowa pomyłka:**
> Brak podania wartości początkowej `0` przy sumowaniu tablicy obiektów:  
> `produkty.reduce((sum, p) => sum + p.cena)`  
> Przy braku drugiego argumentu akumulator w pierwszym kroku przyjmie cały obiekt `produkty[0]`, co doprowadzi do dodawania obiektu do liczby i błędu `[object Object]60`!

---

## 8. Potokowe łączenie metod (Method Chaining)

Metody funkcyjne, które zwracają nową tablicę (`filter`, `map`, `slice`), można łączyć bezpośrednio po kropce w **łańcuchy operacji**. Na końcu łańcucha możemy wywołać metodę `.reduce()` lub `.join("\n")`.

```javascript
const zamowienia = [
  { id: 1, produkt: "Monitor", kwota: 800, oplacone: true },
  { id: 2, produkt: "Myszka", kwota: 50, oplacone: false },
  { id: 3, produkt: "Klawiatura", kwota: 150, oplacone: true },
  { id: 4, produkt: "Kabel HDMI", kwota: 30, oplacone: true }
];

// Zadanie: Znajdź opłacone zamówienia o wartości powyżej 100 zł,
// sformatuj je jako linie tekstu i połącz w jeden raport.
const raport = zamowienia
  .filter(z => z.oplacone && z.kwota > 100)
  .map(z => `Pozycja: ${z.produkt} - ${z.kwota.toFixed(2)} zł`)
  .join("\n");
```

> **Po co to jest?**
> Łańcuch metod czyta się od góry do dołu jak logiczne zdanie w języku naturalnym: *„Weź zamówienia, odfiltruj opłacone powyżej 100 zł, zamień na tekst i połącz nową linią”*. Eliminuje to wszelkie zmienne pośrednie.

---

## 9. Wzorzec egzaminacyjny CKE: separacja danych (`dane.js`)

W zadaniach laboratoryjnych i na arkuszu egzaminacyjnym INF.03 dane wejściowe często dostarczane są w osobnym pliku ze względu na objętość (np. katalog 30 produktów).

W pliku `index.html` włączamy skrypty w ściśle określonej kolejności:
```html
<!-- 1. Najpierw plik z danymi (tworzy globalną stałą, np. BAZA_DANYCH) -->
<script src="dane.js"></script>

<!-- 2. Następnie plik z logiką ucznia (korzysta z BAZA_DANYCH) -->
<script src="script.js"></script>
```

Plik `dane.js` zawiera wyłącznie definicję stałej:
```javascript
// dane.js
const REJESTR_PACZEK = [
  { kod: "PK-101", waga: 12.5, strefa: "A", ekspres: true },
  { kod: "PK-102", waga: 5.0,  strefa: "B", ekspres: false },
  { kod: "PK-103", waga: 22.0, strefa: "A", ekspres: false }
];
```

Dzięki temu plik `script.js` ucznia pozostaje krótki, przejrzysty i skupia się w 100% na logice funkcyjnej.

---

## 10. Standard wypisywania danych w Semestrze 2

Przypomnienie reguły wyjścia Semestru 2:
1. Dane wyjściowe przypisujemy do właściwości `textContent` kontenera o identyfikatorze `#wynik`.
2. Nie stosujemy metody `document.write` (zastrzeżonej dla Semestru 1).
3. Nie stosujemy właściwości `innerHTML` w modułach podstawowych.
4. Nowe linie w tekście tworzymy za pomocą znaku `\n`, a arkusz stylów zawiera regułę:
```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
}
```
5. Skrypt podpinamy na końcu pliku HTML, tuż przed zamykającym znacznikiem `</body>`.
