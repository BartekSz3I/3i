# Wykład: Wbudowany obiekt String i manipulacja łańcuchami znaków

---

## 1. Natura łańcuchów znaków w JavaScript — Prymityw czy obiekt?

W języku JavaScript tekst jest typem prostym (prymitywem `string`). Kiedy deklarujemy zmienną tekstową:

```javascript
let komunikat = "System gotowy do pracy";
```

zmienna przechowuje ciąg znaków w formacie kodowania UTF-16. Choć jest to typ prosty (prymityw), JavaScript pozwala wywoływać na nim metody i odczytywać właściwości (np. `komunikat.length` czy `komunikat.toUpperCase()`). W momencie wywołania takiej metody przeglądarka w tle na ułamek sekundy automatycznie tworzy obiekt pomocniczy (tzw. wrapper / obiekt opakowujący `String`), wykonuje operację, po czym natychmiast go usuwa. Dla programisty działa to zupełnie przezroczyście — po prostu używamy kropki i wywołujemy metodę.

> [!IMPORTANT]
> **Żelazna zasada niemutowalności (Immutability):**
> Łańcuchy znaków w języku JavaScript są **niezmienne**. Żadna metoda na łańcuchu znaków nie modyfikuje oryginalnej zmiennej w miejscu. Wszystkie metody zawsze tworzą i zwracają **nowy łańcuch znaków**.
>
> ```javascript
> let imie = "anna";
> imie.toUpperCase();
> console.log(imie); // Nadal "anna"! Wynik metody nie został przypisany.
>
> imie = imie.toUpperCase();
> console.log(imie); // Dopiero teraz "ANNA".
> ```

---

## 2. Długość łańcucha i indeksowanie znaków

### Właściwość `.length`
Właściwość `.length` zwraca liczbę jednostek kodu tworzących łańcuch (liczbę znaków).

```javascript
let kodTowaru = "PROD-9812";
console.log(kodTowaru.length); // 9
```

*Po co to jest?*  
Niezbędne do walidacji danych wejściowych z formularzy i promptów — sprawdzania, czy wprowadzony kod ma wymaganą liczbę znaków (np. PESEL: dokładnie 11, numer konta: 26).

*Typowa pomyłka:*  
Uczniowie często dopisują nawiasy: `tekst.length()`. Ponieważ `.length` jest właściwością (cechą), a nie funkcją (metodą), dopisanie nawiasów skutkuje błędem: `TypeError: tekst.length is not a function`.

### Odczyt znaków: `charAt(index)` oraz operator nawiasów kwadratowych `[index]`
Każdy znak w tekście posiada swój numer porządkowy (indeks), liczony od zera (`0` do `length - 1`):

```javascript
let miasto = "Gdańsk";
console.log(miasto.charAt(0)); // "G"
console.log(miasto[0]);        // "G"
console.log(miasto.charAt(5)); // "k"
console.log(miasto.charAt(10)); // "" (pusty ciąg znaków)
console.log(miasto[10]);       // undefined
```

*Po co to jest?*  
Pozwala odczytać pierwszą literę (np. inicjał), prefiks lub sprawdzić konkretną pozycję znaku w identyfikatorze.

*Typowa pomyłka:*  
Próba przypisania nowego znaku przez indeks: `miasto[0] = "g";`. Ze względu na niemutowalność, taka operacja zostanie po cichu zignorowana (w trybie ścisłym wywoła błąd), a zmienna nie ulegnie zmianie.

---

## 3. Transformacja wielkości liter: `.toLowerCase()` i `.toUpperCase()`

```javascript
let loginUzytkownika = "Jan.Kowalski@Firma.PL";

let malymi = loginUzytkownika.toLowerCase(); // "jan.kowalski@firma.pl"
let wielkimi = loginUzytkownika.toUpperCase(); // "JAN.KOWALSKI@FIRMA.PL"
```

*Po co to jest?*  
W bazach danych i logice systemowej porównywanie loginów, adresów email czy kodów rabatowych musi być niezależne od wielkości liter (tzw. case-insensitive). Normalizacja tekstu do małych liter przed porównaniem eliminuje błędy wpisywania przez użytkowników.

*Typowa pomyłka:*  
Brak przypisania wyniku metody do zmiennej. Zapis `loginUzytkownika.toLowerCase();` nic nie robi, jeśli nie użyjemy `let wynik = loginUzytkownika.toLowerCase();` lub `loginUzytkownika = loginUzytkownika.toLowerCase();`.

---

## 4. Wyszukiwanie w tekście: `.indexOf()`, `.lastIndexOf()` i `.includes()`

### Metoda `.indexOf(szukanyZnak, odPozycji)`
Zwraca indeks pierwszego wystąpienia podciągu lub `-1`, jeśli podciąg nie został odnaleziony.

```javascript
let email = "sekretariat@szkola.edu.pl";
let pozycjaMalpy = email.indexOf("@"); // 11
let pozycjaKropki = email.indexOf(".", pozycjaMalpy); // 18
let brakujacyZnak = email.indexOf("#"); // -1
```

### Metoda `.lastIndexOf(szukanyZnak)`
Zwraca indeks ostatniego wystąpienia znaku w łańcuchu (przeszukuje od końca).

```javascript
let sciezka = "dokumenty/projekty/2026/raport.pdf";
let ostatniUkosnik = sciezka.lastIndexOf("/"); // 23
```

### Metoda `.includes(szukanyFragment)`
Zwraca wartość logiczną `true` lub `false`.

```javascript
let url = "https://bezpieczny-serwer.pl/logowanie";
let czyBezpieczny = url.includes("https://"); // true
```

*Po co to jest?*  
Kluczowe przy rozdzielaniu domen, sprawdzaniu obecności znaku małpy `@` w adresie email, wykrywaniu zakazanych słów lub sprawdzaniu poprawności rozszerzenia pliku.

*Typowa pomyłka:*  
Sprawdzanie wyniku `indexOf` jako wartości logicznej: `if (tekst.indexOf("A"))`. Jeśli litera `"A"` znajduje się na indeksie `0`, to `0` jest interpretowane jako `false`! Prawidłowy warunek musi bezwzględnie porównywać do `-1`:
```javascript
if (tekst.indexOf("A") !== -1) {
  // Znak znaleziony!
}
```

---

## 5. Wycinanie podciągów: `.slice()` oraz `.substring()`

### Metoda `.slice(poczatek, koniec)`
Wycina fragment tekstu od indeksu `poczatek` (włącznie) do indeksu `koniec` (wyłącznie). Parametr `koniec` jest opcjonalny — jego brak oznacza wycięcie do samego końca łańcucha.

```javascript
let numerSeryjny = "PL-KRK-2026-9901";
let prefiksKraju = numerSeryjny.slice(0, 2);   // "PL"
let miasto = numerSeryjny.slice(3, 6);         // "KRK"
let koncowka = numerSeryjny.slice(7);          // "2026-9901"
```

Co wyróżnia `.slice()`, to **obsługa indeksów ujemnych**, które liczone są od końca ciągu:
```javascript
let ostatnieCztery = numerSeryjny.slice(-4); // "9901"
```

### Metoda `.substring(poczatek, koniec)`
Działa podobnie do `.slice()`, lecz nie obsługuje indeksów ujemnych (ujemne wartości traktuje jak `0`) i automatycznie zamienia miejscami argumenty, jeśli `poczatek > koniec`.

*Po co to jest?*  
Ekstrakcja danych strukturalnych: wyodrębnianie roku z numeru PESEL, rozszerzenia z nazwy pliku czy prefiksu regionalnego z kodu kreskowego.

*Typowa pomyłka:*  
Zapominanie, że drugi indeks jest otwarty (niewłączany do wyniku). Aby wyciąć 3 znaki zaczynające się od indeksu `2`, piszemy `slice(2, 5)`, a nie `slice(2, 4)`.

---

## 6. Oczyszczanie i podmiana znaków: `.trim()`, `.replace()` i `.replaceAll()`

### Metoda `.trim()`
Usuwa wszystkie białe znaki (spacje, tabulatory, znaki nowej linii) z **początku i końca** tekstu. Nie usuwa spacji znajdujących się wewnątrz tekstu.

```javascript
let wpisaneHaslo = "   tajne_haslo_123   \n";
let czysteHaslo = wpisaneHaslo.trim(); // "tajne_haslo_123"
```

### Metoda `.replace(wzorzec, zamiennik)` oraz `.replaceAll(wzorzec, zamiennik)`
* `.replace()` zamienia **tylko pierwsze** znalezione wystąpienie podanego tekstu.
* `.replaceAll()` zamienia **wszystkie** znalezione wystąpienia podanego tekstu.

```javascript
let sciezkaWindows = "C:\\dane\\raporty\\pliki";
let jedno = sciezkaWindows.replace("\\", "/");     // "C:/dane\\raporty\\pliki"
let wszystkie = sciezkaWindows.replaceAll("\\", "/"); // "C:/dane/raporty/pliki"
```

*Po co to jest?*  
Czyszczenie danych z pól tekstowych wprowadzonych przez użytkownika (przypadkowa spacja na początku/końcu to najczęstszy powód błędu logowania) oraz formatowanie separatorów (np. zamiana przecinka na kropkę dziesiętną).

*Typowa pomyłka:*  
Użycie `.replace()` z oczekiwaniem, że podmieni wszystkie spacje lub myślniki w całym numerze konta. W środowisku bez wyrażeń regularnych do podmiany wszystkich wystąpień należy użyć `.replaceAll()`.

---

## 7. Szablony literałów (Template Literals) a tradycyjna konkatenacja

Tradycyjne łączenie ciągów za pomocą operatora `+` przy rozbudowanych komunikatach jest podatne na literówki i trudne w czytaniu:

```javascript
let produkt = "Dysk SSD";
let cena = 320;
let gwarancja = 3;

// Tradycyjna konkatenacja:
let raport1 = "Produkt: " + produkt + ", Cena: " + cena + " zł, Gwarancja: " + gwarancja + " lata.";

// Szablony literałów z interpolacją:
let raport2 = `Produkt: ${produkt}, Cena: ${cena} zł, Gwarancja: ${gwarancja} lata.`;
```

Zalety szablonów literałów:
1. Składnia `${zmienna}` wewnątrz grawisów (backtick `` ` ``).
2. Obsługa tekstu wielowierszowego bez konieczności ciągłego dodawania `\n`:
   ```javascript
   let podsumowanie = `RAPORT SYSTEMOWY
   =================
   Produkt: ${produkt}
   Cena: ${cena} zł`;
   ```

---

## 8. Czysta architektura w Semestrze 2 (Zasada M11)

W zadaniach laboratoryjnych stosujemy ścisłą separację wprowadzania danych od ich logicznego przetwarzania:

```javascript
// 1. CZYSTA FUNKCJA LOGICZNA:
// Pobiera dane wyłącznie jako parametry przez nawias, nie korzysta z prompt() w środku.
function przetworzKodTowaru(kodSurowy) {
  let kodCzysty = kodSurowy.trim().toUpperCase();
  let prefiks = kodCzysty.slice(0, 3);
  let identyfikator = kodCzysty.slice(4);

  return `KOD TOWARU: ${kodCzysty}\nPrefiks branżowy: ${prefiks}\nNumer partii: ${identyfikator}`;
}

// 2. KOD GŁÓWNY (WEJŚCIE DANYCH):
// prompt() występuje wyłącznie tutaj, z wartością domyślną!
let daneWejsciowe = typeof prompt !== "undefined"
  ? prompt("Wprowadź kod towaru:", "kat-89214")
  : "kat-89214";

// 3. PRZEKAZANIE DANYCH DO FUNKCJI:
let wynikRaportu = przetworzKodTowaru(daneWejsciowe);

// 4. WYJŚCIE DANYCH:
document.getElementById("wynik").textContent = wynikRaportu;
```
