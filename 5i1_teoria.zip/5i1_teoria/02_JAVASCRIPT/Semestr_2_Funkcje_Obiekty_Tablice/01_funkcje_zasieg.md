# Teoria: Funkcje, parametry i zasięg zmiennych w JavaScript (INF.03 Semestr 2)

Podręcznik metodyczny dla uczniów technikum informatycznego i programistycznego. Omawia architekturę modularną, tworzenie funkcji, zarządzanie parametrami i zwracanymi wartościami, mechanizmy zasięgu (`scope`) oraz standard prezentacji danych w Semestrze 2.

---

## 1. Wprowadzenie — Po co programiście funkcje?

W Semestrze 1 programy pisane były jako ciągłe skrypty sekwencyjne: instrukcje wykonywały się od góry do dołu. Gdy ten sam algorytm (np. walidacja liczby pierwszej lub obliczenie podatku VAT) był potrzebny w trzech różnych miejscach, konieczne było powielenie kodu.

Zjawisko kopiowania kodu łamie naczelną zasadę inżynierii oprogramowania: **DRY (Don't Repeat Yourself — Nie powtarzaj się)**. W przypadku znalezienia błędu lub zmiany stawki podatku, programista musiałby odszukać i poprawić każde skopiowane miejsce.

Funkcja to **nazwany, wydzielony blok kodu**, który można zdefiniować raz, a następnie wywoływać wielokrotnie z różnymi danymi wejściowymi.

> **Po co to jest:** Funkcje pozwalają podzielić skomplikowany problem biznesowy na małe, czytelne i łatwe do przetestowania podprogramy.
>
> **Typowa pomyłka:** Mylenie zdefiniowania funkcji z jej wywołaniem. Napisanie samej definicji `function oblicz()` sprawia, że kod w jej wnętrzu czeka w pamięci i nie wykona się ani razu, dopóki nie nastąpi jawne wywołanie `oblicz()`.

---

## 2. Deklaracja funkcji a wyrażenie funkcyjne

W języku JavaScript istnieją dwa fundamentalne sposoby tworzenia funkcji:

### 2.1 Deklaracja funkcji (Function Declaration)
Tradycyjny sposób zapisu za pomocą słowa kluczowego `function`:
```javascript
function powitajUzytkownika(imie) {
  return "Witaj w systemie, " + imie + "!";
}

let powitanie = powitajUzytkownika("Jan");
```

### 2.2 Wyrażenie funkcyjne (Function Expression)
Przypisanie funkcji anonimowej do stałej (`const`):
```javascript
const obliczBrutto = function(netto, stawkaVat) {
  return netto * (1 + stawkaVat / 100);
};

let brutto = obliczBrutto(100, 23);
```

### 2.3 Różnica: Hoisting (Wynoszenie)
Deklaracje funkcji podlegają zjawisku **hoistingu** — interpreter JavaScript podczas wstępnej kompilacji przenosi ich definicje na początek bieżącego zakresu. Oznacza to, że funkcję zadeklarowaną przez `function` można wywołać w kodzie **przed** linijką, w której została zdefiniowana.

Wyrażenia funkcyjne (`const nazwa = function()`) **nie mogą** być wywołane przed linijką definicji — próba wcześniejszego wywołania kończy się błędem `ReferenceError` (znajdują się w tzw. *Temporal Dead Zone*).

### 2.4 Funkcje anonimowe i funkcje strzałkowe (Arrow Functions: ES6)
Funkcja, która nie posiada własnej nazwy występującej bezpośrednio po słowie `function`, nazywana jest **funkcją anonimową**:
```javascript
const pomnoz = function(a, b) {
  return a * b;
};
```

W nowoczesnym standardzie ES6 wprowadzono skróconą, bardzo elegancką składnię — **funkcje strzałkowe (Arrow Functions)**, wykorzystujące symbol strzałki `=>`:
```javascript
// Pełny zapis funkcji strzałkowej z blokiem klamrowym:
const dodaj = (a, b) => {
  return a + b;
};

// Zapis skrócony (niejawny return dla pojedynczego wyrażenia):
const odejmij = (a, b) => a - b;

// Zapis dla jednego parametru (nawiasy wokół parametru są opcjonalne):
const kwadrat = x => x * x;
```

#### Gdzie funkcja strzałkowa jest niezastąpiona?
1. **Jako funkcja przekazywana do innej metody (tzw. funkcja zwrotna / komparator):**
   Gdy porządkujemy tablicę liczb za pomocą metody `.sort()`, zamiast pisać długą funkcję:
   ```javascript
   liczby.sort(function(a, b) {
     return a - b;
   });
   ```
   stosujemy zwięzłą funkcję strzałkową:
   ```javascript
   liczby.sort((a, b) => a - b);
   ```
2. **Krótkie kalkulacje i transformacje:** zwięzłość zapisu poprawia czytelność kodu i redukuje zbędny kod szablonowy.

> **Po co to jest:** Wyrażenia funkcyjne i funkcje strzałkowe gwarantują ścisły porządek logiczny oraz umożliwiają zwięzłe przekazywanie logiki obliczeniowej bezpośrednio do metod tablicowych (`sort`, `map`, `filter`).
>
> **Typowa pomyłka:** Zapomnienie o słowie `return` w przypadku otwarcia klamer `{}` w funkcji strzałkowej: `const f = (a, b) => { a - b; };` — funkcja ta zwróci `undefined`, ponieważ klamry wymagają jawnego `return`! Przy zapisie jednolinijkowym bez klamer: `const f = (a, b) => a - b;` wynik wyrażenia zwracany jest automatycznie.

---

## 3. Parametry formalne, argumenty faktyczne i wartości domyślne

Wokół przekazywania danych do funkcji obowiązuje precyzyjna terminologia:
* **Parametr:** zmienna zadeklarowana w nawiasie definicji funkcji (miejsce na dane).
* **Argument:** konkretna wartość przekazywana w nawiasie podczas wywoływania funkcji.

```javascript
// 'cena' i 'rabatProcent' to parametry
function obliczPoRabacie(cena, rabatProcent) {
  return cena - (cena * (rabatProcent / 100));
}

// 200 i 15 to argumenty
let koszt = obliczPoRabacie(200, 15);
```

### 3.1 Parametry domyślne (Default Parameters)
Od standardu ES6 parametry mogą posiadać zdefiniowaną wartość awaryjną, która zostanie użyta, jeśli programista pominie argument lub przekaże `undefined`:

```javascript
function generujRaport(nazwa, iloscKopii = 1) {
  return "Generowanie raportu: " + nazwa + ", liczba kopii: " + iloscKopii;
}

generujRaport("Finanse");        // iloscKopii przyjmie wartość domyślną 1
generujRaport("Magazyn", 5);     // iloscKopii przyjmie wartość 5
```

> **Po co to jest:** Parametry domyślne zapobiegają błędom obliczeniowym (`NaN`), gdy użytkownik lub inny fragment programu pominie opcjonalny argument.
>
> **Typowa pomyłka:** Umieszczenie parametru domyślnego przed parametrem obowiązkowym, np. `function f(a = 10, b)`. Zawsze umieszczaj parametry domyślne na końcu listy parametrów.

---

## 4. Instrukcja `return` — Komunikacja ze światem zewnętrznym

Instrukcja `return` pełni w ciele funkcji dwie kluczowe role:
1. Zwraca obliczoną wartość do miejsca, z którego funkcja została wywołana.
2. **Natychmiast przerywa działanie funkcji** — żadna linijka kodu znajdująca się poniżej `return` w danym bloku nie zostanie już wykonana.

```javascript
function sprawdzPelnoletnosc(wiek) {
  if (wiek < 18) {
    return false; // Wczesne wyjście (Guard Clause)
  }
  return true;
}
```

### 4.1 Różnica między `return` a wypisaniem tekstu
Jednym z najczęstszych błędów początkujących programistów jest mylenie zwracania wartości z jej wyświetlaniem:
* Funkcja z `return` jest jak kalkulator: wykonuje obliczenie i podaje wynik na wyświetlaczu — to programista decyduje, co z nim zrobi (zapisze do zmiennej, przekaże dalej, wyświetli).
* Funkcja, która w środku wywołuje bezpośrednio wypisanie na ekran i nie ma `return`, zwraca niejawnie wartość `undefined`.

```javascript
// BŁĘDNE PODEJŚCIE (brak return, niska elastyczność):
function sumaZle(a, b) {
  console.log(a + b);
}
let wynikZly = sumaZle(2, 3); // wynikZly ma wartość undefined!

// PRAWIDŁOWE PODEJŚCIE (czysta funkcja z return):
function sumaDobrze(a, b) {
  return a + b;
}
let wynikDobry = sumaDobrze(2, 3); // wynikDobry to liczba 5
```

> **Po co to jest:** Zwracanie wartości czyni funkcję uniwersalną. Ta sama funkcja obliczająca ratę kredytu może być użyta w przeglądarce, w aplikacji mobilnej oraz w testach automatycznych.
>
> **Typowa pomyłka:** Zapomnienie o słowie `return`. Jeśli w ciele funkcji wykonasz obliczenia, ale ich nie zwrócisz, zmienna odbierająca wynik przyjmie wartość `undefined`.

---

## 5. Zasięg zmiennych (Scope) i zjawisko przesłaniania (Shadowing)

Zasięg to obszar programu, w którym dana zmienna jest widoczna i dostępna dla kodu.

### 5.1 Trzy poziomy zasięgu w JavaScript
1. **Zasięg globalny (Global Scope):** zmienne zadeklarowane poza wszelkimi funkcjami i blokami kodu. Są dostępne w każdym miejscu skryptu.
2. **Zasięg funkcyjny (Function Scope):** zmienne i parametry zadeklarowane wewnątrz ciała funkcji. Nie istnieją i są całkowicie niedostępne poza tą funkcją.
3. **Zasięg blokowy (Block Scope):** zmienne zadeklarowane za pomocą `let` lub `const` wewnątrz dowolnego bloku ograniczonego klamrami `{ ... }` (np. ciało instrukcji `if` lub pętli `for`).

```javascript
let globalnaStawka = 0.23; // Zasięg globalny

function obliczPodatek(kwota) {
  let narzutLokalny = 50; // Zasięg funkcyjny - niedostępny na zewnątrz!
  
  if (kwota > 1000) {
    let bonus = 10; // Zasięg blokowy - niedostępny poza if!
    return kwota * globalnaStawka + narzutLokalny - bonus;
  }
  
  return kwota * globalnaStawka + narzutLokalny;
}
```

### 5.2 Zjawisko przesłaniania (Variable Shadowing)
Jeśli wewnątrz funkcji zadeklarujemy zmienną o identycznej nazwie jak zmienna globalna, zmienna lokalna „przesłoni” zmienną globalną wewnątrz tej funkcji:

```javascript
let limit = 100; // zmienna globalna

function sprawdz() {
  let limit = 500; // zmienna lokalna przesłania globalną
  return limit;    // zwróci 500
}

sprawdz(); // 500
console.log(limit); // 100 - zmienna globalna pozostała nienaruszona
```

> **Po co to jest:** Hermetyzacja. Dzięki zasięgowi funkcyjnemu praca wewnątrz funkcji nie niszczy zmiennych w innych częściach programu.
>
> **Typowa pomyłka:** Przypadkowe utworzenie zmiennej globalnej przez pominięcie słowa `let` lub `const` wewnątrz funkcji (np. `stawka = 1.2;`). Prowadzi to do trudnych do wykrycia błędów w innych modułach aplikacji.

---

## 6. Nowy standard prezentacji danych w Semestrze 2 (`textContent` i `white-space: pre-wrap`)

W Semestrze 1 wyjście realizowane było za pomocą `document.write`. W nowoczesnym frontendzie i na egzaminie zawodowym INF.03 ta metoda jest zakazana, ponieważ nadpisuje całe drzewo dokumentu po załadowaniu strony.

Od Semestru 2 obowiązuje standard czystego zapisu do dedykowanego węzła DOM:
```javascript
document.getElementById("wynik").textContent = "Treść raportu...";
```

### 6.1 Dlaczego `textContent`, a nie `innerHTML`?
Właściwość `textContent` jest bezpieczna pod kątem ataków XSS (*Cross-Site Scripting*), ponieważ traktuje cały wstawiany tekst jako ciąg znaków, a nie jako kod HTML.

### 6.2 Formatowanie wielowierszowe i reguła `white-space: pre-wrap;`
Domyślnie przeglądarka internetowa zwija wszystkie znaki nowej linii (`\n`) i wielokrotne spacje w pojedynczy odstęp. Aby znaki nowej linii działały wewnątrz elementu `#wynik` bez konieczności stosowania znaczników `<br>`, element ten stylizujemy w pliku CSS regułą:

```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace; /* opcjonalnie: ułatwia czytanie tabelarycznych danych */
}
```

Dzięki temu możemy w kodzie JavaScript estetycznie budować wielowierszowe raporty:
```javascript
let raport = "RAPORT DIAGNOSTYCZNY\n";
raport += "====================\n";
raport += "Status: Pozytywny\n";
raport += "Zużycie: 42.5 kWh\n";

document.getElementById("wynik").textContent = raport;
```

---

## 7. Podsumowanie — Złote reguły pisania funkcji w INF.03
1. **Jedna funkcja = jedno zadanie:** funkcja powinna robić dokładnie jedną rzecz i robić ją dobrze (np. walidować dane LUB obliczać kwotę LUB formatować tekst).
2. **Czystość funkcji:** funkcja powinna przyjmować dane przez parametry i zwracać wynik przez `return`, minimalizując odwoływanie się do zmiennych globalnych.
3. **Jawne deklarowanie:** zawsze używaj `const` lub `let` — nigdy nie twórz zmiennych bez słowa kluczowego.
4. **Separacja logiki od prezentacji:** funkcja obliczeniowa nie powinna bezpośrednio manipulować elementem `#wynik` — powinna zwrócić wartość, którą dopiero skrypt główny przekaże do interfejsu.
