# Podręcznik: Literały obiektów i rekordy w JavaScript

Witaj w module poświęconym obiektom w języku JavaScript! Do tej pory przetwarzałeś dane w postaci pojedynczych wartości prymitywnych (liczb, napisów, wartości logicznych) lub jednorodnych tablic (np. lista ocen, lista cen).

W rzeczywistym programowaniu aplikacji internetowych — a w szczególności w architekturze frontendowej — niemal każda informacja jest **złożonym rekordem**. Użytkownik w sklepie to nie tylko imię, ale też nazwisko, adres e-mail, historia zamówień i status subskrypcji. Towar w magazynie to nie tylko cena, lecz także kod kreskowy EAN, nazwa, stan magazynowy i kategoria.

Do modelowania takich złożonych bytów służą **literały obiektów (obiekty `{}`)** oraz **tablice obiektów**.

---

## 1. Dlaczego sama tablica nie wystarcza? (Problem semantyki danych)

Wyobraź sobie, że próbujesz zapisać dane klienta serwisu komputerowego w zwykłej tablicy:
```javascript
const klient = ["Jan", "Kowalski", "jan@serwis.pl", 4, true];
```
Taki kod rodzi poważne problemy:
1. **Brak czytelności:** Co oznacza liczba `4`? Czy to liczba zgłoszonych laptopów, numer stanowiska, czy może rabat procentowy?
2. **Kruchość indeksów:** Jeśli programista dopisze numer telefonu na początku tablicy, wszystkie dotychczasowe indeksy w całym programie ulegną przesunięciu i aplikacja przestanie działać poprawnie.
3. **Konieczność pamiętania kolejności:** Musisz stale pamiętać, że `klient[2]` to adres e-mail, a `klient[1]` to nazwisko.

Rozwiązaniem tego problemu jest **obiekt** — struktura danych oparta na **nazwanych parach klucz-wartość** (ang. *key-value pairs*):

```javascript
const klient = {
  imie: "Jan",
  nazwisko: "Kowalski",
  email: "jan@serwis.pl",
  liczbaZlecen: 4,
  stalyKlient: true
};
```
W tym zapisie kod staje się **samoopisujący**: `klient.email` natychmiast informuje każdego programistę, jaka dana jest tam przechowywana.

---

## 2. Tworzenie literału obiektu i reguły nazewnictwa

Literał obiektu tworzymy za pomocą nawiasów klamrowych `{}`. Wewnątrz umieszczamy właściwości (pola) oddzielone przecinkami:

```javascript
const podzespol = {
  kodTowaru: "RAM-3200",     // klucz: wartość tekstowa
  cenaNetto: 180.50,         // klucz: wartość liczbowa
  naStanie: true,            // klucz: wartość logiczna
  parametry: {               // obiekt zagnieżdżony!
    pojemnoscGB: 16,
    taktowanieMHz: 3200
  },
  kompatybilnosc: ["DDR4", "AM4", "LGA1200"] // tablica wewnątrz obiektu!
};
```

### Reguły tworzenia kluczy:
- Nazwy właściwości zapisujemy zazwyczaj w notacji `camelCase` (np. `cenaNetto`, `dataZakupu`).
- Jeśli nazwa klucza zawiera spację lub myślnik, musi być ujęta w cudzysłów: `"kod pocztowy": "00-950"`.

> **Po co to jest?**
> Obiekty pozwalają zagnieżdżać struktury danych (obiekt w obiekcie, tablica w obiekcie), co odzwierciedla relacje panujące w bazach danych i standardzie JSON.
>
> **Typowa pomyłka:**
> Użycie znaku równości `=` zamiast dwukropka `:` przy definiowaniu właściwości (np. `{ imie = "Adam" }`). W literałach obiektów zawsze stosujemy dwukropek: `{ imie: "Adam" }`. Znak równości spowoduje błąd składni `SyntaxError: Invalid shorthand property initializer`.

---

## 3. Dostęp do właściwości: Notacja kropkowa vs Notacja nawiasowa

W języku JavaScript mamy dwa sposoby odczytywania i zapisywania pól obiektu:

### 3.1. Notacja kropkowa (Dot notation) — standard codzienny
Stosujemy ją w 95% przypadków, gdy znamy stałą nazwę klucza w momencie pisania kodu:
```javascript
console.log(podzespol.kodTowaru); // "RAM-3200"
podzespol.cenaNetto = 165.00;     // aktualizacja ceny
podzespol.gwarancjaMiesiace = 36; // dynamiczne dodanie NOWEGO pola!
```

### 3.2. Notacja nawiasowa (Bracket notation) — zastosowania specjalne
Stosujemy ją, gdy:
1. Nazwa właściwości zawiera spację lub znaki specjalne:
   ```javascript
   const klient = { "kod pocztowy": "80-100" };
   console.log(klient["kod pocztowy"]); // Działa! (klient.kod pocztowy wywoła błąd)
   ```
2. Nazwa właściwości jest przechowywana w zmiennej (dynamiczny dostęp):
   ```javascript
   const pole = "cenaNetto";
   console.log(podzespol[pole]); // Odczyta podzespol.cenaNetto!
   ```

> **Po co to jest?**
> Notacja nawiasowa umożliwia pisanie uniwersalnych funkcji analitycznych, które mogą odczytywać dowolne pole obiektu przekazane jako parametr tekstowy.
>
> **Typowa pomyłka:**
> Próba odczytu `podzespol[kodTowaru]` bez cudzysłowu, gdy `kodTowaru` nie jest zdefiniowaną zmienną. JavaScript potraktuje `kodTowaru` jako zmienną lokalną, rzucając błąd `ReferenceError: kodTowaru is not defined`. Jeśli odwołujesz się stałym tekstem, zawsze używaj cudzysłowu: `podzespol["kodTowaru"]` lub kropki: `podzespol.kodTowaru`.

---

## 4. Tablice obiektów — standard kolekcji w aplikacjach webowych

Pojedynczy obiekt opisuje jeden byt. Gdy potrzebujemy opisać katalog towarów w sklepie, rejestr pacjentów czy listę zgłoszeń serwisowych, tworzymy **tablicę obiektów (kolekcję rekordów)**:

```javascript
const katalogUslug = [
  { id: "DIAG", nazwa: "Diagnostyka sprzętu", cena: 80, czasMin: 45, kategoria: "sprzet" },
  { id: "INST", nazwa: "Instalacja Windows 11", cena: 120, czasMin: 90, kategoria: "software" },
  { id: "PAST", nazwa: "Wymiana pasty termoprzewodzącej", cena: 160, czasMin: 60, kategoria: "sprzet" },
  { id: "ODZ",  nazwa: "Odzyskiwanie danych z dysku", cena: 250, czasMin: 180, kategoria: "dane" }
];
```

Wszystkie poznane dotychczas metody tablicowe (`forEach`, `find`, `filter`, `map`, `sort`) zyskują teraz ogromną moc:

### 4.1. Wyszukiwanie konkretnego rekordu: `find()`
Metoda `find()` zwraca **pierwszy obiekt**, który spełnia podany warunek logiczny:
```javascript
const wybranaUsluga = katalogUslug.find(u => u.id === "PAST");
console.log(wybranaUsluga.nazwa); // "Wymiana pasty termoprzewodzącej"
```
Jeśli żaden obiekt nie pasuje, `find()` zwraca bezpieczną wartość `undefined`.

### 4.2. Selekcja podzbioru: `filter()`
Metoda `filter()` tworzy nową tablicę zawierającą wszystkie obiekty spełniające kryterium:
```javascript
// Wybierz tylko usługi sprzętowe:
const uslugiSprzetowe = katalogUslug.filter(u => u.kategoria === "sprzet");
// Zwraca tablicę 2 obiektów: DIAG i PAST
```

### 4.3. Transformacja danych: `map()`
Metoda `map()` tworzy nową tablicę, przekształcając każdy obiekt:
```javascript
// Wyciągnij same nazwy usług jako prostą tablicę napisów:
const sameNazwy = katalogUslug.map(u => u.nazwa);
// ["Diagnostyka sprzętu", "Instalacja Windows 11", ...]
```

### 4.4. Sortowanie kolekcji obiektów: `sort()`
Metoda `sort()` sortuje obiekty w miejscu przy użyciu komparatora odejmującego wartości liczbowe:
```javascript
// Sortowanie od najtańszej do najdroższej usługi (rosnąco):
katalogUslug.sort((a, b) => a.cena - b.cena);

// Równoważny zapis tradycyjny z funkcją anonimową:
// katalogUslug.sort(function(a, b) {
//   return a.cena - b.cena;
// });
```

---

## 5. Wzorzec arkuszy CKE: Separacja danych w pliku `dane.js`

W zadaniach egzaminu państwowego kwalifikacji INF.03 dane testowe są oddzielone od logiki programu i dostarczane w osobnym pliku — zazwyczaj `dane.js`.

### Jak to działa w praktyce?
1. Plik `dane.js` zawiera wyłącznie deklarację globalnej bazy danych:
   ```javascript
   // dane.js
   const BAZA_ZGLOSZEN = [
     { nr: 101, klient: "Pol-Trans", koszt: 450, zrealizowane: true },
     { nr: 102, klient: "Agro-Handel", koszt: 280, zrealizowane: false }
   ];
   ```
2. W pliku `index.html` ładujemy skrypty w ścisłej kolejności — najpierw baza, potem skrypt operacyjny:
   ```html
   <script src="dane.js"></script>
   <script src="script.js"></script>
   ```
3. W pliku `script.js` stała `BAZA_ZGLOSZEN` jest od razu dostępna w zasięgu globalnym:
   ```javascript
   // script.js
   const zakonczone = BAZA_ZGLOSZEN.filter(z => z.zrealizowane);
   let suma = 0;
   zakonczone.forEach(z => suma += z.koszt);

   document.getElementById("wynik").textContent = "Przychód z zamkniętych zleceń: " + suma + " zł";
   ```

> **Po co to jest?**
> Zapewnia separację odpowiedzialności: podmienienie danych testowych na egzaminie nie wymaga ingerencji w logikę skryptu `script.js`, a kod działa w 100% lokalnie bez konieczności uruchamiania serwera HTTP ani ryzyka błędów CORS.

---

## 6. Granice metodyczne Semestru 2 a formularze i zdarzenia

Pamiętaj o kluczowej zasadzie obowiązującej w Semestrze 2:
- **NIE używamy jeszcze zdarzeń:** `onclick`, `addEventListener` pojawią się w Semestrze 3.
- **NIE odczytujemy wartości z kontrolek formularza:** `.value`, `.checked` pojawią się w Semestrze 4.
- W zadaniach Semestru 2 parametry wejściowe definiujemy bezpośrednio w kodzie JavaScript (lub pliku `dane.js`), a wyjście kierujemy wyłącznie do:
  ```javascript
  document.getElementById("wynik").textContent = sformatowanyRaport;
  ```
