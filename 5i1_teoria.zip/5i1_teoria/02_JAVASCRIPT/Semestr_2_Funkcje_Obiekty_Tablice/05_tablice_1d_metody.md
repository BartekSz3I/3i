# Podręcznik: Tablice jednowymiarowe (Array 1D) w JavaScript

Witaj w module poświęconym tablicom jednowymiarowym w języku JavaScript. Tablica to uporządkowana kolekcja wartości, która pozwala przechowywać pod jedną nazwą zmiennej wiele powiązanych danych — listę cen produktów, pomiary temperatur, identyfikatory paczek magazynowych czy oceny uczniów.

---

## 1. Architektura i tworzenie tablic

W JavaScript tablica jest obiektem dynamicznym. Oznacza to, że nie musimy deklarować jej stałego rozmiaru z góry — tablica rośnie i zmniejsza się w miarę dodawania lub usuwania elementów.

### A. Tworzenie pustej tablicy
```javascript
const pustaTablica = [];
```

### B. Inicjalizacja tablicy z elementami
```javascript
const temperatury = [18.5, 21.0, 19.4, 22.8, 20.1];
const statusy = ["nowe", "w_realizacji", "zamkniete"];
```

> **Po co to jest?**
> Literał nawiasów kwadratowych `[]` to najszybszy i rekomendowany sposób tworzenia tablic w JavaScript. Pozwala unikać konstruktora `new Array()`, który przy pojedynczym argumencie liczbowym zachowuje się nieintuicyjnie.
>
> **Typowa pomyłka:**
> Mylenie literału tablicy `[]` z literałem obiektu `{}` lub próba deklaracji tablicy ze statycznym rozmiarem w stylu języków C/C++ (`int tab[10]`), co w JavaScript jest błędem składniowym.

---

## 2. Indeksowanie i właściwość `.length`

Elementy w tablicy są numerowane kolejno od indeksu **0**. Ostatni element tablicy ma indeks o 1 mniejszy niż jej łączna długość (`length - 1`).

```javascript
const oceny = [4, 5, 3, 5, 2];

const pierwsza = oceny[0];                   // 4
const ostatnia = oceny[oceny.length - 1];    // 2
const dlugosc = oceny.length;                // 5
```

### Modyfikacja elementów
Element tablicy można nadpisać, przypisując nową wartość do wskazanego indeksu:
```javascript
oceny[2] = 4; // Zmiana oceny na indeksie 2 z 3 na 4
```

> **Po co to jest?**
> Bezpośredni dostęp przez indeks zapewnia natychmiastowy odczyt i modyfikację dowolnego elementu tablicy. Właściwość `.length` pozwala dynamicznie kontrolować wielkość zbioru.
>
> **Typowa pomyłka:**
> Odczyt poza zakresem: próba odczytu `tablica[tablica.length]` zwraca wartość `undefined`, ponieważ ostatni poprawny indeks to zawsze `tablica.length - 1`. Ponadto `.length` jest właściwością, a nie funkcją — zapis `tablica.length()` spowoduje błąd wykonania `TypeError`.

---

## 3. Dodawanie i usuwanie elementów na krańcach (push, pop, unshift, shift)

JavaScript udostępnia cztery podstawowe metody mutujące, które modyfikują oryginalną tablicę:

| Metoda | Działanie | Co zwraca metoda? | Zmiana indeksów |
|:---|:---|:---:|:---:|
| `push(element)` | Dodaje element na **koniec** tablicy | Nowa długość tablicy (`length`) | Brak zmian istniejących |
| `pop()` | Usuwa i zwraca element z **końca** tablicy | Usunięty element | Brak zmian pozostałych |
| `unshift(element)` | Wstawia element na **początek** tablicy | Nowa długość tablicy (`length`) | Przesuwa wszystkie indeksy o +1 |
| `shift()` | Usuwa i zwraca element z **początku** tablicy | Usunięty element | Przesuwa wszystkie indeksy o -1 |

```javascript
const kolejka = ["Zgłoszenie A", "Zgłoszenie B"];

kolejka.push("Zgłoszenie C"); // ["Zgłoszenie A", "Zgłoszenie B", "Zgłoszenie C"]
const obsluzone = kolejka.shift(); // "Zgłoszenie A", w tablicy zostało: ["Zgłoszenie B", "Zgłoszenie C"]
```

> **Po co to jest?**
> Metody te umożliwiają natychmiastową implementację klasycznych struktur danych: stosu (LIFO: `push` + `pop`) oraz kolejki (FIFO: `push` + `shift`).
>
> **Typowa pomyłka:**
> Mylenie kierunków: zapominanie, że `unshift` dodaje na początek, a `shift` z niego usuwa. Ponadto przypisywanie wyniku `tablica = tablica.push("X")` nadpisuje zmienną liczbą (nowym rozmiarem tablicy), niszcząc samą tablicę!

---

## 4. Wyszukiwanie elementów: `indexOf` oraz `includes`

Gdy chcemy sprawdzić, czy element występuje w tablicy, stosujemy:

### A. `indexOf(szukanyElement)`
Zwraca indeks pierwszego wystąpienia elementu lub liczbę `-1`, jeśli element nie istnieje w tablicy.
```javascript
const towary = ["kabel", "router", "switch"];
const pozycja = towary.indexOf("router"); // 1
const brak = towary.indexOf("laptop");    // -1
```

### B. `includes(szukanyElement)`
Zwraca wartość logiczną `true` lub `false`.
```javascript
if (towary.includes("switch")) {
  console.log("Urządzenie jest w magazynie");
}
```

> **Po co to jest?**
> Umożliwia prostą weryfikację uprawnień, dostępności towarów i duplikatów bez potrzeby ręcznego pisania pętli przeszukującej.
>
> **Typowa pomyłka:**
> Użycie `indexOf` w warunku logicznym w postaci `if (towary.indexOf("kabel"))`. Element na zerowej pozycji zwróci liczbę `0`, która w warunku traktowana jest jako fałsz (`falsy`), prowadząc do poważnego błędu logicznego! Zawsze sprawdzamy `!== -1`.

---

## 5. Zamiana tablicy w tekst: `.join(separator)`

Metoda `.join(separator)` łączy wszystkie elementy tablicy w jeden łańcuch znaków, wstawiając pomiędzy nie zdefiniowany łącznik:

```javascript
const podzespoly = ["Procesor", "RAM", "Dysk SSD"];
const listaTekst = podzespoly.join(", ");      // "Procesor, RAM, Dysk SSD"
const sciezka = ["pliki", "projekty", "js"].join("/"); // "pliki/projekty/js"
```

> **Po co to jest?**
> Pozwala estetycznie zaprezentować zbiór danych użytkownikowi bez widocznych nawiasów kwadratowych. Doskonale współpracuje z metodą `.split()` z modułu 03.
>
> **Typowa pomyłka:**
> Wywołanie `.join()` bez argumentu — domyślnym separatorem jest wówczas sam przecinek bez spacji (`"Procesor,RAM,Dysk SSD"`).

---

## 6. Wycinanie i modyfikacja: `.slice()` vs `.splice()`

To dwie kluczowe metody, których nazwy brzmią podobnie, ale działają zupełnie inaczej:

### A. `.slice(start, koniec)` – Niemutujące wycinanie
Zwraca **nową tablicę** zawierającą fragment od indeksu `start` do `koniec - 1`. Oryginalna tablica pozostaje nienaruszona.
```javascript
const planety = ["Merkury", "Wenus", "Ziemia", "Mars", "Jowisz"];
const wewnetrzne = planety.slice(0, 4); // ["Merkury", "Wenus", "Ziemia", "Mars"]
```

### B. `.splice(start, ileUsunac, ...noweElementy)` – Mutująca operacja wewnątrz tablicy
Modyfikuje **oryginalną tablicę**: usuwa z niej określoną liczbę elementów od pozycji `start` i opcjonalnie wstawia w to miejsce nowe wartości.
```javascript
const paczki = ["P-101", "P-102", "P-103", "P-104"];

// Usuwamy 1 element od indeksu 1 ("P-102") i wstawiamy "P-199":
paczki.splice(1, 1, "P-199");
// paczki = ["P-101", "P-199", "P-103", "P-104"]

// Usuwamy 2 elementy od indeksu 2:
paczki.splice(2, 2);
// paczki = ["P-101", "P-199"]
```

### C. `.reverse()` – Odwracanie kolejności
Odwraca kolejność elementów w tablicy (metoda mutująca).
```javascript
const liczby = [1, 2, 3, 4];
liczby.reverse(); // [4, 3, 2, 1]
```

> **Po co to jest?**
> `slice` służy do bezpiecznego pobierania podzbioru danych (np. pierwszych 3 wyników), natomiast `splice` do usuwania lub wstawiania rekordów wewnątrz kolekcji.
>
> **Typowa pomyłka:**
> Pomyłka w parametrach `splice`: drugi argument to **liczba elementów do usunięcia**, a nie indeks końcowy (jak w `slice`)! Zapis `tab.splice(2, 5)` usuwa aż 5 elementów począwszy od indeksu 2.

---

## 7. Sortowanie tablic: `.sort()` i pułapka liczbowa

Metoda `.sort()` porządkuje elementy w tablicy w miejscu (mutuje tablicę).

### Kluczowa pułapka: Domyślne sortowanie leksykograficzne!
Domyślnie JavaScript konwertuje wszystkie elementy na ciągi tekstowe i sortuje je alfabetycznie (według kodów znaków Unicode):
```javascript
const liczby = [25, 8, 100, 4];
liczby.sort();
console.log(liczby); // [100, 25, 4, 8] - BŁĄD LOGICZNY! "100" zaczyna się od "1", więc jest przed "25" i "4"!
```

### Poprawne sortowanie liczb za pomocą funkcji porównującej (komparatora):
Aby poprawnie posortować liczby, musimy przekazać funkcję komparatora.

#### Przypomnienie z Modułu 01: Funkcje anonimowe i strzałkowe
W module 01 poznaliśmy funkcje anonimowe (bez nazwy) oraz nowoczesne **funkcje strzałkowe (Arrow Functions)** o składni `(parametry) => wyrażenie`. 

Metoda `.sort()` przyjmuje jako argument funkcję pomocniczą (tzw. komparator), która dla każdej pary elementów `(a, b)` decyduje o ich kolejności. 
Możemy to zapisać na dwa w pełni równoważne sposoby:

1. **Tradycyjna funkcja anonimowa:**
   ```javascript
   liczby.sort(function(a, b) {
     return a - b;
   });
   ```
2. **Nowoczesna funkcja strzałkowa (zalecany, zwięzły standard):**
   ```javascript
   // Sortowanie rosnąco:
   liczby.sort((a, b) => a - b);
   console.log(liczby); // [4, 8, 25, 100]

   // Sortowanie malejąco:
   liczby.sort((a, b) => b - a);
   console.log(liczby); // [100, 25, 8, 4]
   ```

Zapis `(a, b) => a - b` jest skróconą funkcją strzałkową: przyjmuje dwa parametry `a` i `b`, odejmuje je od siebie i automatycznie (niejawnie) zwraca wynik bez potrzeby pisania słowa `return` i klamer `{}`.

Jak silnik JavaScript interpretuje wynik odejmowania?
* Jeśli wynik `a - b` jest **ujemny** (czyli `a < b`), element `a` trafia przed `b`.
* Jeśli wynik wynosi **zero**, kolejność nie ulega zmianie.
* Jeśli wynik jest **dodatni** (czyli `a > b`), element `b` trafia przed `a`.

> **Po co to jest?**
> Prawidłowe sortowanie pozwala układać cenniki od najtańszego do najdroższego, tworzyć rankingi graczy i porządkować daty. Użycie funkcji strzałkowej skraca kod z 3 linijek do jednej czytelnej instrukcji.
>
> **Typowa pomyłka:**
> Zapomnienie o komparatorze liczbowym `(a, b) => a - b` przy sortowaniu cen, wag czy punktów, co prowadzi do drastycznych błędów biznesowych na egzaminie zawodowym. Druga częsta pomyłka to wstawienie klamer `{}` bez słowa `return`: `(a, b) => { a - b }` — funkcja taka zwraca `undefined` i sortowanie ulega uszkodzeniu.

---

## 8. Wyprowadzanie danych w Semestrze 2

Zgodnie z rygorem metodycznym Semestru 2 dane wyprowadzamy do elementu o identyfikatorze `#wynik` za pomocą właściwości `textContent`:
```javascript
const raport = "Zestawienie paczek:\n" + paczki.join("\n");
document.getElementById("wynik").textContent = raport;
```
W arkuszu CSS kontener ten posiada regułę `white-space: pre-wrap;`, dzięki czemu znaki nowej linii (`\n`) są interpretowane natywnie jako przełamania wiersza.
