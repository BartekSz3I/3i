# Podręcznik: Obiekt Date i obsługa czasu w JavaScript

Witaj w module poświęconym obsłudze daty i czasu w języku JavaScript. Zrozumienie obiektu `Date` jest niezbędne w pracy każdego programisty frontendowego — od wyznaczania terminów ważności biletów, przez rejestrację zgłoszeń serwisowych, aż po precyzyjne odliczanie do wydarzeń i pomiar wydajności algorytmów.

---

## 1. Architektura czasu w JavaScript (Epoka Uniksa)

JavaScript mierzy czas jako liczbę milisekund (ms), które upłynęły od północy **1 stycznia 1970 roku UTC** (tzw. *Unix Epoch*).
Jedna sekunda to 1000 milisekund. Jeden dzień to dokładnie:
```javascript
const JEDEN_DZIEN_MS = 1000 * 60 * 60 * 24; // 86 400 000 ms
```

Dzięki temu odejmowanie dwóch obiektów daty zwraca prostą liczbę całkowitą (różnicę w milisekundach), którą możemy łatwo przeliczyć na dni, godziny lub minuty.

> **Po co to jest?**
> Standard Uniksa pozwala jednoznacznie porównywać daty i mierzyć upływ czasu bez konfliktów związanych z formatem zapisu czy strefami czasowymi.
>
> **Typowa pomyłka:**
> Próba bezpośredniego dzielenia obiektów dat zamiast ich odjęcia lub brak uwzględnienia, że wynik różnicy jest w milisekundach, a nie w sekundach.

---

## 2. Tworzenie obiektów daty (Konstruktor `new Date`)

Obiekt `Date` możemy zainicjalizować na cztery podstawowe sposoby:

### A. Bieżący czas systemowy
```javascript
const teraz = new Date();
```
Tworzy obiekt reprezentujący dokładny moment wykonania instrukcji w oparciu o zegar systemowy użytkownika.

### B. Znacznik czasu w milisekundach (Timestamp)
```javascript
const dataZero = new Date(0); // 1 stycznia 1970 00:00:00 UTC
const dataZMs = new Date(1773000000000);
```

### C. Tekst w formacie ISO 8601
```javascript
const dataWydarzenia = new Date("2026-10-15");
const dataDokladna = new Date("2026-10-15T14:30:00");
```
Format `"RRRR-MM-DD"` jest rekomendowanym standardem międzynarodowym.

### D. Składowe numeryczne (Rok, Miesiąc, Dzień, Godzina...)
```javascript
const startRoku = new Date(2026, 9, 15, 12, 0, 0); // Uwaga: miesiąc 9 to PAŹDZIERNIK!
```
Kolejność argumentów: `rok`, `indeks_miesiaca` (obowiązkowe), `dzien` (domyślnie 1), `godzina` (domyślnie 0), `minuta` (0), `sekunda` (0), `milisekunda` (0).

> **Po co to jest?**
> Różne konstruktory pozwalają łatwo przetwarzać zarówno dane pobrane z bazy (string ISO), wygenerowane w pętli (timestamp), jak i wprowadzone przez użytkownika w polach formularza.
>
> **Typowa pomyłka:**
> Zapomnienie o słowie kluczowym `new`. Wywołanie `Date()` bez `new` zwraca zwykły ciąg znaków (`string`), na którym nie można wywoływać metod takich jak `getFullYear()`!

---

## 3. Odczytywanie składowych daty (Metody typu `get*`)

| Metoda | Zakres zwracanych wartości | Opis |
|:---|:---:|:---|
| `getFullYear()` | np. `2026` | Pełny czterocyfrowy rok kalendarzowy |
| `getMonth()` | `0 - 11` | **Indeks miesiąca (0 = Styczeń, 11 = Grudzień)** |
| `getDate()` | `1 - 31` | Dzień miesiąca |
| `getDay()` | `0 - 6` | **Dzień tygodnia (0 = Niedziela, 6 = Sobota)** |
| `getHours()` | `0 - 23` | Godzina w trybie 24-godzinnym |
| `getMinutes()` | `0 - 59` | Minuty |
| `getSeconds()` | `0 - 59` | Sekundy |
| `getMilliseconds()` | `0 - 999` | Milisekundy |
| `getTime()` | liczba całkowita | Znacznik czasu w milisekundach od 01.01.1970 |

### Kluczowa pułapka 1: Miesiące są indeksowane od zera!
Gdy w kalendarzu mamy październik (10. miesiąc), metoda `getMonth()` zwraca liczbę `9`. Aby wyświetlić użytkownikowi poprawny numer miesiąca, zawsze dodajemy 1:
```javascript
const d = new Date("2026-10-15");
const numerMiesiaca = d.getMonth() + 1; // 10
```

### Kluczowa pułapka 2: `getDate()` a `getDay()`
* `getDate()` zwraca **dzień miesiąca** (np. 15. dzień października).
* `getDay()` zwraca **dzień tygodnia** (0 to Niedziela, 1 to Poniedziałek, 2 to Wtorek itd.).

> **Po co to jest?**
> Metody `get` umożliwiają dekompozycję obiektu daty na poszczególne parametry i budowanie własnych formatów wydruku.
>
> **Typowa pomyłka:**
> Używanie przestarzałej metody `getYear()`, która zwracała liczbę lat od 1900 roku (np. 126 zamiast 2026). Zawsze należy stosować `getFullYear()`!

---

## 4. Modyfikacja daty (Metody typu `set*`) i automatyczne przepełnienie

JavaScript udostępnia odpowiedniki metod `set` dla każdej składowej:
* `setFullYear(rok[, miesiac, dzien])`
* `setMonth(miesiac[, dzien])`
* `setDate(dzien)`
* `setHours(godzina[, minuty, sekundy])`
* `setMinutes(minuty[, sekundy])`
* `setSeconds(sekundy)`
* `setTime(milisekundy)`

### Magia automatycznego przeliczania (Kalendarzowy Overflow)
Gdy ustawimy dzień miesiąca przekraczający liczbę dni w danym miesiącu, JavaScript automatycznie przeskakuje do kolejnego miesiąca:
```javascript
const data = new Date(2026, 0, 25); // 25 stycznia 2026
data.setDate(data.getDate() + 10);  // Dodajemy 10 dni
console.log(data.getDate());       // 4
console.log(data.getMonth() + 1);   // 2 (Luty!)
```
Mechanizm ten działa również wstecz (gdy odejmujemy dni od początku miesiąca).

> **Po co to jest?**
> Programista nie musi ręcznie sprawdzać, ile dni ma dany miesiąc ani czy rok jest przestępny — silnik JavaScript sam przelicza kalendarz.
>
> **Typowa pomyłka:**
> Ręczne dodawanie dni do napisu tekstowego (np. `"2026-01-25" + 10`), co prowadzi do błędów konkatenacji `"2026-01-2510"`.

---

## 5. Różnica czasu i obliczanie liczby dni

Aby obliczyć, ile pełnych dni dzieli dwie daty:
```javascript
function obliczRozniceDni(wczesniejszaData, pozniejszaData) {
  const roznicaMs = pozniejszaData.getTime() - wczesniejszaData.getTime();
  const jedenDzienMs = 1000 * 60 * 60 * 24;
  return Math.floor(roznicaMs / jedenDzienMs);
}
```

Jeśli chcemy sprawdzić czas z dokładnością do godzin:
```javascript
const godziny = Math.floor(roznicaMs / (1000 * 60 * 60));
```

> **Po co to jest?**
> Niezbędne przy wyliczaniu terminów ważności gwarancji, kar umownych, wieku pracowników oraz okresów przydatności towarów.
>
> **Typowa pomyłka:**
> Dzielenie milisekund przez 24 lub 60 bez uwzględnienia pełnego iloczynu `1000 * 60 * 60 * 24`.

---

## 6. Formatowanie daty: dopełnianie zerem (`padStart`)

W języku polskim oraz standardzie międzynarodowym dni i miesiące jednocyfrowe poprzedza się wiodącym zerem (`"04"` zamiast `"4"`).
Najczystszym sposobem formatowania jest metoda `padStart(2, "0")` z obiektu `String`:
```javascript
function formatujDatePolska(data) {
  const dzien = String(data.getDate()).padStart(2, "0");
  const miesiac = String(data.getMonth() + 1).padStart(2, "0");
  const rok = data.getFullYear();
  return dzien + "." + miesiac + "." + rok;
}
```

---

## 7. Wyprowadzanie danych w Semestrze 2

Zgodnie z rygorem metodycznym Semestru 2 dane wyprowadzamy do elementu o identyfikatorze `#wynik`:
```javascript
document.getElementById("wynik").textContent = raportTekstowy;
```
W arkuszu CSS kontener ten posiada regułę `white-space: pre-wrap;`, dzięki czemu znaki nowej linii (`\n`) oraz wielokrotne spacje są zachowywane bez potrzeby używania znaczników `<br>`.
