# Teoria: Git lokalny — kontrola wersji na własnym komputerze

## 1. Po co komu kontrola wersji?

Gdy zapisujesz projekt tylko jako folder na dysku, każda większa zmiana grozi utratą poprzedniej działającej wersji. Kopiowanie katalogów (`strona_v2`, `strona_OST`) szybko się rozjeżdża: nie wiadomo, która kopia jest aktualna, kto ją zmienił i dlaczego.

**System kontroli wersji (VCS)** zapisuje kolejne migawki projektu razem z opisem (komunikatem) i datą. Git jest obecnie najpopularniejszym narzędziem tego typu w zawodzie programisty i pojawia się w wymaganiach INF.03.

**Po co.** Historia pozwala wrócić do stanu sprzed błędu, porównać zmiany i udokumentować kolejne etapy pracy — także gdy pracujesz sam.

**Typowa pomyłka.** Uczeń myli „mam folder na dysku” z „mam repozytorium Git”. Sam katalog z plikami HTML nie jest repozytorium, dopóki nie wykonasz `git init`.

---

## 2. Instalacja i tożsamość autora commitów

Po instalacji Gita (git-scm.com) w terminalu sprawdzasz wersję:

```bash
git --version
```

Każdy commit w historii ma autora. Git bierze imię i e-mail z konfiguracji:

```bash
git config --global user.name "Jan Kowalski"
git config --global user.email "jan.kowalski@zsz.edu.pl"
```

Na sali szkolnej często bezpieczniej ustawić tożsamość **tylko w katalogu projektu** (bez `--global`):

```bash
git config --local user.name "Jan Kowalski"
git config --local user.email "jan.kowalski@zsz.edu.pl"
```

Sprawdzenie:

```bash
git config user.name
git config user.email
```

**Po co.** Gdy kiedyś połączysz repo z GitHubem, historia będzie spójna z Twoją tożsamością. Lokalna konfiguracja nie nadpisuje ustawień innych użytkowników na wspólnym koncie Windows.

**Typowa pomyłka.** Commit bez skonfigurowanego e-maila kończy się ostrzeżeniem albo odmową (w nowszych wersjach Gita). Drugi błąd: ustawienie `--global` na komputerze szkolnym cudzym nazwiskiem.

---

## 3. Inicjalizacja repozytorium: `git init`

W katalogu projektu:

```bash
cd sciezka/do/projektu
git init
```

Git tworzy ukryty folder `.git` z bazą historii. Od tej chwili katalog jest **repozytorium**.

**Po co.** Wszystkie kolejne polecenia (`status`, `add`, `commit`) działają względem tego folderu `.git`.

**Typowa pomyłka.** `git init` wykonany w złym katalogu (np. na pulpicie zamiast w folderze projektu) albo powtórzony niezwanie w podfolderze — wtedy powstają zagnieżdżone repozytoria i chaos.

---

## 4. Trzy obszary pracy

Wyobraź sobie taśmę produkcyjną:

| Obszar | Co zawiera | Typowe polecenie |
|:---|:---|:---|
| **Katalog roboczy** | Pliki, które edytujesz w VS Code | (zapis pliku na dysku) |
| **Poczekalnia (staging / index)** | Wybrane zmiany przygotowane do zapisu w historii | `git add` |
| **Repozytorium (commits)** | Trwała historia migawek | `git commit` |

Cykl życia pliku:

1. Plik nowy → **untracked** (nieśledzony).
2. Po `git add` → **staged** (w poczekalni).
3. Po `git commit` → zapisany w historii; katalog roboczy jest **clean**, jeśli nie ma dalszych edycji.

**Po co.** Rozdzielenie `add` i `commit` pozwala zatwierdzić tylko wybrane pliki (np. bez notatek prywatnych).

**Typowa pomyłka.** Uczeń robi `commit` od razu po edycji i dziwi się, że Git mówi „nothing to commit”. Bez `add` zmiany nie trafiły do poczekalni.

---

## 5. Status: `git status`

```bash
git status
```

Polecenie pokazuje m.in.:

- które pliki są nieśledzone,
- które są w poczekalni,
- które zmieniono od ostatniego commita,
- czy gałąź jest „clean”.

**Po co.** To pierwszy diagnostyczny odruch przed każdym commitem — jak „czy na pewno wiem, co zatwierdzam?”.

**Typowa pomyłka.** Ignorowanie czerwonego/zielonego podziału w komunikacie i dodawanie wszystkiego w ciemno.

---

## 6. Dodawanie do poczekalni: `git add`

```bash
git add index.html
git add style.css script.js
git add .
```

- `git add nazwa_pliku` — jeden plik.
- `git add .` — wszystkie zmiany w bieżącym katalogu i podkatalogach (z wyjątkiem reguł `.gitignore`).

**Po co.** Budujesz zestaw zmian, który ma sens jako jedna logiczna migawka (np. „szkielet HTML wizytówki”).

**Typowa pomyłka.** `git add .` wrzuca do poczekalni także pliki tymczasowe, hasła w `.env` albo katalog `node_modules`, jeśli nie ma `.gitignore`.

---

## 7. Zatwierdzanie: `git commit`

```bash
git commit -m "Dodano szkielet strony głównej klubu"
```

Komunikat commita powinien:

- opisywać **dlaczego / co wniesiono**, nie „poprawki” ani „asdf”,
- być w języku uzgodnionym na sali (u nas: po polsku, pełne zdanie lub zwięzły tryb rozkazujący).

**Po co.** Za pół roku `git log` ma dać się czytać jak dziennik budowy projektu.

**Typowa pomyłka.** Pusty komunikat, komunikat bez `-m` (otwiera się edytor vim/nano i uczeń „utknął”), albo jeden wielki commit „cała strona” zamiast kilku logicznych kroków.

---

## 8. Historia: `git log`

```bash
git log
git log --oneline
```

- `git log` — pełny widok (hash, autor, data, komunikat).
- `git log --oneline` — skrócona lista (wygodna na co dzień).

Wyjście z pełnego logu w pagerze: klawisz `q`.

**Po co.** Potwierdzasz, że commity faktycznie powstały i w jakiej kolejności.

**Typowa pomyłka.** Panika, że „terminal się zawiesił” — to pager (`less`); wystarczy `q`.

---

## 9. Różnice: `git diff`

```bash
git diff
git diff --staged
```

- `git diff` — różnica między katalogiem roboczym a poczekalnią (co zmieniłeś, a jeszcze nie dodałeś).
- `git diff --staged` (alias: `--cached`) — różnica między poczekalnią a ostatnim commitem (co wejdzie do następnego `commit`).

**Po co.** Przeglądasz zmiany linia po linii przed zatwierdzeniem — jak kontrola jakości.

**Typowa pomyłka.** Oczekiwanie, że `git diff` pokaże pliki już dodane `add` — te widać w `git diff --staged`.

---

## 10. Ignorowanie plików: `.gitignore`

W katalogu głównym repozytorium tworzysz plik `.gitignore`, np.:

```gitignore
node_modules/
.env
*.log
.DS_Store
Thumbs.db
```

Git przestaje proponować te ścieżki w `status` i nie doda ich przez `git add .`.

**Po co.** Historii nie zaśmiecasz zależnościami ani sekretami (hasła, klucze API).

**Typowa pomyłka.** Dodanie `.gitignore` **po** tym, jak plik już trafił do commita — samo wpisanie reguły nie usuwa pliku z historii; trzeba go najpierw przestać śledzić (w tym module wystarczy dbać o `.gitignore` **przed** pierwszym `add` problematycznych plików). Reguła `*.log` nie zadziała, jeśli wpiszesz `*.LOG` na systemie rozróżniającym wielkość liter i plik ma inne rozszerzenie.

---

## 11. Minimalny rytuał dnia pracy (checklista)

1. `cd` do katalogu projektu.
2. `git status` — zobacz, co się zmieniło.
3. Edycja plików w edytorze, zapis na dysku.
4. Ponownie `git status` (i w razie potrzeby `git diff`).
5. `git add` wybranych plików.
6. `git diff --staged` — ostatnie spojrzenie.
7. `git commit -m "Komunikat opisujący zmianę"`.
8. `git log --oneline` — potwierdzenie wpisu w historii.

---

## 12. Czego świadomie nie robimy w tym module

- Nie tworzymy gałęzi (`branch`) ani nie scalamy (`merge`).
- Nie łączymy się z GitHubem (`remote`, `push`, `pull`, `clone`).
- Nie przepisujemy historii (`rebase`, `reset --hard`).
- Nie piszemy jeszcze logiki JavaScript — plik `script.js` jest miejscem na przyszły kod z kolejnych działów.
