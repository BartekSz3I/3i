# Teoria: Zmienne, Typy Danych i Operatory w JavaScript

---

## 1. Zmienne i stałe w JavaScript: `let` oraz `const`

W programowaniu zmienna to nazwane miejsce w pamięci operacyjnej komputera, w którym przechowujemy dane potrzebne do działania programu. We współczesnym standardzie JavaScript (ES6+) stosujemy wyłącznie dwa słowa kluczowe do tworzenia zmiennych:

```javascript
// Stała — wartość, która po przypisaniu NIGDY nie ulegnie zmianie
const NAZWA_APLIKACJI = "System Magazynowy PRO";
const STAWKA_VAT = 0.23;

// Zmienna — wartość, którą planujemy modyfikować w trakcie działania programu
let liczbaUzytkownikow = 10;
liczbaUzytkownikow = 11; // poprawne przypisanie nowej wartości
```

### Dlaczego unikamy przestarzałego słowa `var`?
Przed 2015 rokiem stosowano słowo kluczowe `var`. Posiada ono tzw. zasięg funkcyjny zamiast blokowego oraz podlega mechanizmowi *hoistingu* (wynoszenia deklaracji), co prowadziło do trudnych do wykrycia błędów w aplikacjach. Nowoczesne standardy branżowe oraz egzaminy CKE nakazują stosowanie `const` jako domyślnego wyboru oraz `let` wszędzie tam, gdzie wartość musi być nadpisana.

> **Po co to jest?**  
> Używanie `const` zabezpiecza programistę przed przypadkowym nadpisaniem kluczowych danych konfiguracyjnych (np. stawek podatkowych, adresów serwerów czy reguł biznesowych).
>
> **Typowa pomyłka:**  
> Próba ponownego przypisania wartości do stałej:
> ```javascript
> const rabat = 10;
> rabat = 15; // Błąd: TypeError: Assignment to constant variable.
> ```
> Jeśli wartość ma się zmieniać, zadeklaruj ją słowem `let`.

---

## 2. Typy prymitywne w JavaScript

JavaScript jest językiem o **typowaniu dynamicznym** — oznacza to, że nie musimy ręcznie określać typu zmiennej podczas deklaracji; typ jest ustalany automatycznie na podstawie przypisanej wartości.

Do podstawowych typów prymitywnych należą:

| Typ danych | Opis i przykłady | Przykładowy zapis |
|---|---|---|
| **`number`** | Liczby całkowite oraz zmiennoprzecinkowe (dziesiętne zapisujemy z kropką). Specjalne wartości liczbowe: `NaN` (*Not a Number*), `Infinity`. | `let wiek = 18;``<br>``let cena = 49.99;` |
| **`string`** | Łańcuchy znaków (tekst) ujęte w pojedynczy (`'...'`), podwójny (`"..."`) lub ukośny cudzysłów (tzw. backtick \`...\`). | `let imie = "Anna";``<br>``let kod = 'PL-01';` |
| **`boolean`** | Typ logiczny przyjmujący wyłącznie jedną z dwóch wartości: `true` (prawda) albo `false` (fałsz). | `let czyZalogowany = true;` |
| **`undefined`** | Wartość domyślna zmiennej, która została zadeklarowana, ale nie przypisano jej jeszcze żadnej wartości. | `let wynik;` (wynik to `undefined`) |
| **`null`** | Świadome, celowe oznaczenie braku wartości lub pustego obiektu. | `let wybranaOpcja = null;` |

### Operator `typeof`
Operator `typeof` służy do sprawdzania, jakiego typu dane znajdują się aktualnie w zmiennej:
```javascript
let waga = 72.5;
console.log(typeof waga); // wypisze: "number"

let miasto = "Warszawa";
console.log(typeof miasto); // wypisze: "string"

let aktywny = false;
console.log(typeof aktywny); // wypisze: "boolean"
```

> **Po co to jest?**  
> Operator `typeof` pozwala sprawdzić typ zmiennej przed wykonaniem operacji matematycznej, co zapobiega błędom w obliczeniach.
>
> **Typowa pomyłka:**  
> Wywołanie `typeof null` zwraca historyczny błąd języka JavaScript: `"object"` (mimo że `null` jest typem prymitywnym). Warto pamiętać o tym jako o ciekawostce często pojawiającej się w pytaniach testowych CKE!

---

## 3. Operatory arytmetyczne i przypisania

JavaScript udostępnia pełny zestaw operatorów matematycznych:

```javascript
let a = 10;
let b = 3;

let suma = a + b;       // 13 (dodawanie)
let roznica = a - b;    // 7  (odejmowanie)
let iloczyn = a * b;    // 30 (mnożenie)
let iloraz = a / b;     // 3.3333333333333335 (dzielenie)
let reszta = a % b;     // 1  (modulo — reszta z dzielenia: 10 = 3*3 + 1)
let potega = a ** b;    // 1000 (10 do potęgi 3)
```

### Operatory przypisania złożonego:
Zamiast pisać `licznik = licznik + 5;`, możemy zastosować czytelny skrót:
* `licznik += 5;` (zwiększ o 5)
* `licznik -= 2;` (zmniejsz o 2)
* `licznik *= 3;` (pomnóż przez 3)
* `licznik++;` (zwiększ dokładnie o 1 — inkrementacja)
* `licznik--;` (zmniejsz dokładnie o 1 — dekrementacja)

> **Po co to jest?**  
> Operator modulo `%` jest kluczowy w programowaniu: pozwala łatwo sprawdzić, czy liczba jest parzysta (`liczba % 2 === 0`), obliczyć pełne opakowania towaru lub przeliczyć sekundy na minuty.
>
> **Typowa pomyłka:**  
> Pułapka operatora `+` przy łączeniu tekstu z liczbami:
> ```javascript
> let wynik = "10" + 5; // Wynik to napis: "105", a nie liczba 15!
> let odejmowanie = "10" - 5; // Wynik to liczba: 5 (Git/JS dokonał niejawnej konwersji)
> ```
> Operator `+` służy zarówno do dodawania liczb, jak i do łączenia napisów (*konkatenacji*). Jeśli choć jeden składnik jest tekstem, nastąpi złączenie tekstowe.

---

## 4. Konwersje typów: Zamiana tekstu na liczbę

Gdy pobieramy dane z formularza lub okna `prompt()`, dane te zawsze zwracane są jako **tekst (`string`)**. Aby wykonać na nich obliczenia, musimy dokonać jawnej konwersji:

```javascript
let tekstLiczby = "42";
let liczbaCalkowita = parseInt(tekstLiczby);     // 42 (jako number)

let tekstCeny = "19.99";
let liczbaDziesietna = parseFloat(tekstCeny);    // 19.99 (jako number)

// Uniwersalna konwersja za pomocą konstruktora Number:
let cena = Number("120.50"); // 120.5

// Gdy tekst nie jest liczbą:
let blad = Number("sto"); // zwraca specjalną wartość NaN (Not a Number)
```

---

## 5. Operatory porównania: Ścisła równość (`===`) vs luźna równość (`==`)

To jedno z najważniejszych zagadnień na egzaminie zawodowym INF.03:

### 1. Operator ścisłej równości: `===` (oraz ścisłej nierówności: `!==`)
Porównuje **zarówno wartość, jak i typ danych**. Nie dokonuje żadnych automatycznych konwersji.
```javascript
5 === 5;         // true  (ta sama wartość i ten sam typ: number)
5 === "5";       // false (różne typy: number oraz string!)
```

### 2. Operator luźnej równości: `==` (oraz luźnej nierówności: `!=`)
Próbuje niejawnie przekonwertować typy przed porównaniem.
```javascript
5 == "5";        // true  (niebezpieczne — JS przekonwertował tekst "5" na liczbę)
0 == false;      // true
```

> **Zasada programistyczna:**  
> Zawsze i bezwzględnie stosujemy operator ścisły `===` oraz `!==`. Operator `==` jest źródłem subtelnych błędów logicznych i jest uznawany za złą praktykę programistyczną.

### Pozostałe operatory relacji:
* `a > b` (większe niż)
* `a < b` (mniejsze niż)
* `a >= b` (większe lub równe)
* `a <= b` (mniejsze lub równe)

---

## 6. Operatory logiczne: `&&`, `||`, `!`

Operatory logiczne pozwalają budować złożone warunki:

```javascript
let wiek = 20;
let maPrawoJazdy = true;

// 1. Koniunkcja (AND — oba warunki muszą być prawdziwe):
let mozeProwadzicAuto = (wiek >= 18) && maPrawoJazdy; // true

// 2. Alternatywa (OR — wystarczy, że jeden warunek jest prawdziwy):
let jestUczniem = true;
let jestStudentem = false;
let znizka = jestUczniem || jestStudentem; // true

// 3. Negacja (NOT — odwraca wartość logiczną):
let zablokowany = false;
let aktywny = !zablokowany; // true
```

---

## 7. Wypis wyników obliczeń w Semestrze 1 (`document.write`)

Zgodnie z rygorem metodycznym Semestru 1, wyniki obliczeń wypisujemy bezpośrednio wewnątrz kontenera `<div class="wynik">`:

```html
<div class="wynik">
  <script src="script.js"></script>
</div>
```

W pliku `script.js`:
```javascript
const cenaNetto = 100;
const podatek = cenaNetto * 0.23;
const cenaBrutto = cenaNetto + podatek;

document.write("Cena netto: " + cenaNetto + " zł`<br>`");
document.write("Podatek VAT (23%): " + podatek + " zł`<br>`");
document.write("Razem brutto: " + cenaBrutto + " zł");
```

---

## 8. Zestawienie najważniejszych operatorów modułu 04

| Operator | Nazwa | Działanie / Przykład |
|:---:|---|---|
| `let` / `const` | Deklaracja | Tworzenie zmiennej lub stałej w zasięgu blokowym |
| `+`, `-`, `*`, `/` | Arytmetyczne | Standardowe działania matematyczne |
| `%` | Modulo | Reszta z dzielenia całkowitego, np. `11 % 4` daje `3` |
| `**` | Potęgowanie | Podnoszenie do potęgi, np. `2 ** 3` daje `8` |
| `+=`, `-=`, `*=` | Przypisanie złożone | Zmiana wartości zmiennej o zadaną wielkość |
| `===` / `!==` | Ścisłe porównanie | Porównanie wartości ORAZ typu danych bez konwersji |
| `&&` | Koniunkcja (AND) | Zwraca `true` tylko, gdy oba warunki są prawdziwe |
| `\|\|` | Alternatywa (OR) | Zwraca `true`, gdy przynajmniej jeden warunek jest prawdziwy |
| `!` | Negacja (NOT) | Odwrócenie wartości logicznej (`!true` $\to$ `false`) |
| `typeof` | Badanie typu | Zwraca nazwę typu danych jako ciąg tekstowy |
