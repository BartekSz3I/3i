# Teoria: Instrukcje warunkowe i sterowanie przepływem programu w JavaScript

Instrukcje warunkowe to fundamentalne konstrukcje programistyczne umożliwiające podejmowanie decyzji na podstawie wartości logicznych (`true` lub `false`). Dzięki nim program może reagować dynamicznie na wprowadzane dane, wykonywać alternatywne bloki kodu oraz pomijać fragmenty, których warunki nie zostały spełnione.

---

## 1. Wyrażenia warunkowe i konwersja do typu logicznego (Truthy i Falsy)

Każde wyrażenie umieszczone w nawiasie warunku `if (...)` lub w operatorze trójargumentowym jest automatycznie konwertowane na wartość typu boolean (`Boolean(wyrazenie)`).

W języku JavaScript istnieje dokładnie **8 wartości falsy** (uznawanych za fałsz):
1. `false` — literał logiczny fałszu
2. `0` — liczba zero
3. `-0` — ujemne zero
4. `0n` — wartość BigInt zero
5. `""` (pusty łańcuch znaków)
6. `null` — brak wartości
7. `undefined` — niezdefiniowana zmienna
8. `NaN` — wartość Not-a-Number

Wszystkie pozostałe wartości (np. `"0"`, `"false"`, `[]`, `{}`, liczby ujemne i dodatnie różne od zera) są **truthy** (reprezentują logiczną prawdę).

---

## 2. Podstawowa instrukcja warunkowa `if` oraz `if ... else`

### 2.1. Składnia instrukcji `if`
```javascript
if (warunek) {
  // Blok kodu wykonywany TYLKO wtedy, gdy warunek zwraca true
}
```

### 2.2. Składnia instrukcji dwuwariantowej `if ... else`
```javascript
let wiek = 17;

if (wiek >= 18) {
  document.write("<p class='sukces'>Dostęp przyznany: Użytkownik pełnoletni.</p>");
} else {
  document.write("<p class='blad'>Odmowa dostępu: Wymagane ukończenie 18 lat.</p>");
}
```

> **Dobra praktyka:** Zawsze stosuj nawiasy klamrowe `{ ... }`, nawet jeśli blok warunku składa się z pojedynczej instrukcji. Zapobiega to błędom logicznym podczas późniejszego dopisywania kolejnych linii kodu.

---

## 3. Rozgałęzienia wielowariantowe `if ... else if ... else`

Gdy problem wymaga zbadania kilku wzajemnie wykluczających się przedziałów lub warunków, stosuje się kaskadę `else if`:

```javascript
let punkty = 78;
let ocena = "";

if (punkty >= 90) {
  ocena = "bardzo dobra (5)";
} else if (punkty >= 75) {
  ocena = "dobra (4)";
} else if (punkty >= 50) {
  ocena = "dostateczna (3)";
} else if (punkty >= 30) {
  ocena = "dopuszczająca (2)";
} else {
  ocena = "niedostateczna (1)";
}

document.write("<p>Uzyskana ocena: <strong>" + ocena + "</strong></p>");
```

---

## 4. Instrukcja wyboru `switch ... case ... default`

Instrukcja `switch` służy do porównywania jednej wartości (zmiennej lub wyrażenia) z wieloma stałymi przypadkami (`case`). Porównanie w instrukcji `switch` zawsze używa **ścisłej równości** (`===`), co oznacza, że sprawdzana jest zgodność zarówno wartości, jak i typu danych.

### 4.1. Struktura i znaczenie instrukcji `break`
```javascript
let kodRoli = "ADMIN";
let nazwaUprawnien = "";

switch (kodRoli) {
  case "ADMIN":
    nazwaUprawnien = "Pełny dostęp administracyjny";
    break; // Przerywa wykonywanie instrukcji switch
  case "MOD":
    nazwaUprawnien = "Moderacja treści i użytkowników";
    break;
  case "USER":
    nazwaUprawnien = "Standardowe konto użytkownika";
    break;
  default:
    nazwaUprawnien = "Brak autoryzacji (konto gościa)";
    break;
}

document.write("<p>Rola w systemie: " + nazwaUprawnien + "</p>");
```

### 4.2. Efekt Fall-Through (świadome łączenie przypadków)
Brak instrukcji `break` powoduje "wpadnięcie" (fall-through) w kod kolejnego bloku `case`, aż do napotkania słowa `break` lub końca instrukcji `switch`. Właściwość tę można wykorzystać do grupowania przypadków o takim samym rezultacie:

```javascript
let dzienTygodnia = "sobota";
let typDnia = "";

switch (dzienTygodnia.toLowerCase()) {
  case "poniedziałek":
  case "wtorek":
  case "środa":
  case "czwartek":
  case "piątek":
    typDnia = "Dzień roboczy";
    break;
  case "sobota":
  case "niedziela":
    typDnia = "Weekend";
    break;
  default:
    typDnia = "Nieznany dzień";
    break;
}
```

---

## 5. Operator warunkowy trójargumentowy (`? :`)

Operator trójargumentowy (ang. *ternary operator*) to zwięzły odpowiednik prostej konstrukcji `if ... else`, który zwraca wartość i może być stosowany bezpośrednio w przypisaniu do zmiennej lub wewnątrz szablonu tekstowego.

### 5.1. Składnia
```
warunek ? wyrazenieGdyTrue : wyrazenieGdyFalse
```

### 5.2. Przykład zastosowania
```javascript
let stanMagazynu = 12;
let statusTowaru = (stanMagazynu > 0) ? "Dostępny od ręki" : "Brak w magazynie";

document.write("<p>Status produktu: " + statusTowaru + "</p>");
```

---

## 6. Zagnieżdżanie warunków i operatory logiczne

W instrukcjach warunkowych zaleca się stosowanie operatorów logicznych (`&&` — koniunkcja, `||` — alternatywa, `!` — negacja) w celu budowania czytelnych reguł biznesowych:

```javascript
let zalogowany = true;
let rola = "KIEROWNIK";
let aktywneKonto = true;

// Walidacja dostępu wielopoziomowego
if (zalogowany && aktywneKonto) {
  if (rola === "KIEROWNIK" || rola === "ADMIN") {
    document.write("<p class='info'>Dostęp do panelu zarządczego autoryzowany.</p>");
  } else {
    document.write("<p class='uwaga'>Dostęp ograniczony: brak uprawnień kierowniczych.</p>");
  }
} else {
  document.write("<p class='blad'>Sesja nieaktywna lub konto zablokowane.</p>");
}
```

---

## 7. Rygor wyjścia danych i wersjonowanie (Semestr 1)

W Semestrze 1 wszystkie wyniki operacji warunkowych wyprowadzamy do struktury dokumentu za pomocą `document.write` w kontenerze `<div class="wynik">`.

Po ukończeniu implementacji każdego skryptu pamiętaj o zatwierdzeniu zmian w systemie Git:
```bash
git add .
git commit -m "Zadanie z instrukcji warunkowych - wersja gotowa"
git push origin main
```
Możesz także skorzystać z interfejsu graficznego w przeglądarce pod adresem `github.com`.
