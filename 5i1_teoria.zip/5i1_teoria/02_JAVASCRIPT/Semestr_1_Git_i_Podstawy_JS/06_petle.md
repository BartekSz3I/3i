# Teoria: Pętle programistyczne i podstawy iteracji (Moduł 06)

W programowaniu bardzo często zachodzi potrzeba wielokrotnego wykonania tego samego fragmentu kodu: odliczenia czasu, wypisania wierszy tabeli, zsumowania wartości czy przetworzenia kolejnych identyfikatorów. Do tego celu służą **pętle programistyczne** (ang. *loops*).

---

## 1. Pętla iteracyjna `for`

Pętla `for` jest stosowana najczęściej wtedy, gdy z góry wiemy, ile razy ma się powtórzyć dany blok kodu (np. dokładnie 10 razy).

### Składnia:
```javascript
for (inicjalizacja; warunek; krok) {
  // instrukcje powtarzane w każdej iteracji
}
```

* **Inicjalizacja (`let i = 1`):** wykonuje się dokładnie jeden raz przed rozpoczęciem pętli. Służy do zadeklarowania i ustawienia zmiennej sterującej (tzw. iteratora).
* **Warunek kontynuacji (`i <= 10`):** sprawdzany jest **przed każdym** wykonaniem ciała pętli. Jeśli zwraca `true`, pętla się wykonuje. Jeśli `false`, pętla natychmiast się kończy.
* **Krok iteracji (`i++`):** wykonuje się **po każdym** zakończeniu ciała pętli. Modyfikuje iterator (najczęściej zwiększa o 1: inkrementacja, lub zmniejsza o 1: dekrementacja `i--`).

### Przykład:
```javascript
for (let i = 1; i <= 5; i++) {
  document.write("<p>Krok numer: " + i + "</p>");
}
```

> **Po co to jest:** Do sekwencyjnego generowania powtarzalnych elementów, np. numerowanych wierszy zestawienia, kolejnych etykiet paczek magazynowych czy potęg liczb.  
> **Typowa pomyłka (Off-by-one):** Mylenie operatora mniejszości `<` z mniejszością lub równością `<=`. Jeśli chcemy wykonać pętlę od 1 do 10, warunek `i < 10` wykona się tylko 9 razy (zatrzyma się na liczbie 9).

---

## 2. Pętla warunkowa `while`

Pętla `while` (dopóki) sprawdza warunek **przed** każdym wykonaniem. Jest idealna w sytuacjach, gdy nie wiemy z góry, ile dokładnie kroków będzie potrzebnych, ale wiemy, jaki warunek logiczny musi być spełniony, aby kontynuować pracę.

### Składnia:
```javascript
while (warunek) {
  // instrukcje
  // modyfikacja zmiennej wpływającej na warunek!
}
```

### Przykład:
```javascript
let stanPaliwa = 50; // litry

while (stanPaliwa > 0) {
  document.write("<p>Pozostało paliwa: " + stanPaliwa + " l</p>");
  stanPaliwa -= 15; // zużycie w trasie
}

document.write("<p>Zbiornik pusty lub rezerwa.</p>");
```

> **Po co to jest:** Do przetwarzania procesów kończących się pod wpływem zdarzenia lub wyczerpania zasobu (np. rozładowanie akumulatora, odliczanie wsteczne, symulacja bufora danych).  
> **Typowa pomyłka (Pętla nieskończona):** Zapomnienie o modyfikacji zmiennej wewnątrz ciała pętli (np. brak `stanPaliwa -= 15`). Warunek pozostaje wiecznie prawdziwy (`true`), co powoduje zamrożenie karty przeglądarki i wyczerpanie pamięci.

---

## 3. Pętla warunkowa `do..while`

Pętla `do..while` różni się od pętli `while` tym, że sprawdza warunek **po wykonaniu** ciała pętli. Oznacza to, że instrukcje wewnątrz bloku `do { ... }` wykonają się **zawsze co najmniej jeden raz**, nawet jeśli warunek od samego początku był fałszywy (`false`).

### Składnia:
```javascript
do {
  // instrukcje wykonywane co najmniej raz
} while (warunek);
```

### Przykład:
```javascript
let probaPolaczenia = 1;

do {
  document.write("<p>Próba nawiązania połączenia nr: " + probaPolaczenia + "</p>");
  probaPolaczenia++;
} while (probaPolaczenia <= 3);
```

> **Po co to jest:** W procedurach, w których działanie wstępne musi się odbyć przynajmniej raz, zanim podejmiemy decyzję o kolejnej powtórce (np. pobranie danych diagnostycznych, próba wysłania pakietu kontrolnego, autoryzacja).  
> **Typowa pomyłka:** Brak średnika `;` po zamykającym nawiasie `while(warunek);`. Choć JavaScript wybacza brak średników dzięki mechanizmowi ASI, w konstrukcji `do..while` średnik na końcu jest zalecanym standardem języka.

---

## 4. Instrukcje sterujące `break` i `continue`

Wewnątrz pętli możemy dynamicznie wpływać na jej bieg za pomocą dwóch słów kluczowych:

### `break` — natychmiastowe przerwanie pętli:
Instrukcja `break` powoduje natychmiastowe opuszczenie pętli i przejście do pierwszej instrukcji znajdującej się za nią.
```javascript
for (let i = 1; i <= 10; i++) {
  if (i === 6) {
    document.write("<p>Wykryto awarię! Przerywamy pracę pętli.</p>");
    break;
  }
  document.write("<p>Obsługa elementu: " + i + "</p>");
}
```

### `continue` — pominięcie bieżącej iteracji:
Instrukcja `continue` natychmiast kończy bieżący krok pętli i przechodzi do obliczenia kroku (`i++`) oraz sprawdzenia warunku dla kolejnej iteracji.
```javascript
for (let i = 1; i <= 5; i++) {
  if (i === 3) {
    // Pomijamy element nr 3 (np. sektor serwisowy)
    continue;
  }
  document.write("<p>Przetwarzanie paczki: " + i + "</p>");
}
```

> **Po co to jest:** Do optymalizacji i filtrowania — `continue` pozwala pominąć błędne lub niepasujące rekordy bez zagnieżdżania wielu bloków warunkowych, a `break` zapobiega zbędnym obliczeniom po odnalezieniu poszukiwanego wyniku.  
> **Typowa pomyłka:** Użycie `continue` w pętli `while` przed zwiększeniem licznika. Jeśli napiszemy `if (x === 3) continue;`, a inkrementacja `x++` znajduje się poniżej, pętla wejdzie w stan nieskończony dla wartości `x = 3`!

---

## 5. Pętle zagnieżdżone (Nested Loops)

Pętla zagnieżdżona to pętla umieszczona wewnątrz innej pętli. Przy każdym **jednym** kroku pętli zewnętrznej, pętla wewnętrzna wykonuje się **w całości**.

### Składnia i schemat:
```javascript
for (let wiersz = 1; wiersz <= 3; wiersz++) {
  for (let kolumna = 1; kolumna <= 3; kolumna++) {
    let iloczyn = wiersz * kolumna;
    document.write("<span>[" + wiersz + "," + kolumna + "]=" + iloczyn + " </span>");
  }
  document.write("<br>");
}
```

> **Po co to jest:** Do generowania struktur wielowymiarowych: tabel, siatek współrzędnych (np. szachownica, miejsca w kinie, siatka pikseli, tabliczka mnożenia) oraz wzorców geometrycznych.  
> **Typowa pomyłka (Kolizja zmiennych):** Użycie tej samej nazwy zmiennej sterującej (np. `let i`) zarówno w pętli zewnętrznej, jak i wewnętrznej. Zmienna wewnętrzna nadpisze wówczas stan iteratora zewnętrznego, niszcząc logikę całego programu. Pętla zewnętrzna to zazwyczaj `i`, wewnętrzna `j`, kolejna `k`, lub opisowo: `wiersz` i `kolumna`.

---

## 6. Rygor wyjścia Semestru 1: `document.write` w kontenerze `<div class="wynik">`

Pamiętaj, że w Semestrze 1 nie wolno używać metod DOM (`getElementById`, `querySelector`). Wszystkie wyniki generujemy za pomocą sekwencyjnego wypisywania HTML przez `document.write`:
```javascript
document.write("<p>Początek generowania raportu:</p>");
for (let n = 1; n <= 4; n++) {
  document.write("<div class='pozycja-raportu'>Wpis #" + n + ": Stan OK</div>");
}
```
Plik `script.js` jest załadowany wewnątrz `<div class="wynik">`, dzięki czemu wygenerowane elementy natychmiast osadzają się w odpowiednim miejscu makiety graficznej.
