# Teoria: Pierwszy skrypt, konsola i wypis na stronę

---

## 1. Czym jest JavaScript i jak działa w przeglądarce?

**JavaScript** to dynamiczny język programowania wysokiego poziomu, który odpowiada za logikę i zachowanie stron internetowych. Podczas gdy HTML definiuje strukturę strony, a CSS dba o jej wygląd, JavaScript pozwala na interakcję, wykonywanie obliczeń oraz dynamiczne generowanie zawartości.

Kod JavaScript jest wykonywany bezpośrednio przez **silnik przeglądarki internetowej** (np. silnik V8 w Google Chrome i Microsoft Edge czy SpiderMonkey w Mozilla Firefox) na komputerze użytkownika (tzw. środowisko klienta / *client-side*).

---

## 2. Podłączanie skryptu do dokumentu HTML

Kod JavaScript możemy osadzić w dokumencie HTML na dwa sposoby:

### Sposób A: Skrypt wewnętrzny (inline)
Kod umieszczany jest bezpośrednio między znacznikami `<script>` oraz `</script>`:
```html
<script>
  console.log("Skrypt uruchomiony pomyślnie!");
</script>
```

### Sposób B: Skrypt w osobnym pliku zewnętrznym (Zalecany standard produkcyjny)
Kod zapisujemy w osobnym pliku z rozszerzeniem `.js` (np. `script.js`), a w dokumencie HTML łączymy go za pomocą atrybutu `src`:
```html
<script src="script.js"></script>
```

> **Po co to jest?**  
> Oddzielenie kodu JavaScript do osobnego pliku `script.js` ułatwia organizację projektu, umożliwia wersjonowanie w systemie Git oraz pozwala przeglądarce na buforowanie (*cache*) kodu, co przyspiesza działanie witryny.
>
> **Typowa pomyłka:**  
> Próba wpisania kodu wewnątrz znacznika `<script src="script.js">kod...</script>`. Jeśli znacznik `<script>` posiada atrybut `src`, przeglądarka całkowicie zignoruje kod umieszczony pomiędzy jego znacznikami otwierającym i zamykającym!

---

## 3. Konsola deweloperska (DevTools) i logowanie diagnostyczne

Konsola przeglądarki to najważniejsze narzędzie programisty do podglądu działania programu i tropienia błędów. Otwieramy ją klawiszem **F12** (lub skrótem `Ctrl + Shift + I`) w zakładce **Console**.

### Metody obiektu `console`:
```javascript
// Podstawowy komunikat informacyjny (szary/czarny tekst)
console.log("Witaj w konsoli deweloperskiej!");

// Komunikat informacyjny (często z niebieską ikoną)
console.info("Załadowano moduł startowy aplikacji.");

// Ostrzeżenie diagnostyczne (żółte tło / trójkąt ostrzegawczy)
console.warn("Uwaga: Wykryto nieoptymalną konfigurację.");

// Błąd krytyczny (czerwone tło z informacją o pliku i linii błędu)
console.error("Błąd: Nie udało się nawiązać połączenia.");

// Wyczyszczenie zawartości konsoli
console.clear();
```

> **Po co to jest?**  
> Różne poziomy logowania (`log`, `info`, `warn`, `error`) pozwalają na filtrowanie komunikatów w konsoli podczas pracy nad dużym projektem. Pozwalają sprawdzić, co dzieje się w kodzie „pod maską”, zanim wynik trafi na ekran użytkownika.
>
> **Typowa pomyłka:**  
> Literówka w nazwie metody (np. `consol.log` zamiast `console.log`). Ponieważ JavaScript jest językiem wrażliwym na wielkość liter (*case-sensitive*), każda literówka spowoduje błąd `ReferenceError: consol is not defined` i zatrzyma wykonywanie dalszego kodu.

---

## 4. Standardowe okna dialogowe przeglądarki

Przeglądarka udostępnia wbudowane metody interakcji z użytkownikiem:

```javascript
// 1. Okno z informacją i przyciskiem "OK"
alert("Witaj na stronie serwisu!");

// 2. Okno z pytaniem i polem tekstowym do wpisania odpowiedzi
prompt("Podaj swoje imię:", "Jan");

// 3. Okno pytania z przyciskami "OK" (prawda) oraz "Anuluj" (fałsz)
confirm("Czy na pewno chcesz opuścić tę stronę?");
```

### BARDZO WAŻNE: Wstrzymanie wątku JavaScript
> **Zasada działania dialogów:**  
> Wywołanie funkcji `alert()`, `prompt()` oraz `confirm()` **całkowicie wstrzymuje (blokuje)** dalsze wykonywanie kodu JavaScript oraz renderowanie strony w przeglądarce!  
> Oznacza to, że żadna instrukcja znajdująca się pod oknem dialogowym (np. `console.log()` lub `document.write()`) **nie wykona się**, dopóki użytkownik nie kliknie przycisku i nie zamknie okna dialogowego.
>
> **Typowa pomyłka:**  
> Uczeń pisze kod:
> ```javascript
> alert("Poczekaj...");
> console.log("Zalogowano!");
> ```
> i dziwi się, dlaczego w konsoli nie ma wpisu `Zalogowano!`. Wpis pojawi się dopiero w ułamku sekundy po kliknięciu przycisku OK w oknie `alert`.

---

## 5. Rygor wyjścia danych w Semestrze 1: `document.write`

W Semestrze 1 nie stosujemy jeszcze zaawansowanego drzewa DOM ani wyszukiwania elementów po identyfikatorach. Cały wypis na stronę realizujemy za pomocą metody `document.write()`.

### Zasady poprawnego stosowania:
1. Skrypt wywołujący `document.write` musi znajdować się **wewnątrz** docelowego elementu HTML, np. kontenera `<div class="wynik">`:
   ```html
   <div class="wynik">
     <script>
       document.write("Raport systemu: Gotowy do pracy.<br>");
       document.write("Wersja aplikacji: 1.0.0");
     </script>
   </div>
   ```
2. Ponieważ `document.write` wypisuje tekst bezpośrednio do kodu HTML, aby przejść do nowej linii, wewnątrz tekstu musimy umieścić znacznik `<br>` (sam znak nowej linii `\n` nie spowoduje złamania linii w przeglądarce).

> **Po co to jest?**  
> `document.write` pozwala uczniowi skupić się na logice generowania danych, formatowaniu tekstu i algorytmice bez konieczności rozumienia skomplikowanych mechanizmów manipulacji modelem DOM (`getElementById`, `querySelector`, `innerHTML`).
>
> **Ostrzeżenie metodyczne (Dlaczego nie stosujemy `document.write` po wczytaniu strony?):**  
> Metoda `document.write` działa poprawnie wyłącznie **w trakcie wczytywania dokumentu HTML**. Gdyby została wywołana później (np. w reakcji na kliknięcie przycisku po całkowitym załadowaniu strony), przeglądarka automatycznie wyczyści (**skasuje**) całą dotychczasową zawartość strony i zastąpi ją wyłącznie nowo wypisanym tekstem! Dlatego od semestru 2 przejdziemy na nowoczesny model `textContent`.

---

## 6. Dobre nawyki: Zapisywanie pracy w repozytorium GitHub

Po wykonaniu każdego zestawu ćwiczeń uczeń utrwala swoje postępy w repozytorium GitHub:
* **Przez terminal:**
  ```bash
  git add .
  git commit -m "Ukonczono modul 03: pierwszy skrypt i konsola"
  git push
  ```
* **Przez przeglądarkę ([github.com](https://github.com)):**  
  Można wejść do swojego repozytorium na GitHubie i skorzystać z opcji *Add file $\to$ Upload files*, przeciągając zmodyfikowane pliki i klikając *Commit changes*.

---

## 7. Podsumowanie zestawienia składniowego

| Instrukcja | Gdzie pojawia się efekt? | Do czego służy? |
|---|---|---|
| `console.log("tekst")` | Konsola deweloperska (F12) | Podstawowe logowanie diagnostyczne |
| `console.warn("ostrzeżenie")` | Konsola deweloperska (F12) | Wypisanie ostrzeżenia na żółtym tle |
| `console.error("błąd")` | Konsola deweloperska (F12) | Wypisanie błędu krytycznego na czerwonym tle |
| `alert("wiadomość")` | Okno dialogowe w przeglądarce | Wyświetlenie komunikatu i zatrzymanie skryptu |
| `prompt("pytanie")` | Okno dialogowe w przeglądarce | Pobranie tekstu od użytkownika |
| `confirm("pytanie")` | Okno dialogowe w przeglądarce | Pytanie z wyborem OK / Anuluj |
| `document.write("tekst<br>")` | Bezpośrednio na stronie HTML | Wypisanie tekstu w kontenerze `.wynik` |
