# Teoria: Klasyczne algorytmy w programowaniu (INF.03 Semestr 1)

Podręcznik metodyczny dla uczniów technikum informatycznego i programistycznego. Omawia schematy algorytmiczne implementowane za pomocą zmiennych, instrukcji warunkowych i pętli w języku JavaScript.

---

## 1. Wprowadzenie — Czym jest algorytm i dlaczego jest fundamentem programowania?

Algorytm to uporządkowany, jednoznaczny ciąg instrukcji prowadzący do rozwiązania określonego zadania lub uzyskania oczekiwanego wyniku na podstawie dostarczonych danych wejściowych. Każdy poprawny algorytm musi charakteryzować się trzema cechami:
1. **Skończonością:** musi zakończyć działanie po wykonaniu określonej liczby kroków.
2. **Jednoznacznością:** na każdym etapie wiadomo, która operacja ma zostać wykonana jako kolejna.
3. **Poprawnością:** dla dopuszczalnych danych wejściowych zwraca bezbłędny wynik.

W codziennej pracy programisty większość problemów biznesowych (obliczanie rabatów, weryfikacja kodów kreskowych, planowanie dostaw) to adaptacje klasycznych wzorców algorytmicznych.

---

## 2. Algorytm Euklidesa — Największy Wspólny Dzielnik (NWD)

Największy Wspólny Dzielnik dwóch liczb całkowitych dodatnich $a$ i $b$, oznaczany jako $\text{NWD}(a, b)$, to największa liczba naturalna, która dzieli bez reszty zarówno liczbę $a$, jak i $b$.

### 2.1 Metoda z odejmowaniem (klasyczna)
Euklides zauważył, że jeśli od większej liczby odejmiemy mniejszą, to największy wspólny dzielnik nowej pary liczb nie ulega zmianie. Proces powtarzamy tak długo, aż obie liczby staną się równe:

```javascript
let a = 42;
let b = 18;

while (a !== b) {
  if (a > b) {
    a = a - b;
  } else {
    b = b - a;
  }
}

document.write("NWD wynosi: " + a + "<br>");
```

> **Po co to jest:** Służy do optymalizacji podziału zasobów na równe porcje bez reszty (np. pakowanie towaru na palety, podział kadr na równe brygady, skalowanie proporcji ekranu 16:9).
>
> **Typowa pomyłka:** Brak warunku pętli `while (a !== b)` lub omyłkowe użycie przypisania `=` zamiast porównania `!==`, co powoduje pętlę nieskończoną lub przedwczesne zakończenie.

### 2.2 Metoda z resztą z dzielenia (zoptymalizowana)
Zamiast wielokrotnego odejmowania, obliczamy resztę z dzielenia ($a \pmod b$). Zastępujemy $a$ wartością $b$, a $b$ resztą z dzielenia, aż reszta wyniesie 0:

```javascript
let x = 42;
let y = 18;

while (y !== 0) {
  let reszta = x % y;
  x = y;
  y = reszta;
}

document.write("NWD zoptymalizowany: " + x + "<br>");
```

### 2.3 Najmniejsza Wspólna Wielokrotność (NWW)
Mając obliczony NWD, Najmniejszą Wspólną Wielokrotność obliczamy bezpośrednio ze wzoru:
$$\text{NWW}(a, b) = \frac{a \cdot b}{\text{NWD}(a, b)}$$

```javascript
let pierwotneA = 42;
let pierwotneB = 18;
let nww = (pierwotneA * pierwotneB) / x;
document.write("NWW wynosi: " + nww + "<br>");
```

> **Po co to jest:** NWW wyznacza moment zbieżności dwóch cykli czasowych (np. kiedy dwa autobusy odjadą jednocześnie z tego samego przystanku, kiedy zbiegną się okresy przeglądów dwóch maszyn).

---

## 3. Badanie podzielności i liczb pierwszych

Liczba pierwsza to liczba naturalna większa od 1, która posiada dokładnie dwa dzielniki naturalne: 1 oraz samą siebie (np. 2, 3, 5, 7, 11, 13, 17, 19, 23...).

### 3.1 Algorytm weryfikacji liczby pierwszej z flagą logiczną
Aby sprawdzić, czy liczba $n$ jest pierwsza, sprawdzamy, czy dzieli się bez reszty przez jakąkolwiek liczbę w przedziale od 2 do $n - 1$:

```javascript
let n = 29;
let jestPierwsza = true;

if (n < 2) {
  jestPierwsza = false;
} else {
  for (let d = 2; d * d <= n; d++) {
    if (n % d === 0) {
      jestPierwsza = false;
      break;
    }
  }
}

if (jestPierwsza) {
  document.write("Liczba " + n + " jest liczbą pierwszą.<br>");
} else {
  document.write("Liczba " + n + " jest liczbą złożoną.<br>");
}
```

> **Po co to jest:** Liczby pierwsze są fundamentem kryptografii asymetrycznej (RSA), algorytmów haszowania oraz generowania unikalnych identyfikatorów bezpieczeństwa.
>
> **Typowa pomyłka:** Sprawdzanie dzielników aż do $n$, co jest nieefektywne. Wystarczy sprawdzać do $\sqrt{n}$ (czyli warunek `d * d <= n`). Druga częsta pomyłka to brak instrukcji `break` po znalezieniu pierwszego dzielnika.

---

## 4. Wyszukiwanie skrajnych wartości: Minimum i Maksimum

Szukanie elementu o największej lub najmniejszej wartości w ciągu danych to jedna z najczęściej realizowanych operacji analitycznych.

### 4.1 Prawidłowa inicjalizacja zmiennej skrajnej
Żelazną zasadą algorytmu jest zainicjalizowanie zmiennej `max` wartością pierwszego elementu ciągu, a nie wartością 0! Gdyby wszystkie liczby w ciągu były ujemne, inicjalizacja zerem dałaby błędny wynik 0.

```javascript
// Analiza odczytów temperatur w chłodni magazynowej
let odczyt1 = -4;
let odczyt2 = -12;
let odczyt3 = -2;
let odczyt4 = -8;

let minTemp = odczyt1;
let maxTemp = odczyt1;

// Sprawdzanie kolejnych odczytów
if (odczyt2 < minTemp) { minTemp = odczyt2; }
if (odczyt2 > maxTemp) { maxTemp = odczyt2; }

if (odczyt3 < minTemp) { minTemp = odczyt3; }
if (odczyt3 > maxTemp) { maxTemp = odczyt3; }

if (odczyt4 < minTemp) { minTemp = odczyt4; }
if (odczyt4 > maxTemp) { maxTemp = odczyt4; }

document.write("Najniższa temperatura: " + minTemp + "°C<br>");
document.write("Najwyższa temperatura: " + maxTemp + "°C<br>");
```

> **Po co to jest:** Weryfikacja przekroczeń norm technicznych, alarmowanie o skrajnych parametrach urządzeń, wyznaczanie najtańszej i najdroższej oferty w e-sklepie.
>
> **Typowa pomyłka:** Użycie `else if` przy jednoczesnym szukaniu minimum i maksimum. Każdy element musi zostać porównany niezależnie z obiema wartościami skrajnymi za pomocą dwóch odrębnych instrukcji `if`.

---

## 5. Wzorzec Akumulatora: Suma, Licznik i Średnia

Wzorzec akumulatora polega na przygotowaniu zmiennej sumującej z wartością początkową 0 i stopniowym dodawaniu do niej kolejnych składników w pętli.

```javascript
let liczbaDni = 5;
let sumaObrotu = 0;
let dniZyskowne = 0;

for (let dzien = 1; dzien <= liczbaDni; dzien++) {
  let obrotDnia = dzien * 150 + 200; // symulacja obrotu
  sumaObrotu += obrotDnia;
  
  if (obrotDnia >= 500) {
    dniZyskowne++;
  }
}

let sredniObrot = sumaObrotu / liczbaDni;

document.write("Łączny obrót za " + liczbaDni + " dni: " + sumaObrotu + " zł<br>");
document.write("Średni obrót dzienny: " + sredniObrot.toFixed(2) + " zł<br>");
document.write("Liczba dni o obrocie >= 500 zł: " + dniZyskowne + "<br>");
```

> **Po co to jest:** Zestawienia księgowe, bilanse magazynowe, raporty wydajności pracowników, obliczanie średnich ocen i wskaźników KPI.
>
> **Typowa pomyłka:** Dzielenie przez zero przy wyznaczaniu średniej, gdy licznik elementów wynosi 0. Zawsze przed dzieleniem należy upewnić się, że mianownik jest większy od zera.

---

## 6. Rozbijanie liczby na cyfry (Modulo i Dzielenie całkowite)

Częstym zadaniem egzaminacyjnym i praktycznym jest analiza poszczególnych cyfr liczby całkowitej (np. sprawdzanie sumy kontrolnej numeru PESEL, NIP czy kodu EAN).

### 6.1 Pobieranie ostatniej cyfry i obcinanie liczby
1. Ostatnią cyfrę liczby dziesiętnej uzyskujemy za pomocą operatora modulo 10: `liczba % 10`.
2. Usunięcie ostatniej cyfry realizujemy przez dzielenie przez 10 z zaokrągleniem w dół: `Math.floor(liczba / 10)`.

```javascript
let kodTowaru = 4826;
let robocza = kodTowaru;
let sumaCyfr = 0;
let odwrocona = 0;

while (robocza > 0) {
  let cyfra = robocza % 10;
  sumaCyfr += cyfra;
  odwrocona = odwrocona * 10 + cyfra;
  robocza = Math.floor(robocza / 10);
}

document.write("Oryginalny kod: " + kodTowaru + "<br>");
document.write("Suma cyfr: " + sumaCyfr + "<br>");
document.write("Liczba po odwróceniu cyfr: " + odwrocona + "<br>");
```

> **Po co to jest:** Algorytmy walidacji numerów bankowych IBAN, identyfikatorów REGON, tworzenie skrótów cyfrowych oraz sprawdzanie palindromów liczbowych.
>
> **Typowa pomyłka:** Zapomnienie o `Math.floor()`. W JavaScript dzielenie `4826 / 10` daje ułamek `482.6`, a nie liczbę całkowitą, co prowadzi do pętli nieskończonej.

---

## 7. Algorytm Zachłanny: Wydawanie reszty o minimalnej liczbie monet

Algorytm zachłanny podejmuje w danym kroku decyzję lokalnie optymalną (np. wybiera największy możliwy nominał, który mieści się w pozostałej kwocie do wydania), mając na celu osiągnięcie optymalnego wyniku globalnego.

```javascript
let kwotaDoWydania = 68; // zł
document.write("Kwota do wydania: " + kwotaDoWydania + " zł<br>");

// Dostępne nominały w kolejności od największego
let nominaly = [50, 20, 10, 5, 2, 1]; // w semestrze 1 można realizować przez serię zmiennych lub pętle

let n50 = 0;
let n20 = 0;
let n10 = 0;
let n5 = 0;
let n2 = 0;
let n1 = 0;

while (kwotaDoWydania >= 50) { n50++; kwotaDoWydania -= 50; }
while (kwotaDoWydania >= 20) { n20++; kwotaDoWydania -= 20; }
while (kwotaDoWydania >= 10) { n10++; kwotaDoWydania -= 10; }
while (kwotaDoWydania >= 5)  { n5++;  kwotaDoWydania -= 5;  }
while (kwotaDoWydania >= 2)  { n2++;  kwotaDoWydania -= 2;  }
while (kwotaDoWydania >= 1)  { n1++;  kwotaDoWydania -= 1;  }

document.write("Wydano banknotów 50 zł: " + n50 + "<br>");
document.write("Wydano banknotów 20 zł: " + n20 + "<br>");
document.write("Wydano monet 10 zł: " + n10 + "<br>");
document.write("Wydano monet 5 zł: " + n5 + "<br>");
document.write("Wydano monet 2 zł: " + n2 + "<br>");
document.write("Wydano monet 1 zł: " + n1 + "<br>");
```

> **Po co to jest:** Obsługa automatycznych kas fiskalnych, parkomatów, bankomatów oraz pakowanie przesyłek do paczkomatów o standardowych gabarytach A, B, C.
>
> **Typowa pomyłka:** Rozpoczynanie wydawania od najmniejszych nominałów, co prowadzi do wydania ogromnej liczby monet zamiast optymalnego minimum.

---

## 8. Wypis na stronę w Semestrze 1 — Zasada `document.write`
W modułach Semestru 1 skrypt umieszczony jest bezpośrednio wewnątrz kontenera:
```html
<div class="wynik">
  <script src="script.js"></script>
</div>
```
Wszelki wypis formatujemy za pomocą polecenia `document.write()`, wstawiając znaczniki HTML (np. `<br>`, `<p>`, `<strong>`). Bezwzględnie pamiętamy o zakazie używania selektorów manipulacji drzewem DOM (`getElementById`, `querySelector`), które obowiązują w kolejnych semestrach.
