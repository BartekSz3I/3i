# Teoria: Zdalne repozytoria i gałęzie (GitHub, Branching & Merge)

---

## 1. Wprowadzenie do zdalnych repozytoriów (Remote)

Lokalne repozytorium Git (poznane w module 01) działa wyłącznie na dysku komputera roboczego. W przypadku awarii sprzętu lub konieczności pracy w zespole niezbędne jest podłączenie repozytorium zdalnego (**remote**). Najpopularniejszą platformą chmurową dla projektów programistycznych jest serwis **GitHub**.

### Podstawowe pojęcia:
* **Remote (Zdalne repozytorium):** Kopia repozytorium przechowywana na serwerze zewnętrznym, dostępna pod unikalnym adresem URL.
* **Origin:** Domyślna, konwencjonalna nazwa skrócona pierwszego repozytorium zdalnego w konfiguracji Gita.
* **Clone:** Skopiowanie całego zdalnego repozytorium (wraz z pełną historią commitów i gałęziami) na dysk lokalny.
* **Push:** Wysłanie nowych lokalnych commitów do repozytorium zdalnego.
* **Pull:** Pobranie nowych commitów z repozytorium zdalnego i automatyczne scalenie ich z lokalną gałęzią.

---

## 2. Łączenie repozytorium lokalnego z GitHubem

Gdy uczeń ma już utworzone repozytorium lokalne (przez `git init` i zatwierdzony pierwszy commit), podłącza je do nowo założonego, pustego projektu na GitHubie:

```bash
# 1. Dodanie zdalnego adresu i nazwanie go "origin"
git remote add origin https://github.com/twoj-login/twoj-projekt.git

# 2. Sprawdzenie skonfigurowanych połączeń zdalnych
git remote -v

# 3. Ustawienie głównej gałęzi jako main (współczesny standard)
git branch -M main

# 4. Pierwsze wysłanie danych z flagą śledzenia (-u lub --set-upstream)
git push -u origin main
```

> **Po co to jest?**  
> Flaga `-u` (`--set-upstream`) tworzy trwałe powiązanie między Twoją lokalną gałęzią `main` a zdalną gałęzią `origin/main`. Dzięki temu przy kolejnych wysyłkach wystarczy wpisać samo krótkie polecenie `git push` bez podawania nazwy serwera i gałęzi.
>
> **Typowa pomyłka:**  
> Próba wykonania `git push` do nowo utworzonego repozytorium na GitHubie, które podczas tworzenia w przeglądarce zostało zainicjowane z zaznaczonym plikiem `README.md` lub `.gitignore`. Git odrzuci wówczas wysyłkę błędem `[rejected - non-fast-forward]`, ponieważ w chmurze istnieje już commit, którego nie ma na Twoim dysku. Należy tworzyć repozytoria na GitHubie jako całkowicie puste lub przed wysyłką wykonać `git pull origin main --allow-unrelated-histories`.

---

## 3. Klonowanie i synchronizacja (`clone`, `pull`, `fetch`)

Gdy projekt już istnieje na GitHubie, inny programista pobiera go na swoje stanowisko:

```bash
# Sklonowanie całego projektu do nowego folderu
git clone https://github.com/organizacja/projekt.git

# Wejście do pobranego katalogu
cd projekt

# Pobranie najnowszych zmian wprowadzonych przez innych członków zespołu
git pull origin main
```

### Różnica między `git fetch` a `git pull`:
| Polecenie | Co dokładnie robi | Czy zmienia Twoje pliki na dysku? |
|---|---|:---:|
| `git fetch` | Sprawdza i pobiera informacje o nowych commitach z serwera, ale nie łączy ich z Twoim kodem | **Nie** (bezpieczny podgląd) |
| `git pull` | Wykonuje `git fetch`, a następnie od razu wykonuje `git merge`, łącząc zmiany | **Tak** (modyfikuje pliki w katalogu) |

> **Po co to jest?**  
> Tabela wyjaśnia podział odpowiedzialności podczas synchronizacji zespołowej. `git pull` jest wygodnym skrótem na co dzień, natomiast `git fetch` pozwala podejrzeć zmiany bez ryzyka niespodziewanego konfliktu w trakcie pracy.
>
> **Typowa pomyłka:**  
> Wywołanie `git pull` w sytuacji, gdy w lokalnym katalogu roboczym znajdują się niezapisane w commicie zmiany edycyjne w tych samych plikach. Git zgłosi błąd i zablokuje operację, aby nie nadpisać Twojej niescommitowanej pracy. Przed użyciem `git pull` zawsze zatwierdź zmiany (`git commit`) lub odłóż je.

---

## 4. Praca na gałęziach (Branching)

Gałąź (`branch`) to wskaźnik wskazujący na konkretny commit w historii projektu. Pozwala na tworzenie nowych funkcji, eksperymentów lub poprawek w całkowitej izolacji od stabilnego kodu w gałęzi `main`.

```
        C --- D  (feature/nowy-cennik)
       /
A --- B -------- E  (main)
```

### Zarządzanie gałęziami w terminalu:

```bash
# Wyświetlenie listy wszystkich lokalnych gałęzi (* oznacza gałąź aktywną)
git branch

# Utworzenie nowej gałęzi (bez przechodzenia na nią)
git branch feature/kontakt

# Przełączenie się na istniejącą gałąź (nowoczesna składnia)
git switch feature/kontakt

# Szybkie utworzenie nowej gałęzi i natychmiastowe przejście na nią (jeden krok)
git switch -c feature/galeria

# Starsza, tradycyjna składnia równoważna (często spotykana w tutorialach)
git checkout -b feature/galeria
```

> **Po co to jest?**  
> Praca na gałęziach chroni główną wersję programu (`main`) przed wprowadzeniem niesprawdzonego lub zepsutego kodu. Każda zmiana powstaje na osobnej gałęzi funkcyjnej i trafia do `main` dopiero po pełnym przetestowaniu.
>
> **Typowa pomyłka:**  
> Zapomnienie o przełączeniu gałęzi po jej utworzeniu przez `git branch nazwa`. Uczeń tworzy commity, będąc przekonanym, że pracuje w izolacji, podczas gdy nadal modyfikuje bezpośrednio gałąź `main`. Zawsze sprawdzaj aktywną gałąź poleceniem `git branch` lub `git status` przed rozpoczęciem pracy.

---

## 5. Scalanie gałęzi (`git merge`)

Gdy prace na gałęzi funkcyjnej zostaną ukończone i przetestowane, łączymy ją z gałęzią główną:

```bash
# KROK 1: Przechodzimy na gałąź docelową, do której chcemy dołączyć kod
git switch main

# KROK 2: Wciągamy zmiany z gałęzi funkcyjnej
git merge feature/kontakt
```

### Typy operacji scalania:
1. **Fast-forward (Szybkie przewinięcie):**  
   Występuje, gdy na gałęzi `main` nie powstały żadne nowe commity od momentu utworzenia gałęzi funkcyjnej. Wskaźnik `main` zostaje po prostu przesunięty do przodu na ostatni commit gałęzi dołączanej. Nie powstaje żaden dodatkowy commit scalający.
2. **3-way merge (Scalenie trójstronne):**  
   Występuje, gdy na gałęzi `main` oraz na gałęzi funkcyjnej powstały niezależne commity. Git analizuje wspólnego przodka oraz końce obu gałęzi, tworząc nowy, dedykowany **commit scalający** (tzw. *Merge commit*).

---

## 6. Rozwiązywanie konfliktów scalania

Konflikt (`merge conflict`) pojawia się wtedy, gdy w obu scalanych gałęziach zmieniono **dokładnie te same linie w tym samym pliku**, a Git nie potrafi samodzielnie podjąć decyzji, która wersja jest właściwa.

W takiej sytuacji Git zatrzymuje proces scalania i wstawia do pliku specjalne **znaczniki konfliktu**:

```text
<<<<<<< HEAD
Godziny otwarcia serwisu: 8:00 - 16:00
=======
Godziny otwarcia serwisu: 9:00 - 18:00 (sezon letni)
>>>>>>> feature/godziny-letnie
```

### Wyjaśnienie znaczników:
* `<<<<<<< HEAD` — początek wersji znajdującej się na gałęzi, na której aktualnie stoisz (np. `main`).
* `=======` — linia rozdzielająca dwie sprzeczne wersje.
* `>>>>>>> feature/...` — koniec wersji pochodzącej ze scalanej gałęzi funkcyjnej.

### Procedura rozwiązania konfliktu krok po kroku:
1. Otwórz skonfliktowany plik w edytorze kodu.
2. Zdecyduj, która treść jest poprawna (lub połącz obie wersje w logiczną całość).
3. **Bezwzględnie usuń wszystkie znaczniki** (`<<<<<<<`, `=======`, `>>>>>>>`).
4. Zapisz plik.
5. Dodaj poprawiony plik do poczekalni: `git add <nazwa_pliku>`.
6. Dokończ scalenie zatwierdzając commit scalający: `git commit -m "Rozwiazanie konfliktu godzin otwarcia"`.

> **Po co to jest?**  
> Konflikt nie jest błędem programu ani awarią systemu — to naturalna sytuacja w pracy zespołowej. Procedura ta gwarantuje, że to człowiek (programista) decyduje o finalnej logice aplikacji, a nie przypadkowy algorytm.
>
> **Typowa pomyłka:**  
> Pozostawienie w pliku znaczników `<<<<<<<` lub `>>>>>>>` i zatwierdzenie commita. Jeśli w pliku kodu źródłowego pozostaną te znaki, aplikacja zgłosi błąd składniowy (np. `SyntaxError` w JavaScript lub błąd parsowania HTML).

---

## 7. Usunięcie gałęzi po scaleniu

Po pomyślnym dołączeniu kodu zbędną gałąź lokalną usuwamy, aby utrzymać porządek w repozytorium:

```bash
# Bezpieczne usunięcie gałęzi, która została już w pełni scalona
git branch -d feature/kontakt

# Wymuszenie usunięcia gałęzi niescalonej (jeśli porzucamy eksperyment)
git branch -D feature/nieudany-eksperyment
```

---

## 8. Zestawienie najważniejszych poleceń modułu

| Polecenie | Krótki opis działania |
|---|---|
| `git remote add origin <url>` | Powiązanie lokalnego repozytorium z adresem zdalnym na GitHubie |
| `git remote -v` | Sprawdzenie listy skonfigurowanych adresów zdalnych |
| `git push -u origin main` | Wysłanie gałęzi `main` na serwer z ustawieniem śledzenia |
| `git pull origin main` | Pobranie i scalenie najnowszych zmian ze zdalnej gałęzi |
| `git clone <url>` | Sklonowanie całego zdalnego repozytorium do nowego katalogu |
| `git branch <nazwa>` | Utworzenie nowej gałęzi o podanej nazwie |
| `git switch <nazwa>` | Przełączenie się na wskazaną gałąź roboczą |
| `git switch -c <nazwa>` | Utworzenie nowej gałęzi i natychmiastowe przejście na nią |
| `git merge <nazwa>` | Wciągnięcie zmian ze wskazanej gałęzi do gałęzi aktywnej |
| `git branch -d <nazwa>` | Bezpieczne usunięcie scalonej gałęzi |

> **Po co to jest?**  
> Syntetyczne zestawienie służy do szybkiej powtórki przed sprawdzianem i pracą warsztatową.
>
> **Typowa pomyłka:**  
> Mylenie `git clone` z `git pull`. `git clone` uruchamiamy tylko **raz na samym początku**, aby pobrać projekt z serwera do pustego folderu. Do codziennej aktualizacji kodu w istniejącym już katalogu służy wyłącznie `git pull`.
