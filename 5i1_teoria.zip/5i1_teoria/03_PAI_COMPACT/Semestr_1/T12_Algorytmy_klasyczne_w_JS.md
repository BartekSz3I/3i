# Teoria: Klasyczne algorytmy arytmetyczne i iteracyjne w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

W programowaniu aplikacji internetowych umiejętność pisania kodu to nie tylko znajomość składni języka, ale przede wszystkim umiejętność logicznego myślenia i projektowania algorytmów. **Algorytm** to precyzyjny, uporządkowany przepis opisujący ciąg czynności prowadzących do rozwiązania określonego problemu w skończonym czasie.

W tym dziale połączymy poznane dotąd elementy języka JavaScript — deklaracje zmiennych `let` i `const`, operatory arytmetyczne i porównania, instrukcje warunkowe `if/else` oraz pętle `for` i `while` — w celu implementacji kanonicznych algorytmów znanych z informatyki i egzaminów kwalifikacji INF.03.

---

## 1. Wyprowadzanie i wprowadzanie danych w Semestrze 1

W pierwszym semestrze nauki programowania obowiązuje rygor czystego fundamentu logicznego. Oznacza to, że nie korzystamy jeszcze ze złożonych mechanizmów drzewa DOM (takich jak `getElementById` czy zdarzenia `addEventListener`), lecz skupiamy się na przetwarzaniu wartości w pamięci skryptu.

### Wypis wyników
Wyniki działania skryptów wyprowadzamy na stronę za pomocą instrukcji `document.write()`, umieszczając treść w przygotowanym w strukturze HTML kontenerze `<div class="wynik">`. Każdy kolejny wynik oddzielamy znacznikiem nowej linii `"<br>"`. Równolegle, w celach kontrolnych i diagnostycznych, wysyłamy komunikaty do konsoli deweloperskiej za pomocą `console.log()`.

```javascript
document.write("Wynik obliczeń: " + wynik + "<br>");
console.log("Obliczony wynik:", wynik);
```

### Pobieranie danych wejściowych
Do interaktywnego pobierania liczb od użytkownika wykorzystujemy okno dialogowe `prompt()`. W naszym standardzie **każde wywołanie `prompt()` musi posiadać drugi parametr — wartość domyślną**. Dzięki temu testowanie skryptu w przeglądarce jest szybkie i nie wymaga każdorazowego wpisywania danych z klawiatury.

Należy pamiętać, że funkcja `prompt()` zawsze zwraca wartość typu tekstowego (`string`). Aby wykonać operacje matematyczne, musimy dokonać jawnej konwersji tekstu na liczbę za pomocą konstruktora `Number()` lub funkcji `parseInt()`.

```javascript
let wejscie = prompt("Podaj liczbę całkowitą dodatnią:", "12");
let liczba = parseInt(wejscie, 10);
```

> **Ważna uwaga o działaniu `prompt()`:** Okno modalne `prompt()` wstrzymuje wykonywanie wątku JavaScript w przeglądarce. Dopóki użytkownik nie kliknie przycisku „OK” lub „Anuluj”, dalsze linie kodu nie zostaną zinterpretowane, a strona nie dokończy renderowania elementów.

- **Po co to jest:** Wartość domyślna w `prompt()` zapobiega otrzymaniu pustego ciągu lub wartości `null` podczas szybkiego zatwierdzania testów i zabezpiecza skrypt przed generowaniem błędu `NaN`.
- **Typowa pomyłka:** Zapomnienie o konwersji typu `parseInt()` lub `Number()`. W JavaScript dodanie liczby do napisu (`"12" + 5`) skutkuje konkatenacją tekstową `"125"`, a nie operacją dodawania `17`.

---

## 2. Największy Wspólny Dzielnik (NWD) — Algorytm Euklidesa

Największy Wspólny Dzielnik dwóch dodatnich liczb całkowitych $a$ i $b$, oznaczany jako $NWD(a, b)$, to największa liczba naturalna, która dzieli bez reszty zarówno liczbę $a$, jak i liczbę $b$. Jest to jeden z najstarszych znanych ludzkości algorytmów numerycznych, sformułowany przez Euklidesa około 300 r. p.n.e.

### Wersja 1: Euklides z odejmowaniem
Algorytm opiera się na spostrzeżeniu, że jeśli od większej liczby odejmiemy mniejszą, to wspólny dzielnik nowej różnicy i mniejszej liczby pozostanie dokładnie taki sam, jak wspólny dzielnik pierwotnych liczb. Powtarzamy odejmowanie mniejszej liczby od większej tak długo, aż obie zmienne staną się sobie równe.

```javascript
let a = 48;
let b = 18;

console.log("Początkowe wartości: a =", a, ", b =", b);

while (a !== b) {
  if (a > b) {
    a = a - b;
  } else {
    b = b - a;
  }
}

let nwd = a;
document.write("NWD(48, 18) wynosi: " + nwd + "<br>");
console.log("Wyznaczony NWD:", nwd);
```

#### Tabela śladu (krok po kroku dla $a=48$, $b=18$):
| Krok | Warunek `a !== b` | Porównanie `a > b` | Nowa wartość `a` | Nowa wartość `b` |
|:----:|:-----------------:|:------------------:|:----------------:|:----------------:|
| Start| Prawda ($48 \neq 18$) | Prawda ($48 > 18$) | $48 - 18 = 30$   | $18$             |
| 1    | Prawda ($30 \neq 18$) | Prawda ($30 > 18$) | $30 - 18 = 12$   | $18$             |
| 2    | Prawda ($12 \neq 18$) | Fałsz ($12 < 18$)  | $12$             | $18 - 12 = 6$    |
| 3    | Prawda ($12 \neq 6$)  | Prawda ($12 > 6$)  | $12 - 6 = 6$     | $6$              |
| 4    | Fałsz ($6 === 6$) — koniec pętli! | — | **$6$** | **$6$** |

Wynik końcowy: $NWD = 6$.

- **Po co to jest:** Wersja z odejmowaniem jest intuicyjna, łatwa do zapamiętania i bezpośrednio przekłada się na operacje w pętli `while` bez konieczności stosowania zaawansowanych operatorów.
- **Typowa pomyłka:** Użycie instrukcji `if` zamiast pętli `while`, co spowoduje wykonanie operacji odejmowania tylko raz zamiast doprowadzenia do wyrównania liczb.

---

### Wersja 2: Euklides z resztą z dzielenia (modulo `%`)
Wersja z odejmowaniem staje się nieefektywna, gdy jedna z liczb jest wielokrotnie większa od drugiej (np. $a = 1000000$, $b = 2$ wymagałoby aż 500000 iteracji!). Zamiast wielokrotnie odejmować $b$ od $a$, możemy od razu obliczyć resztę z dzielenia $a$ przez $b$ za pomocą operatora modulo `%`. W każdej iteracji zmiennej pomocniczej przypisujemy resztę z dzielenia, a następnie przesuwamy wartości: do $a$ trafia $b$, a do $b$ trafia reszta. Pętla kończy się, gdy $b$ osiągnie zero.

```javascript
let a = 48;
let b = 18;

while (b !== 0) {
  let reszta = a % b;
  a = b;
  b = reszta;
}

let nwd = a;
document.write("NWD (metoda modulo) wynosi: " + nwd + "<br>");
console.log("NWD modulo:", nwd);
```

- **Po co to jest:** Wersja modulo gwałtownie redukuje liczbę kroków z tysięcy do zaledwie kilku iteracji (złożoność logarytmiczna), co jest kluczowe w wydajnym oprogramowaniu.
- **Typowa pomyłka:** Nadpisanie wartości zmiennej $a$ przed wyliczeniem reszty lub zapomnienie o zmiennej pomocniczej `reszta`, co prowadzi do błędnego dzielenia przez nową wartość.

---

## 3. Test pierwszości liczby (Liczby pierwsze)

**Liczba pierwsza** to liczba naturalna większa od 1, która posiada dokładnie dwa dzielniki naturalne: jedynkę oraz samą siebie (np. 2, 3, 5, 7, 11, 13, 17, 19...). Liczba większa od 1, która nie jest pierwsza, nazywana jest **liczbą złożoną**. Liczby 0 i 1 z definicji nie są ani pierwsze, ani złożone.

### Algorytm testu pierwszości
Aby sprawdzić, czy liczba $n$ jest pierwsza:
1. Sprawdzamy przypadek graniczny: jeśli $n < 2$, liczba nie jest pierwsza.
2. Przyjmujemy założenie wstępne za pomocą flagi logicznej `let jestPierwsza = true;`.
3. W pętli sprawdzamy, czy jakakolwiek liczba $d$ (dzielnik) dzieli $n$ bez reszty (`n % d === 0`).
4. Zakres poszukiwań możemy zoptymalizować: wystarczy sprawdzać dzielniki od 2 do pierwiastka kwadratowego z liczby, czyli dopóki $d \cdot d \le n$. Jeśli liczba miałaby dzielnik większy od pierwiastka, to jego para musiałaby być mniejsza od pierwiastka i zostałaby znaleziona wcześniej.
5. Jeśli znajdziemy dzielnik, ustawiamy `jestPierwsza = false;` i natychmiast przerywamy pętlę za pomocą instrukcji `break;`.

```javascript
let n = 29;
let jestPierwsza = true;

if (n < 2) {
  jestPierwsza = false;
} else {
  for (let d = 2; d * d <= n; d++) {
    if (n % d === 0) {
      jestPierwsza = false;
      break;
    }
  }
}

if (jestPierwsza) {
  document.write("Liczba " + n + " JEST liczbą pierwszą.<br>");
} else {
  document.write("Liczba " + n + " NIE JEST liczbą pierwszą (jest złożona).<br>");
}
```

- **Po co to jest:** Flaga typu boolean (`true`/`false`) pozwala zapamiętać fakt znalezienia dzielnika wewnątrz pętli i wykorzystać tę informację po jej zakończeniu do wyświetlenia czytelnego komunikatu.
- **Typowa pomyłka:** Sprawdzanie dzielników aż do $n-1$ zamiast do $\sqrt{n}$ oraz brak instrukcji `break;`, co powoduje niepotrzebne wykonywanie tysięcy obrotów pętli po wykryciu, że liczba jest złożona.

---

## 4. Ciąg Fibonacciego — generowanie iteracyjne

**Ciąg Fibonacciego** to ciąg liczb naturalnych o fundamentalnym znaczeniu w informatyce, kryptografii i algorytmice. Dwa pierwsze wyrazy ciągu wynoszą odpowiednio:
$$F_0 = 0, \quad F_1 = 1$$
Każdy kolejny wyraz powstaje jako suma dwóch bezpośrednio go poprzedzających wyrazów:
$$F_n = F_{n-1} + F_{n-2} \quad \text{dla } n \ge 2$$
Początkowe wyrazy ciągu to: $0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89...$

### Realizacja w JavaScript bez tablic
W Semestrze 1 nie gromadzimy wyrazów w tablicy. Wypisujemy je na bieżąco, pamiętając w zmiennych jedynie dwie ostatnie wartości:

```javascript
let ileWyrazow = 10;
let a = 0;
let b = 1;

document.write("Ciąg Fibonacciego (" + ileWyrazow + " wyrazów):<br>");

for (let i = 0; i < ileWyrazow; i++) {
  document.write(a + " ");
  console.log("Wyraz", i, "=", a);

  let nastepny = a + b;
  a = b;
  b = nastepny;
}
document.write("<br>");
```

- **Po co to jest:** Mechanizm rotacji zmiennych (`let nastepny = a + b; a = b; b = nastepny;`) to klasyczny wzorzec przesuwania okna pamięci, kluczowy w programowaniu o niskim zużyciu zasobów (złożoność pamięciowa $O(1)$).
- **Typowa pomyłka:** Przypisanie `a = b;` przed obliczeniem `a + b`, co gubi pierwotną wartość `a` i powoduje podwajanie wartości zmiennej `b`.
- **Wariant startu:** Jeśli treść zadania wymaga ciągu zaczynającego się od $1, 1, 2, 3\ldots$ (bez zera), ustaw `let a = 1; let b = 1;` — sama rotacja w pętli pozostaje bez zmian.

---

## 5. Przetwarzanie cyfr liczby całkowitej

Wiele zadań praktycznych i egzaminacyjnych wymaga operowania na poszczególnych cyfrach liczby dziesiętnej (np. obliczenie sumy cyfr, sprawdzenie parzystości cyfr, odwrócenie kolejności czy walidacja sumy kontrolnej w systemach kodów kreskowych).

### Obcinanie cyfr: Modulo `% 10` i dzielenie całkowite `Math.floor(n / 10)`
Dowolną liczbę w systemie dziesiętnym można analizować od prawej do lewej:
1. `liczba % 10` zwraca ostatnią cyfrę liczby (resztę z dzielenia przez 10).
2. `Math.floor(liczba / 10)` odrzuca ostatnią cyfrę liczby (przesunięcie w prawo).

### Obliczanie sumy cyfr liczby:
```javascript
let liczba = 5482;
let tempLiczba = liczba;
let sumaCyfr = 0;

while (tempLiczba > 0) {
  let cyfra = tempLiczba % 10;
  sumaCyfr = sumaCyfr + cyfra;
  tempLiczba = Math.floor(tempLiczba / 10);
}

document.write("Suma cyfr liczby " + liczba + " wynosi: " + sumaCyfr + "<br>");
console.log("Suma cyfr:", sumaCyfr);
```

### Odwracanie kolejności cyfr liczby:
```javascript
let n = 1234;
let kopia = n;
let odwrocona = 0;

while (kopia > 0) {
  let cyfra = kopia % 10;
  odwrocona = odwrocona * 10 + cyfra;
  kopia = Math.floor(kopia / 10);
}

document.write("Liczba pierwotna: " + n + ", liczba odwrócona: " + odwrocona + "<br>");
console.log("Odwrócona:", odwrocona);
```

### Zliczanie liczby cyfr (wariant):
Ten sam schemat obcinania cyfr — zamiast sumować, zwiększamy licznik:

```javascript
let liczba = 84;
let ileCyfr = 0;

while (liczba > 0) {
  ileCyfr++;
  liczba = Math.floor(liczba / 10);
}

document.write("Liczba cyfr: " + ileCyfr + "<br>");
```

- **Po co to jest:** Wyciąganie cyfr za pomocą operacji matematycznych `% 10` i `Math.floor(/ 10)` jest znacznie szybsze i bardziej uniwersalne niż zamiana liczby na łańcuch tekstowy i działa w każdym środowisku obliczeniowym.
- **Typowa pomyłka:** Zastosowanie zwykłego dzielenia `tempLiczba = tempLiczba / 10` bez `Math.floor()`. W JavaScript liczby są domyślnie zmiennoprzecinkowe (typ `number`), więc dzielenie da ułamek (np. $548.2$), a pętla `while (tempLiczba > 0)` stanie się nieskończona!

---

## 6. Rozkład liczby na czynniki pierwsze

Zgodnie z Podstawowym Twierdzeniem Arytmetyki każdą liczbę całkowitą większą od 1 można jednoznacznie przedstawić jako iloczyn liczb pierwszych.
Rozkład realizujemy dzieląc liczbę $n$ przez najmniejszy możliwy dzielnik pierwszy (zaczynając od $d = 2$). Dopóki liczba jest podzielna przez $d$, wypisujemy $d$ i dzielimy $n = n / d$. Gdy nie jest podzielna, zwiększamy $d$ o 1.

```javascript
let n = 60;
let liczbaOrg = n;
let d = 2;

document.write("Rozkład liczby " + liczbaOrg + " na czynniki pierwsze: ");

while (n > 1) {
  while (n % d === 0) {
    document.write(d + " ");
    console.log("Czynnik:", d);
    n = Math.floor(n / d);
  }
  d++;
}
document.write("<br>");
```

Dla liczby $60$ skrypt wypisze: `2 2 3 5`, ponieważ $2 \cdot 2 \cdot 3 \cdot 5 = 60$.

- **Po co to jest:** Zagnieżdżona pętla `while` w pętli zewnętrznej pozwala wielokrotnie dzielić liczbę przez ten sam dzielnik (np. przez 2 w przypadku liczby parzystej), dopóki dana potęga dzielnika nie zostanie wyczerpana.
- **Typowa pomyłka:** Zwiększanie dzielnika `d++` wewnątrz pętli dzielącej, co uniemożliwia wielokrotne uwzględnienie tego samego czynnika pierwszego (np. drugiego dzielnika 2 dla liczby 12).
