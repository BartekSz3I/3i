# Teoria: Most CLI — Te same operacje w terminalu

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Wprowadzenie: dlaczego terminal jest niezbędny programiście?

W module T01 poznaliśmy model grafowy systemu Git w interaktywnym symulatorze *Learn Git Branching*. Zobaczyliśmy, jak wskaźniki gałęzi przesuwają się po kolejnych węzłach commitów, jak działa wskaźnik `HEAD` oraz na czym polega scalanie zmian (*merge*). W module T02 nauczyliśmy się wykonywać codzienne operacje wersjonowania poprzez graficzny interfejs w przeglądarce na portalu GitHub.com. 

Interfejs graficzny ma jednak swoje granice. W rzeczywistym środowisku deweloperskim większość operacji wykonuje się bezpośrednio w wierszu poleceń (CLI — *Command Line Interface*). Dlaczego tak jest?
1. **Szybkość i automatyzacja**: Wpisanie krótkiego polecenia w terminalu zintegrowanym w edytorze kodu (np. VS Code) zajmuje ułamek sekundy i nie wymaga odrywania rąk od klawiatury.
2. **Dostępność na każdym środowisku**: Wiele serwerów produkcyjnych, kontenerów czy maszyn w chmurze nie posiada żadnego interfejsu graficznego — jedynym dostępnym narzędziem jest tam czarny ekran terminala.
3. **Precyzja i kontrola**: Terminal wyświetla dokładnie to, co dzieje się z naszymi plikami, nie ukrywając żadnych procesów pod uproszczonymi przyciskami graficznymi.

Niniejszy moduł to **most** łączący zdobytą wiedzę o strukturze drzewa repozytorium z praktycznymi poleceniami wpisywanymi w wierszu poleceń.

---

## 2. Pierwsze kroki: konfiguracja tożsamości autora (`git config`)

Zanim utworzymy jakikolwiek commit, musimy poinformować system Git, kto jest autorem zmian. Każdy commit w systemie Git trwale zapisuje imię, nazwisko oraz adres e-mail osoby zatwierdzającej rewizję. Informacje te są widoczne dla wszystkich członków zespołu w historii projektu.

Konfiguracji dokonujemy poleceniami:

```bash
git config --global user.name "Jan Kowalski"
git config --global user.email "jan.kowalski@szkola.pl"
```

Flaga `--global` oznacza, że ustawienia te zostaną zapisane w głównym pliku konfiguracyjnym użytkownika systemowego (np. w katalogu domowym) i będą automatycznie stosowane we wszystkich repozytoriach na tym komputerze.

Aby sprawdzić aktualne ustawienia, wpisujemy:

```bash
git config --list
```

> **Po co to jest:**  
> Identyfikacja autora pozwala jednoznacznie przypisać odpowiedzialność za dany fragment kodu w zespole. Ułatwia to późniejsze przeglądanie historii (`git log`), ustalanie przyczyn błędów oraz automatyczne przypisywanie wkładu do profilu na platformie GitHub.
> 
> **Typowa pomyłka:**  
> Podanie adresu e-mail innego niż powiązany z kontem GitHub sprawia, że commity w zdalnym repozytorium nie zostaną przypisane do Twojego profilu użytkownika (zamiast Twojego awatara pojawi się szara domyślna ikona). Zawsze sprawdzaj poprawność adresu e-mail przed pierwszym commitem.

---

## 3. Trzy strefy robocze w Git: fundament pracy z CLI

Aby zrozumieć działanie poleceń w terminalu, należy wyobrazić sobie architekturę **trzech stanów (stref)**, przez które przechodzą modyfikowane pliki:

1. **Katalog roboczy (Working Directory)**:  
   To zwykłe pliki i foldery na Twoim dysku, które edytujesz w edytorze kodu (np. pliki `index.html`, `style.css`, obrazy).
2. **Strefa przechowalni (Staging Area / Index)**:  
   Tymczasowa poczekalnia, w której precyzyjnie przygotowujesz zestaw zmian przeznaczonych do najbliższego commita. Plik trafia tu dopiero wtedy, gdy wyraźnie wskażesz go poleceniem `git add`.
3. **Lokalne repozytorium (Repository / Baza historii)**:  
   Ukryty katalog `.git`, w którym system przechowuje skompresowane migawki całego projektu jako niezmienne commity. Zmiany trafiają tu po wykonaniu polecenia `git commit`.

```
[ Katalog roboczy ] --- git add ---> [ Poczekalnia (Staging Area) ] --- git commit ---> [ Repozytorium (.git) ]
```

---

## 4. Inicjalizacja i klonowanie repozytorium (`git init` oraz `git clone`)

Mamy dwie drogi rozpoczęcia pracy nad projektem z kontrolą wersji:

### Utworzenie nowego repozytorium od zera: `git init`

Jeżeli tworzysz zupełnie nowy folder na dysku i chcesz objąć go kontrolą wersji Git, otwierasz w nim terminal i wpisujesz:

```bash
git init
```

Polecenie to tworzy w bieżącym katalogu ukryty podfolder o nazwie `.git`. To właśnie w nim znajduje się baza danych historii projektu. Nie należy modyfikować zawartości folderu `.git` ręcznie.

### Pobranie istniejącego projektu z sieci: `git clone`

Jeżeli projekt istnieje już na serwerze (np. na GitHubie), pobieramy jego pełną kopię wraz z całą historią za pomocą polecenia `git clone`:

```bash
git clone https://github.com/organizacja/projekt-sklep.git
```

Git automatycznie utworzy podfolder o nazwie repozytorium, pobierze pliki robocze, zainicjuje lokalne repozytorium i skonfiguruje zdalny wskaźnik `origin`.

> **Po co to jest:**  
> `git init` pozwala wystartować z wersjonowaniem własnego, nowego projektu na lokalnym komputerze, podczas gdy `git clone` umożliwia błyskawiczne włączenie się do istniejącego projektu zespołowego ze wszystkimi jego gałęziami i historią.
> 
> **Typowa pomyłka:**  
> Uruchomienie `git init` wewnątrz folderu, który już jest repozytorium (albo w folderze nadrzędnym, np. w całym profilu użytkownika `C:\Users\Uczen`). Prowadzi to do zagnieżdżonych repozytoriów i poważnych problemów ze śledzeniem plików. Zawsze upewnij się za pomocą polecenia `git status`, w jakim katalogu się znajdujesz.

---

## 5. Podstawowy cykl rejestracji zmian: `status`, `add`, `commit`

To najważniejszy i najczęściej powtarzany łańcuch poleceń każdego programisty:

### 1. Sprawdzanie stanu: `git status`

Polecenie `git status` odpowiada na trzy kluczowe pytania:
- Na jakiej gałęzi aktualnie pracujesz?
- Które pliki zostały zmodyfikowane lub dodane, ale nie są jeszcze w poczekalni? (*Changes not staged for commit* / *Untracked files*)
- Które pliki znajdują się w strefie przechowalni i wejdą do kolejnego commita? (*Changes to be committed*)

```bash
git status
```

### 2. Dodawanie plików do przechowalni: `git add`

Gdy edytujesz plik `index.html` lub tworzysz nowy arkusz `style.css`, plik ten ma status nieśledzonego lub zmodyfikowanego. Aby przenieść go do poczekalni, używasz polecenia:

```bash
git add index.html
```

Możesz także dodać wszystkie zmodyfikowane i nowo utworzone pliki z bieżącego katalogu za pomocą kropki:

```bash
git add .
```

### 3. Zapisanie migawki w historii: `git commit -m "..."`

Zatwierdzenie zmian powoduje trwałe utrwalenie stanu plików ze strefy przechowalni w postaci nowego obiektu commita w bazie danych. Każdy commit musi posiadać zwięzły, jednoznaczny opis informujący, co zostało zmienione:

```bash
git commit -m "Dodanie sekcji nagłówka oraz menu nawigacji"
```

> **Po co to jest:**  
> Podział na dwa etapy (`git add` oraz `git commit`) daje programiście pełną kontrolę nad zawartością commita. Jeśli zmodyfikowałeś pięć różnych plików, ale tylko dwa z nich dotyczą naprawy formularza, możesz dodać poleceniem `git add` tylko te dwa pliki i zatwierdzić je osobnym, logicznym commitem.
> 
> **Typowa pomyłka:**  
> Zapomnienie o przełączniku `-m` przy poleceniu `git commit`. Jeśli wpiszesz samo `git commit`, terminal uruchomi domyślny edytor tekstowy (często Vim lub Nano), co dla początkującego ucznia bywa dezorientujące. Jeśli edytor się otworzy, wpisz treść opisu, zapisz i zamknij edytor, a w razie utknięcia w Vimie naciśnij klawisz `Esc`, wpisz `:q!` i wciśnij `Enter`.

---

## 6. Przeglądanie historii i badanie różnic: `git log` oraz `git diff`

### Historia commitów: `git log`

Polecenie `git log` wyświetla listę commitów w porządku chronologicznym (od najnowszego do najstarszego). Standardowy widok bywa rozwlekły, dlatego w codziennej pracy programiści stosują flagi skracające:

```bash
git log --oneline
```

Wyświetla każdy commit w pojedynczej linii: 7-znakowy skrót identyfikatora SHA-1 oraz treść wiadomości.

Jeszcze bardziej przydatny jest widok grafu gałęzi w terminalu:

```bash
git log --oneline --graph --all
```

Rysuje on tekstowe linie rozgałęzień i scaleń, dokładnie odpowiadające modelowi grafowemu z modułu T01.

### Badanie różnic: `git diff`

Zanim dodasz pliki do poczekalni, warto sprawdzić, co dokładnie zostało zmienione linijka po linijce:

```bash
git diff
```

Wiersze usunięte są oznaczane znakiem minus `-` i kolorem czerwonym, natomiast wiersze dodane znakiem plus `+` i kolorem zielonym.

**Ważne ograniczenie:** zwykłe `git diff` porównuje pliki **już śledzone** (po co najmniej jednym commicie lub po wcześniejszym `git add`) z wersją w przechowalni/repozytorium. Dla plików całkiem nowych (*untracked*) `git diff` **nic nie wypisze** — najpierw zatwierdź stan bazowy, potem edytuj i dopiero wtedy uruchom `git diff`.

Jeżeli pliki zostały już dodane poleceniem `git add`, standardowe `git diff` nic nie pokaże. Aby sprawdzić zawartość poczekalni, stosujemy flagę `--staged`:

```bash
git diff --staged
```

> **Po co to jest:**  
> `git diff` to podstawowy filtr bezpieczeństwa. Pozwala programiście przejrzeć własne zmiany przed zatwierdzeniem i upewnić się, że przez przypadek nie zostawiono w kodzie roboczych komentarzy, haseł ani zbędnych plików tymczasowych.
> 
> **Typowa pomyłka:**  
> Wykonanie `git diff` zaraz po `git init` na jeszcze nieśledzonym `index.html` i wniosek, że „polecenie nie działa”. Albo wykonanie `git diff` po `git add .` i wniosek, że „zmiany zniknęły” — wtedy użyj `git diff --staged`.

---

## 7. Praca na gałęziach w terminalu: `branch`, `switch`, `merge`

W module T01 nauczyliśmy się, że gałąź w Git to po prostu ruchomy wskaźnik wskazujący na konkretny commit. Tworzenie gałęzi jest natychmiastowe i nie wymaga kopiowania całego projektu na dysku.

### Wyświetlanie listy gałęzi: `git branch`

Wpisanie samego polecenia wyświetla listę wszystkich gałęzi lokalnych. Gwiazdka `*` oraz zielony kolor oznaczają gałąź, na której aktualnie się znajdujesz:

```bash
git branch
```

### Tworzenie i przełączanie gałęzi: `git switch`

Nowoczesny Git (od wersji 2.23) udostępnia intuicyjne polecenie `git switch`, które zastąpiło wieloznaczne dawniej polecenie `git checkout`.

Aby utworzyć nową gałąź i od razu się na nią przełączyć, używamy flagi `-c` (*create*):

```bash
git switch -c feature-formularz-kontaktowy
```

Możesz także spotkać w starszych materiałach i arkuszach egzaminacyjnych tradycyjne polecenie:

```bash
git checkout -b feature-formularz-kontaktowy
```

Oba polecenia działają identycznie: tworzą nową gałąź i przestawiają na nią wskaźnik `HEAD`.

Przełączanie się na już istniejącą gałąź:

```bash
git switch main
```

### Scalanie gałęzi: `git merge`

Gdy prace na gałęzi pobocznej zostaną ukończone i przetestowane, łączymy je z gałęzią główną:
1. Przełączamy się na gałąź docelową (zazwyczaj `main`):
   ```bash
   git switch main
   ```
2. Wciągamy zmiany z gałęzi funkcyjnej:
   ```bash
   git merge feature-formularz-kontaktowy
   ```

Jeżeli na gałęzi `main` nie powstały w tym czasie inne commity, Git wykona tzw. *Fast-Forward* (przewinięcie wskaźnika w przód), co znamy z modułu T01.

> **Po co to jest:**  
> Izolacja prac na osobnych gałęziach chroni główną wersję programu (`main`) przed wprowadzeniem niesprawdzonego, niedziałającego kodu. Każda nowa podstrona czy moduł powstaje na własnej gałęzi i jest dołączana dopiero po ukończeniu.
> 
> **Typowa pomyłka:**  
> Wywołanie `git merge` będąc na niewłaściwej gałęzi (np. próba scalenia `main` do gałęzi funkcyjnej zamiast gałęzi funkcyjnej do `main`). Przed scalaniem zawsze upewnij się za pomocą `git status` lub `git branch`, że stoisz na gałęzi docelowej (np. `main`).

---

## 8. Synchronizacja ze zdalnym serwerem: `remote`, `push`, `pull`

Lokalne repozytorium na Twoim komputerze może współpracować ze zdalnym serwerem (np. GitHub).

> **Zakres praktyki w T03:** w zadaniu 5 ćwiczysz wyłącznie `git remote add origin` oraz `git remote -v`. Polecenia `git push` i `git pull` znasz z teorii i z modułu T02 — **nie uruchamiaj ich** na przykładowym adresie z instrukcji T03.

### Sprawdzanie i dodawanie zdalnego adresu: `git remote`

Aby podejrzeć skonfigurowane adresy repozytoriów zdalnych:

```bash
git remote -v
```

Zazwyczaj domyślny zdalny wskaźnik nazywa się `origin`. Jeśli podłączasz nowe, lokalnie utworzone repozytorium do pustego projektu na GitHubie, łączysz je poleceniem:

```bash
git remote add origin https://github.com/twoj-login/nazwa-repozytorium.git
```

### Wysyłanie zmian na serwer: `git push`

Aby wysłać swoje lokalne commity na GitHub, używamy polecenia `git push`. Przy pierwszym wypchnięciu nowej gałęzi dodajemy przełącznik `-u` (*set-upstream*), który trwale wiąże lokalną gałąź z jej zdalnym odpowiednikiem:

```bash
git push -u origin main
```

Przy kolejnych wysyłkach na tej samej gałęzi wystarczy wpisać samo:

```bash
git push
```

### Pobieranie zmian z serwera: `git pull`

Gdy inny członek zespołu dodał commity na GitHubie lub sam dokonałeś zmian przez interfejs www (np. zaakceptowałeś Pull Request z modułu T02), pobierasz te aktualizacje do swojego lokalnego folderu:

```bash
git pull origin main
```

Polecenie `git pull` łączy w sobie dwie operacje: pobranie nowych danych z sieci (`git fetch`) oraz ich natychmiastowe scalenie z bieżącą gałęzią roboczą (`git merge`).

> **Po co to jest:**  
> `git push` oraz `git pull` tworzą dwukierunkowy pomost między Twoim stanowiskiem pracy a chmurą. Umożliwiają bezpieczne archiwizowanie kodu na wypadek awarii sprzętu oraz asynchroniczną współpracę wielu programistów nad tym samym projektem.
> 
> **Typowa pomyłka:**  
> Próba wykonania `git push` w sytuacji, gdy na zdalnym repozytorium znajdują się nowe commity, których nie ma jeszcze na Twoim komputerze. Git odrzuci takie wysłanie (*non-fast-forward rejected*). Rozwiązaniem jest wykonanie najpierw `git pull`, zbadanie stanu projektu i dopiero ponowne wykonanie `git push`.

---

## 9. Wykluczanie plików z repozytorium: plik `.gitignore`

Nie wszystkie pliki w folderze projektu powinny trafić do historii wersji. Do repozytorium **nigdy nie dodajemy**:
- Plików konfiguracyjnych edytora i środowiska (np. katalog `.vscode/`, `.idea/`).
- Plików systemowych tworzonych automatycznie przez system operacyjny (np. `Thumbs.db` w Windows czy `.DS_Store` w macOS).
- Pobranych zewnętrznych bibliotek i zależności (np. katalog `node_modules/`).
- Plików z poufnymi danymi (klucze API, hasła do baz danych, pliki `.env`).
- Plików tymczasowych i logów diagnostycznych (np. `*.log`, pliki `.tmp`).

Do ignorowania takich plików służy specjalny plik tekstowy umieszczony w katalogu głównym repozytorium o nazwie `.gitignore`.

### Przykładowa składnia pliku `.gitignore`:

```gitignore
# Komentarz w pliku .gitignore zaczyna się od krzyżyka

# Ignoruj pojedynczy konkretny plik
tajne-hasla.txt
.env

# Ignoruj wszystkie pliki z rozszerzeniem .log
*.log

# Ignoruj cały katalog (wraz z całą jego zawartością)
node_modules/
temp/
.vscode/

# Ignoruj pliki tymczasowe edytorów
*~
*.swp
```

Aby zobaczyć listę plików ignorowanych (zwykły `git status` je ukrywa), użyj:

```bash
git status --ignored
```

> **Po co to jest:**  
> Plik `.gitignore` zapobiega zaśmiecaniu repozytorium niepotrzebnymi, gigantycznymi plikami binarnymi i bibliotekami oraz chroni przed przypadkowym opublikowaniem w sieci wrażliwych informacji (haseł, certyfikatów).
> 
> **Typowa pomyłka:**  
> Utworzenie pliku `.gitignore` dopiero po tym, jak niepożądany plik został już dodany poleceniem `git add` i zatwierdzony commitem. Jeśli plik jest już śledzony przez Git, dodanie reguły do `.gitignore` nie usunie go automatycznie z historii. Wtedy należy najpierw usunąć plik z przechowalni poleceniem `git rm --cached <plik>`.

---

## 10. Tabela podsumowująca: interfejs graficzny vs terminal CLI

Poniższa tabela stanowi bezpośredni pomost pojęciowy między modułami T01, T02 a bieżącym modułem T03:

| Czynność deweloperska | Symulator LGB (T01) / GitHub.com (T02) | Polecenie terminala CLI (T03) |
|---|---|---|
| Inicjalizacja projektu | Utworzenie nowego repozytorium na github.com | `git init` |
| Pobranie repozytorium | Klonowanie / pobranie ZIP ze strony www | `git clone <url>` |
| Sprawdzenie stanu plików | Wizualne oznaczenie kółkami / lista plików | `git status` |
| Wrzucenie zmian do poczekalni | Zaznaczenie plików do commita na stronie www | `git add <plik>` lub `git add .` |
| Zapisanie migawki zmian | Przycisk *Commit changes* na github.com | `git commit -m "komunikat"` |
| Przeglądanie historii | Zakładka *Commits* na github.com | `git log --oneline` |
| Badanie różnic w pliku | Podgląd *Diff* (zielone/czerwone linie w PR) | `git diff` |
| Utworzenie nowej gałęzi | `git branch <nazwa>` w LGB / lista w UI GitHub | `git switch -c <nazwa>` |
| Przełączenie gałęzi | `git checkout <nazwa>` w LGB / menu w UI GitHub | `git switch <nazwa>` |
| Scalenie gałęzi | `git merge <nazwa>` w LGB / przycisk *Merge PR* | `git merge <nazwa>` |
| Wysłanie zmian na serwer | Bezpośrednia edycja w przeglądarce | `git push -u origin <nazwa>` |
| Pobranie zmian z serwera | Odświeżenie strony w przeglądarce | `git pull origin <nazwa>` |
