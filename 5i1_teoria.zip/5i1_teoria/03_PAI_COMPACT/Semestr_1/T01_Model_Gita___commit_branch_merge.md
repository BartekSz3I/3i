# Teoria — Model Gita: commit, branch, merge

**Przedmiot:** Programowanie aplikacji internetowych (PAI)  
**Semestr:** 1 (Git, GitHub i Fundamenty Języka JavaScript)  
**Profil:** compact  

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Problem tradycyjnej archiwizacji i geneza systemu kontroli wersji

Wyobraź sobie, że pracujesz nad witryną internetową dla lokalnej piekarni. W poniedziałek tworzysz strukturę strony głównej. We wtorek dodajesz cennik pieczywa. W środę klient prosi o zmianę kolorystyki i dodanie formularza zamówień tortów.

Jak wyglądało zarządzanie taką pracą przed pojawieniem się nowoczesnych systemów kontroli wersji? Programiści ręcznie powielali foldery na dysku, tworząc katalogi o nazwach:
- `piekarnia_kopia/`
- `piekarnia_v2/`
- `piekarnia_v2_poprawiona/`
- `piekarnia_ostateczna_FINAL_na_pewno/`

Taki sposób pracy prowadzi do natychmiastowego chaosu:
1. Nie wiadomo, czym dokładnie różni się wersja „poprawiona” od „ostatecznej”.
2. Jeśli klient po tygodniu powie: *„Jednak wolimy układ menu z wtorku rano”*, odszukanie i przywrócenie konkretnego fragmentu kodu staje się koszmarem.
3. Gdy nad projektem pracuje dwóch programistów i obaj edytują ten sam plik, nawzajem nadpisują swoje zmiany, niszcząc efekty cudzej pracy.

Rozwiązaniem tego problemu jest **Git** — rozproszony system kontroli wersji (VCS — *Version Control System*). Git nie kopiuje całych folderów na ślepo. Zamiast tego rejestruje historię rozwoju projektu jako **uporządkowany ciąg powiązanych ze sobą migawek**.

---

## 2. Commit — niezmienna migawka w grafie historii

Podstawową jednostką zapisu w systemie Git jest **commit** (zatwierdzenie). 

Najprościej wyobrazić sobie commit jako **zdjęcie (migawkę)** całego Twojego repozytorium wykonane w konkretnym momencie czasu. Każdy commit w Git posiada:
1. **Unikalny identyfikator (hash)** — ciąg znaków alfanumerycznych generowany funkcją skrótu SHA-1 (np. `c1`, `a8f3b2...`), jednoznacznie identyfikujący dany stan w historii.
2. **Wskaźnik do rodzica (rodziców)** — referencję do commita, na bazie którego powstała nowa wersja. Dzięki temu commity tworzą łańcuch powiązań.
3. **Metadane** — informację o autorze zmiany oraz dokładny znacznik czasu (datę i godzinę zatwierdzenia).
4. **Opis zmiany (commit message)** — zwięzły, jednoznaczny komunikat wyjaśniający, co i dlaczego zostało zmienione (np. `"Dodanie sekcji cennika w pliku index.html"`).

W symulatorze wizualnym **Learn Git Branching** commity są reprezentowane jako okrągłe węzły oznaczone etykietami `C0`, `C1`, `C2` itd., a strzałki wskazują od commita potomnego do commita nadrzędnego (rodzica).

```text
(C0) <--- (C1) <--- (C2) [HEAD -> main]
```

Podstawowe polecenie tworzące nowy commit w symulatorze:
```bash
git commit
```
W wyniku wykonania tego polecenia powstaje nowy węzeł (np. `C3`), którego rodzicem staje się dotychczasowy aktywny węzeł `C2`, a wskaźnik gałęzi przesuwa się na nowy węzeł.

**Po co to jest:**  
Commit tworzy trwały, nienaruszalny punkt przywracania w historii projektu. Pozwala w dowolnym momencie sprawdzić, kto, kiedy i dlaczego wprowadził daną modyfikację, a w razie błędu — bezpiecznie powrócić do działającej wersji aplikacji bez utraty pozostałych prac.

**Typowa pomyłka:**  
Mylenie commita z zapisaniem pliku na dysku (np. skrótem Ctrl+S). Zwykłe zapisanie pliku modyfikuje jedynie roboczy stan na dysku komputera, ale Git jeszcze o tym nie wie w kontekście historii. Commit to świadomy, oficjalny akt zarejestrowania zamkniętego etapu prac w kronice repozytorium.

---

## 3. Gałąź (`branch`) — równoległe linie rozwoju

W profesjonalnych projektach rzadko pracuje się wyłącznie na jednym, liniowym ciągu commitów. Wyobraź sobie, że działająca strona piekarni znajduje się pod adresem internetowym, a Ty chcesz przez dwa dni testować zupełnie nowy, eksperymentalny układ graficzny. Jeśli zaczniesz wprowadzać niesprawdzone zmiany bezpośrednio w kodzie produkcyjnym, strona klientów może przestać działać.

Do tego celu służą **gałęzie (branches)**.

W systemie Git gałąź **NIE JEST** osobnym folderem na dysku ani ciężką kopią projektu. Gałąź w Git to po prostu **bardzo lekki, ruchomy wskaźnik (etykieta)**, który wskazuje na jeden konkretny commit w grafie historii.

Gdy tworzysz repozytorium, Git tworzy domyślną gałąź główną — tradycyjnie nazywaną `main` (w starszych materiałach można spotkać nazwę `master`).

Aby utworzyć nową gałąź o nazwie `funkcja-galeria`, wydajemy polecenie:
```bash
git branch funkcja-galeria
```

W tym momencie w grafie historii powstaje nowa etykieta wskazująca na ten sam commit, na którym aktualnie stoimy. Nie powiela to plików — dodaje jedynie nowy wskaźnik o wadze kilkunastu bajtów.

**Po co to jest:**  
Gałęzie pozwalają na pełną izolację prac. Programista może eksperymentować, tworzyć nowe moduły, a nawet psuć kod na osobnej gałęzi funkcyjnej (`feature branch`), mając 100% pewności, że główna gałąź stabilna (`main`) pozostaje nienaruszona i gotowa do wdrożenia.

**Typowa pomyłka:**  
Przekonanie, że polecenie `git branch nowa-galaz` automatycznie przenosi nas na tę gałąź. Samo `git branch <nazwa>` jedynie **tworzy** nową etykietę w grafie, ale wskaźnik aktywnego miejsca pracy nadal pozostaje na dotychczasowej gałęzi!

---

## 4. Wskaźnik `HEAD` i przełączanie gałęzi (`checkout` / `switch`)

Skąd Git wie, na której gałęzi aktualnie się znajdujesz i do którego commita ma doczepić Twój następny `git commit`?

Decyduje o tym specjalny wskaźnik o nazwie **`HEAD`**.

`HEAD` to wewnętrzny wskaźnik Gita, który wskazuje na to, co jest aktualnie załadowane w Twoim katalogu roboczym. Najczęściej `HEAD` wskazuje na etykietę gałęzi (np. `HEAD -> main`), a ta z kolei wskazuje na konkretny commit. Mówimy wtedy, że gałąź jest *aktywna*.

Aby przełączyć się na inną gałąź, stosujemy polecenie:
```bash
git checkout funkcja-galeria
```
lub w nowszych wersjach Gita:
```bash
git switch funkcja-galeria
```

Gdy to zrobisz, `HEAD` przełącza się na gałąź `funkcja-galeria`. Teraz każdy nowy commit wykonany poleceniem `git commit` będzie posuwał naprzód wyłącznie gałąź `funkcja-galeria`, podczas gdy gałąź `main` pozostanie w swoim dawnym miejscu!

```text
       (C2) [main]
      /
(C1) <
      \
       (C3) [HEAD -> funkcja-galeria]
```

Można też połączyć operację utworzenia i natychmiastowego przełączenia w jedną komendę:
```bash
git checkout -b nowa-galaz
# lub:
git switch -c nowa-galaz
```

**Po co to jest:**  
`HEAD` precyzyjnie definiuje kontekst pracy. Dzięki niemu programista może w ułamku sekundy przeskakiwać pomiędzy pracą nad nową funkcją a pilną naprawą błędu w wersji stabilnej bez ryzyka pomieszania zmian.

**Typowa pomyłka:**  
Wykonywanie commitów w stanie tzw. *detached HEAD* (odłączony HEAD), czyli sytuacji, gdy przełączono się bezpośrednio na identyfikator commita (np. `git checkout C1`), a nie na nazwę gałęzi. Nowe commity powstałe w takim stanie nie należą do żadnej gałęzi i po przełączeniu na `main` mogą zostać osierocone.

---

## 5. Scalanie gałęzi (`git merge`)

Kiedy prace na gałęzi tematycznej zostaną ukończone i przetestowane, nadchodzi moment włączenia ich do stabilnej gałęzi głównej `main`. Operacja ta nazywa się **scalaniem (mergowaniem)**.

Kluczowa zasada procedury scalania brzmi:  
**Zawsze najpierw przełącz się na gałąź docelową (tę, do której chcesz wlać zmiany), a dopiero potem wywołaj polecenie scalenia z nazwą gałęzi źródłowej!**

```bash
git checkout main
git merge funkcja-galeria
```

W zależności od topologii grafu historii, Git wykona scalenie w jednym z dwóch trybów:

### Wariant A: Scalanie *Fast-forward* (przewijanie w przód)

Występuje wtedy, gdy od momentu odgałęzienia `funkcja-galeria` na gałęzi `main` **nie powstały żadne nowe commity**. Droga od `main` do `funkcja-galeria` jest prostą linią.

W takiej sytuacji Git nie musi tworzyć żadnych dodatkowych węzłów — po prostu przesuwa etykietę `main` w przód na węzeł, na którym stoi `funkcja-galeria`.

```text
PRZED MERGE (fast-forward):
(C1) [main] <--- (C2) [HEAD -> funkcja-galeria]

PO WYKONANIU: git checkout main; git merge funkcja-galeria
(C1) <--- (C2) [HEAD -> main, funkcja-galeria]
```

### Wariant B: Scalanie trójstronne (*3-way merge* / Merge Commit)

Występuje wtedy, gdy historia się rozgałęziła — zarówno na gałęzi `main`, jak i na gałęzi `funkcja-galeria` powstały niezależne commity.

Git analizuje trzy punkty w grafie:
1. Ostatni commit gałęzi `main`.
2. Ostatni commit gałęzi `funkcja-galeria`.
3. Wspólnego przodka obu gałęzi (punkt rozgałęzienia).

Na podstawie tej analizy Git generuje zupełnie nowy **commit scalający (merge commit)**, który ma **dwóch rodziców** — domyka on obie linie rozwoju w jeden spójny węzeł.

```text
PRZED MERGE:
       (C2) [HEAD -> main]
      /
(C1) <
      \
       (C3) [funkcja-galeria]

PO WYKONANIU: git merge funkcja-galeria
       (C2) <--- \
      /           (C4) [HEAD -> main]
(C1) <           /
      \         /
       (C3) <--
        [funkcja-galeria]
```

**Po co to jest:**  
Polecenie `git merge` umożliwia bezpieczną integrację niezależnych linii prac programistycznych. Gwarantuje, że kod z różnych gałęzi funkcjonalnych zostaje połączony z zachowaniem pełnej historii tego, kiedy i z jakiego rozgałęzienia pochodziły zmiany.

**Typowa pomyłka:**  
Mylenie kierunku scalania — próba wpisania `git merge main` będąc na gałęzi funkcyjnej zamiast gałęzi `main`. W takim przypadku wciągamy kod z `main` do gałęzi pobocznej, zamiast zintegrować gotową funkcję z gałęzią główną projektu.

---

## 6. Praca w symulatorze Learn Git Branching

W ramach tego modułu wszystkie ćwiczenia wykonujesz w symulatorze wizualnym pod adresem [learngitbranching.js.org](https://learngitbranching.js.org).

Symulator ten w czasie rzeczywistym rysuje graf powiązań między commitami, co pozwala:
- Na bieżąco obserwować, gdzie znajduje się gwiazdka oznaczająca `HEAD`.
- Wizualnie kontrolować, które gałęzie przesuwają się po wywołaniu polecenia `git commit`.
- Bez stresu i bez ryzyka utraty plików uczyć się zachowania komend `branch`, `checkout` i `merge`.

### Piaskownica a poziomy Intro

Symulator ma dwa tryby:

1. **Poziomy Intro** (np. „Wprowadzenie do commitów Gita”, „Rozgałęzienia w Gicie”, „Merge w Gicie”) — mają własny cel (konkretne nazwy gałęzi, liczba commitów) i komunikat sukcesu.
2. **Piaskownica (sandbox)** — wolny tryb bez celu poziomu. Tu budujesz graf dokładnie według instrukcji zadań z folderu `nauka/` i `sprawdzian/`.

Aby wejść do piaskownicy, wpisz w konsoli symulatora:

```bash
sandbox
```

Aby wrócić do czystego startu (`C0`, `C1`, `main` na `C1`):

```bash
reset
```

**Ważne:** Zadania laboratoryjne i sprawdzianowe używają **własnych nazw gałęzi** (np. `oferta-klimatyzacja`, `cennik-szczepien`). Nie wykonuj ich „na zaliczenie” wbudowanych poziomów Intro — cele się nie pokrywają. Ocenie podlega zgodność Twojego grafu z opisem w `instrukcja.md`, a nie komunikat sukcesu poziomu.

W konsoli wpisujesz wyłącznie polecenia Git (`git commit`, `git checkout -b …`, `git merge …`). Cytaty fabularne z instrukcji (oferta, komunikat biznesowy) trafiają do pliku `index.html` w folderze zadania — nie do konsoli symulatora.

Dzięki opanowaniu modelu mentalnego w tym środowisku, późniejsze przejście do platformy GitHub oraz lokalnego terminala staje się naturalne i intuicyjne.
