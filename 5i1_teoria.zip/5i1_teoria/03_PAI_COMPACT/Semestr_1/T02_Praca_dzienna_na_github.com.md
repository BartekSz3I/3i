# Teoria modułu T02: Praca dzienna na github.com

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Wprowadzenie: Czym jest GitHub i repozytorium zdalne (`remote`)

W poprzednim module poznaliśmy zasady pracy z lokalnym repozytorium Git — tworzenie rewizji (`git commit`), przełączanie gałęzi (`git branch`, `git switch`) oraz ich scalanie (`git merge`). Wszystkie te operacje odbywały się wyłącznie na dysku twardym Twojego komputera, w ukrytym katalogu `.git`. 

W rzeczywistych projektach informatycznych programiści niemal nigdy nie pracują w całkowitej izolacji. Kod źródłowy musi być przechowywany w bezpiecznym, centralnym miejscu dostępnym dla całego zespołu. Takim miejscem jest **serwer zdalny** (ang. *remote repository*). Najpopularniejszą na świecie platformą hostingową dla repozytoriów Git jest **GitHub.com**. 

Repozytorium na GitHubie to lustrzana, serwerowa kopia Twojego projektu. Zawiera ono pełną historię commitów, wszystkie gałęzie i tagi. Dzięki niemu praca zespołu staje się zsynchronizowana: programista może pobrać najnowsze zmiany wprowadzone przez kolegę lub koleżankę, opublikować własne funkcjonalności oraz zabezpieczyć kod przed utratą w wyniku awarii sprzętu komputerowego.

Domyślną nazwą dla głównego serwera zdalnego w ekosystemie Git jest słowo **`origin`**. Jest to po prostu wygodny alias (etykieta skrótowa) wskazujący na pełny adres internetowy repozytorium (np. `https://github.com/uzytkownik/projekt.git`).

- **Po co to jest:** Rejestrowanie serwera zdalnego pod krótką nazwą `origin` pozwala programiście wysyłać i pobierać kod bez konieczności każdorazowego wpisywania długiego adresu URL repozytorium w terminalu.
- **Typowa pomyłka:** Mylenie platformy GitHub z samym narzędziem Git. Git to lokalny program konsolowy zarządzający historią plików, natomiast GitHub to zewnętrzny serwis internetowy, który udostępnia serwery dla repozytoriów Git oraz narzędzia do pracy zespołowej.

---

## 2. Klonowanie repozytorium (`git clone`)

Gdy dołączasz do istniejącego projektu komercyjnego lub chcesz uruchomić na swoim komputerze kod udostępniony na GitHubie, nie tworzysz pustego folderu i nie wpisujesz polecenia `git init`. Zamiast tego wykonujesz operację **klonowania**.

Polecenie `git clone` przyjmuje jako argument adres URL (GitHub) **albo** ścieżkę do lokalnego repozytorium bare (ćwiczenia w pracowni szkolnej):

```bash
git clone https://github.com/nazwa-uzytkownika/nazwa-projektu.git
git clone ../remotes/aroma-roast.git moj-klon-aroma-roast
```

> W module T02 nauczyciel przygotowuje lokalne bare remotes skryptem z pliku `przygotowanie_srodowiska.md`. Działają one jak serwer GitHub: `clone`, `pull` i `push` mają się udać.

W wyniku wykonania tego polecenia Git realizuje automatycznie cztery czynności:
1. Tworzy nowy katalog na Twoim dysku o nazwie odpowiadającej nazwie projektu.
2. Inicjalizuje wewnątrz niego nowe repozytorium Git (tworzy katalog `.git`).
3. Pobiera kompletną historię wszystkich commitów i gałęzi z serwera.
4. Automatycznie konfiguruje połączenie zdalne pod nazwą `origin` oraz przełącza katalog roboczy na domyślną gałąź główną (`main`).

- **Po co to jest:** Klonowanie pozwala w kilkanaście sekund uzyskać w 100% działającą, kompletną kopię projektu wraz z pełną historią zmian i skonfigurowanym połączeniem zdalnym.
- **Typowa pomyłka:** Wykonywanie polecenia `git init` w pustym katalogu, a następnie próba wykonania `git clone` w tym samym miejscu. Klonowanie należy uruchamiać w katalogu nadrzędnym (np. w folderze projektów), ponieważ Git sam stworzy podfolder dla pobieranego kodu.

---

## 3. Łączenie istniejącego repozytorium lokalnego z serwerem zdalnym (`git remote`)

Często zdarza się odwrotna sytuacja: stworzyłeś stronę internetową lokalnie na swoim komputerze, zainicjalizowałeś repozytorium poleceniem `git init`, wykonałeś pierwsze commity i teraz chcesz opublikować ten projekt na nowo utworzonym, pustym repozytorium na GitHubie.

Do powiązania repozytorium lokalnego ze zdalnym służy rodzina poleceń `git remote`:

```bash
# Dodanie nowego serwera zdalnego o nazwie origin
git remote add origin https://github.com/twoj-login/twoj-projekt.git

# Weryfikacja zarejestrowanych adresów (flaga -v oznacza verbose - szczegółowo)
git remote -v
```

Wynik polecenia `git remote -v` wyświetla dwa wpisy: jeden dla operacji pobierania (`fetch`), a drugi dla operacji wysyłania (`push`):

```text
origin  https://github.com/twoj-login/twoj-projekt.git (fetch)
origin  https://github.com/twoj-login/twoj-projekt.git (push)
```

Gdybyś popełnił literówkę w adresie URL, możesz go zaktualizować poleceniem:

```bash
git remote set-url origin https://github.com/twoj-login/poprawny-projekt.git
```

- **Po co to jest:** Polecenie `git remote add` ustanawia most komunikacyjny pomiędzy Twoim komputerem a chmurą GitHuba, informując lokalnego Gita, dokąd mają trafiać Twoje rewizje.
- **Typowa pomyłka:** Próba ponownego wykonania `git remote add origin ...`, gdy połączenie o tej nazwie już istnieje. Git zgłosi wtedy błąd `fatal: remote origin already exists`. W takiej sytuacji należy użyć polecenia `git remote set-url origin ...` lub najpierw usunąć błędny wpis poleceniem `git remote remove origin`.

---

## 4. Publikacja zmian w chmurze: `git push` oraz flaga `-u`

Po zatwierdzeniu zmian w repozytorium lokalnym poleceniem `git commit`, nowe rewizje znajdują się wciąż wyłącznie na Twoim komputerze. Aby przesłać je na serwer GitHub, używamy polecenia `git push`.

Podczas pierwszego wysyłania nowej gałęzi na serwer należy poinstruować Gita, aby powiązał gałąź lokalną z jej zdalnym odpowiednikiem. Służy do tego flaga `-u` (skrót od `--set-upstream`):

```bash
git push -u origin main
```

Co dokładnie robi flaga `-u`? Zapamiętuje ona relację śledzenia (ang. *tracking branch*). Dzięki temu przy kolejnych wysyłkach z tej gałęzi nie musisz już powtarzać nazwy serwera ani gałęzi — wystarczy wpisać zwięzłe:

```bash
git push
```

Git odczyta z konfiguracji, że bieżąca gałąź `main` ma przesyłać commity bezpośrednio do `origin/main`.

- **Po co to jest:** Flaga `-u` konfiguruje stałe powiązanie między gałęzią lokalną a zdalną, eliminując konieczność ciągłego wpisywania parametrów połączenia i automatyzując pracę w terminalu.
- **Typowa pomyłka:** Zapomnienie o wykonaniu lokalnego commitu przed wysłaniem kodu. Polecenie `git push` wysyła wyłącznie zatwierdzone rewizje z bazy Gita — nie wysyła plików niezapisanych w commitach (niezindeksowanych zmian ze strefy roboczej).

---

## 5. Pobieranie aktualizacji z serwera: `git fetch` a `git pull`

Kiedy nad projektem pracuje kilka osób (lub gdy pracujesz sam na dwóch różnych komputerach — np. w szkole i w domu), na serwerze GitHub pojawią się commity, których nie ma jeszcze na Twoim dysku. Aby zachować spójność, musisz zsynchronizować repozytorium lokalne.

Do dyspozycji masz dwa polecenia:

### A. Bezpieczna inspekcja: `git fetch`
Polecenie `git fetch` łączy się z serwerem i pobiera wszystkie nowe obiekty oraz informacje o gałęziach zdalnych, **nie modyfikując przy tym żadnych Twoich plików lokalnych**. Aktualizuje jedynie lokalne wskaźniki gałęzi zdalnych (np. `origin/main`). Pozwala to sprawdzić, co zmienili inni, zanim zdecydujesz się na wdrożenie ich pracy do swojego kodu:

```bash
git fetch origin
```

### B. Pełna synchronizacja: `git pull`
Polecenie `git pull` idzie o krok dalej. Jest ono w rzeczywistości sekwencją dwóch operacji: najpierw wykonuje `git fetch`, a natychmiast potem scala pobrane commity z Twoją bieżącą gałęzią lokalną (`git merge`):

```bash
git pull origin main
# lub po wcześniejszym ustawieniu upstream (-u):
git pull
```

Jeśli na Twojej gałęzi lokalnej nie było nowych, rozbieżnych commitów, Git wykona tzw. scalenie szybkie (*fast-forward*), przesuwając wskaźnik gałęzi do najnowszej rewizji z serwera.

- **Po co to jest:** Regularne wykonywanie `git pull` na początku każdego dnia pracy gwarantuje, że budujesz nowe funkcjonalności na najbardziej aktualnym stanie projektu, co zapobiega powstawaniu trudnych konfliktów scalania.
- **Typowa pomyłka:** Rozpoczynanie pracy nad nowym zadaniem bez uprzedniego wykonania `git pull`. Jeśli kolega z zespołu zmienił pliki, a Ty zaczniesz modyfikować ten sam fragment kodu na przestarzałej wersji, Git odrzuci późniejsze wysłanie zmian i wymusi ręczne rozwiązywanie konfliktu.

---

## 6. Gałęzie zdalne (`origin/main`, `origin/feature`) i ich podgląd

W systemie Git gałęzie dzielą się na lokalne oraz zdalne. Gałąź lokalna to wskaźnik, który możesz swobodnie przestawiać, tworząc nowe commity. Z kolei gałęzie zdalne (nazywane w żargonie *remote-tracking branches*) odzwierciedlają stan gałęzi na serwerze w momencie ostatniego kontaktu (`fetch` lub `push`).

W terminalu gałęzie zdalne poprzedzone są nazwą serwera, np. `origin/main` czy `origin/naglowek-witryny`. Nie można się na nie bezpośrednio przełączyć w celu pisania kodu — służą one Gitowi jako punkt odniesienia do porównań.

Do przeglądania gałęzi służą opcje polecenia `git branch`:

```bash
# Wyświetlenie wyłącznie gałęzi lokalnych
git branch

# Wyświetlenie wyłącznie gałęzi zdalnych pobranych z serwera
git branch -r

# Wyświetlenie wszystkich gałęzi (lokalnych i zdalnych)
git branch -a
```

Gdy chcesz pracować nad gałęzią, którą ktoś inny utworzył na GitHubie i opublikował, wystarczy wykonać:

```bash
git checkout nazwa-nowej-galezi
# lub nowocześnie:
git switch nazwa-nowej-galezi
```

Git automatycznie wykryje gałąź `origin/nazwa-nowej-galezi`, utworzy dla Ciebie lokalną gałąź o tej samej nazwie i ustawi dla niej powiązanie upstream.

- **Po co to jest:** Rozróżnienie gałęzi lokalnych i zdalnych umożliwia programiście pracę w trybie offline i eksperymentowanie bez natychmiastowego wpływania na kod współdzielony przez zespół.
- **Typowa pomyłka:** Próba przełączenia się na gałąź wpisując `git checkout origin/main`. Spowoduje to wejście w tzw. stan *detached HEAD* (odłączonej głowy), w którym nowe commity nie należą do żadnej gałęzi i mogą zostać utracone. Prawidłowo należy przełączać się na gałąź lokalną: `git checkout main`.

---

## 7. Praca zespołowa i procedura Pull Request (PR)

W profesjonalnych zespołach programistycznych nikt nie wysyła zmian bezpośrednio do gałęzi głównej (`main`). Bezpośredni push do `main` niesie ryzyko wprowadzenia błędu, który zepsuje całą aplikację na produkcji.

Prawidłowy, codzienny obieg pracy (ang. *GitHub Flow*) wygląda następująco:
1. Pobierasz najnowszy stan gałęzi głównej: `git checkout main && git pull`.
2. Tworzysz nową gałąź tematyczną dla swojego zadania: `git switch -c feature-formularz-kontaktowy`.
3. Wprowadzasz zmiany w plikach i tworzysz logiczne commity: `git commit -m "Dodanie walidacji pól formularza"`.
4. Publikujesz gałąź na GitHubie: `git push -u origin feature-formularz-kontaktowy`.
5. W interfejsie GitHub.com otwierasz **Pull Request (PR)**.
6. Inny członek zespołu przegląda Twój kod (ang. *Code Review*), dodaje ewentualne uwagi lub zatwierdza propozycję.
7. Po zatwierdzeniu Pull Request zostaje scalony (*merged*) do gałęzi `main` bezpośrednio na serwerze GitHub.

Pull Request nie jest poleceniem Gita, lecz funkcjonalnością platformy GitHub. Jest to formalna prośba o włączenie zmian z Twojej gałęzi do gałęzi głównej projektu, połączona z panelem dyskusyjnym i widokiem różnic w kodzie (ang. *diff*).

- **Po co to jest:** Mechanizm Pull Request wprowadza kontrolę jakości kodu, umożliwia wzajemną naukę w zespole oraz chroni stabilność głównej gałęzi przed niedetestowanymi zmianami.
- **Typowa pomyłka:** Otwieranie Pull Requesta z gałęzi `main` do gałęzi `main`. PR musi zawsze łączyć dwie różne gałęzie — gałąź źródłową (np. `feature-nowy-baner`) z gałęzią docelową (zazwyczaj `main`).

---

## 8. Rozwiązywanie konfliktów przy synchronizacji

Wyobraźmy sobie częstą sytuację: programista Janek i programistka Anna pobrali rano ten sam stan projektu. Oboje zmodyfikowali plik `index.html` w tej samej linijce. Janek pierwszy wykonał `git push` i jego zmiana trafiła na serwer. Gdy Anna spróbuje wykonać `git push`, GitHub odrzuci jej operację komunikatem:

```text
! [rejected]        main -> main (fetch first)
error: failed to push some refs to 'https://github.com/...'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
```

Oznacza to, że historia na serwerze poszła naprzód. Anna musi najpierw pobrać zmiany poleceniem `git pull`. Jeśli zmiany dotyczą tych samych linii, Git zatrzyma scalanie i zgłosi **konflikt** (*CONFLICT (content): Merge conflict in index.html*).

W pliku pojawią się wówczas znaczniki konfliktu:

```html
<<<<<<< HEAD
<h1>Portal Informacyjny - Witamy w Krakowie</h1>
=======
<h1>Portal Informacyjny Miasta Kraków</h1>
>>>>>>> abc1234...
```

Część pomiędzy `<<<<<<< HEAD` a `=======` to wersja lokalna (Anny), a część pomiędzy `=======` a `>>>>>>>` to wersja pobrana z serwera (Janka). Aby rozwiązać konflikt, należy:
1. Otworzyć plik w edytorze kodu.
2. Zdecydować wspólnie, która wersja jest poprawna (lub połączyć obie w zgrabny sposób).
3. Skasować wszystkie znaczniki konfliktu (`<<<<<<<`, `=======`, `>>>>>>>`).
4. Zapisać plik, dodać go do poczekalni: `git add index.html`.
5. Dokończyć scalenie commitem: `git commit -m "Rozwiazanie konfliktu w naglowku portalu"`.
6. Wypchnąć rozwiązany stan na serwer: `git push`.

- **Po co to jest:** Znaczniki konfliktu zapobiegają cichemu nadpisaniu pracy jednego programisty przez drugiego; zmuszają zespół do świadomego wyboru właściwego kodu.
- **Typowa pomyłka:** Próba użycia wymuszenia `git push --force`. Opcja `--force` brutalnie nadpisuje historię na serwerze kodem z Twojego komputera, bezpowrotnie niszcząc commity wysłane wcześniej przez innych członków zespołu. W pracy zespołowej stosowanie `--force` na gałęzi `main` jest bezwzględnie zakazane.

---

## 9. Wizytówka projektu i zarządzanie zadaniami: `README.md` oraz Issues

Profesjonalne repozytorium na GitHubie nie składa się z samego kodu źródłowego. Każdy wartościowy projekt zawiera dwa kluczowe elementy organizacyjne:

### A. Plik `README.md`
Plik ten, umieszczony w katalogu głównym projektu i sformatowany w języku Markdown, jest automatycznie renderowany przez GitHub jako strona główna repozytorium. Powinien on zawierać:
- Tytuł projektu i krótki opis, jaki problem rozwiązuje aplikacja.
- Wymagania wstępne i instrukcję uruchomienia (np. otwarcie pliku `index.html` w przeglądarce).
- Opis struktury katalogów i technologii użytych w projekcie.
- Informacje o autorach oraz licencji.

### B. Karta zgłoszeń: GitHub Issues
Zakładka **Issues** na GitHubie to wbudowany system śledzenia błędów i zadań (*issue tracker*). Zamiast wysyłać maile czy wiadomości na komunikatorach, programiści tworzą zgłoszenia opisujące:
- Zgłoszenie błędu (*Bug report*): dokładny opis nieprawidłowego zachowania strony wraz z krokami do jego odtworzenia.
- Propozycję nowej funkcjonalności (*Feature request*): opis elementu, który należy dopisać (np. „Dodać sekcję cennika w stopce”).

Zgłoszenia w Issues posiadają numery (np. `#1`, `#2`), do których można odwoływać się bezpośrednio w treści commitów (np. `git commit -m "Naprawa bledu szerokosci banera, zamyka #3"`), co ułatwia zarządzanie postępem prac w zespole.

- **Po co to jest:** Plik `README.md` oraz zgłoszenia Issues tworzą kulturę przejrzystości projektu — każdy nowy członek zespołu może natychmiast dowiedzieć się, jak uruchomić aplikację i jakie zadania są aktualnie do wykonania.
- **Typowa pomyłka:** Pozostawianie repozytorium bez pliku `README.md` lub z pustym plikiem zawierającym wyłącznie jeden nagłówek. Repozytorium bez opisu jest traktowane jako niekompletne i nieprofesjonalne.
