# Moduł T13 — Repetytorium Fundamentów JS: Warunki, Pętle, Typy

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

**Zakres powtórki programowej:**  
`PAI · Semestr 1 · T13 · ↻ Powtórka JS: warunki, pętle, typy (04–07)`

Niniejszy materiał stanowi zwartą, całościową syntezę wiedzy inżynierskiej wymaganej na egzaminie zawodowym INF.03 w obszarze podstaw języka JavaScript. Łączy pojęcia izolowane w poprzednich modułach w spójny warsztat programistyczny.

---

## 1. Zmienne, stałe i typy danych

Język JavaScript jest językiem o dynamicznym typowaniu, co oznacza, że typ wartości jest powiązany z samą wartością, a nie z nazwą zmiennej. W nowoczesnym standardzie języka (ES6+) do deklaracji używa się wyłącznie słów kluczowych `let` oraz `const`. Słowo kluczowe `var` jest historyczne i zakazane w standardach współczesnego kodu ze względu na brak zasięgu blokowego i niebezpieczny mechanizm hoistingu.

```javascript
// Deklaracja zmiennej o zmiennej wartości
let stawkaGodzinowa = 45.50;
stawkaGodzinowa = 48.00; // Dozwolona reasocjacja

// Deklaracja stałej o niezmiennym przypisaniu
const PODATEK_VAT = 0.23;
// PODATEK_VAT = 0.25; // Błąd: TypeError: Assignment to constant variable
```

**Po co to jest:**  
`const` chroni przed przypadkowym nadpisaniem wartości bazowych i konfiguracji biznesowej w trakcie działania programu. `let` stosuje się wyłącznie wtedy, gdy wartość zmiennej musi ulegać zmianie w czasie (np. licznik pętli, akumulator sumy).

**Typowa pomyłka:**  
Deklarowanie zmiennej akumulującej (np. sumy punktów) za pomocą `const suma = 0;`, a następnie próba modyfikacji `suma += punkty;`, co natychmiast przerywa wykonywanie skryptu błędem wykonania.

### 1.1. Typy proste (prymitywne) i operator `typeof`

W języku JavaScript wyróżniamy pięć fundamentalnych typów prostych:
- `number` — liczby całkowite i zmiennoprzecinkowe (np. `42`, `-15`, `3.14`).
- `string` — ciągi znaków otoczone apostrofami (`'...'`), cudzysłowami (`"..."`) lub grawisami (\`...\`).
- `boolean` — wartości logiczne `true` oraz `false`.
- `undefined` — domyślna wartość zmiennej zadeklarowanej, lecz niezainicjalizowanej.
- `null` — celowe oznaczenie braku wartości.

Operator `typeof` pozwala sprawdzić typ bieżący:

```javascript
let wiek = 18;
let nazwisko = "Kowalski";
let czyZalogowany = true;
let brakDanych;

console.log(typeof wiek);          // "number"
console.log(typeof nazwisko);      // "string"
console.log(typeof czyZalogowany);  // "boolean"
console.log(typeof brakDanych);    // "undefined"
```

**Po co to jest:**  
Operator `typeof` umożliwia weryfikację poprawności danych wejściowych pochodzących od użytkownika lub zewnętrznego źródła przed przystąpieniem do operacji matematycznych.

**Typowa pomyłka:**  
Zakładanie, że `typeof null` zwróci `"null"`. Ze względów zaszłości historycznych w silnikach JS wyrażenie `typeof null` zwraca `"object"`, co jest powszechną pułapką w pytaniach testowych.

---

## 2. Konwersje typów i koercja (jawna vs niejawna)

Wszelkie dane pobierane od użytkownika w przeglądarce (np. za pośrednictwem funkcji `prompt()`) są zwracane jako ciągi znaków (`string`). Zastosowanie operatora `+` na tekście i liczbie skutkuje konkatenacją, a nie dodawaniem arytmetycznym.

```javascript
let a = "10";
let b = 5;

let wynikNiejawny = a + b; // "105" (konkatenacja napisów)
let wynikOdejmowania = a - b; // 5 (niejawna konwersja do liczby)
```

Aby zagwarantować poprawność obliczeń, należy stosować **jawną konwersję typów**:
- `Number(wartosc)` — zamienia ciąg na liczbę; jeśli ciąg zawiera nieprawidłowe znaki, zwraca `NaN`.
- `parseInt(tekst, 10)` — parsuje ciąg od początku do pierwszej nie-cyfry, zwracając liczbę całkowitą (zawsze z podaniem podstawy 10).
- `parseFloat(tekst)` — parsuje liczbę zmiennoprzecinkową.
- `String(wartosc)` — jawna konwersja na ciąg znaków.
- `Boolean(wartosc)` — konwersja na wartość logiczną.

```javascript
let wejscie = "120 sztuk";
let liczbaA = Number(wejscie);     // NaN (ponieważ zawiera tekst)
let liczbaB = parseInt(wejscie, 10); // 120 (odczytuje początkowe cyfry)

console.log(Number.isNaN(liczbaA)); // true
```

**Po co to jest:**  
Jawna konwersja chroni aplikacje przed cichymi błędami logicznymi, w których zsumowanie cen towarów zamiast `150 + 50 = 200` daje `15050`.

**Typowa pomyłka:**  
Sprawdzanie wartości `NaN` za pomocą porównania `liczba === NaN`. Wartość `NaN` w specyfikacji IEEE 754 nie jest równa samej sobie (`NaN === NaN` daje `false`). Poprawne sprawdzenie wymaga użycia `Number.isNaN(liczba)` lub globalnego `isNaN(liczba)`.

### 2.1. Zaokrąglanie wyników: `Math.floor` oraz `toFixed`

W obliczeniach inżynierskich i rozliczeniowych stosuje się dwie typowe formy prezentacji liczb:

- `Math.floor(wartosc)` — zaokrąglenie **w dół** do liczby całkowitej (np. masa w funtach, emisja po redukcji).
- `liczba.toFixed(2)` — formatowanie do **dokładnie dwóch miejsc po przecinku** jako ciąg znaków (np. kwoty w PLN). Metoda zwraca tekst (`"127.50"`), gotowy do wypisu na stronę.

```javascript
let wagaLbs = Math.floor(3025 * 2.20462); // 6668
let kosztPln = (150 * 0.85 + 18).toFixed(2); // "145.50"

document.write("<p>Waga: " + wagaLbs + " lbs</p>");
document.write("<p>Należność: " + kosztPln + " PLN</p>");
```

**Po co to jest:**  
`Math.floor` gwarantuje wynik całkowity bez części ułamkowej. `toFixed(2)` zapewnia jednolity zapis pieniężny (zawsze dwie cyfry po przecinku), zgodny z oczekiwaniami raportów rozliczeniowych.

**Typowa pomyłka:**  
Wypisanie surowej wartości zmiennoprzecinkowej (np. `127.5`) zamiast `"127.50"` — format raportu nie zgadza się ze specyfikacją zadania.

---

## 3. Operatory logiczne, porównania i wartości Truthy/Falsy

### 3.1. Porównanie ścisłe (`===`) a luźne (`==`)

W standardzie INF.03 obowiązuje bezwzględne stosowanie operatorów tożsamości ścisłej (`===` oraz `!==`), które porównują zarówno wartość, jak i typ operandów bez niejawnej konwersji.

```javascript
console.log(5 == "5");   // true  (luźne porównanie — niejawna koercja typu)
console.log(5 === "5");  // false (ścisłe porównanie — number !== string)
console.log(0 == false); // true  (koercja)
console.log(0 === false);// false (różne typy)
```

**Po co to jest:**  
Porównanie `===` eliminuje nieprzewidywalne zachowania skryptu wynikające ze skomplikowanych reguł niejawnego rzutowania typów w języku JavaScript.

**Typowa pomyłka:**  
Używanie pojedynczego znaku równości `=` wewnątrz instrukcji warunkowej: `if (punkty = 100)`. Powoduje to przypisanie wartości `100` do zmiennej i zawsze ewaluuje warunek do prawdy (`truthy`).

### 3.2. Wartości falsy i truthy

W kontekście logicznym każda wartość w JS traktowana jest jako prawda (`truthy`) z wyjątkiem dokładnie sześciu wartości fałszywych (`falsy`):
1. `false`
2. `0` (oraz `-0`)
3. `""` (pusty ciąg znaków)
4. `null`
5. `undefined`
6. `NaN`

Wszystkie pozostałe wartości (w tym ciągi ze spacją `" "`, tekst `"0"` czy liczba `-1`) są wartościami `truthy`.

### 3.3. Operatory logiczne i ewaluacja zwarciowa (short-circuit)

- Koniunkcja `&&` (AND): zwraca prawdę tylko wtedy, gdy oba warunki są prawdziwe. Jeśli lewy operand jest `falsy`, prawy operand w ogóle nie jest obliczany.
- Alternatywa `||` (OR): zwraca prawdę, jeśli co najmniej jeden warunek jest prawdziwy. Jeśli lewy operand jest `truthy`, prawy operand nie jest obliczany.
- Negacja `!` (NOT): odwraca wartość logiczną (`!true === false`, `!0 === true`).

```javascript
let wiekUcznia = 17;
let maZgodeRodzica = true;

if (wiekUcznia >= 18 || (wiekUcznia >= 16 && maZgodeRodzica)) {
  document.write("Kwalifikacja do udziału zatwierdzona.<br>");
}
```

**Po co to jest:**  
Ewaluacja zwarciowa pozwala zabezpieczać operacje zależne, np. sprawdzić, czy wartość została podana, zanim przystąpimy do jej przetwarzania.

**Typowa pomyłka:**  
Zapisywanie warunku przedziałowego w stylu matematycznym: `if (10 <= x <= 20)`. W JS wyrażenie to jest ewaluowane od lewej: `(10 <= x)` daje `true` lub `false`, a następnie `true <= 20` rzutuje `true` na `1`, co zawsze daje prawdę. Poprawny zapis wymaga koniunkcji: `if (x >= 10 && x <= 20)`.

---

## 4. Instrukcje warunkowe: `if...else` oraz `switch`

### 4.1. Drabina `if`, `else if`, `else`

Służy do podejmowania decyzji wielowariantowych na podstawie warunków logicznych.

```javascript
let ocenaProcentowa = 78;
let ocenaSlowna = "";

if (ocenaProcentowa >= 90) {
  ocenaSlowna = "bardzo dobry";
} else if (ocenaProcentowa >= 75) {
  ocenaSlowna = "dobry";
} else if (ocenaProcentowa >= 50) {
  ocenaSlowna = "dostateczny";
} else {
  ocenaSlowna = "niedostateczny";
}

document.write("Ocena: " + ocenaSlowna + "<br>");
```

**Po co to jest:**  
Drabina warunkowa sprawdza warunki sekwencyjnie. Po napotkaniu pierwszego spełnionego warunku, przypisany blok kodu jest wykonywany, a reszta drabiny zostaje pominięta.

**Typowa pomyłka:**  
Zastosowanie ciągu niezależnych instrukcji `if` zamiast `else if`. Wówczas każda instrukcja wykona się niezależnie, co może doprowadzić do błędnego nadpisania wyniku końcowego.

### 4.2. Operator warunkowy trójargumentowy (`?:`)

Kompaktowa forma prostego warunku dwustronnego: `warunek ? wartoscGdyPrawda : wartoscGdyFalsz`.

```javascript
let stanMagazynu = 12;
let statusDostepnosci = stanMagazynu > 0 ? "Dostępny od ręki" : "Brak towaru";
```

### 4.3. Instrukcja wyboru `switch`

Instrukcja `switch` służy do porównywania jednej wartości z listą stałych wariantów (`case`) przy użyciu ścisłego porównania (`===`).

```javascript
let kodStrefy = "B";
let kosztDostawy = 0;

switch (kodStrefy) {
  case "A":
    kosztDostawy = 15;
    break;
  case "B":
  case "C": // Świadomy fall-through: strefy B i C mają identyczną stawkę
    kosztDostawy = 25;
    break;
  case "D":
    kosztDostawy = 40;
    break;
  default:
    kosztDostawy = 50;
    break;
}
```

**Po co to jest:**  
`switch` zwiększa czytelność kodu w przypadku testowania jednej zmiennej pod kątem wielu dyskretnych wartości (np. kody taryf, kody statusu, dni tygodnia).

**Typowa pomyłka:**  
Pominięcie instrukcji `break` na końcu bloku `case`. Powoduje to automatyczne „przelanie się” wykonania kodu do kolejnego bloku `case` (niezamierzony fall-through), niezależnie od tego, czy warunek został spełniony.

---

## 5. Pętle iteracyjne: `for`, `while`, `do...while`

Pętle umożliwiają wielokrotne powtarzanie bloku instrukcji tak długo, jak długo spełniony jest zdefiniowany warunek logiczny.

### 5.1. Pętla licznikowa `for`

Składa się z trzech sekcji oddzielonych średnikami: inicjalizacji zmiennej sterującej, warunku kontynuacji oraz kroku iteracji.

```javascript
// Obliczanie sumy liczb parzystych od 2 do 20
let sumaParzystych = 0;

for (let i = 2; i <= 20; i += 2) {
  sumaParzystych += i;
}

document.write("Suma liczb parzystych: " + sumaParzystych + "<br>");
```

Iteracja w dół (odliczanie):
```javascript
for (let i = 10; i >= 1; i--) {
  console.log("Odliczanie: " + i);
}
```

Pętle zagnieżdżone (np. siatka współrzędnych lub tabliczka):
```javascript
for (let wiersz = 1; wiersz <= 3; wiersz++) {
  for (let kolumna = 1; kolumna <= 3; kolumna++) {
    document.write("[" + wiersz + "," + kolumna + "] ");
  }
  document.write("<br>");
}
```

**Po co to jest:**  
Pętla `for` jest optymalnym wyborem, gdy z góry znamy liczbę powtórzeń lub zakres iteracji.

**Typowa pomyłka:**  
Błąd przesunięcia o jeden (off-by-one): użycie warunku `i < 10` zamiast `i <= 10`, co skutkuje wykonaniem o jeden krok za mało lub za dużo.

### 5.2. Pętle warunkowe `while` oraz `do...while`

- `while`: warunek sprawdzany jest **przed** wykonaniem ciała pętli. Jeśli warunek jest od początku fałszywy, pętla nie wykona się ani razu.
- `do...while`: warunek sprawdzany jest **po** wykonaniu ciała pętli. Gwarantuje wykonanie instrukcji co najmniej jeden raz.

```javascript
// Pętla while: podwajanie kapitału
let kapital = 1000;
let lata = 0;

while (kapital < 2000) {
  kapital *= 1.07; // stopa zwrotu 7%
  lata++;
}
document.write("Czas podwojenia kapitału: " + lata + " lat.<br>");

// Pętla do...while: walidacja prosta
let proba = 0;
do {
  proba++;
  console.log("Próba synchronizacji: " + proba);
} while (proba < 3);
```

### 5.3. Sterowanie pętlami: `break` oraz `continue`

- `break` — bezwarunkowo przerywa wykonywanie całej pętli i przekazuje sterowanie do pierwszej instrukcji za pętlą.
- `continue` — natychmiast kończy bieżącą iterację i przechodzi do obliczenia kroku oraz kolejnego sprawdzenia warunku.

```javascript
for (let i = 1; i <= 10; i++) {
  if (i === 5) {
    continue; // Pomija wypisanie liczby 5
  }
  if (i === 8) {
    break; // Kończy całą pętlę przy liczbie 8
  }
  console.log("Wartość: " + i);
}
```

**Po co to jest:**  
`break` optymalizuje procedury wyszukiwania (np. przerwanie pętli natychmiast po znalezieniu dzielnika), a `continue` pozwala pominąć przetwarzanie niepoprawnych rekordów.

**Typowa pomyłka:**  
Zapomnienie o modyfikacji zmiennej sterującej w pętli `while` przed wywołaniem `continue`:
```javascript
// BŁĄD NIESKOŃCZONEJ PĘTLI:
let i = 0;
while (i < 10) {
  if (i === 5) continue; // Zmienna i nigdy nie osiągnie 6!
  i++;
}
```

Poprawny wzorzec: **najpierw zwiększ licznik cyklu, potem ewentualnie `continue`**:
```javascript
let stan = 500;
const PORCJA = 70;
const REZERWA = 100;
let cykl = 0;

while (stan - PORCJA >= REZERWA) {
  cykl++;
  if (cykl === 3) {
    document.write("Cykl diagnostyczny — pominięto pobór.<br>");
    continue; // stan bez zmian; licznik już zwiększony
  }
  stan -= PORCJA;
  document.write("Cykl " + cykl + ": pozostało " + stan + "<br>");
}
```

Warunek `stan - PORCJA >= REZERWA` oznacza: pętla trwa tylko wtedy, gdy **po** odjęciu kolejnej porcji poziom nadal nie spadnie poniżej rezerwy.

---

## 6. Klasyczne algorytmy iteracyjne

### 6.1. Największy Wspólny Dzielnik (NWD) — Algorytm Euklidesa

Algorytm wyznacza największą liczbę całkowitą dzielącą bez reszty dwie liczby naturalne `a` i `b`.

Wariant z odejmowaniem:
```javascript
let a = 56;
let b = 24;

while (a !== b) {
  if (a > b) {
    a -= b;
  } else {
    b -= a;
  }
}
let nwdOdejmowanie = a;
```

Wariant z resztą z dzielenia (modulo — znacznie szybszy):
```javascript
let x = 56;
let y = 24;

while (y !== 0) {
  let temp = y;
  y = x % y;
  x = temp;
}
let nwdModulo = x;
```

**Po co to jest:**  
NWD jest fundamentalnym algorytmem algebry komputerowej stosowanym m.in. przy upraszczaniu ułamków, skalowaniu siatek graficznych oraz w kryptografii.

**Typowa pomyłka:**  
Warunek zakończenia: w wersji z odejmowaniem pętla trwa dopóki `a !== b`. W wersji modulo pętla trwa dopóki `b !== 0`, a wynikiem jest `a`.

**Najmniejsza wspólna wielokrotność (NWW):**  
Gdy znane jest NWD dwóch liczb dodatnich `a` i `b`, najmniejszą wspólną wielokrotność oblicza się ze wzoru:

```javascript
let nww = (a * b) / nwd;
```

### 6.2. Test pierwszości liczby

Liczba pierwsza to liczba naturalna większa od 1, która dzieli się bez reszty wyłącznie przez 1 i samą siebie.

```javascript
let sprawdzanaLiczba = 29;
let czyPierwsza = true;

if (sprawdzanaLiczba < 2) {
  czyPierwsza = false;
} else {
  for (let d = 2; d * d <= sprawdzanaLiczba; d++) {
    if (sprawdzanaLiczba % d === 0) {
      czyPierwsza = false;
      break; // Znaleziono dzielnik właściwy — przerywamy
    }
  }
}

if (czyPierwsza) {
  document.write("Liczba " + sprawdzanaLiczba + " jest liczbą pierwszą.<br>");
} else {
  document.write("Liczba " + sprawdzanaLiczba + " jest liczbą złożoną.<br>");
}
```

**Po co to jest:**  
Konieczność przerwania pętli (`break`) po znalezieniu pierwszego dzielnika drastycznie redukuje liczbę operacji procesora przy dużych liczbach złożonych.

**Typowa pomyłka:**  
Pomijanie warunku brzegowego dla liczb `0` i `1`. Liczby `0` i `1` nie są liczbami pierwszymi, ani liczbami złożonymi.

### 6.3. Ciąg Fibonacciego

Ciąg, w którym dwa pierwsze wyrazy to `0` i `1`, a każdy kolejny wyraz jest sumą dwóch poprzednich: $F_n = F_{n-1} + F_{n-2}$.

```javascript
let nWyrazow = 8;
let f0 = 0;
let f1 = 1;

document.write("Ciąg Fibonacciego (" + nWyrazow + " wyrazów): ");

if (nWyrazow >= 1) {
  document.write(f0 + " ");
}
if (nWyrazow >= 2) {
  document.write(f1 + " ");
}

for (let k = 3; k <= nWyrazow; k++) {
  let fNastepny = f0 + f1;
  document.write(fNastepny + " ");
  f0 = f1;
  f1 = fNastepny;
}
document.write("<br>");
```

### 6.4. Analiza i rozkład cyfr liczby całkowitej

Wyciąganie poszczególnych cyfr liczby odbywa się za pomocą operacji reszty z dzielenia przez 10 (`liczba % 10`) oraz dzielenia całkowitego (`Math.floor(liczba / 10)`).

```javascript
let liczba = 4825;
let sumaCyfr = 0;
let kopiaLiczby = liczba;

while (kopiaLiczby > 0) {
  let ostatniaCyfra = kopiaLiczby % 10;
  sumaCyfr += ostatniaCyfra;
  kopiaLiczby = Math.floor(kopiaLiczby / 10);
}

document.write("Liczba: " + liczba + ", suma jej cyfr: " + sumaCyfr + "<br>");
```

---

## 7. Wypis danych i interakcja z użytkownikiem w Semestrze 1

### 7.1. Wypis wyników na stronę: `document.write`

Zgodnie z rygorem metodycznym Semestru 1, wszelki sformatowany wynik na stronie WWW wyprowadzany jest bezpośrednio za pomocą instrukcji `document.write()`. W plikach HTML przygotowany jest dedykowany kontener:

```html
<div class="wynik">
  <script src="script.js"></script>
</div>
```

Wewnątrz skryptu `script.js` wyprowadzamy tekst i znaczniki HTML formatujące treść:

```javascript
document.write("<p>Status zamówienia: <strong>Zrealizowano</strong></p>");
document.write("<p>Całkowity koszt: " + sumaKosztow + " PLN</p>");
console.log("Pomyślnie wygenerowano raport zamówienia.");
```

**Dlaczego tak:**  
W Semestrze 1 uczeń koncentruje się na logice algorytmicznej, zmiennych i pętlach. Wypis przez `document.write` nie wymaga znajomości struktury drzewa DOM, selektorów CSS ani mechanizmów asynchronicznych, co eliminuje przeciążenie poznawcze przed wejściem w Semestr 2 i 3.

### 7.2. Interaktywne pobieranie danych: `prompt()` z wartością domyślną

Funkcja `prompt(komunikat, wartoscDomyslna)` wyświetla systemowe okno dialogowe z polem edycyjnym. 

> **Ważne:** Wywołanie funkcji `prompt()` jest operacją synchroniczną i blokującą. Do momentu kliknięcia przycisku „OK” lub „Anuluj” przez użytkownika, silnik przeglądarki całkowicie wstrzymuje wykonywanie kodu JavaScript oraz dalsze renderowanie strony.

Zgodnie ze standardem egzaminacyjnym INF.03, każde wywołanie `prompt()` **musi bezwzględnie posiadać drugi argument — wartość domyślną**:

```javascript
let wejscie = prompt("Podaj liczbę przepracowanych godzin:", "40");
let godziny = parseInt(wejscie, 10);

if (Number.isNaN(godziny) || godziny < 0) {
  document.write("<p>Błąd: Wprowadzono niepoprawną liczbę godzin.</p>");
} else {
  let wyplata = godziny * 45;
  document.write("<p>Wynagrodzenie brutto: " + wyplata + " PLN</p>");
}
```

**Po co to jest:**  
Obowiązkowa wartość domyślna w `prompt()` gwarantuje, że egzaminator lub skrypt automatyczny po zatwierdzeniu okna dialogowego natychmiast otrzyma poprawne dane testowe bez konieczności każdorazowego ręcznego wpisywania wartości.
