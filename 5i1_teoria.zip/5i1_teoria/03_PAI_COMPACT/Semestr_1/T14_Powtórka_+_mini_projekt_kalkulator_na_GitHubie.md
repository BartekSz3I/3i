# Teoria: Powtórka semestralna i mini-projekt kalkulatora na GitHubie

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

**Zakres powtórki (↻):** `PAI · Semestr 1 · T14 · ↻ Powtórka + mini-projekt (kalkulator) na GitHubie (01–13)`

---

## 1. Wypis na stronę i wejście danych w Semestrze 1

W pierwszym semestrze nauki programowania aplikacji internetowych skupiamy się na fundamentach algorytmiki i składni języka JavaScript, bez komplikowania kodu zaawansowanym drzewem obiektowym przeglądarki (DOM). 

Wyniki działania skryptu prezentujemy za pomocą polecenia `document.write()`, umieszczając kod JavaScript wewnątrz kontenera o klasie `.wynik` (np. `<div class="wynik"><script src="script.js"></script></div>`), a także w konsoli deweloperskiej za pomocą `console.log()`. Zmianę linii tekstu na stronie realizujemy poprzez wypisanie znacznika HTML `"<br>"`.

```javascript
// Bezpieczne pobranie liczby od użytkownika z wartością domyślną
const liczbaA = Number(prompt("Podaj pierwszą liczbę do kalkulatora:", "10"));
const liczbaB = Number(prompt("Podaj drugą liczbę do kalkulatora:", "5"));

const suma = liczbaA + liczbaB;

// Wypis do kontenera na stronie oraz do konsoli deweloperskiej
document.write("Wynik dodawania: " + suma + "<br>");
console.log(`[KALKULATOR] Dodawanie: ${liczbaA} + ${liczbaB} = ${suma}`);
```

- **Po co to jest:** Polecenie `document.write()` umożliwia natychmiastowe wypisanie sformatowanego tekstu i znaczników HTML bezpośrednio do dokumentu podczas jego ładowania. Z kolei `console.log()` pozwala programiście kontrolować przebieg obliczeń i stan zmiennych w narzędziach DevTools (klawisz F12 w przeglądarce).
- **Typowa pomyłka:** Użycie `document.write()` po zakończeniu ładowania dokumentu (np. w późniejszym zdarzeniu kliknięcia) nadpisałoby całą stronę. W Semestrze 1 skrypt wykonuje się synchronicznie w trakcie wczytywania pliku HTML.

> **Ważne ostrzeżenie:** Okno dialogowe `prompt()` jest operacją blokującą (wstrzymuje dalsze wykonywanie kodu JavaScript oraz renderowanie strony do momentu zatwierdzenia lub anulowania dialogu przez użytkownika). Zawsze należy podawać drugi parametr w wywołaniu `prompt()`, który określa wartość domyślną. Zapobiega to przypadkowemu zwróceniu pustego ciągu i ułatwia testowanie kodu.

---

## 2. Zmienne, stałe, typy i konwersje

W nowoczesnym JavaScript do deklaracji zmiennych używamy słowa kluczowego `let`, a dla wartości niezmiennych — `const`. Przestarzałe słowo `var` jest bezwzględnie zakazane z uwagi na brak zasięgu blokowego i niebezpieczny mechanizm windowania deklaracji (hoisting).

```javascript
const STAWKA_VAT = 0.23;
let cenaNetto = Number(prompt("Wprowadź cenę netto towaru w zł:", "100"));

// Sprawdzenie, czy użytkownik podał poprawną liczbę
if (isNaN(cenaNetto) || cenaNetto <= 0) {
  document.write("Błąd: Wprowadzono niepoprawną cenę towaru.<br>");
} else {
  let wartoscVat = cenaNetto * STAWKA_VAT;
  let cenaBrutto = cenaNetto + wartoscVat;
  document.write(`Cena netto: ${cenaNetto} zł, Brutto: ${cenaBrutto.toFixed(2)} zł<br>`);
}
```

- **Po co to jest:** Jawna konwersja za pomocą funkcji `Number()`, `parseInt()` lub `parseFloat()` jest kluczowa, ponieważ funkcja `prompt()` zawsze zwraca typ tekstowy (`string`). Bez konwersji operator `+` wykona konkatenację (połączenie napisów) zamiast dodawania arytmetycznego.
- **Typowa pomyłka:** Próba dodania dwóch liczb pobranych z `prompt()` bez konwersji: `"10" + "5"` da w wyniku `"105"`, a nie `15`. Wartość specjalna `NaN` (Not a Number) powstaje w wyniku nieudanej konwersji tekstu na liczbę i nie jest równa samej sobie (`NaN === NaN` zwraca `false`), dlatego do jej wykrywania zawsze stosujemy funkcję `isNaN()`.

---

## 3. Podejmowanie decyzji: `if / else if / else` oraz `switch`

W kalkulatorze obliczeniowym wybór operacji matematycznej realizujemy za pomocą instrukcji warunkowej lub instrukcji wyboru.

### Instrukcja `switch`: idealna do wyboru znaku działania
```javascript
const liczba1 = Number(prompt("Wprowadź pierwszą liczbę:", "12"));
const operacja = prompt("Wybierz operację (+, -, *, /, %, potega):", "+");
const liczba2 = Number(prompt("Wprowadź drugą liczbę:", "4"));

let wynik = 0;
let czyPoprawne = true;

switch (operacja) {
  case "+":
    wynik = liczba1 + liczba2;
    break;
  case "-":
    wynik = liczba1 - liczba2;
    break;
  case "*":
    wynik = liczba1 * liczba2;
    break;
  case "/":
    if (liczba2 === 0) {
      document.write("Błąd krytyczny: Dzielenie przez zero jest zabronione!<br>");
      czyPoprawne = false;
    } else {
      wynik = liczba1 / liczba2;
    }
    break;
  case "%":
    if (liczba2 === 0) {
      document.write("Błąd krytyczny: Dzielenie modulo przez zero jest zabronione!<br>");
      czyPoprawne = false;
    } else {
      wynik = liczba1 % liczba2;
    }
    break;
  default:
    document.write(`Nieznany operator kalkulatora: "${operacja}".<br>`);
    czyPoprawne = false;
    break;
}

if (czyPoprawne) {
  document.write(`Działanie: ${liczba1} ${operacja} ${liczba2} = <strong>${wynik}</strong><br>`);
}
```

- **Po co to jest:** Instrukcja `switch` sprawdza wartość zmiennej w oparciu o porównanie ścisłe (`===`). Jest znacznie bardziej przejrzysta niż rozbudowane, wielopiętrowe konstrukcje `if ... else if`.
- **Typowa pomyłka:** Zapomnienie o słowie kluczowym `break` na końcu bloku `case`. Bez `break` sterowanie przechodzi do kolejnych gałęzi `case` (tzw. fall-through), co prowadzi do nadpisania prawidłowo obliczonego wyniku.

---

## 4. Pętle iteracyjne w operacjach kalkulatora

Pętle `for`, `while` oraz `do...while` pozwalają implementować zaawansowane operacje kalkulatora bez używania gotowych funkcji wbudowanych.

### Przykład 1: Potęgowanie w pętli `for`
```javascript
const podstawa = Number(prompt("Podaj podstawę potęgi:", "2"));
const wykladnik = Number(prompt("Podaj wykładnik potęgi (liczba całkowita >= 0):", "5"));

let potega = 1;
for (let i = 0; i < wykladnik; i++) {
  potega *= podstawa;
}
document.write(`${podstawa} do potęgi ${wykladnik} wynosi: ${potega}<br>`);
```

### Przykład 2: Algorytm Euklidesa (NWD) z pętlą `while`
```javascript
let a = Number(prompt("Podaj pierwszą liczbę całkowitą dodatnią:", "56"));
let b = Number(prompt("Podaj drugą liczbę całkowitą dodatnią:", "24"));

const kopiaA = a;
const kopiaB = b;

while (b !== 0) {
  let reszta = a % b;
  a = b;
  b = reszta;
}
document.write(`Największy Wspólny Dzielnik NWD(${kopiaA}, ${kopiaB}) wynosi: ${a}<br>`);
```

- **Po co to jest:** Pętla `for` sprawdza się, gdy z góry znamy liczbę kroków (np. wielkość wykładnika potęgi). Pętla `while` jest niezastąpiona przy procesach zbieżnościowych, w których liczba powtórzeń zależy od spełnienia określonego stanu (np. dopóki reszta z dzielenia jest różna od zera).
- **Typowa pomyłka:** Brak modyfikacji zmiennej sterującej wewnątrz ciała pętli `while`, co powoduje pętlę nieskończoną i zawieszenie karty przeglądarki.

### Przykład 3: Sumowanie kilku stałych w `for` bez tablic
W Semestrze 1 nie używamy tablic `[]`. Kilka znanych wartości sumujemy w pętli, wybierając stałą po numerze iteracji:

```javascript
const linia1 = 120;
const linia2 = 250;
const linia3 = 180;
let suma = 0;

for (let nr = 1; nr <= 3; nr++) {
  if (nr === 1) suma += linia1;
  else if (nr === 2) suma += linia2;
  else suma += linia3;
}
document.write("Suma: " + suma + "<br>");
```

---

## 5. Kontrola wersji: Git i platforma GitHub w pigułce

Mini-projekt kalkulatora wymaga udokumentowania procesu powstawania w lokalnym repozytorium Git oraz przygotowania projektu pod publikację na GitHubie.

### Podstawowy przepływ pracy w terminalu Git CLI:

```bash
# 1. Inicjalizacja nowego repozytorium w katalogu projektu
git init

# 2. Sprawdzenie stanu plików (czerwone = nieśledzone)
git status

# 3. Dodanie plików projektu do poczekalni (staging area)
git add index.html style.css script.js README.md .gitignore
# Przykładowa treść .gitignore:
# .DS_Store
# *.log
# .vscode/

# 4. Utworzenie pierwszego commita z jednoznacznym opisem
git commit -m "feat: Inicjalizacja projektu kalkulatora i struktury plików"

# 5. Utworzenie i przełączenie na gałąź nowej funkcjonalności
git switch -c feature/obliczenia-poteg
# (lub klasycznie: git checkout -b feature/obliczenia-poteg)

# 6. Po wprowadzeniu i przetestowaniu zmian w script.js:
git add script.js
git commit -m "feat: Dodanie obsługi potęgowania i pierwiastkowania w pętli"

# 7. Powrót na gałąź główną i scalenie zmian
git switch main
git merge feature/obliczenia-poteg

# 8. Przegląd zwięzłej historii zatwierdzeń
git log --oneline
```

- **Po co to jest:** Git rejestruje pełną historię zmian w projekcie, umożliwiając bezpieczne eksperymentowanie na oddzielnych gałęziach (`branch`), pracę w zespole oraz natychmiastowe wycofanie zmian w przypadku awarii.
- **Typowa pomyłka:** Próba wykonania `git commit` bez wcześniejszego przygotowania zmian poleceniem `git add`. Commit zapisuje wyłącznie pliki znajdujące się w poczekalni (staged).

### Struktura profesjonalnego pliku `README.md` projektu na GitHubie:
Plik `README.md` powinien zawierać:
1. **Nazwę projektu i krótki opis biznesowy:** czym jest aplikacja i komu służy.
2. **Wykaz zaimplementowanych operacji matematycznych:** dodawanie, odejmowanie, mnożenie, dzielenie, modulo, potęgowanie, NWD.
3. **Instrukcję uruchomienia:** otwarcie pliku `index.html` w dowolnej nowoczesnej przeglądarce.
4. **Zastosowane technologie:** HTML5, CSS3, czysty JavaScript ES6 (bez zewnętrznych bibliotek).
5. **Historię rozwoju i wykaz gałęzi (git branch log):** opis zrealizowanych zadań.
