# Teoria: Obiekt Math w języku JavaScript — zaokrąglanie, potęgi i operacje arytmetyczne

**Przedmiot:** Programowanie aplikacji internetowych (160h)  
**Semestr:** 2 (Funkcje, Obiekty Wbudowane i Tablice)  
**Kwalifikacja:** INF.03 (Część Kliencka)  

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Wprowadzenie do wbudowanego obiektu Math

W codziennej pracy programisty tworzącego aplikacje webowe standardowe operatory arytmetyczne (`+`, `-`, `*`, `/`, `%`) okazują się niewystarczające, gdy zachodzi potrzeba obliczenia pierwiastka, podniesienia liczby do potęgi, obliczenia pola koła czy zaokrąglenia kwoty transakcji do pełnych groszy. Język JavaScript udostępnia wbudowany obiekt globalny o nazwie `Math`, który grupuje gotowe stałe matematyczne oraz funkcje (zwane metodami statycznymi) ułatwiające zaawansowane obliczenia.

W przeciwieństwie do wielu innych obiektów w JavaScript, obiekt `Math` nie jest funkcją konstruktora. Oznacza to, że nigdy nie tworzymy jego nowej instancji za pomocą słowa kluczowego `new`. Wszystkie właściwości i metody są dostępne bezpośrednio z poziomu identyfikatora `Math`.

```javascript
// Prawidłowe użycie:
const promien = 5;
const poleKola = Math.PI * promien ** 2;
console.log(`Pole koła: ${poleKola}`);

// Błędne użycie (obiekt Math nie jest konstruktorem):
// const mojMath = new Math(); // Błąd: TypeError: Math is not a constructor
```

> **Po co to jest:**  
> Obiekt `Math` stanowi centralną bibliotekę narzędzi arytmetycznych wbudowaną bezpośrednio w silnik przeglądarki. Dzięki temu programista nie musi samodzielnie implementować skomplikowanych algorytmów numerycznych ani dołączać zewnętrznych bibliotek, aby realizować precyzyjne wyliczenia techniczne czy finansowe.

> **Typowa pomyłka:**  
> Próba utworzenia obiektu za pomocą zapisu `new Math()`. Prowadzi to do natychmiastowego zgłoszenia błędu wykonania `TypeError`, ponieważ `Math` jest statycznym kontenerem metod, a nie funkcją konstrukcyjną.

---

## 2. Stałe matematyczne obiektu Math

Obiekt `Math` udostępnia stałe liczbowe o bardzo wysokiej precyzji zmiennoprzecinkowej. Do najczęściej wykorzystywanych w praktyce szkolnej i egzaminacyjnej należą:

- `Math.PI` — stosunek obwodu koła do jego średnicy, w przybliżeniu `3.141592653589793`.
- `Math.E` — podstawa logarytmu naturalnego (liczba Eulera), w przybliżeniu `2.718281828459045`.

```javascript
const promienKola = 10;
const obwod = 2 * Math.PI * promienKola;
console.log(`Obwód koła o promieniu 10 wynosi: ${obwod}`);
```

> **Po co to jest:**  
> Wykorzystanie stałej `Math.PI` zamiast ręcznie wpisywanego przybliżenia `3.14` gwarantuje maksymalną precyzję obliczeń geometrycznych i eliminuje błędy zaokrągleń na wczesnym etapie kalkulacji.

> **Typowa pomyłka:**  
> Wywoływanie stałej jak funkcji: `Math.PI()`. Ponieważ `PI` jest właściwością liczbową (stałą), a nie funkcją, dodanie nawiasów okrągłych kończy się błędem `TypeError: Math.PI is not a function`.

---

## 3. Metody zaokrąglania liczb: round, floor, ceil, trunc

Jednym z najważniejszych zagadnień na egzaminie zawodowym INF.03 jest kontrolowanie ułamkowej części liczb zmiennoprzecinkowych. JavaScript oferuje cztery wyspecjalizowane metody, z których każda realizuje inny typ zaokrąglenia:

| Metoda | Działanie | Przykład (liczba dodatnia) | Przykład (liczba ujemna) |
|---|---|---|---|
| `Math.round(x)` | Zaokrągla do najbliższej liczby całkowitej (od 0.5 w górę) | `Math.round(4.5)` → `5`; `Math.round(4.4)` → `4` | `Math.round(-4.5)` → `-4`; `Math.round(-4.6)` → `-5` |
| `Math.floor(x)` | Zaokrągla zawsze w dół (w stronę minus nieskończoności) | `Math.floor(4.9)` → `4` | `Math.floor(-4.1)` → `-5` |
| `Math.ceil(x)` | Zaokrągla zawsze w górę (w stronę plus nieskończoności) | `Math.ceil(4.1)` → `5` | `Math.ceil(-4.9)` → `-4` |
| `Math.trunc(x)` | Obcina część ułamkową (usuwa cyfry po przecinku) | `Math.trunc(4.9)` → `4` | `Math.trunc(-4.9)` → `-4` |

```javascript
const wartoscDodatnia = 7.6;
const wartoscUjemna = -7.6;

console.log(Math.round(wartoscDodatnia)); // 8
console.log(Math.floor(wartoscDodatnia)); // 7
console.log(Math.ceil(wartoscDodatnia));  // 8
console.log(Math.trunc(wartoscDodatnia)); // 7

console.log(Math.round(wartoscUjemna)); // -8
console.log(Math.floor(wartoscUjemna)); // -8 (zawsze w dół na osi liczbowej!)
console.log(Math.ceil(wartoscUjemna));  // -7 (zawsze w górę na osi liczbowej!)
console.log(Math.trunc(wartoscUjemna)); // -7 (po prostu odrzuca część po przecinku)
```

### Zaokrąglanie do określonej liczby miejsc po przecinku

W aplikacjach finansowych kwoty musimy zaokrąglać do dwóch miejsc po przecinku (np. grosze). Sam obiekt `Math` zaokrągla wyłącznie do liczb całkowitych, ale możemy zastosować klasyczny wzorzec z mnożeniem i dzieleniem przez potęgę liczby 10:

```javascript
function zaokraglijDoGroszy(kwota) {
  // Mnożymy przez 100, zaokrąglamy do liczby całkowitej, po czym dzielimy przez 100
  return Math.round(kwota * 100) / 100;
}

const cenaNetto = 19.99;
const stawkaVat = 0.23;
const brutto = cenaNetto * (1 + stawkaVat); // 24.5877
const bruttoZaokraglone = zaokraglijDoGroszy(brutto); // 24.59
```

#### Obliczenia a prezentacja na stronie

Warto rozróżnić dwa cele:

1. **Obliczenia** — wzór `Math.round(wartosc * 100) / 100` zostawia wynik jako liczbę, na której można dalej liczyć.
2. **Wypis do `#wynik`** — jeśli w przykładzie widać dwa miejsca po przecinku (`2.50`, `68.00`), użyj metody `toFixed(2)`. Sama operacja `Math.round(...) / 100` nie dopisuje końcowego zera (`2.5` zamiast `2.50`).

```javascript
const kwota = Math.round(brutto * 100) / 100; // liczba: 24.59
wynikEl.textContent = `Do zapłaty: ${kwota.toFixed(2)} PLN`; // tekst: "24.59"

// Gdy nie potrzebujesz dalej liczyć na tej wartości, możesz wypisać od razu:
wynikEl.textContent = `Do zapłaty: ${brutto.toFixed(2)} PLN`;
```

Pamiętaj: `toFixed()` zwraca ciąg znaków (`string`), a nie liczbę — nie mnoż przez wynik `toFixed` w kolejnych obliczeniach bez ponownej konwersji.

> **Po co to jest:**  
> Ścisłe rozróżnienie metod zaokrąglania jest kluczowe w logistyce i handlu. Jeśli obliczamy liczbę palet potrzebnych do przewiezienia 101 skrzyń, gdy jedna paleta mieści 100 sztuk, musimy użyć `Math.ceil(101 / 100) = 2`, aby nie zostawić ładunku w magazynie. Z kolei przy obliczaniu pełnych lat stażu pracownika naturalnym wyborem jest `Math.floor()` lub `Math.trunc()`.

> **Typowa pomyłka:**  
> Mylenie `Math.floor()` z `Math.trunc()` przy liczbach ujemnych. Wywołanie `Math.floor(-3.2)` daje wynik `-4`, ponieważ na osi liczbowej wartość przesuwa się w lewo (w dół). Z kolei `Math.trunc(-3.2)` odrzuca część ułamkową i zwraca `-3`.

---

## 4. Potęgowanie i pierwiastkowanie: Math.pow, operator **, Math.sqrt

W języku JavaScript podnoszenie liczby do potęgi można zrealizować na dwa równorzędne sposoby:

1. **Metoda `Math.pow(podstawa, wykladnik)`** — klasyczna funkcja obecna od początku języka JavaScript.
2. **Operator potęgowania `**` (wprowadzony w standardzie ES2016)** — nowoczesny, zwięzły operator arytmetyczny o wysokim priorytecie wiązania.

Do obliczania pierwiastka kwadratowego służy funkcja `Math.sqrt(x)`:

```javascript
// Potęgowanie klasyczne i nowoczesne:
const podstawa = 3;
const wykladnik = 4;

const potega1 = Math.pow(podstawa, wykladnik); // 81
const potega2 = podstawa ** wykladnik;         // 81

// Pierwiastkowanie:
const liczba = 64;
const pierwiastek = Math.sqrt(liczba);         // 8

// Pierwiastki wyższych stopni (wykładnik ułamkowy 1/n):
const pierwiastekSzescienny = 27 ** (1 / 3);   // 3
```

> **Po co to jest:**  
> Potęgowanie i pierwiastkowanie stanowią trzon algorytmów geometrycznych (np. twierdzenie Pitagorasa: `Math.sqrt(a**2 + b**2)`), obliczania pól figur, objętości brył oraz wskaźników fizycznych (np. wskaźnik BMI: masa / wzrost²).

> **Typowa pomyłka:**  
> Próba użycia symbolu daszka `^` do potęgowania, np. `2 ^ 3`. W języku JavaScript znak `^` nie jest operatorem potęgowania, lecz operatorem bitowym XOR (różnicy symetrycznej), co prowadzi do błędnych wyników arytmetycznych bez zgłoszenia błędu składni.

---

## 5. Wartość bezwzględna i znak liczby: Math.abs oraz Math.sign

- `Math.abs(x)` — zwraca wartość bezwzględną liczby (moduł), czyli usuwa znak ujemny.
- `Math.sign(x)` — zwraca informację o znaku liczby: `1` dla liczby dodatniej, `-1` dla liczby ujemnej, `0` dla zera oraz `NaN` dla wartości nieliczbowych.

```javascript
const roznicaTemperatur = Math.abs(18 - 25); // 7 (nie -7)
console.log(`Różnica wynosi: ${roznicaTemperatur}°C`);

console.log(Math.sign(45));  // 1
console.log(Math.sign(-12)); // -1
console.log(Math.sign(0));   // 0
```

> **Po co to jest:**  
> `Math.abs()` zapobiega otrzymaniu ujemnych odległości, różnic wskaźników lub odchyleń pomiarowych. Przydaje się m.in. przy porównywaniu tolerancji produkcyjnej lub wyznaczaniu dystansu na osi współrzędnych.

> **Typowa pomyłka:**  
> Ręczne sprawdzanie warunku `if (x < 0) { x = -x; }` zamiast użycia czytelnej i zoptymalizowanej metody `Math.abs(x)`.

---

## 6. Wyszukiwanie wartości skrajnych: Math.min oraz Math.max

Metody `Math.min()` oraz `Math.max()` przyjmują dowolną liczbę argumentów liczbowych i zwracają odpowiednio najmniejszą lub największą wartość z podanego zbioru:

```javascript
const najmniejsza = Math.min(12, 5, 89, -3, 24); // -3
const najwieksza = Math.max(12, 5, 89, -3, 24);  // 89

// Ograniczanie wartości do przedziału (tzw. clamping):
function ograniczDoZakresu(wartosc, min, max) {
  return Math.min(Math.max(wartosc, min), max);
}

const wprowadzonyWiek = 150;
const bezpiecznyWiek = ograniczDoZakresu(wprowadzonyWiek, 0, 120); // 120
```

> **Po co to jest:**  
> Wyznaczanie wartości minimalnej i maksymalnej bez pętli i rozbudowanych instrukcji warunkowych ułatwia walidację danych (np. nakładanie limitów rabatu lub ograniczeń prędkości w symulatorach).

> **Typowa pomyłka:**  
> Wywołanie `Math.min()` lub `Math.max()` bez żadnego argumentu. Wbrew intuicji `Math.min()` zwraca wtedy `Infinity`, a `Math.max()` zwraca `-Infinity`.

---

## 7. Generowanie liczb losowych: Math.random i losowanie w przedziale [min, max]

Funkcja `Math.random()` zwraca pseudolosową liczbę zmiennoprzecinkową z przedziału lewostronnie domkniętego `[0, 1)`, czyli większą lub równą `0` i ściśle mniejszą od `1`.

Ponieważ w praktyce szkolnej i zawodowej niemal zawsze potrzebujemy losowej liczby całkowitej z konkretnego przedziału, stosujemy następujący algorytm:

```javascript
function losujLiczbeCalkowita(min, max) {
  // Obliczamy liczbę możliwych wartości całkowitych: (max - min + 1)
  // Mnożymy wynik Math.random(), zaokrąglamy w dół przez Math.floor()
  // i przesuwamy o wartość początkową min:
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Przykład: symulacja rzutu tradycyjną kostką sześcienną (od 1 do 6):
const rzutKostka = losujLiczbeCalkowita(1, 6);
console.log(`Wylosowano: ${rzutKostka}`);
```

Krok po kroku — dlaczego ten wzór działa?
1. `Math.random()` daje wartość od `0.0` do `0.999999...`
2. Mnożenie przez `(max - min + 1)` daje zakres od `0.0` do np. `5.999999...` (dla kostki, gdzie `6 - 1 + 1 = 6`).
3. `Math.floor()` sprowadza wynik do jednej z liczb całkowitych: `0, 1, 2, 3, 4, 5` z równym prawdopodobieństwem.
4. Dodanie `min` (`+ 1`) przesuwa cały zakres do przedziału `1, 2, 3, 4, 5, 6`.

> **Po co to jest:**  
> Losowanie liczb leży u podstaw generowania identyfikatorów transakcji, kodów weryfikacyjnych, losowania pytań w quizach oraz symulacji zdarzeń biznesowych (np. losowe opóźnienie dostawy towaru).

> **Typowa pomyłka:**  
> Użycie `Math.round(Math.random() * (max - min)) + min`. Taki zapis powoduje, że wartości skrajne (`min` oraz `max`) wypadają z dwukrotnie mniejszym prawdopodobieństwem niż wartości środkowe. Do losowania liczb całkowitych zawsze stosujemy `Math.floor()`.

---

## 8. Łączenie metod obiektu Math z funkcjami i standardem wyjścia

Zgodnie z wymaganiami semestru 2 kwalifikacji INF.03 wszelką logikę obliczeniową organizujemy w postaci czytelnych funkcji (zarówno w formie deklaracji `function`, jak i funkcji strzałkowych `() => {}`), które przyjmują parametry i zwracają wyliczone wartości instrukcją `return`.

Wypisywanie wyników na stronę WWW odbywa się poprzez pobranie elementu wyjściowego `#wynik` i przypisanie tekstu do właściwości `textContent`. W arkuszu stylów CSS kontener ten posiada regułę `white-space: pre-wrap`, dzięki czemu znaki nowej linii `\n` są wiernie interpretowane w przeglądarce.

```javascript
// Przykład kompleksowej funkcji wyliczającej koszt transportu:
const obliczKosztTransportu = (odlegloscKm, wagaKg) => {
  const stawkaZaKm = 2.5;
  const stawkaZaKg = 1.2;
  const kosztBazowy = (odlegloscKm * stawkaZaKm) + (wagaKg * stawkaZaKg);
  
  // Koszt zaokrąglamy w górę do pełnego złotego:
  const kosztKoncowy = Math.ceil(kosztBazowy);
  return kosztKoncowy;
};

// Wywołanie i prezentacja wyniku w elemencie DOM:
const dystans = 124.5;
const masa = 45.2;
const doZaplaty = obliczKosztTransportu(dystans, masa);

const wynikEl = document.getElementById("wynik");
if (wynikEl) {
  wynikEl.textContent = `Podsumowanie zlecenia transportowego:\n` +
                        `- Dystans: ${dystans} km\n` +
                        `- Waga ładunku: ${masa} kg\n` +
                        `- Należność (zaokrąglona w górę): ${doZaplaty} PLN`;
}
```

> **Po co to jest:**  
> Enkapsulacja obliczeń matematycznych wewnątrz funkcji zapewnia czystość kodu, ułatwia testowanie i eliminuje powtarzanie kodu. Z kolei wypis przez `textContent` z obsługą `white-space: pre-wrap` zabezpiecza aplikację przed atakami typu XSS i gwarantuje estetyczny, wielowierszowy raport dla użytkownika.

> **Typowa pomyłka:**  
> Umieszczanie instrukcji interakcji z dokumentem (`document.getElementById`) lub poleceń `console.log()` wewnątrz ciała funkcji obliczeniowej zamiast zwrócenia wartości instrukcją `return`. Funkcja powinna przetwarzać dane wejściowe i zwracać wynik, a prezentacja powinna odbywać się na zewnątrz.
