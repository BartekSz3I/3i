# Teoria: Obiekt String — split() i praca z fragmentami tekstu

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

## 1. Wprowadzenie do fragmentacji tekstu

W codziennej pracy programisty aplikacje internetowe rzadko operują na jednolitych, pojedynczych wyrazach. Bardzo często otrzymujemy z formularza, bazy danych lub pliku tekstowego ciąg znaków, który zawiera wiele składowych informacji oddzielonych określonym znakiem. Typowe przykłady to lista adresów e-mail rozdzielona przecinkami, pełne imię i nazwisko rozdzielone spacją, data w formacie `2026-10-18` czy linia z pliku CSV zawierająca dane towaru: `Młotek;Narzędzia;49.99;15`.

Do podziału jednolitego łańcucha znaków na logiczne części służy w języku JavaScript wbudowana metoda `split()`, dostępna w każdym obiekcie typu `String`. Wynikiem działania tej metody jest uporządkowana lista (tablica) wyodrębnionych fragmentów tekstowych, zwanych często tokenami.

**Po co to jest:** Metoda `split()` pozwala zamienić jeden długi, złożony tekst na kolekcję niezależnych fragmentów, co umożliwia ich indywidualne badanie, sortowanie, zliczanie lub modyfikację.

**Typowa pomyłka:** Oczekiwanie, że `split()` modyfikuje oryginalny łańcuch znaków. W języku JavaScript łańcuchy znaków są niemutowalne (ang. *immutable*). Metoda `split()` zawsze tworzy i zwraca nową tablicę fragmentów, pozostawiając źródłowy napis w stanie nienaruszonym.

---

## 2. Podstawowa składnia i działanie metody split()

Metoda `split()` przyjmuje do dwóch argumentów:

```javascript
const tablicaFragmentow = tekst.split(separator, limit);
```

- `separator` (opcjonalny) — łańcuch znaków określający miejsce, w którym ma nastąpić podział tekstu.
- `limit` (opcjonalny) — liczba całkowita określająca maksymalną liczbę elementów, które mają zostać umieszczone w zwracanej tablicy.

### 2.1. Podział według określonego znaku (separator jednopozycyjny)

Najprostszym i najczęstszym scenariuszem jest podział tekstu według konkretnego znaku, na przykład przecinka, myślnika lub ukośnika:

```javascript
const spisMiast = "Warszawa,Kraków,Gdańsk,Wrocław";
const miasta = spisMiast.split(",");

console.log(miasta); // ["Warszawa", "Kraków", "Gdańsk", "Wrocław"]
console.log(miasta.length); // 4
```

Separator sam w sobie zostaje usunięty — nie trafia do żadnego z wyodrębnionych fragmentów.

**Po co to jest:** Pozwala bez trudu wyekstrahować dane z formatów rozdzielanych znakami (np. CSV, pliki konfiguracyjne, listy tagów).

**Typowa pomyłka:** Zapomnienie o spacjach występujących po przecinku. Jeśli łańcuch wejściowy to `"Warszawa, Kraków"`, a separatorem jest samo `","`, wówczas drugi element będzie zawierał spację na początku: `" Kraków"`. W takiej sytuacji separatorem powinien być ciąg `", "` lub należy użyć metody `trim()` na każdym fragmencie.

---

### 2.2. Podział według spacji — zliczanie i analiza słów

Jeżeli jako separator przekażemy pojedynczą spację `" "`, łańcuch znaków zostanie podzielony na poszczególne wyrazy:

```javascript
const zdanie = "Nauka programowania rozwija logiczne myslenie";
const slowa = zdanie.split(" ");

console.log(slowa); // ["Nauka", "programowania", "rozwija", "logiczne", "myslenie"]
console.log(`Liczba słów w zdaniu: ${slowa.length}`);
```

Dzięki odczytaniu właściwości `.length` z powstałej tablicy natychmiast poznajemy liczbę słów w tekście.

**Po co to jest:** Umożliwia zliczanie słów w edytorach tekstu, limitowanie liczby wprowadzonych wyrazów w komentarzach czy badanie struktury zdań.

**Typowa pomyłka:** Stosowanie podziału przez spację na tekście zawierającym wielokrotne spacje obok siebie (np. `"Ala   ma   kota"`). W takim przypadku `split(" ")` utworzy puste elementy `""` pomiędzy sąsiadującymi spacjami.

---

### 2.3. Pusty separator `""` — podział na pojedyncze znaki

Szczególnym przypadkiem jest przekazanie jako separatora pustego ciągu znaków `""` (dwa cudzysłowy bez spacji w środku). Powoduje to rozbicie tekstu na tablicę złożoną z pojedynczych liter i znaków:

```javascript
const haslo = "Sekret123";
const litery = haslo.split("");

console.log(litery); // ["S", "e", "k", "r", "e", "t", "1", "2", "3"]
console.log(litery.length); // 9
```

**Po co to jest:** Pozwala na inspekcję każdego pojedynczego znaku w tekście z osobna, co jest niezwykle przydatne przy analizie siły haseł, zliczaniu samogłosek czy szyfrowaniu.

**Typowa pomyłka:** Mylenie pustego łańcucha `""` ze spacją `" "`. Wywołanie `napis.split(" ")` dzieli tekst po spacjach na słowa, natomiast `napis.split("")` rozbija go na pojedyncze litery.

---

### 2.4. Wywołanie bez argumentu oraz separator nieobecny w tekście

Co się stanie, gdy nie podamy separatora lub podamy znak, który w danym tekście w ogóle nie występuje?

```javascript
const tekst = "JavaScript";

// Brak argumentu:
const wynikBrak = tekst.split();
console.log(wynikBrak); // ["JavaScript"] — tablica z jednym elementem

// Separator nieistniejący:
const wynikNieobecny = tekst.split(";");
console.log(wynikNieobecny); // ["JavaScript"] — podział nie zaszedł
```

W obu sytuacjach JavaScript zwraca tablicę jednoelementową zawierającą cały pierwotny łańcuch znaków.

**Po co to jest:** Gwarantuje bezpieczeństwo kodu — wywołanie metody nie rzuca błędu krytycznego, lecz zwraca przewidywalny typ danych (zawsze tablicę).

**Typowa pomyłka:** Zakładanie, że brak dopasowania separatora zwróci `null` lub pustą tablicę `[]`. Zwracana jest tablica o długości 1, co oznacza, że warunek `wynik.length === 0` nigdy nie będzie prawdziwy.

---

### 2.5. Opcjonalny parametr limit

Drugi, opcjonalny argument metody `split()` pozwala ograniczyć liczbę zwracanych fragmentów:

```javascript
const rejestr = "PL-WAW-2026-A48-PRO";
const pierwszeElementy = rejestr.split("-", 2);

console.log(pierwszeElementy); // ["PL", "WAW"]
```

Pozostała część tekstu zostaje odrzucona i nie trafia do tablicy wynikowej.

**Po co to jest:** Przydaje się wtedy, gdy interesuje nas tylko kilka początkowych segmentów nagłówka lub prefiksu i nie chcemy marnować zasobów na parsowanie całego długiego dokumentu.

**Typowa pomyłka:** Oczekiwanie, że odrzucona część tekstu zostanie doklejona jako ostatni element. Tak nie jest — parametr `limit` bezwzględnie ucina tablicę po osiągnięciu zadanej liczby pozycji.

---

## 3. Praca z otrzymaną tablicą fragmentów

Gdy metoda `split()` wykona podział, otrzymujemy tablicę łańcuchów znaków. Podstawowe operacje na tej tablicy obejmują:

### 3.1. Indeksowanie elementów i właściwość .length

Elementy tablicy numerowane są od zera. Oznacza to, że:
- Pierwszy fragment to `fragmenty[0]`.
- Drugi fragment to `fragmenty[1]`.
- Ostatni fragment to `fragmenty[fragmenty.length - 1]`.

```javascript
const data = "2026-10-18";
const czesciDaty = data.split("-");

const rok = czesciDaty[0];     // "2026"
const miesiac = czesciDaty[1]; // "10"
const dzien = czesciDaty[2];   // "18"

console.log(`Rok: ${rok}, Miesiąc: ${miesiac}, Dzień: ${dzien}`);
```

**Po co to jest:** Umożliwia precyzyjne odczytanie poszczególnych pól z ustrukturyzowanych kodów i formatów danych.

**Typowa pomyłka:** Próba odczytu ostatniego elementu przez `fragmenty[fragmenty.length]`. Ponieważ indeksy zaczynają się od `0`, poprawny indeks ostatniego elementu to zawsze `fragmenty.length - 1`.

---

## 4. Scalanie fragmentów za pomocą metody join()

Naturalnym dopełnieniem metody `split()` jest metoda `join()`. O ile `split()` dzieli łańcuch znaków na tablicę, o tyle `join()` łączy elementy tablicy z powrotem w jeden ciąg znaków, wstawiając pomiędzy nie wskazany separator:

```javascript
const elementy = ["HTML", "CSS", "JavaScript"];

const polaczone1 = elementy.join(" - ");
console.log(polaczone1); // "HTML - CSS - JavaScript"

const polaczone2 = elementy.join(", ");
console.log(polaczone2); // "HTML, CSS, JavaScript"

const polaczone3 = elementy.join("");
console.log(polaczone3); // "HTMLCSSJavaScript"
```

Domyślnym separatorem w metodzie `join()`, jeśli nie podamy żadnego argumentu, jest przecinek `","`.

**Po co to jest:** Pozwala złożyć przefiltrowaną, poprawioną lub zreorganizowaną listę słów w czytelne zdanie lub z powrotem w kod formatu (np. zmiana separatora z myślników na ukośniki).

**Typowa pomyłka:** Wywołanie `tablica.join()` bez argumentu w nadziei, że połączy elementy bez separatora. Wywołanie bez argumentu użyje domyślnego przecinka `","`. Aby połączyć elementy bezpośrednio, należy jawnie podać pusty ciąg: `tablica.join("")`.

---

## 5. Przetwarzanie fragmentów w pętli

Często po rozbiciu tekstu konieczne jest przeanalizowanie każdego fragmentu z osobna: zliczenie elementów spełniających warunek, oczyszczenie ich z białych znaków lub zmiana wielkości liter.

### 5.1. Pętla tradycyjna `for` z licznikiem indeksu

```javascript
const logi = "INFO:Logowanie;WARN:BrakPliku;ERROR:BazaOffline";
const wpisy = logi.split(";");

let bledy = 0;
for (let i = 0; i < wpisy.length; i++) {
  if (wpisy[i].startsWith("ERROR")) {
    bledy++;
  }
}

console.log(`Liczba błędów krytycznych: ${bledy}`);
```

### 5.2. Pętla `for...of` — nowoczesna iteracja po wartościach

Jeżeli nie potrzebujemy bezpośredniego numeru indeksu `i`, wygodniejszy i bardziej czytelny jest zapis pętli `for...of`:

```javascript
const listaTowarow = "  młotek , śrubokręt , kombinerki , klucz  ";
const elementySurowe = listaTowarow.split(",");

let wynikFormatowany = "";
for (const element of elementySurowe) {
  const czysty = element.trim().toUpperCase();
  wynikFormatowany += `[TOWAR: ${czysty}]\n`;
}

console.log(wynikFormatowany);
```

**Po co to jest:** Umożliwia zautomatyzowane czyszczenie, weryfikację i budowanie raportów ze złożonych ciągów wejściowych.

**Typowa pomyłka:** Próba modyfikacji elementu wewnątrz pętli `for...of` przez przypisanie `element = element.trim()`. Taki zapis modyfikuje jedynie zmienną lokalną pętli, a nie tablicę źródłową.

### 5.3. Budowanie nowej tablicy oczyszczonych fragmentów (`push` + `join`)

Gdy po podziale tekstu chcesz jednocześnie oczyścić fragmenty i potem scalić je innym łącznikiem, zbieraj wyniki do **nowej** tablicy. Metoda `push()` dopisuje element na koniec tablicy:

```javascript
const zlecenie = "  wymiana oleju ; diagnostyka ; geometria  ";
const pozycjeSurowe = zlecenie.split(";");
const pozycjeCzyste = [];

for (const pozycja of pozycjeSurowe) {
  pozycjeCzyste.push(pozycja.trim().toUpperCase());
}

const liniaProtokolu = pozycjeCzyste.join(" | ");
console.log(liniaProtokolu);
// "WYMIANA OLEJU | DIAGNOSTYKA | GEOMETRIA"
```

Dzięki temu:
- unikasz typowej pomyłki z `for...of` (punkty 5.2),
- masz gotową tablicę do indeksowania (`[0]`, `[length - 1]`) oraz do `join()`.

**Po co to jest:** Standardowy wzorzec „podziel → oczyść w pętli → scal”, używany w zadaniach integrujących i na sprawdzianie.

**Typowa pomyłka:** Wywołanie `split(";")` na tekście ze spacjami po średniku **bez** `trim()`. Fragment `" cynk"` ma wtedy długość 5 zamiast 4, co psuje zliczanie po `.length`.

---

## 6. Standard wypisu wyników w Semestrze 2

Zgodnie z wymogami programowymi Semestru 2 kwalifikacji INF.03, wszelkie wyniki obliczeń i analizy tekstu prezentowane są na stronie WWW w dedykowanym kontenerze wyjściowym o identyfikatorze `wynik`:

```html
<div id="wynik"></div>
```

W kodzie JavaScript do wpisania danych używamy właściwości `textContent`:

```javascript
document.getElementById("wynik").textContent = wygenerowanyTekst;
```

Aby zachować formatowanie wielowierszowe (znaki nowej linii `\n`) oraz wielokrotne spacje, arkusz CSS dla kontenera `#wynik` musi zawierać właściwość:

```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
}
```

Dzięki temu tekst sformatowany w szablonie tekstowym zachowuje przejrzysty, uporządkowany układ tabelaryczny bez konieczności stosowania znaczników HTML wewnątrz skryptu.

---

### 6.1. Standard wejścia danych: Zewnętrzny plik `dane.js` (model CKE)

W zadaniach operujących na zestawach danych (pakiety CSV, ciągi tagów, listy surowców) dane wejściowe często dostarczane są w osobnym pliku `dane.js`.

Plik ten dołączany jest w kodzie strony HTML przed skryptem z rozwiązaniem:
```html
<script src="dane.js"></script>
<script src="script.js"></script>
```

**Zasada działania:**
1. Stałe zadeklarowane w `dane.js` (np. `const DANE_SPECYFIKACJA_ZAMOWIENIA = "...";`) stają się natychmiast widoczne w `script.js` w zasięgu globalnym.
2. W swoim kodzie odwołujesz się do nich bezpośrednio:
   ```javascript
   const zleceniaDoPodzialu = DANE_SPECYFIKACJA_ZAMOWIENIA;
   const elementy = zleceniaDoPodzialu.split(", ");
   ```
3. W środowisku przeglądarkowym opartym na protokole `file:///` nie stosuje się modułów ES (`import`/`export`), ponieważ przeglądarki blokują je z powodu polityki bezpieczeństwa CORS. Sekwencyjne załączanie skryptów w HTML to standardowy mechanizm INF.03.

**Po co to jest:**  
Oddziela surowe dane testowe od logiki algorytmu `split()` / `join()`, umożliwiając szybkie testowanie różnych zestawów danych.

**Typowa pomyłka:**  
Próba użycia `import` (błąd CORS) lub ponowne deklarowanie tej samej stałej w pliku `script.js`.
