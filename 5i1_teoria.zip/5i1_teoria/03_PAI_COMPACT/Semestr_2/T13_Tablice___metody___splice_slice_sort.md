# Teoria: Tablice — metody: splice, slice, sort

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

W poprzednich tematach poznaliśmy podstawowe metody dodawania i usuwania elementów z krańców tablicy: `push()`, `pop()`, `shift()` oraz `unshift()`. W rzeczywistych projektach frontendowych dane rzadko jednak zmieniają się wyłącznie na samym początku lub na samym końcu. Użytkownik w sklepie internetowym może usunąć trzecią pozycję z koszyka, edytować wpis w środku listy zadań, pobrać fragment historii transakcji z wybranego tygodnia lub posortować katalog produktów według ceny czy nazwy.

W tym module opanujemy cztery fundamentalne metody, które dają pełną kontrolę nad zawartością i układem tablic jednowymiarowych: `splice()`, `slice()`, `sort()` oraz `reverse()`.

---

## 1. Modyfikowanie środka tablicy — metoda `splice()`

Metoda `splice()` jest najbardziej wszechstronnym narzędziem do modyfikacji zawartości tablicy w miejscu (mówimy, że jest to metoda **mutująca**, czyli zmieniająca tablicę źródłową). Pozwala ona na jednoczesne:
1. usuwanie elementów z dowolnego miejsca,
2. wstawianie nowych elementów w dowolnym miejscu,
3. zastępowanie jednych elementów innymi.

### Składnia metody:
```javascript
const usunieteElementy = tablica.splice(start, liczbaDoUsuniecia, element1, element2, /* ... */);
```

- **`start`**: Indeks w tablicy, od którego rozpoczynamy operację. Jeśli podamy liczbę ujemną, odliczanie nastąpi od końca tablicy (np. `-1` to ostatni element).
- **`liczbaDoUsuniecia`** (*deleteCount*): Liczba elementów, które chcemy usunąć począwszy od indeksu `start`. Jeśli podamy `0`, żaden element nie zostanie usunięty.
- **`element1, element2, ...`** (*opcjonalne*): Nowe elementy, które zostaną wstawione do tablicy w miejscu wskazanym przez `start`.
- **Wartość zwracana**: Nowa tablica zawierająca usunięte elementy (jeśli nic nie usunięto, zwracana jest pusta tablica `[]`).

### Scenariusz 1: Usuwanie elementów ze środka tablicy
Gdy klient anuluje wybraną pozycję z listy zamówień, usuwamy ją wskazując jej indeks oraz liczbę elementów do skasowania:

```javascript
const zamowienia = ["Myszka", "Klawiatura", "Podkładka", "Monitor", "Kabel HDMI"];

// Usuwamy 1 element pod indeksem 2 (czyli "Podkładka")
const skasowane = zamowienia.splice(2, 1);

console.log(zamowienia); 
// Wynik: ["Myszka", "Klawiatura", "Monitor", "Kabel HDMI"]

console.log(skasowane); 
// Wynik: ["Podkładka"]
```

### Scenariusz 2: Wstawianie nowych elementów bez usuwania
Gdy do kolejki zgłoszeń serwisowych chcemy wstawić nowe zadanie pomiędzy istniejące zlecenia, podajemy `liczbaDoUsuniecia = 0`:

```javascript
const zgloszenia = ["Awaria sieci", "Instalacja drukarki", "Wymiana dysku"];

// Wstawiamy zlecenie pilne pod indeksem 1, nie usuwając niczego
zgloszenia.splice(1, 0, "PILNE: Konfiguracja routera");

console.log(zgloszenia);
// Wynik: ["Awaria sieci", "PILNE: Konfiguracja routera", "Instalacja drukarki", "Wymiana dysku"]
```

### Scenariusz 3: Zastępowanie elementów (edycja w miejscu)
Gdy chcemy zastąpić nieaktualną pozycję nowym produktem, usuwamy jeden element i w tym samym miejscu wstawiamy nowy:

```javascript
const cennikUslug = ["Diagnostyka: 50 zł", "Czyszczenie: 80 zł", "Formatowanie: 100 zł"];

// Zastępujemy element pod indeksem 1 nową stawką
cennikUslug.splice(1, 1, "Czyszczenie z wymianą pasty: 120 zł");

console.log(cennikUslug);
// Wynik: ["Diagnostyka: 50 zł", "Czyszczenie z wymianą pasty: 120 zł", "Formatowanie: 100 zł"]
```

> **Po co to jest:**  
> Metoda `splice()` jest niezastąpiona przy operacjach typu CRUD (Create, Read, Update, Delete) w pamięci podręcznej aplikacji. Pozwala precyzyjnie usunąć kliknięty przez użytkownika element z listy, wstawić element w konkretnej pozycji rankingu czy edytować pojedynczy rekord bez konieczności przepisywania całej tablicy w pętli.

> **Typowa pomyłka:**  
> 1. Mylenie drugiego parametru z indeksem końcowym. Zapis `tablica.splice(2, 4)` **nie oznacza** „usuń od indeksu 2 do indeksu 4”, lecz **„usuń 4 elementy poczynając od indeksu 2”** (czyli elementy o indeksach 2, 3, 4 i 5).  
> 2. Przypisywanie wyniku `splice()` z powrotem do głównej zmiennej: `zamowienia = zamowienia.splice(1, 1)`. W ten sposób w zmiennej `zamowienia` znajdzie się tablica usuniętych elementów, a nie zaktualizowana lista!

---

## 2. Bezpieczne wycinanie i kopiowanie — metoda `slice()`

W przeciwieństwie do `splice()`, metoda `slice()` jest metodą **niemutującą** (czystą). Oznacza to, że **nie modyfikuje** tablicy, na której została wywołana, lecz tworzy i zwraca nową tablicę zawierającą wycięty fragment.

### Składnia metody:
```javascript
const fragment = tablica.slice(poczatek, koniec);
```

- **`poczatek`** (*opcjonalny*): Indeks, od którego zaczynamy wycinanie (włącznie). Domyślnie `0`.
- **`koniec`** (*opcjonalny*): Indeks, na którym kończymy wycinanie (**wyłącznie** — element pod tym indeksem nie wejdzie do nowej tablicy). Jeśli nie zostanie podany, wycinanie trwa do końca tablicy.
- **Wartość zwracana**: Nowa tablica z wybranymi elementami.

Matematycznie wycinany przedział można zapisać jako prawostronnie otwarty: `[poczatek, koniec)`.

```javascript
const miesiace = ["Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec"];

// Pobieramy I kwartał (indeksy 0, 1, 2 — indeks 3 nie jest włączany)
const kwartal1 = miesiace.slice(0, 3);

console.log(kwartal1); 
// Wynik: ["Styczeń", "Luty", "Marzec"]

console.log(miesiace); 
// Oryginalna tablica pozostała nienaruszona!
```

### Wycinanie z użyciem indeksów ujemnych
Indeksy ujemne liczone są od końca tablicy (`-1` oznacza ostatni element, `-2` przedostatni itd.). Jest to bardzo wygodny sposób na pobieranie np. trzech ostatnich transakcji lub najnowszych powiadomień:

```javascript
const logiSerwera = ["LOG_01", "LOG_02", "LOG_03", "LOG_04", "LOG_05"];

// Pobieramy 2 ostatnie wpisy
const ostatnieLogi = logiSerwera.slice(-2);

console.log(ostatnieLogi); 
// Wynik: ["LOG_04", "LOG_05"]
```

### Kopiowanie całej tablicy (klonowanie płytkie)
Wywołanie `slice()` bez żadnych argumentów zwraca kopię całej tablicy. Jest to klasyczny sposób na utworzenie kopii roboczej przed wykonaniem operacji mutujących:

```javascript
const oryginal = [10, 20, 30];
const kopia = oryginal.slice();

kopia.push(40);
console.log(oryginal); // [10, 20, 30] - bezpieczny
console.log(kopia);    // [10, 20, 30, 40]
```

> **Po co to jest:**  
> Metoda `slice()` pozwala na bezpieczną analizę i prezentację danych bez ryzyka uszkodzenia lub zmiany oryginalnego źródła danych. Używamy jej do stronnicowania (paginacji) wyników na stronie (np. „wyświetl elementy od 10 do 20”), tworzenia podglądów, generowania raportów okresowych oraz bezpiecznego kopiowania tablic przed ich posortowaniem.

> **Typowa pomyłka:**  
> Oczekiwanie, że `tablica.slice(1, 3)` usunie elementy z `tablica`. Uczeń pisze `tablica.slice(1, 3)` i dziwi się, że na ekranie wciąż wyświetla się kompletna tablica. Pamiętajmy: `slice()` nie zmienia oryginału — wynik wywołania musimy przypisać do nowej zmiennej lub przekazać dalej.

---

## 3. Zestawienie porównawcze: `splice()` vs `slice()`

Zbieżność nazw obu metod jest jedną z najczęstszych przyczyn pomyłek na egzaminie zawodowym INF.03. Poniższa tabela zbiera kluczowe różnice:

| Cecha | `tablica.splice()` | `tablica.slice()` |
|-------|--------------------|-------------------|
| **Wpływ na oryginał** | **Mutująca**: zmienia oryginalną tablicę w miejscu. | **Niemutująca**: nie narusza oryginału. |
| **Wartość zwracana** | Tablica **usuniętych** elementów. | Nowa tablica zawierająca **wycięty fragment**. |
| **Znaczenie 2. parametru** | Liczba elementów do usunięcia (*ile sztuk*). | Indeks końcowy wycinania (*do którego indeksu, bez niego*). |
| **Wstawianie nowych danych**| Tak — od 3. parametru w górę (`...items`). | Nie — służy wyłącznie do odczytu i kopiowania. |
| **Kluczowe zastosowanie** | Usuwanie ze środka, wstawianie, edycja. | Paginacja, pobieranie podzbioru, bezpieczne klonowanie. |

---

## 4. Porządkowanie danych — metoda `sort()`

Metoda `sort()` służy do sortowania elementów tablicy w miejscu (jest to metoda **mutująca**). Domyślnie konwertuje wszystkie elementy na łańcuchy znaków i porównuje ich kody w tablicy znaków (porządek leksykograficzny).

### Pułapka domyślnego sortowania liczb
Jeśli wywołamy `sort()` na tablicy liczb bez parametrów, otrzymamy wynik sprzeczny z intuicją matematyczną:

```javascript
const punkty = [25, 8, 100, 4, 12];
punkty.sort();

console.log(punkty);
// Wynik: [100, 12, 25, 4, 8]  <-- BŁĄD LOGICZNY!
```

Dlaczego tak się stało? Ponieważ w porządku słownikowym napis `"100"` zaczyna się od cyfry `"1"`, która występuje przed cyfrą `"2"` (w `"25"`), a ta z kolei przed `"4"`. Dlatego `"100"` znalazło się na samym początku!

### Funkcja komparatora (funkcja porównująca)
Aby posortować liczby według ich rzeczywistej wartości matematycznej, musimy przekazać do `sort()` funkcję porównującą (tzw. komparator), która przyjmuje dwa parametry `(a, b)`:

- Jeśli funkcja zwróci wartość **ujemną** (`< 0`), element `a` zostanie umieszczony **przed** `b`.
- Jeśli funkcja zwróci wartość **dodatnią** (`> 0`), element `b` zostanie umieszczony **przed** `a`.
- Jeśli funkcja zwróci **zero** (`=== 0`), kolejność elementów `a` i `b` nie ulegnie zmianie.

Dzięki temu wzór na sortowanie liczb rosnąco sprowadza się do prostego odejmowania `a - b`, a malejąco do `b - a`.

#### Wariant 1: Funkcja strzałkowa (nowoczesny standard ES6)
```javascript
const liczby = [25, 8, 100, 4, 12];

// Sortowanie rosnąco:
liczby.sort((a, b) => a - b);
console.log(liczby); // [4, 8, 12, 25, 100]

// Sortowanie malejąco:
liczby.sort((a, b) => b - a);
console.log(liczby); // [100, 25, 12, 8, 4]
```

#### Wariant 2: Klasyczna deklaracja funkcji (zapis równoważny)
Na egzaminie CKE oba zapisy są w 100% równoważne i poprawnie interpretowane przez silnik JavaScript:
```javascript
// Zapis klasyczny rosnąco:
liczby.sort(function(a, b) {
  return a - b;
});
```

### Sortowanie napisów i obsługa polskich znaków — `localeCompare()`
Sortowanie domyślne dla zwykłego alfabetu angielskiego działa poprawnie:
```javascript
const kraje = ["Dania", "Austria", "Belgia"];
kraje.sort();
console.log(kraje); // ["Austria", "Belgia", "Dania"]
```

Jednak w przypadku polskich znaków diakrytycznych (`ą`, `ć`, `ę`, `ł`, `ń`, `ó`, `ś`, `ź`, `ż`) kody znaków Unicode znajdują się w zupełnie innym miejscu niż litery podstawowe. Bez komparatora słowo „Łódź” wyląduje na samym końcu za literą „Z”!

Rozwiązaniem egzaminacyjnym jest metoda łańcuchowa `localeCompare()`:
```javascript
const miasta = ["Łódź", "Warszawa", "Gdańsk", "Kraków", "Poznań", "Świdnica"];

// Poprawne sortowanie alfabetyczne zgodne z regułami języka polskiego:
miasta.sort((a, b) => a.localeCompare(b, "pl"));

console.log(miasta);
// Wynik: ["Gdańsk", "Kraków", "Łódź", "Poznań", "Świdnica", "Warszawa"]
```

> **Po co to jest:**  
> Sortowanie to podstawowa funkcja każdej aplikacji webowej prezentującej dane: od tabeli z wynikami egzaminów, przez sortowanie produktów od najtańszego do najdroższego w sklepie, po alfabetyczne listy klientów i pacjentów.

> **Typowa pomyłka:**  
> 1. Wywołanie `tablica.sort()` na liczbach bez funkcji `(a, b) => a - b`. Jest to kardynalny błąd egzaminacyjny skutkujący utratą punktów za logikę sortowania.  
> 2. Zapominanie, że `sort()` bezpowrotnie modyfikuje tablicę oryginalną. Jeśli chcemy zachować pierwotną kolejność danych (np. według kolejności wprowadzania), musimy najpierw utworzyć kopię roboczą za pomocą `const kopia = tablica.slice()`, a dopiero potem posortować kopię: `kopia.sort(...)`.

---

## 5. Odwracanie kolejności — metoda `reverse()`

Metoda `reverse()` odwraca kolejność elementów w tablicy w miejscu. Pierwszy element staje się ostatnim, a ostatni pierwszym.

```javascript
const etapy = ["Krok 1: Rejestracja", "Krok 2: Płatność", "Krok 3: Realizacja"];
etapy.reverse();

console.log(etapy);
// Wynik: ["Krok 3: Realizacja", "Krok 2: Płatność", "Krok 1: Rejestracja"]
```

> **Po co to jest:**  
> Szybkie odwracanie kolejności wyświetlania zdarzeń (np. odwrócenie chronologicznego dziennika zdarzeń na widok od najnowszych do najstarszych) lub zmiana kierunku sortowania po wcześniejszym uporządkowaniu danych.

> **Typowa pomyłka:**  
> Przeoczenie faktu, że `reverse()` modyfikuje tablicę w miejscu. Podobnie jak przy `sort()`, jeśli potrzebujemy oryginału w stanie nienaruszonym, najpierw wykonujemy `slice()`.

---

## 6. Wzorzec egzaminacyjny CKE: separacja danych i prezentacja w DOM

W arkuszach egzaminacyjnych kwalifikacji INF.03 często stosowany jest profesjonalny podział na plik z danymi oraz plik ze skryptem wykonawczym:
1. **`dane.js`**: Zawiera zadeklarowaną stałą w konwencji `UPPER_SNAKE_CASE` (np. `const DANE_MAGAZYN = [...];`).
2. **`index.html`**: Dołącza oba skrypty w ściśle określonej kolejności za pomocą dwóch znaczników `<script>`:
   ```html
   <script src="dane.js"></script>
   <script src="script.js"></script>
   ```
   Dzięki temu zmienna z pliku `dane.js` staje się natychmiast dostępna w kodzie `script.js` jako zmienna o zasięgu globalnym.
3. **`script.js`**: Wykonuje operacje logiczne (np. filtrowanie, wycinanie `slice()`, modyfikacje `splice()`, sortowanie `sort()`), a następnie formatuje czytelny raport tekstowy i wypisuje go do kontenera `#wynik`:
   ```javascript
   // Bezpieczne pobranie referencji do elementu wyjściowego
   const kontenerWyniku = document.getElementById("wynik");
   
   // Przygotowanie raportu i wypis z zachowaniem formatowania
   kontenerWyniku.textContent = raportTekstowy;
   ```

Pamiętajmy, że w Semestrze 2 nie stosujemy jeszcze `querySelector()` ani dynamicznych zdarzeń `addEventListener()`. Wypis danych realizowany jest statycznie po załadowaniu skryptu do elementu z identyfikatorem `wynik`.
