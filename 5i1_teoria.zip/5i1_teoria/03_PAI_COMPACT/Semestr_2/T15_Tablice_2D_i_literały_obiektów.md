# Teoria: Tablice dwuwymiarowe (macierze) i literały obiektów w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

W dotychczasowych modułach poznaliśmy tablice jednowymiarowe — struktury przypominające pojedynczy rząd szuflad lub ponumerowaną listę zakupów. W rzeczywistych aplikacjach biznesowych oraz zadaniach egzaminacyjnych kwalifikacji INF.03 dane rzadko występują w tak prostej postaci. Informacje ze sklepów internetowych, rozkłady miejsc w kinie, siatki temperatur czy rekordy pobrane z relacyjnych baz danych wymagają struktur wielowymiarowych lub obiektowych. Ten dział wprowadza dwa fundamentalne narzędzia modelowania danych: **tablice dwuwymiarowe** (macierze) oraz **literały obiektów** jako rekordy danych.

---

## 1. Tablice dwuwymiarowe (tablice tablic / macierze)

Tablica dwuwymiarowa (nazywana w informatyce i matematyce macierzą) to w języku JavaScript tablica, której elementami są inne tablice. Taki układ pozwala odtworzyć strukturę siatki, tabeli arkusza kalkulacyjnego lub szachownicy o wierszach i kolumnach.

```javascript
// Deklaracja macierzy 3x3 reprezentującej siatkę punktów pomiarowych
const siatkaPomiarow = [
  [12, 15, 18], // Wiersz o indeksie 0
  [20, 22, 19], // Wiersz o indeksie 1
  [14, 16, 25]  // Wiersz o indeksie 2
];
```

### Podwójne indeksowanie

Aby odczytać lub zmodyfikować wartość w siatce, stosujemy dwa nawiasy kwadratowe następujące bezpośrednio po sobie:
1. Pierwszy nawias określa **numer wiersza** (liczony od zera).
2. Drugi nawias określa **numer kolumny** wewnątrz tego wiersza (również liczony od zera).

```javascript
// Odczyt komórki w wierszu 1, kolumnie 2:
const pomiar = siatkaPomiarow[1][2]; // Wartość 19

// Zmiana wartości w wierszu 0, kolumnie 0:
siatkaPomiarow[0][0] = 99;
```

**Po co to jest:**  
Podwójne indeksowanie pozwala bezpośrednio odwzorować układ współrzędnych `(wiersz, kolumna)` znany z tabel bazy danych, matryc ekranowych, map kafelkowych czy siatek rezerwacji biletów. Zamiast tworzyć skomplikowane algorytmy przeliczające pozycję w pojedynczej tablicy, odwołujemy się do naturalnego adresu komórki.

**Typowa pomyłka:**  
Częstym błędem osób początkujących jest próba odwołania w składni matematycznej `siatkaPomiarow[0, 1]`, co w języku JavaScript kończy się błędem lub nieoczekiwanym zachowaniem (operator przecinka zwraca ostatnią wartość, czyli `[1]`, co pobierze cały wiersz zamiast komórki). Pamiętaj: każdy wymiar tablicy wymaga osobnej pary nawiasów kwadratowych: `tablica[wiersz][kolumna]`. Drugą pomyłką jest zamiana kolejności indeksów — najpierw zawsze wybieramy wiersz (tablicę nadrzędną), a dopiero potem kolumnę (element tablicy podrzędnej).

---

## 2. Iteracja po tablicy 2D — pętle zagnieżdżone

Do przetworzenia wszystkich elementów macierzy potrzebujemy dwóch pętli, z których jedna wykonuje się wewnątrz drugiej:
- **Pętla zewnętrzna** odpowiada za przechodzenie przez kolejne wiersze.
- **Pętla wewnętrzna** przechodzi przez poszczególne komórki (kolumny) aktualnego wiersza.

### Klasyczna pętla `for` z indeksami liczbowymi

Stosujemy ją, gdy podczas obliczeń potrzebujemy znać dokładne współrzędne elementu:

```javascript
let sumaCalkowita = 0;

for (let i = 0; i < siatkaPomiarow.length; i++) {
  // siatkaPomiarow[i] to aktualny wiersz (tablica 1D)
  for (let j = 0; j < siatkaPomiarow[i].length; j++) {
    sumaCalkowita += siatkaPomiarow[i][j];
  }
}

console.log(`Łączna suma pomiarów: ${sumaCalkowita}`);
```

### Nowoczesna pętla `for...of` po elementach

Gdy potrzebujemy jedynie odczytać wartości bez konieczności manipulowania indeksami, kod staje się znacznie bardziej zwięzły:

```javascript
let najwyzszyWynik = -Infinity;

for (const wiersz of siatkaPomiarow) {
  for (const wartosc of wiersz) {
    if (wartosc > najwyzszyWynik) {
      najwyzszyWynik = wartosc;
    }
  }
}
```

**Po co to jest:**  
Pętle zagnieżdżone są podstawowym mechanizmem raportowania tabelarycznego. Pozwalają obliczać sumy wierszy (np. obrót dzienny sklepu), sumy kolumn (np. sprzedaż danego produktu we wszystkich filiach) oraz znajdować anomalie i wartości skrajne w całych arkuszach.

**Typowa pomyłka:**  
Użycie tej samej nazwy zmiennej sterującej w obu pętlach, np. `for (let i = 0; ...)` w pętli zewnętrznej oraz `for (let i = 0; ...)` w wewnętrznej. Nadpisanie zmiennej `i` powoduje natychmiastowe uszkodzenie logiki iteracji lub nieskończoną pętlę zawieszającą przeglądarkę. Zawsze stosuj czytelne, unikalne liczniki (np. `r` od row i `c` od col, lub `i` oraz `j`).

---

## 3. Literały obiektów jako rekordy danych (`{}`)

Tablica przechowuje elementy uporządkowane według numerów indeksów (0, 1, 2...). W życiu codziennym dane opisujemy jednak nazwanymi cechami: produkt ma nazwę, cenę, kategorię i stan magazynowy. W języku JavaScript do opisu pojedynczego bytu służy **obiekt**, a jego najprostszym i najwydajniejszym sposobem tworzenia jest **literał obiektu** za pomocą nawiasów klamrowych `{}`.

```javascript
const uslugaSerwisowa = {
  id: 104,
  nazwa: "Diagnostyka stacji roboczej",
  kategoria: "SPRZĘT",
  cenaNetto: 120,
  czyAktywna: true
};
```

Struktura obiektu opiera się na parach **klucz: wartość** (property name: property value). Klucze są identyfikatorami (napisami), a wartościami mogą być liczby, teksty, wartości logiczne, a nawet inne tablice.

### Dostęp do właściwości obiektu

Istnieją dwa sposoby odczytu i zapisu danych w obiekcie:

1. **Notacja kropkowa (`obiekt.klucz`)** — najbardziej czytelna i preferowana, gdy z góry znamy nazwę właściwości:
   ```javascript
   console.log(uslugaSerwisowa.nazwa); // "Diagnostyka stacji roboczej"
   uslugaSerwisowa.cenaNetto = 135;   // Zmiana wartości pola
   ```

2. **Notacja nawiasowa (`obiekt["klucz"]`)** — niezbędna, gdy klucz jest zmienną dynamiczną, zawiera znaki specjalne lub spacje:
   ```javascript
   const szukanaCecha = "kategoria";
   console.log(uslugaSerwisowa[szukanaCecha]); // "SPRZĘT"
   ```

### Dodawanie, modyfikacja i usuwanie właściwości

W języku JavaScript obiekty są strukturami otwartymi:
- Aby **dodać** nowe pole, wystarczy przypisać do niego wartość: `uslugaSerwisowa.gwarancjaMiesiace = 24;`.
- Aby **usunąć** pole z obiektu, stosujemy słowo kluczowe `delete`: `delete uslugaSerwisowa.czyAktywna;`.
- Aby **sprawdzić obecność** właściwości, używamy operatora `in`: `if ("cenaNetto" in uslugaSerwisowa) { ... }`.

### Przydatne metody statyczne: `Object.keys`, `Object.values`, `Object.entries`

Gdy zachodzi potrzeba zbadania struktury obiektu lub dynamicznego przetworzenia wszystkich jego pól:
- `Object.keys(obiekt)` — zwraca tablicę nazw wszystkich właściwości obiektu.
- `Object.values(obiekt)` — zwraca tablicę wszystkich wartości przypisanych do pól.
- `Object.entries(obiekt)` — zwraca tablicę par `[klucz, wartość]`.

**Po co to jest:**  
Literały obiektów organizują powiązane ze sobą informacje w jedną spójną całość. Zamiast tworzyć pięć równoległych tablic (`nazwyUslug[]`, `cenyUslug[]`, `idUslug[]`), tworzymy jeden rekord skupiający wszystkie atrybuty danego bytu, co radykalnie zmniejsza ryzyko pomyłki przy sortowaniu i filtrowaniu.

**Typowa pomyłka:**  
Próba odwołania w notacji nawiasowej bez cudzysłowu do stałego klucza: `uslugaSerwisowa[nazwa]` zamiast `uslugaSerwisowa["nazwa"]`. W pierwszym przypadku JavaScript szuka zmiennej o nazwie `nazwa`. Jeśli taka zmienna nie istnieje, program zgłosi błąd `ReferenceError: nazwa is not defined`. Jeśli istnieje i ma inną wartość, odczytamy zupełnie inne pole!

---

## 4. Tablice obiektów — standard struktur bazodanowych

Najważniejszą strukturą danych na egzaminie zawodowym INF.03 oraz w pracy programisty frontendowego jest **tablica obiektów** (ang. *array of objects*). Reprezentuje ona dokładnie tabelę z bazy danych lub arkusza kalkulacyjnego, gdzie:
- cała tablica to zbiór wszystkich rekordów (tabela),
- każdy element tablicy to pojedynczy wiersz (obiekt z właściwościami),
- właściwości obiektu odpowiadają kolumnom tabeli.

```javascript
const REJESTR_PRODUKTOW = [
  { id: 1, nazwa: "Kabel sieciowy RJ45", kategoria: "Sieci", cena: 15.50, ilosc: 120 },
  { id: 2, nazwa: "Router Wi-Fi 6", kategoria: "Sieci", cena: 249.00, ilosc: 15 },
  { id: 3, nazwa: "Klawiatura mechaniczna", kategoria: "Akcesoria", cena: 189.99, ilosc: 40 },
  { id: 4, nazwa: "Mysz optyczna USB", kategoria: "Akcesoria", cena: 45.00, ilosc: 85 }
];
```

### Iteracja i filtrowanie tablicy obiektów

Dzięki metodom poznanym w module T14 możemy przetwarzać tablicę obiektów w sposób niezwykle elegancki:

```javascript
// Filtrowanie produktów z kategorii "Sieci"
const tylkoSieci = REJESTR_PRODUKTOW.filter(produkt => produkt.kategoria === "Sieci");

// Obliczenie łącznej wartości magazynowej za pomocą pętli for...of
let wartoscMagazynu = 0;
for (const p of REJESTR_PRODUKTOW) {
  wartoscMagazynu += p.cena * p.ilosc;
}
```

### Sortowanie tablicy obiektów za pomocą komparatora

Metoda `sort()` bez podania funkcji porównującej (komparatora) konwertuje elementy na tekst i sortuje je alfabetycznie. Dla obiektów dałoby to bezużyteczny wynik `"[object Object]"`. Dlatego przy sortowaniu tablicy obiektów **zawsze** przekazujemy funkcję komparatora `(a, b)`:

#### Sortowanie według właściwości numerycznej (cena rosnąco):
Poniższe dwa zapisy są w pełni równoważne syntaktycznie:

*Zapis funkcyjny strzałkowy (rekomendowany w nowoczesnym JS):*
```javascript
REJESTR_PRODUKTOW.sort((a, b) => a.cena - b.cena);
```

*Klasyczny zapis z pełnym słowem kluczowym `function`:*
```javascript
REJESTR_PRODUKTOW.sort(function(a, b) {
  return a.cena - b.cena;
});
```

#### Sortowanie według właściwości tekstowej (nazwa alfabetycznie z polskimi znakami):
```javascript
REJESTR_PRODUKTOW.sort((a, b) => a.nazwa.localeCompare(b.nazwa, "pl"));
```

**Po co to jest:**  
Zarządzanie kolekcjami obiektów jest sercem aplikacji internetowych. Każdy panel administracyjny, sklep online, platforma aukcyjna czy portal rezerwacyjny pobiera z serwera tablicę obiektów w formacie JSON i musi ją przefiltrować, posortować według wybranego kryterium (np. „od najtańszych”) oraz wygenerować czytelną listę dla użytkownika.

**Typowa pomyłka:**  
Pamiętaj, że metoda `sort()` **mutuje** (modyfikuje) oryginalną tablicę w miejscu. Ponadto odejmowanie `a.nazwa - b.nazwa` dla ciągów tekstowych da w wyniku wartość `NaN` i tablica nie zostanie posortowana. Dla liczb stosujemy odejmowanie `a.wartosc - b.wartosc`, a dla napisów metodę `a.tekst.localeCompare(b.tekst)`.

---

## 5. Wzorzec architektoniczny CKE: Zewnętrzny plik `dane.js`

W arkuszach egzaminacyjnych CKE oraz w profesjonalnych projektach frontendowych obowiązuje zasada separacji danych od logiki:
1. Dane testowe umieszczamy w osobnym pliku `dane.js` jako stałą w notacji wielkich liter (`const BAZA_ZAMOWIEN = [...]`).
2. W pliku `index.html` dołączamy najpierw zbiór danych, a dopiero potem skrypt operacyjny:
   ```html
   <script src="dane.js"></script>
   <script src="script.js"></script>
   ```
3. Skrypt `script.js` ma wówczas natychmiastowy dostęp do stałej globalnej zadeklarowanej w `dane.js`.

---

## 6. Standard wypisu wyników w Semestrze 2

Wszystkie wyniki przetwarzania danych prezentujemy na stronie w kontenerze `#wynik`:

```javascript
const kontener = document.getElementById("wynik");
kontener.textContent = raportTekstowy;
```

Dzięki stylowi CSS zadeklarowanemu w arkuszu:
```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
}
```
znaki nowej linii `\n` oraz wcięcia generowane za pomocą template literals (`` `...` ``) zostaną zachowane i wyświetlone dokładnie tak, jak w oknie terminala lub wydruku raportu.
