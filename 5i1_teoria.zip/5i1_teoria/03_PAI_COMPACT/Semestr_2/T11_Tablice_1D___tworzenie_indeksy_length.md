# Teoria: Tablice jednowymiarowe (1D) — tworzenie, indeksowanie i właściwość length

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Dlaczego potrzebujemy tablic? Wprowadzenie do kolekcji danych

Dotychczas w programach każdą pojedynczą informację przechowywaliśmy w osobnej zmiennej deklarowanej za pomocą słowa kluczowego `let` lub `const`. Takie podejście sprawdza się doskonale, gdy przetwarzamy imię jednego użytkownika, stawkę podatku VAT czy aktualną datę. Wyobraźmy sobie jednak sytuację, w której musimy zapisać wyniki pomiarów temperatury z całego miesiąca (30 wartości) albo listę cen produktów w koszyku zamówienia (100 pozycji).

Gdybyśmy chcieli stworzyć osobną zmienną dla każdej ceny (`cena1`, `cena2`, `cena3`, ..., `cena100`), nasz kod stałby się nieczytelny, podatny na błędy i niemożliwy do zautomatyzowania. Nie moglibyśmy łatwo przejść pętlą przez wszystkie zmienne ani sprawdzić, ile ich tak naprawdę jest.

Rozwiązaniem tego problemu w języku JavaScript jest **tablica jednowymiarowa** (`Array`) — uporządkowana lista wartości przechowywana pod jedną, wspólną nazwą zmiennej.

> **Po co to jest:**  
> Tablice pozwalają przechowywać setki lub tysiące powiązanych elementów w jednej strukturze danych i przetwarzać je automatycznie za pomocą pętli, bez konieczności ręcznego tworzenia dziesiątek zmiennych.

> **Typowa pomyłka:**  
> Próba nadawania zmiennym numerowanych nazw (np. `let uczen1`, `let uczen2`, `let uczen3`) zamiast utworzenia jednej tablicy `const uczniowie = [...]`. Kod z numerowanymi zmiennymi uniemożliwia iterację pętlą.

---

## 2. Tworzenie i inicjalizacja tablicy 1D

W języku JavaScript tablicę jednowymiarową można utworzyć na dwa główne sposoby. Zdecydowanie najpopularniejszym, najszybszym i zalecanym standardem jest **literał tablicowy** (ang. *array literal*), czyli nawiasy kwadratowe `[]`.

### Sposób 1: Literał tablicowy `[]` (standard zalecany)

Literał tablicowy pozwala stworzyć pustą tablicę lub od razu wypełnić ją wartościami początkowymi rozdzielonymi przecinkami:

```javascript
// Pusta tablica gotowa do wypełnienia
const zamowienia = [];

// Tablica liczb całkowitych (np. identyfikatory usług)
const kodyUslug = [101, 102, 108, 115, 120];

// Tablica łańcuchów tekstowych (np. nazwy dni roboczych)
const kategorie = ["Serwery", "Chmura", "Sieci", "Audyt"];

// Tablica mieszana (JavaScript dopuszcza różne typy, choć w praktyce dbamy o spójność)
const profilKlienta = ["Firma ABC", 12, true];
```

### Sposób 2: Konstruktor `new Array()`

Drugim sposobem jest wywołanie wbudowanego konstruktora `new Array()`:

```javascript
// Utworzenie tablicy z gotowymi elementami
const oceny = new Array(5, 4, 3, 5, 6);

// UWAGA: podanie pojedynczej liczby tworzy tablicę o zadanej długości z pustymi miejscami (tzw. dziury w pamięci)
const pustaTablica = new Array(5); // tablica o length = 5, ale bez przypisanych elementów
```

> **Po co to jest:**  
> Literał tablicowy `[]` to najkrótszy, najbardziej czytelny i pozbawiony niejednoznaczności sposób inicjalizacji tablicy w nowoczesnym kodzie JavaScript.

> **Typowa pomyłka:**  
> Zapisanie nawiasów klamrowych `{}` zamiast kwadratowych `[]`. Pamiętaj: nawiasy klamrowe `{}` tworzą obiekt ze słownikiem par klucz-wartość, natomiast nawiasy kwadratowe `[]` tworzą uporządkowaną indeksowaną tablicę.

---

## 3. Indeksowanie elementów — zasada zera

Każdy element umieszczony w tablicy otrzymuje automatycznie swój unikalny numer porządkowy, nazywany **indeksem** (ang. *index*). W języku JavaScript (podobnie jak w C++, C#, Javie czy Pythonie) tablice są indeksowane **od zera**:

- Pierwszy element ma indeks `0`.
- Drugi element ma indeks `1`.
- Trzeci element ma indeks `2`.
- Element o pozycji `N` ma indeks `N - 1`.

Aby odczytać wartość znajdującą się pod wybranym indeksem, po nazwie zmiennej tablicowej wpisujemy nawiasy kwadratowe z numerem indeksu w środku:

```javascript
const serwery = ["Web-01", "Database-01", "Backup-01", "Mail-01"];

const glownySerwer = serwery[0];   // "Web-01" (pierwszy element)
const bazaDanych = serwery[1];     // "Database-01" (drugi element)
const serwerPoczty = serwery[3];   // "Mail-01" (czwarty element)

console.log(glownySerwer); // wypisze: Web-01
```

### Dlaczego komputery liczą od zera? Mechanizm pamięci
Dla początkującego programisty liczenie od zera bywa nieintuicyjne. W architekturze komputerowej indeks tablicy to tak zwany **offset**, czyli przesunięcie względem adresu początku tablicy w pamięci operacyjnej RAM. Adres pierwszego elementu to dokładnie początek tablicy (przesunięcie równe `0` jednostek). Drugi element leży z przesunięciem `1` jednostki pamięci dalej, stąd indeks `1`.

> **Po co to jest:**  
> Indeks numeryczny pozwala komputerowi odnaleźć dowolny element w pamięci w czasie natychmiastowym $O(1)$, bez konieczności przeglądania całej listy od początku.

> **Typowa pomyłka:**  
> Próba pobrania pierwszego elementu za pomocą zapisu `tablica[1]`. Zapis `tablica[1]` pobiera drugi element kolekcji, a nie pierwszy! Pierwszy element zawsze ma indeks `0`.

---

## 4. Modyfikacja elementów tablicy

Tablica zadeklarowana ze słowem kluczowym `const` jest stałą referencją do kolekcji w pamięci, co oznacza, że nie możemy przypisać do tej zmiennej zupełnie nowej tablicy (`tablica = [1, 2]`), ale **możemy swobodnie modyfikować jej zawartość**:

```javascript
const statusy = ["NOWY", "W_TRAKCIE", "ZAKONCZONY"];

// Modyfikacja wartości drugiego elementu (indeks 1)
statusy[1] = "WSTRZYMANY";

console.log(statusy[1]); // wypisze: WSTRZYMANY
console.log(statusy);    // wypisze: ["NOWY", "WSTRZYMANY", "ZAKONCZONY"]
```

Możemy również przypisać wartość do nowego indeksu na końcu tablicy:

```javascript
statusy[3] = "ARCHIWALNY";
console.log(statusy.length); // wypisze: 4
```

> **Po co to jest:**  
> Bezpośrednie przypisanie `tablica[i] = nowaWartosc` pozwala aktualizować dane (np. zmieniać status zamówienia, aktualizować stan magazynowy produktu) bez konieczności ponownego przepisywania całej tablicy.

> **Typowa pomyłka:**  
> Przypisanie wartości do indeksu znacznie wyższego niż aktualny rozmiar tablicy (np. `tablica[100] = "alarm"` w tablicy 3-elementowej). W ten sposób w tablicy powstają tzw. „dziury” (`empty slots`), a odczyt pominiętych indeksów zwraca `undefined`.

---

## 5. Właściwość `length` i odczyt ostatniego elementu

Każda tablica w języku JavaScript posiada wbudowaną, automatycznie aktualizowaną właściwość **`length`**. Właściwość ta przechowuje całkowitą liczbę elementów znajdujących się w tablicy:

```javascript
const magazyn = ["Dysk SSD", "RAM DDR5", "Karta sieciowa", "Zasilacz"];

console.log(magazyn.length); // wypisze: 4
```

### Relacja między indeksem ostatniego elementu a właściwością `length`
Skoro elementy są numerowane od `0`, to:
- Przy długości `length = 1`, jedyny element znajduje się pod indeksem `0`.
- Przy długości `length = 4`, elementy mają indeksy `0, 1, 2, 3`.
- W tablicy o dowolnej długości ostatni element **zawsze ma indeks `length - 1`**.

Wzorzec bezpiecznego odczytu ostatniego elementu tablicy:
```javascript
const ostatniTowar = magazyn[magazyn.length - 1]; // "Zasilacz"
```

### Sprawdzanie, czy tablica jest pusta
Aby upewnić się, że tablica nie zawiera elementów, sprawdzamy warunek:
```javascript
if (magazyn.length === 0) {
  console.log("Magazyn jest pusty!");
} else {
  console.log(`Liczba pozycji w magazynie: ${magazyn.length}`);
}
```

> **Po co to jest:**  
> Właściwość `length` pozwala pętlom i algorytmom dokładnie wiedzieć, ile danych znajduje się w strukturze, bez konieczności ręcznego zliczania elementów przez programistę.

> **Typowa pomyłka:**  
> Zapis `tablica[tablica.length]` w celu pobrania ostatniego elementu. Taki zapis zawsze zwróci `undefined`, ponieważ element o indeksie równym `length` leży już poza zakresem tablicy (indeksy kończą się na `length - 1`).

---

## 6. Przekroczenie zakresu i wartość `undefined`

W przeciwieństwie do języków takich jak C++ czy Java, gdzie próba odwołania się do nieistniejącego indeksu powoduje błąd wykonania programu (ang. *IndexOutOfBoundsException*), JavaScript zachowuje się elastycznie i w przypadku odwołania do indeksu spoza zakresu zwraca wartość **`undefined`**:

```javascript
const dni = ["Pn", "Wt", "Śr"];

console.log(dni[10]);  // wypisze: undefined (brak błędu!)
console.log(dni[-1]);  // wypisze: undefined
```

Dzięki temu program nie ulega nagłemu zatrzymaniu, jednak niezamierzone odczytanie `undefined` może prowadzić do subtelnych błędów w obliczeniach (np. `undefined + 5` daje w wyniku `NaN`).

> **Po co to jest:**  
> Wartość `undefined` chroni aplikację przed natychmiastową awarią i pozwala programiście sprawdzić warunkiem `if (tablica[i] !== undefined)`, czy element o danym numerze istnieje.

> **Typowa pomyłka:**  
> Założenie, że `tablica[-1]` pobiera ostatni element (wzorzec z języka Python). W JavaScript zapis w nawiasach kwadratowych traktuje `-1` jak zwykłą nieistniejącą właściwość tekstową i zwraca `undefined`.

---

## 7. Jak sprawdzić, czy zmienna jest tablicą? `Array.isArray()`

Operator `typeof` dla tablicy zwraca ogólny napis `"object"`, ponieważ w architekturze języka JavaScript tablice są wyspecjalizowanymi obiektami:

```javascript
const lista = [10, 20, 30];
console.log(typeof lista); // wypisze: "object" (mało precyzyjne!)
```

Aby w 100% pewnie sprawdzić, czy dana zmienna jest faktycznie tablicą, używamy wbudowanej metody statycznej **`Array.isArray()`**:

```javascript
console.log(Array.isArray(lista)); // wypisze: true
console.log(Array.isArray("tekst")); // wypisze: false
console.log(Array.isArray(123));     // wypisze: false
```

> **Po co to jest:**  
> Metoda `Array.isArray()` zabezpiecza funkcje przed próbą iterowania po zmiennych, które nie są tablicami (np. gdy ktoś przekazał liczbę zamiast listy).

> **Typowa pomyłka:**  
> Sprawdzanie `typeof zmienna === "array"`. Taki warunek nigdy nie będzie spełniony, ponieważ `typeof` nigdy nie zwraca słowa `"array"`.

---

## 8. Iteracja po tablicy: pętla `for` oraz `for...of`

Przetwarzanie tablicy polega najczęściej na przejściu przez wszystkie jej elementy po kolei (tzw. iteracja). W zależności od tego, czy potrzebujemy znać numer indeksu, stosujemy dwa podstawowe mechanizmy.

### Wariant 1: Klasyczna pętla `for` ze zmienną indeksującą (kanon egzaminacyjny CKE)

W tym wariancie zmienna sterująca `let i = 0` przyjmuje kolejne indeksy od `0` do `tablica.length - 1`:

```javascript
const stawki = [120, 150, 180, 220];

for (let i = 0; i < stawki.length; i++) {
  console.log(`Pozycja ${i + 1} (indeks ${i}): stawka wynosi ${stawki[i]} PLN`);
}
```

Zalety klasycznej pętli `for`:
- Mamy pełny dostęp do numeru bieżącego indeksu `i`.
- Możemy modyfikować elementy w trakcie pętli (`stawki[i] = stawki[i] * 1.1`).
- Możemy iść co drugi element (`i += 2`) lub od tyłu (`let i = tablica.length - 1; i >= 0; i--`).

### Wariant 2: Pętla `for...of` (nowoczesna iteracja bezpośrednia)

Gdy interesują nas wyłącznie same wartości elementów, a nie ich numery indeksów, możemy użyć pętli `for...of`:

```javascript
const miasta = ["Warszawa", "Kraków", "Gdańsk", "Poznań"];

for (const miasto of miasta) {
  console.log(`Obszar wdrożenia: ${miasto}`);
}
```

> **Po co to jest:**  
> Pętle automatyzują powtarzalne czynności na zbiorach danych — umożliwiają przeszukiwanie, formatowanie i kalkulację na milionach wpisów w ułamku sekundy.

> **Typowa pomyłka:**  
> Użycie warunku `i <= tablica.length` zamiast `i < tablica.length` w klasycznej pętli `for`. W ostatnim kroku pętla spróbuje odczytać `tablica[tablica.length]`, co da wartość `undefined` i może zaburzyć obliczenia!

---

## 9. Klasyczne algorytmy tablicowe w praktyce

W zadaniach praktycznych oraz arkuszach egzaminacyjnych CKE operacje na tablicach 1D sprowadzają się do czterech fundamentalnych algorytmów.

### Algorytm 1: Sumowanie elementów i obliczanie średniej arytmetycznej

Inicjalizujemy zmienną akumulatora przed pętlą na `0`, a wewnątrz pętli dodajemy każdy element:

```javascript
function obliczSumeISrednia(liczby) {
  if (liczby.length === 0) {
    return "Brak danych do obliczeń.";
  }

  let suma = 0;
  for (let i = 0; i < liczby.length; i++) {
    suma += liczby[i];
  }

  const srednia = suma / liczby.length;
  return `Suma: ${suma.toFixed(2)}, Średnia: ${srednia.toFixed(2)}`;
}

const pomiary = [12.5, 14.0, 15.5, 13.0, 16.0];
console.log(obliczSumeISrednia(pomiary));
```

### Algorytm 2: Zliczanie elementów spełniających warunek progowy

Zmienna licznikowa zwiększa się tylko wtedy, gdy sprawdzany element spełnia warunek `if`:

```javascript
function zliczZgloszeniaPilne(czasyReakcji, progPilnosci) {
  let licznik = 0;

  for (const czas of czasyReakcji) {
    if (czas <= progPilnosci) {
      licznik++;
    }
  }

  return `Liczba zgłoszeń priorytetowych: ${licznik} z ${czasyReakcji.length}`;
}

const czasy = [45, 120, 30, 240, 15, 60];
console.log(zliczZgloszeniaPilne(czasy, 60)); // poniżej lub równe 60 min
```

### Algorytm 3: Wyszukiwanie wartości minimalnej i maksymalnej

Jako punkt startowy przyjmujemy pierwszy element tablicy (`tablica[0]`), a następnie porównujemy z nim kolejne elementy:

```javascript
function znajdzEkstrema(wartosci) {
  if (wartosci.length === 0) return "Pusta tablica.";

  let min = wartosci[0];
  let max = wartosci[0];

  for (let i = 1; i < wartosci.length; i++) {
    if (wartosci[i] < min) {
      min = wartosci[i];
    }
    if (wartosci[i] > max) {
      max = wartosci[i];
    }
  }

  return `Wartość minimalna: ${min}, maksymalna: ${max}`;
}

const zuzycie = [450, 120, 890, 320, 750];
console.log(znajdzEkstrema(zuzycie));
```

> **Po co to jest:**  
> Wzorzec akumulatora (`suma += ...`), licznika (`licznik++`) oraz szukania ekstremów to fundament wszelkiej analityki biznesowej w aplikacjach internetowych (wykresy, podsumowania koszyka, wskaźniki SLA).

> **Typowa pomyłka:**  
> Inicjalizacja zmiennej `min` wartością `0` przed szukaniem minimum w tablicy liczb dodatnich. Jeśli wszystkie liczby w tablicy są większe od zera (np. `[10, 20, 30]`), algorytm błędnie zwróci `0`, mimo że zera w ogóle nie było w tablicy! Wartością startową dla `min` i `max` musi być zawsze `tablica[0]`.

---

## 10. Wzorzec CKE: Gotowe zbiory danych w pliku `dane.js`

W standardzie egzaminacyjnym INF.03 oraz w zadaniach integrujących w szkole często rozdziela się dane od logiki aplikacji. Dane testowe (np. cennik, katalog usług, rejestr pomiarów) umieszcza się w osobnym pliku `dane.js` pod nazwą stałej pisanej w konwencji `UPPER_SNAKE_CASE`.

Struktura plików w projekcie:
```text
zadanie/
├── index.html
├── dane.js
├── script.js
└── style.css
```

Dołączanie skryptów w dokumencie `index.html` (kolejność ma kluczowe znaczenie):
```html
<!-- KROK 1: Najpierw ładujemy plik z danymi -->
<script src="dane.js"></script>

<!-- KROK 2: Następnie ładujemy skrypt logiczny, który korzysta ze stałych z dane.js -->
<script src="script.js"></script>
```

Zawartość pliku `dane.js`:
```javascript
const REJESTR_TEMPERATUR = [19.5, 21.0, 22.4, 20.8, 18.9, 23.1];
```

Zawartość pliku `script.js`:
```javascript
// Stała REJESTR_TEMPERATUR jest natychmiast dostępna, ponieważ dane.js załadował się wcześniej!
console.log(`Wczytano pomiarów: ${REJESTR_TEMPERATUR.length}`);
```

> **Po co to jest:**  
> Rozdzielenie danych od logiki pozwala na wygodną aktualizację bazy danych testowych bez ingerencji w kod algorytmów i symuluje profesjonalną architekturę oprogramowania.

> **Typowa pomyłka:**  
> Dołączenie pliku `script.js` przed plikiem `dane.js` w pliku HTML. Jeśli `script.js` zostanie załadowany pierwszy, przeglądarka zgłosi błąd `ReferenceError: REJESTR_... is not defined`, ponieważ stała jeszcze nie istnieje w pamięci.

---

## 11. Rygor wyjścia danych w Semestrze 2

Zgodnie ze standardem drugiego semestru kwalifikacji INF.03, wszystkie wyniki pracy programu prezentujemy w elemencie o identyfikatorze `wynik` za pomocą właściwości `textContent`. W arkuszu stylów CSS element ten ma zdefiniowaną regułę `white-space: pre-wrap;`, co pozwala na zachowanie znaków nowej linii (`\n`) i czytelnych wcięć tabelarycznych:

```javascript
// Budowanie czytelnego raportu tekstowego
let raport = "=== RAPORT INWENTARYZACJI SERWERÓW ===\n\n";

for (let i = 0; i < serwery.length; i++) {
  raport += `${i + 1}. Identyfikator: ${serwery[i]}\n`;
}

raport += `\nŁącznie zarejestrowanych serwerów: ${serwery.length}`;

// Wypis do DOM oraz do konsoli deweloperskiej
document.getElementById("wynik").textContent = raport;
console.log(raport);
```

Styl w pliku `style.css`:
```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
  background-color: #f4f6f8;
  padding: 16px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
}
```

> **Po co to jest:**  
> Właściwość `textContent` jest w 100% bezpieczna przed atakami typu XSS (ang. *Cross-Site Scripting*), a reguła CSS `white-space: pre-wrap;` pozwala tworzyć estetyczne, czytelne raporty blokowe bez używania znaczników `<br>` czy `<table>`.

> **Typowa pomyłka:**  
> Stosowanie `innerHTML` i znaczników `<br>` do formatowania tekstu. W semestrze 2 obowiązuje rygor `textContent` oraz znaków `\n`.

---

## 12. Okno `prompt()` oraz zapis liczb w raporcie

Część zadań prosi o jedną daną od użytkownika. Funkcja `prompt()` otwiera okno dialogowe i **zawsze zwraca tekst** (albo `null`, gdy użytkownik kliknie „Anuluj”). Drugi argument to wartość domyślna, również tekstowa. Wywołanie stoi poza ciałem funkcji, tak jak w pozostałych modułach semestru 2:

```javascript
const surowyProg = prompt("Podaj próg temperatury:", "22.5");
const prog = parseFloat(surowyProg); // z tekstu "22.5" powstaje liczba 22.5
```

Dopóki wartość jest tekstem, porównanie `pomiar > surowyProg` nie ma sensu arytmetycznego. Dlatego przed pętlą zamieniamy odczyt na liczbę funkcją `parseFloat()`.

Osobną sprawą jest **wygląd liczby w raporcie**. Złączenie liczby z tekstem korzysta z jej zwykłego zapisu: liczba `15` w szablonie `` `${limit} kg` `` daje napis `15 kg`, a nie `15.0 kg`. Metoda `toFixed` zwraca tekst z ustaloną liczbą miejsc po przecinku:

```javascript
const limit = parseFloat("15.0");
limit.toFixed(1); // "15.0"
(120.8).toFixed(2); // "120.80"
(-20).toFixed(1); // "-20.0"
(-25).toFixed(1); // "-25.0"
```

`toFixed` wywołujemy dopiero przy składaniu raportu. Do porównań i do sumy zostawiamy zwykłe liczby.

> **Po co to jest:**  
> Okno dialogowe zbiera jedną wartość od użytkownika, a `parseFloat` oraz `toFixed` rozdzielają dwie czynności: liczenie na liczbach i pokazanie tych liczb w ustalonym formacie.

> **Typowa pomyłka:**  
> Wypisanie limitu bez `toFixed(1)`. Uczeń widzi w przykładzie `15.0 kg` albo `-20.0°C`, a na stronie dostaje `15 kg` albo `-20°C`, bo JavaScript przy sklejaniu tekstu obcina końcowe zero.
