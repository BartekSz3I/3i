# Teoria: Obliczenia i formatowanie dat w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Wprowadzenie: Czas jako dynamiczna wartość w aplikacji

W codziennej pracy programisty tworzącego aplikacje webowe samo pobranie aktualnego roku czy godziny to zaledwie punkt wyjścia. Użytkownicy sklepów internetowych oczekują informacji o przewidywanej dacie doręczenia przesyłki (np. „za 3 dni robocze”), klienci wypożyczalni samochodów muszą znać dokładny koszt wyliczony z różnicy godzin między odbiorem a zwrotem pojazdu, a panele administracyjne stale monitorują czas pozostały do wygaśnięcia sesji lub naruszenia warunków gwarancji (SLA).

W języku JavaScript obiekt `Date` wyposażony jest w zestaw mechanizmów pozwalających na swobodne przesuwanie punktów na osi czasu, obliczanie dystansu czasowego między zdarzeniami oraz prezentowanie rezultatów w formatach akceptowalnych dla człowieka. W niniejszym rozdziale poznamy reguły rządzące arytmetyką dat oraz techniki ich niezawodnego formatowania.

---

## 2. Tworzenie obiektów `Date` ze zdefiniowanymi parametrami

Aby móc wykonywać operacje na konkretnych datach z przeszłości lub przyszłości, musimy utworzyć instancję obiektu `Date`, przekazując do konstruktora precyzyjne wartości liczbowe reprezentujące poszczególne składowe kalendarzowe:

```javascript
// Składnia pełna: new Date(rok, indeksMiesiaca, dzien, godzina, minuta, sekunda, milisekunda)
const terminZlecenia = new Date(2026, 9, 25, 14, 30); // 25 października 2026, godz. 14:30
console.log(terminZlecenia);
```

Parametry konstruktora podawane są od lewej do prawej, w kolejności od jednostki największej do najmniejszej:
1. `rok` — pełny rok w postaci czterocyfrowej liczby (np. `2026`).
2. `indeksMiesiaca` — liczba całkowita z przedziału od `0` do `11` (gdzie `0` to styczeń, a `11` to grudzień).
3. `dzien` — dzień miesiąca z przedziału od `1` do `31`.
4. `godzina`, `minuta`, `sekunda`, `milisekunda` — opcjonalne wartości czasu (domyślnie przyjmują wartość `0`, jeśli zostaną pominięte).

Alternatywnie możemy zainicjalizować datę na podstawie tekstowego łańcucha znaków w standardzie ISO:

```javascript
const startPromocji = new Date("2026-10-25T14:30:00");
```

**Po co to jest:**  
Konstruktor parametryczny pozwala aplikacji operować na precyzyjnie określonych zdarzeniach w harmonogramie (np. dacie złożenia zamówienia zapisanej w bazie danych czy terminie spotkania wprowadzonym przez użytkownika), zamiast ograniczać się wyłącznie do chwili obecnej.

**Typowa pomyłka:**  
Najczęstszym błędem początkujących programistów jest podanie numeru miesiąca zgodnie z tradycyjnym kalendarzem (np. `10` dla października). W języku JavaScript wartość `10` w konstruktorze liczbowym oznacza **listopad** (ponieważ miesiące są indeksowane od `0`). Aby ustawić październik, należy przekazać wartość `9`.

---

## 3. Modyfikacja składowych daty (metody `set*`) i mechanizm przepełnienia

Obiekt `Date` jest strukturą mutowalną, co oznacza, że możemy zmieniać poszczególne jego elementy po utworzeniu, korzystając z rodziny metod rozpoczynających się od przedrostka `set`:
- `setFullYear(rok)` — ustawia rok (może opcjonalnie przyjąć również miesiąc i dzień).
- `setMonth(miesiac)` — ustawia miesiąc (0–11).
- `setDate(dzien)` — ustawia dzień miesiąca (1–31).
- `setHours(godzina)` — ustawia godzinę (0–23).
- `setMinutes(minuta)` — ustawia minuty (0–59).
- `setSeconds(sekunda)` — ustawia sekundy (0–59).

### Magia automatycznej normalizacji (Rollover)

Co się stanie, jeśli do bieżącego dnia dodamy liczbę dni, która przekracza długość trwającego miesiąca? Silnik JavaScript realizuje automatyczną normalizację:

```javascript
const terminDostawy = new Date(2026, 9, 28); // 28 października 2026
// Dodajemy 7 dni roboczych:
terminDostawy.setDate(terminDostawy.getDate() + 7);

console.log(terminDostawy.getMonth()); // 10 -> listopad!
console.log(terminDostawy.getDate());  // 4 -> 4 listopada 2026
```

Wartość `28 + 7 = 35`. Ponieważ październik ma 31 dni, JavaScript automatycznie przeskakuje do następnego miesiąca (listopada) i przypisuje dzień `4` (`35 - 31`). Mechanizm ten działa analogicznie przy odejmowaniu dni (przeskok do poprzedniego miesiąca) oraz przy modyfikacji godzin i minut.

**Po co to jest:**  
Mechanizm automatycznego przepełnienia uwalnia programistę od konieczności ręcznego sprawdzania w instrukcjach warunkowych, ile dni ma dany miesiąc, czy luty ma 28 czy 29 dni w roku przestępnym i kiedy przypada zmiana roku kalendarzowego. Wystarczy pobrać składową metodą `getDate()`, dodać wymaganą liczbę i zapisać wynik przez `setDate()`.

**Typowa pomyłka:**  
Mylenie metody `setDate()` z metodą `setDay()`. Metoda `setDay` **nie istnieje** w JavaScript, ponieważ dzień tygodnia (`getDay()`) jest wartością wynikową zależną od daty kalendarzowej i nie może być modyfikowany bezpośrednio. Do zmiany dnia miesiąca służy wyłącznie `setDate()`.

---

## 4. Znaczniki czasu w milisekundach (`getTime` i `Date.now`)

Każda data w pamięci komputera może zostać sprowadzona do pojedynczej liczby całkowitej — liczby milisekund, które upłynęły od północy 1 stycznia 1970 roku czasu uniwersalnego (początek tzw. ery Uniksa, ang. *Unix Epoch*).

Do odczytu tej wartości służą dwie metody:
1. `instancjaDaty.getTime()` — zwraca liczbę milisekund dla danego obiektu daty.
2. `Date.now()` — metoda statyczna zwracająca bieżący znacznik czasu komputera w milisekundach (bez konieczności tworzenia obiektu przez `new Date()`).

```javascript
const teraz = Date.now();
const dataKonkretna = new Date(2026, 9, 1);
const msOdEpoki = dataKonkretna.getTime();

console.log(msOdEpoki); // np. 1790805600000
```

**Po co to jest:**  
Znacznik czasu w milisekundach jest najbardziej uniwersalnym, bezstronnym i łatwym do porównywania formatem czasu. Zamiast porównywać osobno lata, miesiące i dni, wystarczy porównać dwie liczby: `dataA.getTime() > dataB.getTime()`.

**Typowa pomyłka:**  
Próba formatowania surowego znacznika czasu do wyświetlenia użytkownikowi. Liczba `1790805600000` jest całkowicie nieczytelna dla człowieka i służy wyłącznie do obliczeń wewnątrz skryptu.

---

## 5. Różnica czasu: Dekompozycja milisekund na dni, godziny i minuty

Gdy odejmiemy od siebie dwa obiekty daty lub ich znaczniki czasu, wynikiem jest różnica wyrażona w milisekundach:

```javascript
const terminRozpoczecia = new Date(2026, 9, 20, 10, 0);
const terminZakonczenia = new Date(2026, 9, 23, 16, 30);

const roznicaMs = terminZakonczenia - terminRozpoczecia; 
// Równoważne: terminZakonczenia.getTime() - terminRozpoczecia.getTime();
console.log(roznicaMs); // 282 600 000 ms
```

Aby przeliczyć tę surową liczbę na jednostki zrozumiałe dla człowieka, stosujemy stałe przeliczeniowe:
- $1\text{ s} = 1000\text{ ms}$
- $1\text{ min} = 60 \cdot 1000 = 60\,000\text{ ms}$
- $1\text{ h} = 60 \cdot 60 \cdot 1000 = 3\,600\,000\text{ ms}$
- $1\text{ d} = 24 \cdot 60 \cdot 60 \cdot 1000 = 86\,400\,000\text{ ms}$

### Algorytm dekompozycji na pełne dni, godziny i minuty

Najczęstszym zadaniem w panelach zgłoszeń jest rozbicie całkowitego czasu na składowe: „Upłynęło: X dni, Y godzin i Z minut”:

```javascript
function dekomponujCzas(roznicaMs) {
  const MS_W_DNIU = 1000 * 60 * 60 * 24;
  const MS_W_GODZINIE = 1000 * 60 * 60;
  const MS_W_MINUCIE = 1000 * 60;

  // 1. Obliczamy pełne dni i odejmujemy je z puli:
  const dni = Math.floor(roznicaMs / MS_W_DNIU);
  let reszta = roznicaMs % MS_W_DNIU;

  // 2. Z pozostałego czasu wyliczamy pełne godziny:
  const godziny = Math.floor(reszta / MS_W_GODZINIE);
  reszta = reszta % MS_W_GODZINIE;

  // 3. Z kolejnej reszty wyliczamy minuty:
  const minuty = Math.floor(reszta / MS_W_MINUCIE);

  return `${dni} dni, ${godziny} godz., ${minuty} min.`;
}
```

**Po co to jest:**  
Dekompozycja różnicy czasowej jest fundamentem systemów fakturowania usług serwisowych, rozliczania czasu pracy (ang. *timesheet*), wypożyczalni sprzętu oraz prezentowania liczników czasu pozostałego do końca promocji.

**Typowa pomyłka:**  
Stosowanie zaokrąglenia matematycznego `Math.round()` zamiast obcinania w dół `Math.floor()`. Użycie `Math.round()` sprawia, że upływ 1 dnia i 18 godzin zostanie błędnie zaklasyfikowany jako 2 pełne dni, co prowadzi do błędów rachunkowych i fałszywych naliczeń.

---

## 6. Weryfikacja terminowości i statusów SLA

W systemach obsługi klienta kluczowe znaczenie ma weryfikacja, czy zlecenie zostało zrealizowane przed upływem gwarantowanego czasu naprawy (SLA — ang. *Service Level Agreement*):

```javascript
function sprawdzStatusZlecenia(dataZgloszenia, czasSlaGodziny) {
  // Tworzymy kopię daty zgłoszenia, aby nie mutować oryginału:
  const terminSla = new Date(dataZgloszenia.getTime());
  terminSla.setHours(terminSla.getHours() + czasSlaGodziny);

  const teraz = new Date();
  const roznicaMs = terminSla - teraz;

  if (roznicaMs < 0) {
    const spoznienieMs = Math.abs(roznicaMs);
    const spoznienieGodz = Math.floor(spoznienieMs / (1000 * 60 * 60));
    return `ZLECENIE PRZETERMINOWANE! Opóźnienie: ${spoznienieGodz} godz.`;
  } else {
    const pozostaloGodz = Math.floor(roznicaMs / (1000 * 60 * 60));
    return `Zlecenie w normie SLA. Pozostało: ${pozostaloGodz} godz.`;
  }
}
```

**Po co to jest:**  
Logika badania znaku różnicy (`roznicaMs < 0`) pozwala na automatyczną kategoryzację zgłoszeń, alarmowanie administratorów o zagrożonych terminach oraz dynamiczne generowanie raportów sprawności zespołu.

**Typowa pomyłka:**  
Modyfikowanie oryginalnego obiektu daty zgłoszenia (`dataZgloszenia.setHours(...)`) bez uprzedniego sklonowania instancji (`new Date(dataZgloszenia.getTime())`). Sprawia to, że w dalszej części programu data zarejestrowania zlecenia bezpowrotnie przepada, zastąpiona wyliczonym terminem granicznym.

---

## 7. Formatowanie daty: Dopełnianie zerami wiodącymi (`padStart`)

W standardzie europejskim i polskim daty prezentowane są w postaci dwucyfrowych liczb oddzielonych kropkami lub dywizami (np. `09.05.2026`, a nie `9.5.2026`). Ponieważ metody `getDate()`, `getMonth()` czy `getHours()` zwracają pojedyncze liczby (od `0` do `9`), przed wyświetleniem musimy uzupełnić je o zero wiodące.

W nowoczesnym JavaScript najprostszą i najbardziej czytelną metodą jest funkcja `padStart(docelowaDlugosc, znakUzupelniajacy)` z obiektu `String`:

```javascript
function formatujDateISO(data) {
  const rok = data.getFullYear();
  // Pamiętamy o dodaniu 1 do miesiąca!
  const miesiac = String(data.getMonth() + 1).padStart(2, "0");
  const dzien = String(data.getDate()).padStart(2, "0");
  const godzina = String(data.getHours()).padStart(2, "0");
  const minuta = String(data.getMinutes()).padStart(2, "0");

  return `${rok}-${miesiac}-${dzien} ${godzina}:${minuta}`;
}

const dataTestowa = new Date(2026, 4, 9, 8, 5); // 9 maja 2026, godz. 08:05
console.log(formatujDateISO(dataTestowa)); // "2026-05-09 08:05"
```

### Mapowanie słowne: Tablice Lookup

W wielu dokumentach urzędowych wymagane jest podanie słownej nazwy miesiąca lub dnia tygodnia. Zamiast rozbudowanych instrukcji `switch`, w JavaScript stosujemy zwięzłe tablice pomocnicze indeksowane bezpośrednio wartościami liczbowymi z metod `getMonth()` i `getDay()`:

```javascript
const NAZWY_MIESIECY = [
  "stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca",
  "lipca", "sierpnia", "września", "października", "listopada", "grudnia"
];

const NAZWY_DNI = [
  "niedziela", "poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota"
];

const dataDzialania = new Date(2026, 9, 18);
const dzienTygodnia = NAZWY_DNI[dataDzialania.getDay()];
const dzienMiesiaca = dataDzialania.getDate();
const nazwaMiesiaca = NAZWY_MIESIECY[dataDzialania.getMonth()];
const rok = dataDzialania.getFullYear();

console.log(`${dzienTygodnia}, ${dzienMiesiaca} ${nazwaMiesiaca} ${rok} r.`);
// "niedziela, 18 października 2026 r."
```

**Po co to jest:**  
Formatowanie z zerami wiodącymi zapewnia stałą szerokość prezentowanych kolumn w raportach i tabelach, eliminuje dwuznaczności oraz zapobiega błędom w parsowaniu dat przez zewnętrzne systemy IT. Tablice słownikowe (lookup) sprawiają z kolei, że komunikaty generowane dla polskiego klienta brzmią w pełni profesjonalnie i naturalnie.

**Typowa pomyłka:**  
Wywołanie metody `.padStart()` bezpośrednio na liczbie, np. `data.getDate().padStart(2, "0")`. Metoda `padStart` jest metodą wbudowanego typu `String`. Przed jej wywołaniem liczbę należy bezwzględnie przekonwertować na ciąg tekstowy za pomocą funkcji `String(...)` lub metody `.toString()`.

### Kwoty pieniężne: dwa miejsca po przecinku (`toFixed`)

Przy naliczaniu opłat (np. kara × stawka dzienna) wynik mnożenia bywa liczbą zmiennoprzecinkową. Do prezentacji kwoty w raporcie stosujemy metodę liczby `toFixed(2)`, która zwraca **napis** z dokładnie dwoma cyframi po kropce:

```javascript
const kara = 8 * 2.5;           // 20
const karaTekst = kara.toFixed(2); // "20.00"
```

**Typowa pomyłka:**  
Traktowanie wyniku `toFixed(2)` jak liczby — dalsze działania arytmetyczne wykonuj na wartości liczbowej *przed* formatowaniem; do raportu wstawiaj już gotowy napis.

---

## 8. Standard wyjścia na stronę w Semestrze 2

Przypominamy żelazną zasadę prezentacji danych obowiązującą w semestrze 2: wszelkie rezultaty wypisujemy do dedykowanego kontenera o identyfikatorze `#wynik` za pomocą właściwości `textContent`. Aby zachować formatowanie wieloliniowych zestawień tabelarycznych i raportów tekstowych, kontener ten posiada w arkuszu stylów regułę `white-space: pre-wrap`:

```javascript
// Bezpieczny, czytelny wypis raportu:
const kontener = document.getElementById("wynik");
kontener.textContent = raportTekstowy;
```

Stosowanie właściwości `textContent` gwarantuje pełne bezpieczeństwo kodu (odporność na ataki typu XSS) oraz uczy dyscypliny w formatowaniu czystych ciągów tekstowych.
