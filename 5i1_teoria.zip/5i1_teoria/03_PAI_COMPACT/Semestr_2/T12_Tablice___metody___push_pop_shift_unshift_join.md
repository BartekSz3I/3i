# Teoria: Metody tablicowe — push, pop, shift, unshift, join

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Wprowadzenie: dynamiczna natura tablic w JavaScript

W poprzednim module poznaliśmy tablice jednowymiarowe jako uporządkowane kolekcje danych. Wiemy już, jak tworzyć tablice za pomocą literału `[]`, jak odczytywać i modyfikować elementy za pomocą indeksów numerycznych oraz jak kontrolować ich rozmiar za pośrednictwem właściwości `length`.

W praktyce tworzenia aplikacji internetowych zbiory danych rzadko pozostają niezmienne. Klienci sklepu internetowego dodają produkty do koszyka i z nich rezygnują, zgłoszenia serwisowe trafiają do kolejki oczekujących na pomoc, a logi systemowe stale powiększają się o nowe komunikaty. Ręczne przeliczanie indeksów i przypisywanie elementów (np. `tablica[tablica.length] = wartosc`) jest uciążliwe i podatne na błędy.

Język JavaScript wyposaża tablice w zestaw wbudowanych metod, które pozwalają na bezpieczne, czytelne i zautomatyzowane modyfikowanie zawartości tablicy od jej początku oraz końca.

---

## 2. Dodawanie elementów: metody push() i unshift()

### 2.1. Metoda push() — wstawianie na koniec tablicy

Metoda `push()` dodaje jeden lub więcej elementów na sam koniec tablicy. W wyniku jej wywołania oryginalna tablica zostaje powiększona (zmutowana), a metoda zwraca nową długość tablicy (`length`).

```javascript
const koszyk = ['Klawiatura', 'Mysz bezprzewodowa'];

// Dodajemy nowy produkt na koniec koszyka
const nowaDlugosc = koszyk.push('Podkładka ergonomiczna');

console.log(koszyk); 
// Wypis: ['Klawiatura', 'Mysz bezprzewodowa', 'Podkładka ergonomiczna']

console.log(nowaDlugosc); 
// Wypis: 3
```

> **Po co to jest:**  
> Metoda `push()` jest najczęściej stosowanym sposobem powiększania kolekcji. Używamy jej za każdym razem, gdy pojawia się nowy rekord: dopisanie kolejnego punktu na liście zadań, dodanie towaru do paragonu czy rejestracja nowego pomiaru temperatury.
>
> **Typowa pomyłka:**  
> Początkujący programiści często zapominają, czym jest wartość zwracana przez `push()`. Zapis `const wynik = koszyk.push('Monitor');` nie przypisze do zmiennej `wynik` zmodyfikowanej tablicy ani dodanego napisu, lecz liczbę całkowitą oznaczającą nowy rozmiar tablicy.

---

### 2.2. Metoda unshift() — wstawianie na początek tablicy

Metoda `unshift()` wstawia podany element na zerową pozycję tablicy (indeks `0`). Aby zrobić miejsce na nową wartość, JavaScript automatycznie przesuwa wszystkie dotychczasowe elementy o jeden indeks w prawo (element spod indeksu 0 trafia na 1, z 1 na 2 itd.). Podobnie jak `push()`, metoda `unshift()` zwraca nową długość tablicy.

```javascript
const powiadomienia = ['Aktualizacja systemu o 22:00', 'Nowa wiadomość od administratora'];

// Dodajemy pilny alert na sam początek listy
const liczbaWpisow = powiadomienia.unshift('AWARIA ZASILANIA — TRYB AWARYJNY');

console.log(powiadomienia[0]); 
// Wypis: 'AWARIA ZASILANIA — TRYB AWARYJNY'

console.log(liczbaWpisow); 
// Wypis: 3
```

> **Po co to jest:**  
> Metoda `unshift()` jest niezastąpiona, gdy nowy element ma najwyższy priorytet i musi znaleźć się na czele stawki — np. pilny komunikat ostrzegawczy na portalu informacyjnym, zamówienie z płatną dostawą ekspresową VIP czy najświeższy wpis w kanale wiadomości.
>
> **Typowa pomyłka:**  
> Złożoność operacji: w przeciwieństwie do `push()`, który dopisuje wartość na końcu, `unshift()` zmusza silnik przeglądarki do przenumerowania indeksów wszystkich istniejących elementów. W małych tablicach różnica jest niezauważalna, ale warto rozumieć mechanizm tego przesunięcia.

---

## 3. Usuwanie elementów: metody pop() i shift()

### 3.1. Metoda pop() — usuwanie z końca tablicy

Metoda `pop()` usuwa dokładnie jeden element z końca tablicy. Zmniejsza właściwość `length` o 1 oraz — co kluczowe — **zwraca usuniętą wartość**. Jeśli tablica była pusta, wywołanie `pop()` zwraca `undefined`.

```javascript
const stosDokumentow = ['Umowa nr 1', 'Faktura 12/2026', 'Protokół odbioru'];

// Zdejmujemy ostatnio odłożony dokument
const zdjetyDokument = stosDokumentow.pop();

console.log(zdjetyDokument); 
// Wypis: 'Protokół odbioru'

console.log(stosDokumentow); 
// Wypis: ['Umowa nr 1', 'Faktura 12/2026']
```

> **Po co to jest:**  
> Metoda `pop()` pozwala nie tylko skrócić tablicę, ale przede wszystkim pobrać ostatni element do natychmiastowej obsługi. To podstawa operacji cofania zmian (funkcja *Cofnij / Undo* w edytorach tekstu i programach graficznych), gdzie ostatnio wykonany krok jest anulowany jako pierwszy.
>
> **Typowa pomyłka:**  
> Przekazywanie argumentu do metody `pop(element)` lub `pop(indeks)`. Metoda `pop()` nie przyjmuje żadnych argumentów — zawsze usuwa bezwzględnie ostatni element.

---

### 3.2. Metoda shift() — usuwanie z początku tablicy

Metoda `shift()` usuwa pierwszy element tablicy (indeks `0`), przesuwa wszystkie pozostałe elementy w lewo (ich indeksy maleją o 1) i zwraca usuniętą wartość. W przypadku pustej tablicy zwraca `undefined`.

```javascript
const kolejkaDoKasy = ['Klient Jan', 'Klientka Anna', 'Klient Piotr'];

// Obsługujemy pierwszą osobę w kolejce
const obsluzonyKlient = kolejkaDoKasy.shift();

console.log(obsluzonyKlient); 
// Wypis: 'Klient Jan'

console.log(kolejkaDoKasy[0]); 
// Wypis: 'Klientka Anna' (stała się nowym pierwszym elementem)
```

> **Po co to jest:**  
> Metoda `shift()` jest fundamentem obsługi kolejek: pierwsze zadanie, które wpłynęło do systemu, jest pobierane do realizacji jako pierwsze.
>
> **Typowa pomyłka:**  
> Mylenie nazw `shift` i `unshift`. Pomocna mnemotechnika: słowo krótsze (`shift`) skraca tablicę (usuwa element z początku), a słowo dłuższe (`unshift`) wydłuża tablicę (dodaje element na początek).

---

## 4. Zestawienie metod mutujących końce tablicy

Poniższa tabela stanowi kluczowe podsumowanie mechaniki czterech podstawowych metod mutujących:

| Metoda | Miejsce operacji | Wpływ na rozmiar tablicy | Co zwraca metoda? | Przesunięcie indeksów pozostałych? |
|:-------|:-----------------|:-------------------------|:------------------|:------------------------------------|
| `push(x)` | Koniec tablicy | Zwiększa o 1 | Nowa długość tablicy (`number`) | Nie |
| `pop()` | Koniec tablicy | Zmniejsza o 1 | Usunięty element (`any`) | Nie |
| `unshift(x)` | Początek tablicy | Zwiększa o 1 | Nowa długość tablicy (`number`) | Tak (w prawo, `+1`) |
| `shift()` | Początek tablicy | Zmniejsza o 1 | Usunięty element (`any`) | Tak (w lewo, `-1`) |

---

## 5. Klasyczne struktury danych: Stos (LIFO) vs Kolejka (FIFO)

Dzięki omówionym metodom możemy bez trudu zrealizować dwa elementarne modele przetwarzania danych w informatyce:

### 5.1. Stos — LIFO (*Last In, First Out*)
Zasada: *ostatni przybył, pierwszy obsłużony* (jak stos talerzy w restauracji — nowy kładziemy na wierzchu, czysty zdejmujemy z wierzchu).
- Dodawanie: `push()`
- Pobieranie: `pop()`

```javascript
const stosHistoriiPrzegladarki = [];
stosHistoriiPrzegladarki.push('strona-glowna.html');
stosHistoriiPrzegladarki.push('katalog-produktow.html');
stosHistoriiPrzegladarki.push('szczegoly-laptopa.html');

// Użytkownik klika przycisk "Wstecz"
const poprzedniaStrona = stosHistoriiPrzegladarki.pop();
console.log(`Opuszczono: ${poprzedniaStrona}`); // Wypis: 'szczegoly-laptopa.html'
```

### 5.2. Kolejka — FIFO (*First In, First Out*)
Zasada: *pierwszy przybył, pierwszy obsłużony* (jak kolejka do lekarza lub w urzędzie — nowi petenci stają na końcu, obsługiwana jest osoba z początku).
- Dodawanie: `push()`
- Pobieranie: `shift()`

```javascript
const buforWydruku = [];
buforWydruku.push('Faktura_VAT.pdf');
buforWydruku.push('Zdjecie_legitymacyjne.png');
buforWydruku.push('Umowa_zlecenie.docx');

// Drukarka pobiera pierwsze zadanie z bufora
const doDruku = buforWydruku.shift();
console.log(`Drukuję: ${doDruku}`); // Wypis: 'Faktura_VAT.pdf'
```

---

## 6. Formatowanie i konwersja tablicy: metoda join()

### 6.1. Działanie metody join()

Metoda `join()` łączy wszystkie elementy tablicy w jeden łańcuch znaków (`string`), umieszczając pomiędzy nimi wskazany separator.
Jeśli nie podamy separatora, domyślnym łącznikiem jest przecinek `,`.

```javascript
const etapyZlecenia = ['Przyjęte', 'Weryfikacja techniczna', 'Naprawa', 'Gotowe do odbioru'];

// Łączenie za pomocą myślnika ze spacjami
const sciezka = etapyZlecenia.join(' -> ');
console.log(sciezka);
// Wypis: "Przyjęte -> Weryfikacja techniczna -> Naprawa -> Gotowe do odbioru"

// Łączenie z separatorem nowej linii \n
const listaPionowa = etapyZlecenia.join('\n');
console.log(listaPionowa);

// Łączenie z separatorem przecinka i spacji
const listaPoPrzecinku = etapyZlecenia.join(', ');
console.log(listaPoPrzecinku);
```

> **Po co to jest:**  
> Metoda `join()` służy do estetycznej prezentacji danych użytkownikowi oraz generowania formatów wymiany danych (np. plików CSV rozdzielanych średnikami `;`). Zamienia tablicę obiektów/napisów w gotowy, czytelny tekst bez konieczności ręcznego pisania pętli i pilnowania, by nie postawić przecinka za ostatnim elementem.
>
> **Typowa pomyłka:**  
> Oczekiwanie, że `join()` zmieni tablicę w miejscu. Wywołanie `tablica.join(' - ');` nie modyfikuje oryginalnej tablicy! Metoda `join()` **nie mutuje** tablicy źródłowej — tworzy i zwraca zupełnie nowy łańcuch znaków, który należy zapisać do zmiennej lub bezpośrednio przypisać do elementu `#wynik`.

---

### 6.2. Duet: split() i join()

W module T07 poznaliśmy metodę `split()`, która rozbija napis na tablicę fragmentów. Metoda `join()` jest jej dokładnym odwrotnym dopełnieniem:

$$\text{Napis} \xrightarrow{\quad \text{split(separator)} \quad} \text{Tablica} \xrightarrow{\quad \text{join(nowySeparator)} \quad} \text{Nowy Napis}$$

```javascript
const tagiWejsciowe = "javascript,frontend,programowanie,kurs";

// Rozbicie na tablicę
const tablicaTagow = tagiWejsciowe.split(',');

// Dodanie nowego tagu na koniec
tablicaTagow.push('inf03');

// Ponowne złączenie w elegancki ciąg z separatorem " | "
const wynikowyNapis = tablicaTagow.join(' | ');
console.log(wynikowyNapis);
// Wypis: "javascript | frontend | programowanie | kurs | inf03"
```

---

## 7. Wypis danych w Semestrze 2: standard document.getElementById("wynik").textContent

Zgodnie z wymaganiami semestru 2 kwalifikacji INF.03, wszystkie wyniki ćwiczeń prezentujemy w dedykowanym kontenerze `#wynik`:

```javascript
const wynikElement = document.getElementById("wynik");
wynikElement.textContent = `Raport zleceń:\n${listaZlecen.join('\n')}`;
```

Aby znaki nowej linii `\n` oraz wielokrotne spacje były prawidłowo renderowane w przeglądarce, kontener `#wynik` w stylach CSS posiada regułę:

```css
#wynik {
    white-space: pre-wrap;
    font-family: monospace;
}
```

Dzięki temu tekst sformatowany za pomocą `join('\n')` zachowuje estetyczny, tabelaryczny układ w oknie przeglądarki.

---

## 8. Kontrakt raportu w zadaniach T12

W ćwiczeniach laboratoryjnych i na sprawdzianie wynik nie jest dowolnym tekstem — każda `instrukcja.md` zawiera sekcję **Wzorzec raportu w `#wynik`** z dokładnym układem linii.

Praktyczna kolejność pracy:
1. Zaimplementuj operacje na tablicy (`push` / `pop` / `shift` / `unshift` / `join`).
2. Złóż raport z etykiet podanych w instrukcji oraz wartości zmiennych (usunięty element, wynik `join`, `tablica.length`).
3. Porównaj wynik na ekranie z wzorcem — kolejność wierszy i brzmienie etykiet muszą się zgadzać.

Jeśli zadanie wymaga numeracji pozycji (np. `[Partia nr 1] ...`), użyj pętli `for`. Metoda `join('\n')` łączy elementy wierszami, ale **nie dodaje numerów**.
