# Teoria: Synteza wiedzy — Funkcje, Obiekt Math i Obiekt String

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

**Kwalifikacja:** INF.03 · **Przedmiot:** Programowanie aplikacji internetowych (PAI) · **Semestr:** 2  
**Zakres powtórki (↻):** `PAI · Semestr 2 · T08 · ↻ Powtórka funkcje + Math + String (01–03)`

---

## 1. Architektura wejścia i wyjścia danych w Semestrze 2

W drugim semestrze nauki programowania w języku JavaScript przechodzimy od prostego dopisywania tekstu do dokumentu (`document.write`) do precyzyjnego zarządzania dedykowanymi elementami interfejsu użytkownika.

### 1.1. Bezpieczny wypis danych przez `textContent`

Wzorcem obowiązującym w całym semestrze jest kierowanie wyników działania programu do wyznaczonego elementu o identyfikatorze `wynik`:

```javascript
const elementWyniku = document.getElementById("wynik");
elementWyniku.textContent = `Wynik kalkulacji: ${kwotaKoncowa} zł\nStatus: Zrealizowano`;
console.log("Informacja diagnostyczna w konsoli dewelopera:", kwotaKoncowa);
```

Dlaczego stosujemy właściwość `.textContent`, a nie `.innerHTML`?
1. **Bezpieczeństwo (ochrona przed atakami XSS):** Właściwość `textContent` traktuje przypisany ciąg znaków wyłącznie jako surowy tekst. Jeżeli w tekście pojawią się znaki specjalne, takie jak `<` lub `>`, przeglądarka wyświetli je dosłownie, zamiast interpretować je jako znaczniki języka HTML czy potencjalnie złośliwe skrypty.
2. **Zachowanie formatowania i łamania wierszy:** Aby znaki nowej linii (`\n`) oraz wielokrotne spacje były widoczne na stronie WWW w elemencie blokowym (np. w znaczniku `<div>`), w arkuszu stylów CSS definiujemy regułę `white-space: pre-wrap;`. Dzięki temu tekst zachowuje czytelny układ tabelaryczny bez konieczności wstrzykiwania znaczników `<br>`.

```css
#wynik {
    white-space: pre-wrap;
    font-family: monospace;
    background-color: #f4f6f8;
    padding: 12px;
    border-radius: 6px;
}
```

- **Po co to jest:** Właściwość `.textContent` gwarantuje całkowicie bezpieczne przekazywanie danych tekstowych i liczbowych do interfejsu strony bez ryzyka naruszenia struktury drzewa DOM.
- **Typowa pomyłka:** Próba wstawienia znacznika `<br>` do `textContent`. Skutkuje to dosłownym wyświetleniem tekstu `"<br>"` na ekranie zamiast przejścia do nowego wiersza. W `textContent` nowy wiersz uzyskujemy wyłącznie za pomocą literału znaku nowej linii `\n`.

---

### 1.2. Dialog `prompt()` jako wejście danych poza ciałem funkcji

Jeżeli zadanie wymaga interaktywnego pobrania danych od użytkownika w trakcie ładowania strony, korzystamy z wbudowanej funkcji `prompt()`:

```javascript
// Pobranie danych w kodzie głównym programu
const surowaWartosc = prompt("Podaj promień koła w centymetrach:", "10");
const promien = Number(surowaWartosc);

// Wywołanie czystej funkcji logicznej z pobranym argumentem
const pole = obliczPoleKola(promien);
document.getElementById("wynik").textContent = `Pole koła: ${pole.toFixed(2)} cm²`;
```

> **Ważna uwaga metodyczna:** Funkcja `prompt()` jest funkcją wstrzymującą (*blocking call*). Oznacza to, że w momencie wyświetlenia okna dialogowego przeglądarka całkowicie zamraża jednowątkowy cykl przetwarzania skryptu, czekając na reakcję użytkownika. Z tego względu:
> 1. Wymagane jest podanie drugiego argumentu funkcji `prompt("komunikat", "wartośćDomyślna")`, co zapobiega zablokowaniu testów automatycznych.
> 2. `prompt()` wywołujemy **wyłącznie w głównym wątku programu**, nigdy wewnątrz ciał funkcji logicznych. Funkcje powinny być niezależne od środowiska wejścia/wyjścia i przyjmować dane przez parametry.

- **Po co to jest:** Wartość domyślna w `prompt()` ułatwia szybkie testowanie programu bez konieczności każdorazowego ręcznego wpisywania danych przez użytkownika.
- **Typowa pomyłka:** Umieszczenie instrukcji `prompt()` wewnątrz funkcji obliczeniowej. Taka funkcja traci swoją uniwersalność, staje się trudna do przetestowania i łamie regułę separacji logiki od interfejsu.

---

### 1.3. Zewnętrzny plik danych `dane.js` jako wejście danych (model CKE)

W zadaniach powtórzeniowych oraz na egzaminie praktycznym dane wejściowe często nie pochodzą z okna `prompt()`, lecz dostarczane są w osobnym pliku `dane.js` (np. zestaw transakcji CSV, logi serwera, pozycje zamówień).

W kodzie `index.html` plik z danymi wczytywany jest **przed** skryptem z rozwiązaniem:
```html
<script src="dane.js"></script>
<script src="script.js"></script>
```

**Zasada działania w przeglądarce:**
1. Stałe zadeklarowane w `dane.js` (np. `const DANE_CSV_ZAMOWIENIE = "...";`) trafiają do przestrzeni globalnej.
2. W pliku `script.js` odwołujesz się do nich bezpośrednio:
   ```javascript
   const raport = analizujZamowienie(DANE_CSV_ZAMOWIENIE);
   ```
3. Zgodnie ze standardem INF.03 dla plików uruchamianych z dysku (`file:///`) nie stosujemy modułów ES (`import`/`export`), które byłyby blokowane przez mechanizm CORS.

- **Po co to jest:** Zapewnia separację danych od algorytmu i pozwala na testowanie skryptu z różnymi danymi bez modyfikowania kodu implementacji.
- **Typowa pomyłka:** Próba ponownego deklarowania tej samej stałej w `script.js` (`const DANE_... = ...`), co wywołuje błąd `SyntaxError: Identifier has already been declared`.

---

## 2. Funkcje: Deklaracje, Strzałki i Zarządzanie Zasięgiem

Funkcje są podstawowym budulcem modularnego kodu. W zadaniach kwalifikacji INF.03 stosujemy dwa równorzędne sposoby zapisu funkcji.

### 2.1. Deklaracja tradycyjna a funkcja strzałkowa

```javascript
// 1. Tradycyjna deklaracja funkcji (Function Declaration)
function obliczBrutto(netto, stawkaVat = 0.23) {
    const brutto = netto * (1 + stawkaVat);
    return Math.round(brutto * 100) / 100;
}

// 2. Równoważna funkcja strzałkowa (Arrow Function)
const obliczBruttoStrzalkowa = (netto, stawkaVat = 0.23) => {
    const brutto = netto * (1 + stawkaVat);
    return Math.round(brutto * 100) / 100;
};

// 3. Skrócony zapis funkcji strzałkowej z niejawnym return (Implicit Return)
const przeliczNaGrosze = (zlote) => Math.round(zlote * 100);
```

- **Po co to jest:** Funkcje strzałkowe oferują zwięzłą składnię, eliminują konieczność pisania słowa kluczowego `function` oraz pozwalają na jednolinijkowy zapis prostych transformacji obliczeniowych.
- **Typowa pomyłka:** Zastosowanie nawiasów klamrowych `{}` w jednolinijkowej funkcji strzałkowej przy jednoczesnym pominięciu słowa kluczowego `return` (np. `const podwoj = (x) => { x * 2 };`). Taka funkcja zwróci wartość `undefined`.

---

### 2.2. Zasięg zmiennych i zjawisko przesłaniania (*Shadowing*)

Zmienne zadeklarowane za pomocą słów kluczowych `let` oraz `const` posiadają zasięg blokowy — istnieją wyłącznie wewnątrz pary nawiasów klamrowych `{ ... }`, w których zostały zdefiniowane.

```javascript
const progRabatowy = 100; // Zasięg globalny modułu

function naliczRabat(kwota) {
    // Zmienna lokalna przesłaniająca (shadowing) — niezalecana praktyka
    const progRabatowy = 50; 
    
    if (kwota > progRabatowy) {
        const wartoscRabatu = kwota * 0.10; // Zasięg blokowy instrukcji if
        return kwota - wartoscRabatu;
    }
    return kwota;
}
```

- **Po co to jest:** Zasięg blokowy chroni przed przypadkowym nadpisaniem wartości zmiennych w innych częściach programu, co znacząco zmniejsza liczbę trudnych do wykrycia błędów.
- **Typowa pomyłka:** Definiowanie parametru funkcji lub zmiennej lokalnej o takiej samej nazwie jak stała globalna. Choć silnik języka JavaScript na to zezwala, prowadzi to do zamieszania metodycznego i błędów logicznych w obliczeniach.

---

## 3. Obiekt `Math`: Obliczenia Numeryczne i Losowość

Obiekt `Math` jest statycznym obiektem wbudowanym w środowisko języka JavaScript. Oznacza to, że nie tworzymy jego instancji operatorem `new`, lecz bezpośrednio wywołujemy jego właściwości i metody.

### 3.1. Metody zaokrąglania liczb

```javascript
const liczba = 7.65;

Math.floor(liczba); // 7  - zaokrąglenie w dół do najbliższej liczby całkowitej
Math.ceil(liczba);  // 8  - zaokrąglenie w górę do najbliższej liczby całkowitej
Math.round(liczba); // 8  - zaokrąglenie do najbliższej liczby całkowitej (od .5 w górę)
Math.trunc(liczba); // 7  - odcięcie części ułamkowej (porzucenie cyfr po przecinku)
```

W przypadku liczb ujemnych uwidacznia się różnica między `Math.floor()` a `Math.trunc()`:
- `Math.floor(-4.2)` zwraca `-5` (ponieważ `-5` leży niżej na osi liczbowej niż `-4.2`).
- `Math.trunc(-4.2)` zwraca `-4` (odrzuca część po przecinku w kierunku zera).

- **Po co to jest:** Precyzyjne sterowanie zaokrągleniami jest niezbędne w kalkulacjach magazynowych (np. liczba pełnych paczek przez `Math.floor`) oraz przy wyliczaniu zapotrzebowania (np. liczba potrzebnych kartonów przez `Math.ceil`).
- **Typowa pomyłka:** Mylenie `Math.round()` z `toFixed()`. Metoda `toFixed(2)` zwraca wartość typu tekstowego (`string`), podczas gdy metody obiektu `Math` zawsze zwracają wartość liczbową (`number`).

---

### 3.2. Operator reszty `%` oraz zaokrąglanie z precyzją dziesiętną

Operator `%` (reszta z dzielenia, *modulo*) zwraca to, co pozostaje po dzieleniu całkowitym:

```javascript
148 % 24; // 4  — 148 = 6 * 24 + 4, więc reszta wynosi 4
17 % 5;   // 2
```

Typowe połączenie w zadaniach magazynowych: `Math.floor(n / pojemnosc)` daje liczbę pełnych jednostek, a `n % pojemnosc` — liczbę sztuk luzem.

Metody `Math.ceil()`, `Math.floor()` i `Math.round()` działają na **liczbach całkowitych**. Aby zaokrąglić w górę do jednego miejsca po przecinku (np. zapotrzebowanie surowca 1.53 → 1.6), najpierw mnożymy przez 10, stosujemy `Math.ceil`, a potem dzielimy przez 10:

```javascript
const surowaMaka = 1.53;
const makaDoZakupu = Math.ceil(surowaMaka * 10) / 10; // 1.6

// Analogicznie: kwota do dwóch miejsc po przecinku (grosze)
const kwota = Math.round(83.456 * 100) / 100; // 83.46
```

Do **prezentacji** liczby jako tekstu z ustaloną liczbą miejsc po przecinku służy `toFixed(n)` (zwraca `string`). Do **obliczeń** pozostajemy przy typie `number` i wzorach z `Math.round` / `Math.ceil`.

- **Po co to jest:** Operator `%` rozstrzyga resztę przy podziale na paczki, palety czy kartony. Wzorzec `Math.ceil(x * 10) / 10` pozwala zaokrąglać w górę z dokładnością do 0.1 bez zgadywania.
- **Typowa pomyłka:** Wywołanie samego `Math.ceil(1.53)`, które daje `2` zamiast `1.6`. Przy precyzji dziesiętnej zawsze skalujemy wartość przed zaokrągleniem.

---

### 3.3. Uniwersalny wzór na losowanie liczb całkowitych

Metoda `Math.random()` generuje liczbę pseudolosową z przedziału lewostronnie domkniętego `[0, 1)`, czyli liczbę większą lub równą `0` i ściśle mniejszą od `1`.

Aby uzyskać losową liczbę całkowitą z przedziału domkniętego `[min, max]`, stosujemy sprawdzony wzór:

```javascript
function losujLiczbeCalkowita(min, max) {
    // Różnica (max - min + 1) określa liczbę możliwych wyników w przedziale
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Przykład: losowanie rzutu tradycyjną kostką do gry [1, 6]
const rzutKostka = losujLiczbeCalkowita(1, 6);
```

- **Po co to jest:** Wzór ten pozwala modelować symulacje losowe, wybierać losowe elementy z zestawów danych czy generować identyfikatory sesji w aplikacjach internetowych.
- **Typowa pomyłka:** Zastosowanie `Math.round(Math.random() * (max - min)) + min`. Taki zapis powoduje, że wartości skrajne (`min` oraz `max`) mają dwukrotnie mniejsze prawdopodobieństwo wylosowania niż liczby ze środka zakresu. Prawidłowy rozkład jednostajny zapewnia wyłącznie `Math.floor()`.

---

## 4. Obiekt `String`: Przetwarzanie i Analiza Napisów

Napisy w języku JavaScript są wartościami prymitywnymi i charakteryzują się **niezmiennością** (*immutability*). Oznacza to, że żadna metoda obiektu `String` nie modyfikuje oryginalnego łańcucha znaków w miejscu, lecz zawsze zwraca nowy łańcuch z wynikiem operacji.

> **Pojęcie wrappera (opakowania obiektowego):** Gdy wywołujemy metodę na prymitywnym napisie (np. `"warsztat".toUpperCase()`), silnik JavaScript tymczasowo tworzy w tle obiekt opakowujący (*wrapper*), wykonuje żądaną metodę, po czym natychmiast usuwa ten obiekt z pamięci.

### 4.1. Podstawowe operacje: Długość, wielkość liter i oczyszczanie tekstu

```javascript
const wejscie = "   Jan Kowalski   ";

// Usunięcie zbędnych spacji z początku i końca
const oczyszczony = wejscie.trim(); // "Jan Kowalski"
const dlugosc = oczyszczony.length;  // 12 znaków

// Normalizacja wielkości liter
const wielkie = oczyszczony.toUpperCase(); // "JAN KOWALSKI"
const male = oczyszczony.toLowerCase();    // "jan kowalski"

// Dostęp do pojedynczych znaków
const pierwszyZnak = oczyszczony[0];       // "J"
const ostatniZnak = oczyszczony.charAt(oczyszczony.length - 1); // "i"
```

- **Po co to jest:** Metoda `trim()` wraz z `toLowerCase()` jest fundamentalnym krokiem przygotowania danych wejściowych od użytkownika przed ich dalszą walidacją lub porównaniem.
- **Typowa pomyłka:** Oczekiwanie, że wywołanie `wejscie.trim()` zmieni wartość zmiennej `wejscie`. Wynik metody należy zawsze przypisać do nowej zmiennej lub nadpisać istniejącą (`tekst = tekst.trim()`).

---

### 4.2. Wyszukiwanie i sprawdzanie fragmentów

```javascript
const email = "klient.biuro@firma.pl";

// Sprawdzanie obecności podłańcucha
const maMape = email.includes("@");           // true
const czyPl = email.endsWith(".pl");          // true
const czyKlient = email.startsWith("klient"); // true

// Wyznaczanie pozycji znaku
const pozycjaMalpy = email.indexOf("@");      // 12 (indeks znaku @)
const brakujacy = email.indexOf("#");         // -1 (brak znaku w tekście)
```

- **Po co to jest:** Metody `includes`, `startsWith` oraz `endsWith` eliminują konieczność stosowania skomplikowanych pętli i pozwalają na błyskawiczne weryfikowanie formatu danych.
- **Typowa pomyłka:** Zapominanie, że `indexOf()` zwraca `-1`, gdy szukany łańcuch nie istnieje. Błędny warunek `if (email.indexOf("@"))` zadziała niepoprawnie, ponieważ `-1` jest wartością prawdziwą (*truthy*), a `0` (znak na początku) wartością fałszywą (*falsy*). Prawidłowy warunek to `if (email.indexOf("@") !== -1)`.

---

### 4.3. Wycinanie i zastępowanie fragmentów tekstu

```javascript
const kodTowaru = "PRD-98432-PL";

// Wycinanie metodą slice(poczatek, koniecWykluczony)
const prefiks = kodTowaru.slice(0, 3); // "PRD"
const numer = kodTowaru.slice(4, 9);   // "98432"
const kraj = kodTowaru.slice(-2);      // "PL" (indeks ujemny liczy od końca)

// Zamiana fragmentów tekstu
const zanonimizowany = kodTowaru.replace("98432", "*****"); // "PRD-*****-PL"
const sciezka = "kat/podkat/plik".replaceAll("/", "\\");    // "kat\podkat\plik"
```

- **Po co to jest:** Metoda `slice()` pozwala na bezpieczne wydzielanie segmentów identyfikatorów, numerów PESEL czy kodów pocztowych.
- **Typowa pomyłka:** Mylenie drugiego argumentu `slice(start, end)` z długością wycinanego fragmentu. Drugi argument to indeks, na którym wycinanie się kończy (znak pod tym indeksem nie wchodzi do wyniku).

---

### 4.4. Tokenizacja za pomocą `split()` i ponowne łączenie przez `join()`

Metoda `split(separator)` rozbija łańcuch znaków na tablicę fragmentów (tokenów) według wskazanego rozdzielnika:

```javascript
const wpisCsv = "Kowalski;Jan;Programista;8500";
const elementy = wpisCsv.split(";"); // ["Kowalski", "Jan", "Programista", "8500"]

// Dostęp do wygenerowanych tokenów
const nazwisko = elementy[0];
const pensja = Number(elementy[3]);

// Iteracja po fragmentach za pomocą pętli for...of
let podsumowanie = "Dane pracownika:\n";
for (const element of elementy) {
    podsumowanie += ` - ${element}\n`;
}

// Ponowne złączenie fragmentów innym łącznikiem
const zunifikowany = elementy.join(" | "); // "Kowalski | Jan | Programista | 8500"
```

- **Po co to jest:** Metoda `split()` jest standardowym narzędziem do przetwarzania ciągów znaków reprezentujących linie plików CSV, listy adresów e-mail rozdzielanych przecinkami czy zdań dzielonych na pojedyncze wyrazy.
- **Typowa pomyłka:** Wywołanie `split("")` (z pustym separatorem), co dzieli tekst na pojedyncze litery, zamiast `split(" ")` (ze spacją), które dzieli tekst na całe słowa.

---

## 5. Zintegrowany Przykład Praktyczny

Poniższy przykład demonstruje połączenie wszystkich omawianych elementów w ramach jednego, zwartego modułu rozliczeniowego:

```javascript
// 1. Czysta funkcja strzałkowa normalizująca dane klienta
const normalizujIdentyfikator = (kod) => kod.trim().toUpperCase();

// 2. Funkcja logiczna kalkulująca rabat z wykorzystaniem metod Math
function wyliczRabat(kwota, typKlienta) {
    const bazaRabatu = typKlienta === "VIP" ? 0.15 : 0.05;
    const rabatZlotych = kwota * bazaRabatu;
    return Math.round(rabatZlotych * 100) / 100;
}

// 3. Funkcja przetwarzająca listę zamówień przekazaną w formacie tekstowym
function przetworzZamowieniaTekstowe(daneTekstowe) {
    const pozycje = daneTekstowe.split(";");
    let sumaCalkowita = 0;
    let raport = "RAPORT ROZLICZENIOWY:\n";

    for (const pozycja of pozycje) {
        const czystaPozycja = pozycja.trim();
        if (czystaPozycja.length === 0) continue;

        // Podział pozycji na nazwę i cenę
        const czesci = czystaPozycja.split(":");
        const nazwa = normalizujIdentyfikator(czesci[0]);
        const cena = Number(czesci[1]);

        if (!isNaN(cena) && cena > 0) {
            sumaCalkowita += cena;
            raport += ` Towar: ${nazwa.padEnd(12, " ")} | Kwota: ${cena.toFixed(2)} zł\n`;
        }
    }

    const rabat = wyliczRabat(sumaCalkowita, "VIP");
    const doZaplaty = Math.max(0, sumaCalkowita - rabat);

    raport += "----------------------------------------\n";
    raport += `Suma pozycji: ${sumaCalkowita.toFixed(2)} zł\n`;
    raport += `Naliczony rabat: ${rabat.toFixed(2)} zł\n`;
    raport += `Do zapłaty: ${doZaplaty.toFixed(2)} zł`;

    return raport;
}

// 4. Główny kod programu — bezpieczny wypis do interfejsu użytkownika
const daneWejsciowe = "  monitor: 800.50 ; klawiatura: 150 ; mysz: 75.99 ";
const wynikRaportu = przetworzZamowieniaTekstowe(daneWejsciowe);

document.getElementById("wynik").textContent = wynikRaportu;
console.log("Przetwarzanie zakończone sukcesem.");
```
