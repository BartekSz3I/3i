# Teoria — Obiekt Date: odczyt składowych w JavaScript

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

W aplikacjach internetowych niemal każdy system biznesowy przetwarza czas: sklepy rejestrują moment złożenia zamówienia, serwisy bankowe wystawiają potwierdzenia przelewów z dokładną godziną, a panele logistyczne wyznaczają planowane daty doręczenia przesyłek. W języku JavaScript do reprezentacji i odczytu punktów w czasie służy wbudowany obiekt `Date`.

---

## 1. Jak komputer widzi czas — istota obiektu `Date`

Dla człowieka data składa się z dni, miesięcy, lat, godzin i stref czasowych. Dla komputera czas to pojedyncza, nieustannie rosnąca liczba całkowita. 

JavaScript korzysta z uniwersalnego standardu znanego jako **czas uniksowy** (ang. *Unix Epoch*). Jest to liczba milisekund, które upłynęły od północy **1 stycznia 1970 roku według czasu uniwersalnego (UTC)**. Gdy tworzymy obiekt `Date`, środowisko pobiera z systemu operacyjnego bieżącą liczbę milisekund i hermetyzuje ją w wygodnym obiekcie, który udostępnia metody do odczytu czytelnych dla człowieka wartości.

### Tworzenie instancji za pomocą operatora `new`
Aby móc odczytywać składowe bieżącej daty, musimy utworzyć nową instancję obiektu za pomocą słowa kluczowego `new`:

```javascript
const teraz = new Date();
console.log(teraz);
```

Wywołanie `new Date()` bez żadnych argumentów powoduje "zamrożenie" bieżącego momentu w czasie systemowym w utworzonym obiekcie `teraz`.

**Po co to jest:**  
Utworzenie obiektu `Date` pozwala na wykonanie jednorazowego zrzutu aktualnego czasu systemowego, dzięki czemu wszystkie kolejne zapytania o rok, miesiąc czy sekundę odnoszą się dokładnie do tego samego, spójnego momentu.

**Typowa pomyłka:**  
Wywołanie `Date()` bez operatora `new` (np. `const x = Date();`). Bez słowa kluczowego `new` JavaScript nie tworzy obiektu `Date`, lecz zwraca zwykły łańcuch tekstowy (string) z opisem daty. Na takim łańcuchu próba wywołania metod odczytu, np. `x.getFullYear()`, zakończy się błędem wykonania `TypeError: x.getFullYear is not a function`.

---

## 2. Odczyt składowych daty kalendarzowej

Gdy posiadamy już utworzoną instancję obiektu `Date`, możemy odpytać ją o poszczególne parametry kalendarzowe. Do tego celu służą metody rozpoczynające się od przedrostka `get`.

### Metoda `getFullYear()` — pełny czterocyfrowy rok
Metoda `getFullYear()` zwraca pełny numer roku (np. `2026`).

```javascript
const data = new Date();
const rok = data.getFullYear();
console.log(`Bieżący rok: ${rok}`); // 2026
```

**Po co to jest:**  
Zapewnia jednoznaczną, czterocyfrową reprezentację roku, eliminując dwuznaczności przy zmianie stuleci.

**Typowa pomyłka:**  
Używanie archaicznej metody `getYear()`. Metoda `getYear()` pochodzi z wczesnych lat 90. XX wieku i zwraca liczbę lat, które upłynęły od roku 1900 (dla roku 2026 zwróci wartość `126`). Jest to metoda przestarzała, podatna na błędy i bezwzględnie zakazana w nowoczesnym standardzie języka.

---

### Metoda `getMonth()` — pułapka indeksowania miesięcy od zera
Metoda `getMonth()` zwraca liczbę reprezentującą miesiąc w roku, jednak w JavaScript miesiące są indeksowane **od zera**:
- `0` oznacza styczeń,
- `1` oznacza luty,
- `...`
- `11` oznacza grudzień.

Oznacza to, że jeśli bieżącym miesiącem jest październik, metoda `data.getMonth()` zwróci wartość `9`. Aby zaprezentować użytkownikowi naturalny, kalendarzowy numer miesiąca, musimy bezwzględnie dodać `1`:

```javascript
const data = new Date();
const indeksMiesiaca = data.getMonth();
const numerMiesiaca = indeksMiesiaca + 1; // Wartość 1 - 12
console.log(`Miesiąc kalendarzowy: ${numerMiesiaca}`);
```

**Po co to jest:**  
Indeksowanie od zera zostało zapożyczone z języka C oraz bibliotek uniksowych i jest bardzo wygodne dla programistów, ponieważ bezpośrednio odpowiada indeksom w tablicach z nazwami miesięcy.

**Typowa pomyłka:**  
Wypisanie wartości `data.getMonth()` wprost na ekranie lub w raporcie bez dodania jedynki. W rezultacie uczeń w marcu wyświetla użytkownikowi informację o "miesiącu 2", co wprowadza w błąd odbiorcę systemu.

---

### Metoda `getDate()` — dzień miesiąca
Metoda `getDate()` zwraca dzień miesiąca jako liczbę całkowitą z przedziału **od 1 do 31**.

```javascript
const data = new Date();
const dzienMiesiaca = data.getDate();
console.log(`Dzień miesiąca: ${dzienMiesiaca}`);
```

---

### Metoda `getDay()` — dzień tygodnia i pułapka niedzieli
Bardzo częstym błędem początkujących programistów jest mylenie metody `getDate()` z metodą `getDay()`.
- `getDate()` zwraca dzień miesiąca (1–31).
- `getDay()` zwraca **dzień tygodnia** jako liczbę od `0` do `6`.

Dodatkowo w standardzie międzynarodowym JavaScriptu pierwszym dniem tygodnia o indeksie `0` jest **niedziela**:
- `0` = Niedziela
- `1` = Poniedziałek
- `2` = Wtorek
- `3` = Środa
- `4` = Czwartek
- `5` = Piątek
- `6` = Sobota

```javascript
const data = new Date();
const dzienTygodnia = data.getDay();

if (dzienTygodnia === 0 || dzienTygodnia === 6) {
  console.log("Dzisiaj jest weekend!");
} else {
  console.log("Dzień roboczy.");
}
```

**Po co to jest:**  
Pozwala systemom informatycznym automatycznie weryfikować tryb pracy (np. naliczanie dodatku weekendowego za dyżur techniczny czy blokowanie wysyłki zamówień poza dniami roboczymi).

**Typowa pomyłka:**  
Zakładanie, że tydzień w JavaScript zaczyna się od poniedziałku (indeks 0). W takim błędnym założeniu programista sprawdza `data.getDay() === 0` myśląc, że bada poniedziałek, podczas gdy w rzeczywistości bada niedzielę.

---

## 3. Odczyt składowych czasu zegarowego

Podobnie jak w przypadku daty, instancja `Date` udostępnia metody do odczytu bieżącego czasu w strefie czasowej klienta:

| Metoda | Zakres zwracanych wartości | Opis składowej |
|---|:---:|---|
| `getHours()` | `0 – 23` | Godzina w trybie 24-godzinnym |
| `getMinutes()` | `0 – 59` | Minuty |
| `getSeconds()` | `0 – 59` | Sekundy |
| `getMilliseconds()` | `0 – 999` | Milisekundy (tysięczne części sekundy) |

Przykład odczytu czasu:

```javascript
const teraz = new Date();
const godzina = teraz.getHours();
const minuta = teraz.getMinutes();
const sekunda = teraz.getSeconds();

console.log(`Aktualny czas: ${godzina}:${minuta}:${sekunda}`);
```

Gdybyśmy jednak uruchomili powyższy kod o godzinie 8 rano i 5 minut po pełnej godzinie, otrzymalibyśmy napis `8:5:0`. W profesjonalnych systemach wymaga się formatu dwucyfrowego `08:05:00`.

---

## 4. Formatowanie składowych — dopełnianie zerem wiodącym (`padStart`)

> **Kontrakt w zadaniach:** stosuj `padStart` wyłącznie wtedy, gdy instrukcja wymaga formatu dwucyfrowego (`GG:MM`, `GG:MM:SS`, `RRRR-MM-DD`).  
> Gdy instrukcja podaje format `RRRR-M-D`, wypisuj `${rok}-${miesiac}-${dzien}` bez dopełniania (np. `2026-1-5`).

Aby zagwarantować, że jednocyfrowe wartości (np. dzień `7` czy minuta `3`) zostaną wyświetlone w estetycznym, standardowym formacie dwucyfrowym (`07`, `03`), stosujemy metodę `padStart()` dostępną na typie tekstowym `String`.

Metoda `padStart(docelowaDlugosc, znakWypelniajacy)` sprawdza długość napisu i jeśli jest ona mniejsza niż zadana, dopełnia początek ciągu wskazanym znakiem:

```javascript
const dzien = 7;
const sformatowanyDzien = String(dzien).padStart(2, "0");
console.log(sformatowanyDzien); // "07"
```

Zauważ, że przed wywołaniem metody `padStart()` musimy zamienić liczbę na ciąg tekstowy za pomocą `String(...)`, ponieważ `padStart()` jest metodą łańcuchów znaków, a nie liczb.

Złożenie pełnej daty i godziny w ustandaryzowany ciąg:

```javascript
const data = new Date();

const rok = data.getFullYear();
const miesiac = String(data.getMonth() + 1).padStart(2, "0");
const dzien = String(data.getDate()).padStart(2, "0");

const godzina = String(data.getHours()).padStart(2, "0");
const minuta = String(data.getMinutes()).padStart(2, "0");
const sekunda = String(data.getSeconds()).padStart(2, "0");

const pelnaData = `${rok}-${miesiac}-${dzien} ${godzina}:${minuta}:${sekunda}`;
console.log(`Raport wygenerowano: ${pelnaData}`);
```

**Po co to jest:**  
Wypisywanie dat w ustandaryzowanym formacie z zerami wiodącymi zapewnia czytelność interfejsu użytkownika, a także umożliwia prawidłowe sortowanie alfabetyczne ciągów tekstowych reprezentujących daty.

**Typowa pomyłka:**  
Próba wywołania `data.getDate().padStart(2, "0")` bezpośrednio na liczbie bez uprzedniej konwersji do typu `String`. Spowoduje to błąd `TypeError: data.getDate(...).padStart is not a function`.

---

## 5. Mapowanie wartości liczbowych na nazwy tekstowe (tablice lookup)

Często w aplikacjach zamiast numeru dnia tygodnia czy miesiąca chcemy zaprezentować użytkownikowi pełną nazwę w języku polskim (np. "Środa, 18 października"). Najczystszym i najbardziej eleganckim rozwiązaniem jest użycie pomocniczej tablicy słownikowej (tzw. *lookup table*).

### Tablica nazw dni tygodnia
Ponieważ `getDay()` zwraca wartości od `0` do `6`, układamy elementy tablicy dokładnie w tej samej kolejności:

```javascript
const nazwyDni = [
  "Niedziela",   // indeks 0
  "Poniedziałek",// indeks 1
  "Wtorek",      // indeks 2
  "Środa",       // indeks 3
  "Czwartek",    // indeks 4
  "Piątek",      // indeks 5
  "Sobota"       // indeks 6
];

const dzis = new Date();
const nazwaDnia = nazwyDni[dzis.getDay()];
console.log(`Dziś jest: ${nazwaDnia}`);
```

### Tablica nazw miesięcy
Podobnie postępujemy z miesiącami, pamiętając, że `getMonth()` zwraca indeksy `0–11`:

```javascript
const nazwyMiesiecy = [
  "stycznia",    // indeks 0
  "lutego",      // indeks 1
  "marca",       // indeks 2
  "kwietnia",    // indeks 3
  "maja",        // indeks 4
  "czerwca",     // indeks 5
  "lipca",       // indeks 6
  "sierpnia",    // indeks 7
  "września",    // indeks 8
  "października",// indeks 9
  "listopada",   // indeks 10
  "grudnia"      // indeks 11
];

const dzis = new Date();
const dzienMiesiaca = dzis.getDate();
const nazwaMiesiaca = nazwyMiesiecy[dzis.getMonth()];
const rok = dzis.getFullYear();

console.log(`Data uroczystości: ${dzienMiesiaca} ${nazwaMiesiaca} ${rok} roku`);
```

---

## 6. Standard wypisu danych w Semestrze 2

W semestrze 2 rygor programowy wymaga wypisywania wyników działania skryptu do dedykowanego elementu interfejsu za pomocą właściwości `textContent`:

```javascript
document.getElementById("wynik").textContent = komunikat;
```

W arkuszu stylów CSS kontener `#wynik` posiada regułę `white-space: pre-wrap;`, co oznacza, że znaki nowej linii `\n` w szablonach tekstowych (template literals z użyciem znaków backtick `` `...` ``) są renderowane bezpośrednio na ekranie jako nowe linie, bez potrzeby stosowania znaczników HTML.

Wypisywanie za pomocą `textContent` jest bezpieczne, chroni aplikację przed atakami typu Cross-Site Scripting (XSS) i uczy separacji danych od prezentacji wizualnej.
