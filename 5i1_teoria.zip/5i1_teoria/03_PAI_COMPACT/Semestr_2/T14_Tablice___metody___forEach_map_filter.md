# Teoria: Metody funkcyjne tablic w JavaScript (forEach, map, filter)

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

---

## 1. Wstęp do programowania deklaratywnego i pojęcie callbacku

Do tej pory iteracja po elementach tablicy opierała się głównie na podejściu **imperatywnym** — pisaliśmy pętlę `for (let i = 0; i < tab.length; i++)` lub `for (const element of tablica)`, precyzując każdy krok komputera: jak zainicjować licznik, jak sprawdzać warunek i jak przechodzić do kolejnego indeksu.

W nowoczesnym standardzie języka JavaScript powszechnie stosuje się podejście **deklaratywne (funkcyjne)**. Zamiast instruować silnik przeglądarki, jak krok po kroku zarządzać wskaźnikiem pętli, informujemy go, **co chcemy zrobić** z każdym elementem kolekcji. Do tego celu służą wbudowane metody prototypu tablicy (`Array.prototype`), które przyjmują jako argument tzw. **funkcję zwrotną (callback)**.

Funkcja zwrotna (callback) to funkcja przekazana do innej funkcji jako parametr, która zostanie wywołana automatycznie dla każdego kolejnego elementu przetwarzanej tablicy.

Callback może być zdefiniowany w postaci tradycyjnej funkcji anonimowej lub nowoczesnej funkcji strzałkowej (`arrow function`). W metodach tablicowych do callbacku przekazywane są standardowo 3 parametry:
1. `element` (lub skrótowo `el`) — bieżący element tablicy w danej iteracji,
2. `index` (lub `i`, parametr opcjonalny) — indeks numeryczny bieżącego elementu (od 0 do length - 1),
3. `array` (lub `arr`, parametr opcjonalny) — referencja do całej przetwarzanej tablicy źródłowej.

```javascript
// Tradycyjna funkcja anonimowa jako callback:
tablica.forEach(function(element, index) {
  console.log(`Element ${index}: ${element}`);
});

// Nowoczesna i zalecana funkcja strzałkowa jako callback:
tablica.forEach((element, index) => {
  console.log(`Element ${index}: ${element}`);
});
```

**Po co to jest:**  
Funkcje zwrotne pozwalają oddzielić sam proces wędrówki po tablicy (którym zarządza silnik JavaScript) od operacji biznesowej, jaką chcemy wykonać na każdym elemencie. Dzięki temu kod staje się krótszy, bardziej czytelny i wolny od typowych błędów pętli (np. przekroczenia zakresu indeksu `off-by-one`).

**Typowa pomyłka:**  
Wywoływanie funkcji zwrotnej w argumencie metody tablicowej zamiast jej przekazania. Zapis `tablica.forEach(mojaFunkcja())` wywołuje funkcję natychmiast i przekazuje jej wynik (często `undefined`), zamiast przekazać samą definicję funkcji `tablica.forEach(mojaFunkcja)`.

---

## 2. Metoda forEach() — iteracja i efekty uboczne

Metoda `Array.prototype.forEach()` służy do sekwencyjnego wykonania dostarczonej funkcji zwrotnej raz dla każdego elementu tablicy. Jest bezpośrednim funkcyjnym odpowiednikiem pętli `for...of`.

Kluczową cechą metody `forEach()` jest to, że **zawsze zwraca wartość `undefined`**. Metoda ta nie tworzy nowej tablicy ani nie modyfikuje automatycznie istniejącej — jej celem jest wywołanie **efektu ubocznego (side effect)**, takiego jak:
- wypisanie sformatowanego tekstu do bloku wynikowego na stronie lub w konsoli,
- zsumowanie wartości do zmiennej akumulującej zdefiniowanej poza pętlą,
- zaktualizowanie zewnętrznego stanu programu.

### Przykład użycia forEach:

```javascript
const cenyUslug = [120, 250, 80, 400];
let lacznyKoszt = 0;
let raportTekstowy = "Zestawienie pozycji kosztowych:\n";

cenyUslug.forEach((cena, index) => {
  lacznyKoszt += cena;
  raportTekstowy += `Pozycja [${index + 1}]: ${cena} PLN\n`;
});

raportTekstowy += `Razem do zapłaty: ${lacznyKoszt} PLN`;
document.getElementById("wynik").textContent = raportTekstowy;
```

### Porównanie składni: strzałka vs słowo kluczowe function

Gdy ciało callbacku składa się z jednej instrukcji, funkcja strzałkowa zapewnia maksymalną czytelność:

```javascript
// Wariant A: funkcja strzałkowa
dane.forEach(el => console.log(el));

// Wariant B: tradycyjne słowo kluczowe function
dane.forEach(function(el) {
  console.log(el);
});
```

Warto pamiętać, że wewnątrz `forEach()` instrukcje `break` i `continue` nie działają! Jeśli w ciele callbacku użyjemy `return`, spowoduje to jedynie przedwczesne zakończenie bieżącego wywołania callbacku (działa to identycznie jak `continue` w tradycyjnej pętli), przechodząc do następnego elementu.

**Po co to jest:**  
Metoda `forEach` pozwala na czytelną iterację bez konieczności deklarowania i ręcznego inkrementowania zmiennej sterującej `i`. Znakomicie sprawdza się przy budowaniu raportów, rejestrowaniu zdarzeń w logach oraz agregacji danych.

**Typowa pomyłka:**  
Próba przypisania wyniku `forEach()` do zmiennej w oczekiwaniu nowej tablicy: `const nowaTablica = tablica.forEach(...)`. Zmienna `nowaTablica` otrzyma wartość `undefined`, ponieważ `forEach` niczego nie zwraca. Do tworzenia nowej tablicy służy wyłącznie metoda `map()`.

---

## 3. Metoda map() — transformacja 1:1 i niemutowalność

Metoda `Array.prototype.map()` tworzy i zwraca **nową tablicę**, której elementy są wynikiem wywołania funkcji zwrotnej dla każdego elementu tablicy źródłowej. 

Zasada działania `map()` opiera się na **transformacji 1:1**:
- Jeśli tablica źródłowa posiada 5 elementów, tablica wynikowa również będzie miała **dokładnie 5 elementów**.
- Oryginalna tablica **nie ulega zmianie (niemutowalność — immutability)**. Oryginał zachowuje swoje początkowe wartości, a wynik transformacji jest zapisywany w nowej tablicy.
- Wewnątrz callbacku instrukcja `return` jest **bezwzględnie obowiązkowa** — wartość zwrócona przez `return` staje się nowym elementem w tablicy wynikowej. Brak słowa `return` spowoduje, że nowa tablica wypełni się wartościami `undefined`.

### Przykład użycia map:

```javascript
const cenyNetto = [100, 200, 50, 320];
const STAWKA_VAT = 1.23;

// Transformacja kwot netto na brutto
const cenyBrutto = cenyNetto.map(cena => Math.round(cena * STAWKA_VAT));

console.log("Ceny netto (nienaruszone):", cenyNetto); // [100, 200, 50, 320]
console.log("Ceny brutto (nowa tablica):", cenyBrutto); // [123, 246, 62, 394]

// Transformacja tekstu na formatowane etykiety
const identyfikatory = [14, 98, 105];
const sformatowaneId = identyfikatory.map((id, index) => `ZLEC-${id.toString().padStart(4, "0")}`);
console.log(sformatowaneId); // ["ZLEC-0014", "ZLEC-0098", "ZLEC-0105"]
```

### Zwięzłość funkcji strzałkowej z niejawnym return (implicit return)

Gdy funkcja strzałkowa nie zawiera klamer `{ ... }`, wyrażenie po strzałce jest automatycznie zwracane:

```javascript
// Niejawny return (implicit):
const kwadraty = [1, 2, 3, 4].map(x => x * x); // [1, 4, 9, 16]

// Równoważny zapis z klamrami i jawnym return (explicit):
const kwadratyJawne = [1, 2, 3, 4].map(x => {
  return x * x;
});
```

**Po co to jest:**  
Metoda `map` pozwala przekształcić dowolny zestaw danych w inną postać (np. liczby na kwoty sformatowane z walutą, kody błędów na czytelne komunikaty, identyfikatory na kody kreskowe) w sposób bezpieczny, bez ryzyka przypadkowego zniszczenia danych wejściowych.

**Typowa pomyłka:**  
Zapomnienie o słowie kluczowym `return` w bloku klamrowym funkcji strzałkowej:
`const wynik = tab.map(x => { x * 2 });` — tablica `wynik` będzie zawierać same `undefined`, ponieważ blok klamrowy `{}` wymaga jawnego `return x * 2;`.

---

## 4. Metoda filter() — selekcja danych i predykaty

Metoda `Array.prototype.filter()` tworzy i zwraca **nową tablicę** zawierającą wyłącznie te elementy tablicy źródłowej, które spełniają określony warunek logiczny.

Funkcja zwrotna przekazywana do `filter()` nosi nazwę **predykatu**. Predykat musi zwrócić wartość logiczną:
- `true` — bieżący element zostaje **dołączony** do nowej tablicy wynikowej,
- `false` (lub wartość falsy) — bieżący element zostaje **odrzucony** (pominięty).

Tablica wynikowa metody `filter()`:
- nigdy nie jest dłuższa niż tablica źródłowa (jej długość mieści się w przedziale od 0 do `length` tablicy źródłowej),
- jest całkowicie nową strukturą w pamięci (oryginalna tablica pozostaje nienaruszona),
- jeśli żaden element nie spełnia warunku, metoda zwraca pustą tablicę `[]` (nigdy `null` ani `undefined`).

### Przykład użycia filter:

```javascript
const rejestrPunktow = [45, 82, 19, 94, 60, 31, 75];

// Selekcja wyników zaliczających (minimum 50 punktów)
const zdane = rejestrPunktow.filter(punkty => punkty >= 50);
console.log("Wszystkie wyniki:", rejestrPunktow); // nienaruszone: [45, 82, 19, 94, 60, 31, 75]
console.log("Tylko zaliczone:", zdane);           // [82, 94, 60, 75]

// Filtrowanie z użyciem indeksu lub metod pomocniczych
const nazwyUslug = ["Wymiana dysku SSD", "Formatowanie", "Diagnostyka RAM", "Czyszczenie"];
const dlugieNazwy = nazwyUslug.filter(nazwa => nazwa.length > 12);
console.log(dlugieNazwy); // ["Wymiana dysku SSD", "Diagnostyka RAM"]

// Filtrowanie i mapowanie tablicy obiektów (wzorzec z plików dane.js)
const zlecenia = [
  { id: "Z-1", status: "pilne", kwota: 450 },
  { id: "Z-2", status: "zwykle", kwota: 120 },
  { id: "Z-3", status: "pilne", kwota: 890 }
];
const pilne = zlecenia.filter(z => z.status === "pilne");
const etykiety = pilne.map(z => `${z.id}: ${z.kwota} PLN`);
console.log(etykiety); // ["Z-1: 450 PLN", "Z-3: 890 PLN"]
```

**Po co to jest:**  
Metoda `filter` eliminuje potrzebę ręcznego tworzenia pustej tablicy pomocniczej, pisania pętli `for` oraz instrukcji warunkowej `if (warunek) nowaTablica.push(element)`. Cała ta procedura zostaje zastąpiona jedną deklaratywną linią kodu.

**Typowa pomyłka:**  
Mylenie roli `filter()` i `map()`. Próba użycia `filter()` do modyfikacji wartości elementów (np. `tab.filter(x => x * 2)`) nie zmieni liczb, lecz potraktuje wynik `x * 2` jako wartość prawdomówną (`truthy`), zwracając nienaruszone elementy! Podobnie próba użycia `map()` do usuwania elementów (np. `tab.map(x => { if (x > 10) return x; })`) nie skróci tablicy, lecz wstawi `undefined` w miejsca odrzuconych elementów.

---

## 5. Łączenie metod w potoki (Method Chaining)

Jedną z największych zalet metod funkcyjnych w JavaScript jest możliwość ich bezpośredniego łączenia w **łańcuchy wywołań (method chaining)**. Wynika to z faktu, że metody takie jak `filter()` oraz `map()` zwracają instancję tablicy (`Array`), na której natychmiast możemy wywołać kolejną metodę tablicową.

Standardowy schemat potoku danych w aplikacjach frontendowych wygląda następująco:
1. `filter()` — odsianie niepotrzebnych rekordów według zadanego kryterium,
2. `map()` — przetransformowanie przefiltrowanych rekordów do docelowego formatu lub przeliczenie wartości,
3. `join()` lub `forEach()` — scalenie elementów w czytelny napis lub wypisanie raportu.

### Przykład kompletnego potoku:

```javascript
const transakcjePLN = [450, 120, 890, 40, 650, 95];
const PROG_DUZEJ_TRANSAKCJI = 100;
const PROWIZJA = 1.05; // doliczamy 5% opłaty manipulacyjnej

// Potok: wybierz transakcje powyżej progu -> dolicz prowizję i zaokrąglij -> sformatuj do tekstu
const raport = transakcjePLN
  .filter(kwota => kwota >= PROG_DUZEJ_TRANSAKCJI)
  .map(kwota => Math.round(kwota * PROWIZJA))
  .map((kwota, i) => `${i + 1}. Kwota z prowizją: ${kwota} PLN`)
  .join("\n");

console.log(raport);
/*
Wynik:
1. Kwota z prowizją: 473 PLN
2. Kwota z prowizją: 126 PLN
3. Kwota z prowizją: 935 PLN
4. Kwota z prowizją: 683 PLN
*/
```

**Po co to jest:**  
Potoki danych eliminują konieczność tworzenia tymczasowych zmiennych pośrednich (`let temp1 = ...; let temp2 = ...;`). Kod czyta się z góry na dół jak logiczny opis procedury biznesowej: „weź transakcje, odfiltruj małe, przelicz prowizję, sformatuj raport”.

**Typowa pomyłka:**  
Próba wywołania `map()` lub `filter()` po metodzie, która nie zwraca tablicy! Na przykład:
`tab.forEach(...).map(...)` — spowoduje błąd `TypeError: Cannot read properties of undefined (reading 'map')`, ponieważ `forEach` zwraca `undefined`. Podobnie po `.join()` otrzymujemy string, więc dalsze metody muszą być metodami obiektów String, a nie Array.

---

## 6. Podsumowanie różnic i tabela decyzyjna

| Cecha | `forEach()` | `map()` | `filter()` |
| :--- | :--- | :--- | :--- |
| **Główny cel** | Wykonanie efektu ubocznego (wypis, sumowanie) | Przekształcenie danych każdego elementu | Wybór podzbioru elementów spełniających warunek |
| **Zwracana wartość** | `undefined` | Nowa tablica (`Array`) | Nowa tablica (`Array`) |
| **Długość wyniku** | Brak (brak tablicy) | Dokładnie taka sama jak oryginał (`length === length`) | Mniejsza lub równa oryginałowi (`0 <= length <= n`) |
| **Wpływ na oryginał** | Brak (chyba że celowo zmodyfikujemy `arr[i]`) | Niemutująca (brak wpływu) | Niemutująca (brak wpływu) |
| **Rola callbacku** | Instrukcja do wykonania | Zwraca nowy element (`return nowaWartosc`) | Zwraca decyzję logiczną (`return true/false`) |
| **Możliwość chainingu** | Nie (kończy łańcuch jako odbiornik) | Tak (zwraca nową tablicę) | Tak (zwraca nową tablicę) |

---

## 7. Wypis danych na stronę w Semestrze 2

Zgodnie z rygorem egzaminacyjnym drugiego semestru, wszystkie wyniki generowane przez skrypty JavaScript prezentujemy użytkownikowi za pomocą właściwości `textContent` elementu wyjściowego `#wynik`:

```javascript
document.getElementById("wynik").textContent = wygenerowanyTekst;
```

W pliku stylu `style.css` kontener `#wynik` posiada obowiązkową regułę:
```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
}
```

Dzięki właściwości `white-space: pre-wrap` wszelkie znaki nowej linii (`\n`), spacje oraz wcięcia generowane przy łączeniu tablic za pomocą `join("\n")` są odwzorowywane na ekranie w identyczny sposób, jak w konsoli tekstowej.
