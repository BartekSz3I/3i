# Teoria modułu T04: Obiekt Math — generowanie liczb losowych, skalowanie zakresów oraz wartości skrajne (min, max)

> ✦ **Materiały wspomagane AI** — treść działu powstała z udziałem narzędzi AI
> według programu i standardów INF.03; przed zajęciami weryfikuje ją nauczyciel.

W aplikacjach internetowych generowanie liczb pseudolosowych jest fundamentalnym mechanizmem wykorzystywanym w setkach scenariuszy: od symulacji biznesowych, kalkulatorów ubezpieczeniowych i rzutów kośćmi w grach, przez generowanie kodów rabatowych czy losowanie personelu do dyżurów, aż po tworzenie realistycznych danych testowych na potrzeby testowania interfejsu. Język JavaScript udostępnia wbudowany obiekt statyczny `Math`, który zawiera narzędzia do generowania wartości losowych oraz wyznaczania wartości skrajnych.

---

## 1. Natura metody `Math.random()` i rozkład prawdopodobieństwa

Metoda `Math.random()` jest funkcją bezparametrową, która po wywołaniu zwraca liczbę zmiennoprzecinkową (ułamek dziesiętny) pseudolosową z przedziału lewostronnie domkniętego i prawostronnie otwartego:

$$[0, 1) = \{ x \in \mathbb{R} : 0 \le x < 1 \}$$

Oznacza to, że funkcja ta:
- może zwrócić dokładnie `0.0`,
- zwraca wartości ułamkowe, na przykład `0.14728491...`, `0.738291...`, `0.999999...`,
- **nigdy nie zwróci dokładnie liczby `1.0`**.

```javascript
// Przykładowe wywołanie w konsoli przeglądarki
const losowyUlamek = Math.random();
console.log(losowyUlamek); // np. 0.6839123847291834
```

Liczby generowane przez `Math.random()` cechują się **rozkładem jednostajnym ciągłym** — każda wartość z tego przedziału ma dokładnie takie samo prawdopodobieństwo wylosowania.

> **Po co to jest:**
> Metoda `Math.random()` dostarcza surowy, uniwersalny fundament matematyczny w postaci ułamka bazowego z zakresu `[0, 1)`. Dzięki temu, że wynik mieści się w stałych granicach, programista może go łatwo przeskalować (mnożąc) i przesunąć (dodając) do dowolnego przedziału liczbowego wymaganego w danej dziedzinie biznesowej.

> **Typowa pomyłka:**
> Zakładanie, że `Math.random()` może wylosować liczbę `1`. W wielu algorytmach błąd ten prowadzi do błędnego obliczania indeksów lub nieoczekiwanego zaokrąglenia, gdy programista oczekuje, że losowanie wygeneruje pełną wartość krańcową bez odpowiedniej modyfikacji wzoru.

---

## 2. Wyprowadzenie wzoru na losowanie liczb całkowitych w przedziale `[min, max]`

W praktyce programistycznej rzadko potrzebujemy surowego ułamka z zakresu `[0, 1)`. Najczęściej celem jest wylosowanie liczby całkowitej z konkretnego, obustronnie domkniętego przedziału `[min, max]`, na przykład rzutu tradycyjną sześcienną kością do gry `[1, 6]`, losowania procentu rabatu `[5, 25]` czy numeru przydzielonego stanowiska `[100, 999]`.

Aby przekształcić przedział `[0, 1)` w przedział liczb całkowitych `[min, max]`, stosujemy proces trzystopniowy:

1. **Obliczenie liczby możliwych wyników całkowitych:**  
   Liczba liczb całkowitych w przedziale od `min` do `max` włącznie wynosi:
   $$\text{liczbaWynikow} = \max - \min + 1$$
   Dla rzutu kością od 1 do 6 mamy: $6 - 1 + 1 = 6$ wariantów (1, 2, 3, 4, 5, 6).

2. **Skalowanie zakresu za pomocą mnożenia:**  
   Mnożąc `Math.random()` przez $(\max - \min + 1)$, otrzymujemy liczbę zmiennoprzecinkową z przedziału:
   $$[0, \max - \min + 1)$$
   Dla kości do gry jest to przedział $[0, 6)$, czyli wartości od `0.0` do `5.999999...`.

3. **Obcięcie części ułamkowej za pomocą `Math.floor()`:**  
   Funkcja `Math.floor()` zaokrągla w dół do najbliższej liczby całkowitej (obcina część dziesiętną). Z przedziału $[0, 6)$ otrzymujemy równomiernie rozłożone liczby całkowite: $0, 1, 2, 3, 4, 5$.

4. **Przesunięcie początku przedziału przez dodanie `min`:**  
   Dodając do otrzymanej liczby wartość `min`, przesuwamy cały zbiór. Z wartości $0, 1, 2, 3, 4, 5$ po dodaniu $1$ otrzymujemy dokładnie zbiór: $1, 2, 3, 4, 5, 6$.

Oto pełny, uniwersalny wzór w języku JavaScript:

```javascript
// Uniwersalna formuła losowania liczby całkowitej w przedziale [min, max]
const losowaCalkowita = Math.floor(Math.random() * (max - min + 1)) + min;
```

### Dlaczego stosujemy `Math.floor()`, a nie `Math.round()`?

Jest to jedno z najważniejszych zagadnień egzaminacyjnych i inżynierskich:
- Jeśli użylibyśmy `Math.round(Math.random() * (max - min)) + min`, wartości skrajne `min` oraz `max` miałyby **dwukrotnie mniejsze prawdopodobieństwo wylosowania** niż wartości środkowe!
- Wynika to z faktu, że `Math.round()` zaokrągla do $0$ tylko liczby z przedziału $[0, 0.5)$ (długość przedziału $0.5$), podczas gdy do $1$ zaokrągla liczby z przedziału $[0.5, 1.5)$ (długość przedziału $1.0$).
- Natomiast `Math.floor()` dzieli całą przestrzeń losową na idealnie równe koszyki o długości $1.0$: $[0, 1) \to 0$, $[1, 2) \to 1$, $[2, 3) \to 2$ itd. Dzięki temu każdy wynik całkowity ma dokładnie identyczną szansę wystąpienia.

> **Po co to jest:**
> Zastosowanie `Math.floor()` gwarantuje zachowanie rozkładu jednostajnego dyskretnego — symulacje, losowania nagród i algorytmy obliczeniowe są w pełni sprawiedliwe, a każdy element z dozwolonego przedziału ma identyczne prawdopodobieństwo wylosowania.

> **Typowa pomyłka:**
> Zapisanie wzoru jako `Math.floor(Math.random() * max) + min`. W takim zapisie zakres jest przesunięty i nieprawidłowo zinterpretowany: maksymalna wartość może przekroczyć oczekiwany zakres lub liczba możliwych wariantów będzie mniejsza od faktycznej rozpiętości przedziału. Zawsze należy pamiętać o członie `(max - min + 1)`.

---

## 3. Losowanie liczb zmiennoprzecinkowych i formatowanie dokładności

Nie każde losowanie dotyczy sztuk czy liczb całkowitych. W systemach finansowych, magazynowych i laboratoryjnych zachodzi potrzeba wylosowania wartości ciągłej, na przykład wagi towaru (od 1.50 kg do 4.80 kg), kursu waluty lub temperatury w chłodni.

W takim przypadku:
1. Skalujemy ułamek losowy do różnicy przedziału: `Math.random() * (max - min)`.
2. Przesuwamy go o wartość początkową: `+ min`.
3. Do sformatowania liczby do określonej liczby miejsc po przecinku stosujemy metodę `.toFixed(miejsca)`.

```javascript
// Losowanie liczby zmiennoprzecinkowej z przedziału [min, max] z zaokrągleniem do 2 miejsc po przecinku
function losujWage(min, max) {
  const wartoscCiazgla = Math.random() * (max - min) + min;
  return wartoscCiazgla.toFixed(2); // Zwraca napis, np. "3.47"
}

const wagaPaczki = losujWage(1.5, 4.8);
console.log(`Wylosowana waga: ${wagaPaczki} kg`);
```

Należy pamiętać, że metoda `.toFixed()` zwraca wynik typu `string` (łańcuch tekstowy). Jeżeli na wylosowanej wartości chcemy wykonywać dalsze operacje matematyczne (np. sumowanie, porównywanie za pomocą operatorów relacyjnych), należy przekonwertować ją z powrotem na typ liczbowy za pomocą `parseFloat()` lub `Number()`:

```javascript
const cenaJednostkowa = parseFloat((Math.random() * (120 - 40) + 40).toFixed(2));
const wartoscBrutto = (cenaJednostkowa * 1.23).toFixed(2);
```

> **Po co to jest:**
> Metoda `.toFixed()` pozwala na eleganckie sformatowanie surowych ułamków o nieskończonej liczbie cyfr po przecinku (np. `2.4918237192837`) do formatu zgodnego z normami handlowymi i prezentacyjnymi na stronach WWW (np. `2.49 zł`).

> **Typowa pomyłka:**
> Wykonywanie dodawania arytmetycznego bezpośrednio na wyniku `.toFixed()`: np. `wartosc.toFixed(2) + 10`. Ponieważ `.toFixed()` zwraca napis, nastąpi konkatenacja tekstowa (np. `"2.4910"` zamiast `12.49`). Przed dodawaniem arytmetycznym zawsze należy dokonać jawnej konwersji przez `parseFloat()` lub `Number()`.

---

## 4. Wyznaczanie wartości skrajnych: `Math.min()` oraz `Math.max()`

Obiekt `Math` udostępnia dwie statyczne metody analityczne służące do szybkiego wyznaczania najmniejszej oraz największej wartości spośród przekazanych argumentów:

- `Math.min(w1, w2, ..., wN)` — zwraca najmniejszą wartość liczbową ze zbioru argumentów,
- `Math.max(w1, w2, ..., wN)` — zwraca największą wartość liczbową ze zbioru argumentów.

```javascript
const a = 12;
const b = 45;
const c = 28;

const najmniejsza = Math.min(a, b, c); // 12
const najwieksza = Math.max(a, b, c);   // 45
```

### Praktyczne zastosowania `Math.min()` i `Math.max()`

1. **Ograniczanie wartości do przedziału (tzw. clamping):**  
   Częstym zadaniem jest upewnienie się, że obliczona lub wylosowana wartość nie wykracza poza dozwolone widełki systemowe (np. rabat od 0% do 30%):
   ```javascript
   // Wartość nie może być mniejsza niż 0 ani większa niż 30
   const surowyRabat = 35;
   const bezpiecznyRabat = Math.min(Math.max(surowyRabat, 0), 30); // 30
   ```

2. **Analiza wielokrotnych losowań:**  
   Gdy w pętli generujemy serię prób losowych, `Math.min()` i `Math.max()` pozwalają w zwięzły sposób śledzić zaobserwowane minimum i maksimum bez konieczności rozbudowywania złożonych drabin `if / else`.

> **Po co to jest:**
> Metody `Math.min()` i `Math.max()` zastępują rozwlekłe warunki logiczne z operatorami `<` i `>`, czyniąc kod zwięzłym, wysoce czytelnym i mniej podatnym na błędy logiczne przy analizie wartości krańcowych.

> **Typowa pomyłka:**
> Wywołanie `Math.min()` lub `Math.max()` bez żadnych argumentów: `Math.min()` bez argumentów zwraca `Infinity`, natomiast `Math.max()` bez argumentów zwraca `-Infinity`. Ponadto, jeśli choć jeden z argumentów nie da się przekonwertować na liczbę (np. `undefined` lub tekst `"abc"`), obie metody zwrócą `NaN`.

---

## 5. Implementacja modularnych funkcji narzędziowych z parametrami i `return`

Zgodnie z wymaganiami nowoczesnego programowania oraz standardem Semestru 2, operacje losowania i kalkulacji zamykamy w dedykowanych funkcjach. Funkcje te:
- przyjmują parametry określające granice losowania lub dane wejściowe,
- wykonują czystą operację matematyczną,
- zwracają wynik za pomocą słowa kluczowego `return`,
- **nie manipulują bezpośrednio drzewem DOM ani nie wywołują dialogów wewnątrz swojego ciała**.

W module ćwiczymy zarówno klasyczną deklarację `function`, jak i zwięzłą składnię funkcji strzałkowych (Arrow Functions):

```javascript
// 1. Tradycyjna deklaracja funkcyjna
function generujKodMagazynowy(prefiks, minKod, maxKod) {
  const numer = Math.floor(Math.random() * (maxKod - minKod + 1)) + minKod;
  return `${prefiks}-${numer}`;
}

// 2. Funkcja strzałkowa ze skróconym ciałem
const obliczRozstep = (minimum, maksimum) => maksimum - minimum;

// 3. Funkcja strzałkowa z pełnym blokiem obliczeniowym
const losujStawkeGodzinowa = (minStawka, maxStawka) => {
  const stawka = Math.random() * (maxStawka - minStawka) + minStawka;
  return parseFloat(stawka.toFixed(2));
};
```

> **Po co to jest:**
> Rozdzielenie czystej logiki obliczeniowej od warstwy prezentacji (wypisu na ekran) to kardynalna zasada inżynierii oprogramowania. Funkcja zwracająca wartość przez `return` może być wielokrotnie wykorzystywana w różnych miejscach systemu, łatwo testowana i łączona z innymi procedurami.

> **Typowa pomyłka:**
> Umieszczanie instrukcji wypisu (np. `document.getElementById(...)` lub `console.log`) bezpośrednio wewnątrz ciała funkcji losującej zamiast zwrócenia wartości przez `return`. Ogranicza to wielokrotne użycie funkcji i utrudnia późniejsze przetwarzanie wylosowanej liczby.

---

## 6. Standard wypisu wyników w Semestrze 2

W Semestrze 2 wyjście danych na stronę WWW realizowane jest wyłącznie do dedykowanego kontenera o identyfikatorze `#wynik` przy użyciu właściwości `textContent`:

```javascript
// Pobranie referencji do kontenera wyjściowego
const kontenerWyniku = document.getElementById("wynik");

// Przygotowanie sformatowanego raportu wieloliniowego
let raport = "=== RAPORT SYMULACJI SYSTEMU ===\n";
raport += `Wylosowane zamówienie: #${generujKodMagazynowy("ZAM", 1000, 9999)}\n`;
raport += `Stawka robocza: ${losujStawkeGodzinowa(45.5, 95.0)} PLN/h\n`;

// Bezpieczny wypis tekstu do elementu HTML
kontenerWyniku.textContent = raport;

// Równoległy zapis diagnostyczny w konsoli przeglądarki
console.log(raport);
```

Aby znaki nowej linii `\n` były prawidłowo renderowane w przeglądarce, kontener wyjściowy w arkuszu `style.css` musi posiadać właściwość:
```css
#wynik {
  white-space: pre-wrap;
  font-family: monospace;
}
```

> **Po co to jest:**
> Właściwość `textContent` gwarantuje bezpieczeństwo przed atakami typu XSS (Cross-Site Scripting), w przeciwieństwie do `innerHTML`. W połączeniu z regułą CSS `white-space: pre-wrap` pozwala tworzyć czytelne, wielowierszowe raporty tekstowe przy zachowaniu pełnej kontroli nad układem danych.

> **Typowa pomyłka:**
> Używanie znaczników `<br>` wewnątrz tekstu przypisywanego do `textContent`. Ponieważ `textContent` traktuje cały ciąg jako czysty tekst, na stronie wyświetli się dosłownie napis `<br>` zamiast przejścia do nowej linii. Nową linię tworzymy wyłącznie za pomocą znaku modyfikatora `\n` przy włączonym `white-space: pre-wrap`.
