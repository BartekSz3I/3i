const button = document.querySelector('button');

const kostka = document.querySelector('.kostka');



function losowa_liczba(){
    return Math.floor(Math.random() * 6) + 1;
}

button.addEventListener('click', function(){

    kostka.replaceChildren();

    let ilosc_oczek = losowa_liczba();

    if (ilosc_oczek == 1){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '150px';

        kropka1.style.left = '150px';

        kostka.appendChild(kropka1);
    }

    if (ilosc_oczek == 2){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '20px';

        kropka1.style.left = '20px';

        const kropka2 = document.createElement('div');

        kropka2.classList.add('kropka');

        kropka2.style.position = 'absolute';

        kropka2.style.top = '280px';

        kropka2.style.left = '280px';

        kostka.appendChild(kropka1);

        kostka.appendChild(kropka2);
    }

    if (ilosc_oczek == 3){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '20px';

        kropka1.style.left = '20px';

        const kropka2 = document.createElement('div');

        kropka2.classList.add('kropka');

        kropka2.style.position = 'absolute';

        kropka2.style.top = '280px';

        kropka2.style.left = '280px';

        const kropka3 = document.createElement('div');

        kropka3.classList.add('kropka');

        kropka3.style.position = 'absolute';

        kropka3.style.top = '150px';

        kropka3.style.left = '150px';

        kostka.appendChild(kropka1);

        kostka.appendChild(kropka2);

        kostka.appendChild(kropka3);
    }

    if (ilosc_oczek == 4){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '20px';

        kropka1.style.left = '20px';

        const kropka2 = document.createElement('div');

        kropka2.classList.add('kropka');

        kropka2.style.position = 'absolute';

        kropka2.style.top = '20px';

        kropka2.style.left = '280px';

        const kropka3 = document.createElement('div');

        kropka3.classList.add('kropka');

        kropka3.style.position = 'absolute';

        kropka3.style.top = '280px';

        kropka3.style.left = '20px';

        const kropka4 = document.createElement('div');

        kropka4.classList.add('kropka');

        kropka4.style.position = 'absolute';

        kropka4.style.top = '280px';

        kropka4.style.left = '280px';

        kostka.appendChild(kropka1);

        kostka.appendChild(kropka2);

        kostka.appendChild(kropka3);

        kostka.appendChild(kropka4);
    }

    if (ilosc_oczek == 5){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '20px';

        kropka1.style.left = '20px';

        const kropka2 = document.createElement('div');

        kropka2.classList.add('kropka');

        kropka2.style.position = 'absolute';

        kropka2.style.top = '280px';

        kropka2.style.left = '280px';

        const kropka3 = document.createElement('div');

        kropka3.classList.add('kropka');

        kropka3.style.position = 'absolute';

        kropka3.style.top = '150px';

        kropka3.style.left = '150px';

        const kropka4 = document.createElement('div');

        kropka4.classList.add('kropka');

        kropka4.style.position = 'absolute';

        kropka4.style.top = '280px';

        kropka4.style.left = '20px';

        const kropka5 = document.createElement('div');

        kropka5.classList.add('kropka');

        kropka5.style.position = 'absolute';

        kropka5.style.top = '20px';

        kropka5.style.left = '280px';

        kostka.appendChild(kropka1);

        kostka.appendChild(kropka2);

        kostka.appendChild(kropka3);

        kostka.appendChild(kropka4);

        kostka.appendChild(kropka5);
    }

    if (ilosc_oczek == 6){
        const kropka1 = document.createElement('div');

        kropka1.classList.add('kropka');

        kropka1.style.position = 'absolute';

        kropka1.style.top = '20px';

        kropka1.style.left = '20px';

        const kropka2 = document.createElement('div');

        kropka2.classList.add('kropka');

        kropka2.style.position = 'absolute';

        kropka2.style.top = '20px';

        kropka2.style.left = '280px';

        const kropka3 = document.createElement('div');

        kropka3.classList.add('kropka');

        kropka3.style.position = 'absolute';

        kropka3.style.top = '280px';

        kropka3.style.left = '20px';

        const kropka4 = document.createElement('div');

        kropka4.classList.add('kropka');

        kropka4.style.position = 'absolute';

        kropka4.style.top = '280px';

        kropka4.style.left = '280px';

        const kropka5 = document.createElement('div');

        kropka5.classList.add('kropka');

        kropka5.style.position = 'absolute';

        kropka5.style.top = '150px';

        kropka5.style.left = '20px';

        const kropka6 = document.createElement('div');

        kropka6.classList.add('kropka');

        kropka6.style.position = 'absolute';

        kropka6.style.top = '150px';

        kropka6.style.left = '280px';

        kostka.appendChild(kropka1);

        kostka.appendChild(kropka2);

        kostka.appendChild(kropka3);

        kostka.appendChild(kropka4);

        kostka.appendChild(kropka5);

        kostka.appendChild(kropka6);
    }


})