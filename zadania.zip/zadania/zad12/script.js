const btn = document.querySelector('#convertBtn');
const results = document.querySelector('#results');

btn.addEventListener('click', function(){
    results.style.display ='block'
    results.style.color='#f00'
    results.style.backgroundColor="#ff0"
})